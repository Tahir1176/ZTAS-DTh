# Response to the Reviewer — revised manuscript (v4)

**Manuscript:** ZTAS-DTh: A Lifecycle-Spanning Zero-Trust Security Architecture for the Digital Thread—Design, Bounded Formal Analysis, and Simulation-Based Evaluation

We thank the reviewer for a detailed and demanding report. We treated each concern as a hypothesis to test, not a wording problem. The revision adds new experiments, a new formal model, new implementation tests, and a re-analysis of existing data. Several of the results are unfavourable to the architecture. They are reported in full, and the claims have been narrowed to match.

**About this version.** This letter covers both revision rounds.
- Each concern keeps the account of the work done in the previous round (v3).
- Each concern then adds a block headed **"Further work in this round (v4)"**.
- The v4 round re-audited the package and ran the experiments needed to close the gaps the audit found.
- It also shortened the manuscript from 18 to 17 pages. Six floats moved to the supplement, and the Discussion was condensed.
- Every number quoted is checked against the output files: `08_Final_Reports/number_check.py`, 182/182.

Section, table and figure numbers refer to the revised manuscript (`ZTAS_DTh_Revised_Manuscript.pdf`, v4); "Supp." refers to the Supplementary Material (`ZTAS_DTh_Supplementary_Material.pdf`). File paths refer to the revision package `ZTAS_DTh_Major_Revision_Research_v4/`.

---

## Concern 1 — Joint parameter robustness and conditional effectiveness

**Reviewer comment.** The central performance claim depends on the assumed effectiveness of several defensive mechanisms (exploit success, authorisation, monitoring, artifact-mediated share, provenance rejection, segment opening, step-up failure, evidence threshold, decay, approval delay). One-at-a-time variation is insufficient; a joint analysis is needed to establish when the advantage holds and when it diminishes.

**Response.** We agree. One-at-a-time sweeps cannot reveal interactions. We replaced them as the primary robustness evidence with a joint design.

**Actions taken.**
- **Parameter audit.** Every simulator parameter was classified as assumption, configuration or derived; none is measured.
- **Latin-hypercube sampling.** Eleven parameters were varied jointly: 400 points over the full ranges, plus 150 points in each of three explicitly defined defensive-control regimes (optimistic, moderate, adverse).
- **Evaluation units.** All five architectures were evaluated on 144 common evaluation units (9 families × 4 fresh graphs × 4 runs) with common random numbers, giving 612 000 simulations.
- **Sobol indices.** Computed on the reference topology (Saltelli N = 256, 3328 points), together with PRCC across all families.
- **Uncertainty.** A two-way cluster bootstrap over parameter points and graphs.
- **Vanishing advantage.** A decision tree locating where the advantage over ZT+provenance falls below 0.05.

**Evidence.**
- `01_Experiments/01_Joint_Sensitivity/` contains the experiment, configuration, analysis, executed notebook, results CSVs, figures and `JOINT_SENSITIVITY_REPORT.md`.
- Raw data: `02_Data/Raw/joint_sensitivity_*`.

**Findings.**
- ZTAS-DTh had a lower compromised fraction than ZT+provenance in 96.7% of point–topology cells and was lower by ≥ 0.05 in 75.5%. It was **worse by ≥ 0.01 in 1.2%**.
- In the adverse regime the margin shrank to −0.12 [−0.15, −0.10], and ZTAS-DTh ranked first in only 44% of cells. Static zones, which were not degraded, often did as well.
- The margin is driven by interactions (ΣS₁ ≈ 0.4 vs ΣS_T ≈ 1.9). The most influential parameters are the segment duty cycle (S_T = 0.35), exploit rate (0.30) and attacker stealth (0.29).
- The advantage nearly vanishes in sparse threads, and when segments are mostly open and the attacker is stealthy.

**Manuscript changes.**
- §VI: joint design, ranges and regimes.
- New §VII-D "Joint Parameter Robustness", with Table VII and Fig. 3.
- Abstract, Introduction and Conclusion now state the conditional nature of the advantage.
- Supp. S2 gives the ranges, rationales, regimes, global indices, per-topology results and the decision tree.

**Further work in this round (v4).**
- **Legitimate cost at every joint point.** Each joint point's evidence threshold and decay were applied to legitimate entities (`joint_legitimate_impact.py`).
  - In 79.5% of continuous-design cells, an advantage of at least 0.05 coincides with at most 1% false isolation of field devices per shift.
  - False isolation is concentrated at κ ≤ 2, which is also where the margin is largest.
  - Location: new paragraph in §VII-D; Supp. Table S11 and Fig. S8.
- **Parameter audit.** `parameter_audit.csv` now carries a justification (grounded in the Sobol/PRCC results) and a recommended range for each parameter.
- **Re-execution.** Three evaluation units were re-run from scratch and are bit-identical to the archive.

**Remaining limitation.**
- The joint ranges are assumptions.
- Zones and perimeter parameters were not degraded, which biases the adverse-regime comparison in favour of zones; this is stated in Threats to Validity.
- Each cell rests on 16 units.

---

## Concern 2 — Calibration and operational validity of the 5-D risk engine

**Reviewer comment.** The risk engine is evaluated mainly on synthetic distributions. Its behaviour may differ under distribution shift, low prevalence, correlated or heavy-tailed data, overlap and asymmetric costs. A clearer operational interpretation is needed.

**Response.** We agree, and we now state explicitly that **the engine has been evaluated only on synthetic distributions and has not been calibrated on industrial data**. We did not run a calibration, because no labelled data were available.

**Actions taken.**
1. **Implementation audit** across the manuscript, the simulator, the E2 study and the PoC. It found:
   - three different decay units (simulation step, request, second);
   - no step-up credit in E1;
   - no block-tier evidence in E2;
   - **missing dimensions treated as zero risk in the PoC (fail-open)**, now fixed and verified by test T-I;
   - "degraded mode" in Algorithm 1 versus fail-closed in the code (text corrected).
2. **Operational measurement specification** for each dimension: signals, source, frequency, normalisation, noise, missing data, privacy, manipulation and calibration need.
3. **Calibration protocol** (proposed, not executed): shadow mode, labelled data, constrained logistic fitting, cost- and budget-constrained thresholds, drift monitoring and recalibration triggers.
4. **Extended experiment.**
   - Prevalence 0.1–20%, 10⁵ draws per class, Wilson CIs, operator workload per 10⁵ requests.
   - Calibration transfer (Platt; ECE, Brier).
   - Cost-sensitive thresholds under four cost scenarios, including safety-critical isolation, plus budget-constrained thresholds.

**Evidence.** `01_Experiments/risk_engine/` (`risk_engine_audit.md`, `risk_dimension_operational_specification.csv`, `risk_calibration_protocol.md`, the experiment script, `risk_engine_analysis.ipynb`, `RISK_ENGINE_VALIDATION_REPORT.md`); `02_Data/processed/risk_engine/` (processed metrics, confusion matrices, calibration, thresholds).

**Findings.**
- With heavy-tailed, skewed or correlated legitimate scores, ROC-AUC is 0.75–0.97. Yet at 0.1% prevalence 16–94 escalations are false per true one (precision 1–6%), and operator workload is 1200–1700 false step-ups per 10⁵ requests.
- Gaussian assumptions are the optimistic case.
- A calibration fitted in one condition over-predicts three- to fourfold in others.
- The cost-optimal threshold moves from 64.5 to 14 with prevalence, so no universal threshold exists.

**Manuscript changes.**
- §IV-D: calibration status, measurement definition, missing-data rule, decay units.
- §VI: E2 extension.
- §VII-F: prevalence, workload, calibration and thresholds.
- Discussion and Limitations.
- Supp. S4: specification, protocol and full prevalence table.

**Further work in this round (v4).** A robustness study (`risk_engine_robustness_experiment.py`; new paragraph in §VII-F; Supp. Table S17 and Fig. S9) found:
- **Measurement noise.** With σ = 20, the FPR rose from 5×10⁻⁵ to 0.10 under Gaussian scores. False escalations per true escalation at 0.1% prevalence rose from 0.46 to 356.
- **Missing components.** Mid-scale imputation (our default, fail-safe) raised the FPR to 0.022 at 5% missing and to 0.17 at 20% missing.
- **Withholding attacker.** If the attacker withholds its behavioural and system signals 90% of the time:
  - zero, legitimate-mean or re-weighting imputation let it escape (TPR 0.06–0.07);
  - mid-scale imputation catches it (TPR 0.97).
- **Consequence.** No imputation rule is both workload-friendly and evasion-resistant. The manuscript now says that missing signals should be treated as evidence about the source, not imputed silently; this finding is in the Abstract.
- **Signal specification.** `RISK_SIGNAL_OPERATIONAL_SPECIFICATION.csv` adds prototype status, sampling frequency and measurement limitations for every signal. Every dimension is theoretical in the PoC.

**Remaining limitation.** No industrial telemetry and no calibration. The results describe model behaviour, not detection performance.

---

## Concern 3 — Evidence accumulation and delayed containment

**Reviewer comment.** The revised rule raises the median escalated requests to quarantine a stealthy attacker from 22 to 86. A request count does not establish operational acceptability.

**Response.** We agree, and the new analysis shows the cost is larger than the request count suggested.

**Actions taken.**
- Audit of the evidence mechanism.
- A **continuous-time event simulation** that couples request-driven attack progression with wall-clock elements (operator approval, time-based decay):
  - 4 base rates (1–1000 req/s), 7 attacker profiles and 5 policies, the last of these a criticality-aware policy that restricts rather than isolates operations assets;
  - common random numbers, 52 500 runs, none censored;
  - legitimate false isolation per 8 h shift at 0.1–10 req/s.

**Evidence.** `01_Experiments/evidence_accumulation/` (script, analysis, notebook, figures, paired comparisons, `EVIDENCE_ACCUMULATION_REPORT.md`); `02_Data/Raw/evidence_accumulation_raw.csv.gz`; `02_Data/processed/evidence_accumulation_*.csv`.

**Findings.**
- With request-based decay, outcomes are rate-invariant except for time.
- The revised rule reduces containment before the operations phase from 0.43 to 0.11 and roughly doubles the number of compromised entities (−23.8 [−26.1, −21.8] in favour of the original rule).
- It avoids false isolation that the original rule causes in 15–100% of legitimate entities per shift.
- Wall-clock decay lets a slow attacker evade completely.
- No evidence policy contains stealthy or rapid attackers by itself.
- The criticality-aware policy gives a small gain (−0.84 entities) at a 0.1% restriction cost.

**Manuscript changes.**
- §IV-D: decay units.
- §VI: the design.
- New §VII-G, with Table VIII (figure now Supp. Fig. S5).
- §VII-F: "a point on a trade-off curve, not an operationally validated setting".
- Discussion: safety of responses.

**Further work in this round (v4).** We extended the evidence study (`evidence_policy_extension_experiment.py`; new paragraph in §VII-G; Supp. Tables S18–S19 and Fig. S10). It covers thresholds κ = 1–5, approval delays of 0/30/600 s, emergency isolation, safe-state transition and a propagation-aware threshold, for moderate, burst, stealthy and rapid attackers.
- **Every threshold pays on one side.**
  - κ = 1 contains a moderate attacker before operations in 79% of runs (5.3 entities compromised), but falsely isolates 40–100% of legitimate entities per shift.
  - κ = 2 leaves 40.2 entities compromised.
  - κ ≥ 3 isolates no legitimate entity.
- **Stealthy and rapid attackers** evade every threshold above one.
- **Approval delay, safe state and emergency isolation** changed compromise by 0.06–0.35 entities. Containment, when it happens, isolates the foothold before operations is reached.
- **Propagation-aware threshold** helped modestly: −2.2 [−3.7, −0.9] entities.
- **Interpretation.** Response tuning is not a substitute for segments and provenance. This is now stated in the Abstract and Limitations.

**Remaining limitation.**
- The rates, approval delay and profiles are assumptions.
- The criticality-aware policy is a simulation policy, not a demonstrated safety function.
- Emergency override is not modelled.

---

## Concern 4 — Formal assurance and its boundaries

**Reviewer comment.** Bounded abstract model checking does not verify the integrated implementation. Strengthen where feasible and define the limits precisely.

**Response.** We added model M4 for asynchronous, distributed enforcement and mapped every property to its enforcing component, assumption and type of evidence. We do not claim implementation-level assurance.

**Actions taken.**
- Audit of P1–P8, Propositions 1–3 and M1–M3; M1–M3 were re-run with identical results.
- **M4a–e:**
  - M4a: revocation with cached decisions and an asynchronous CRL;
  - M4b: PDP, provenance and segmentation-controller failure;
  - M4c: a policy-update race;
  - M4d: concurrent replay;
  - M4e: compromised administrators and a two-person rule.
- Each sub-model has negative controls: 16 runs, all matching expectation.
- **One mis-specified negative control is reported.** In the first M4a run, a control produced no counterexample; it was replaced, and both logs are kept.
- **Assurance-boundary diagram** and a **property → enforcement → verification-status map**.
- P3, P6, P7 and P8 statements were updated to the design rules found: window mode, revocation bound, durable quarantine, quorum.

**Evidence.** `src/formal/model_check_v3.py`; `src/formal/logs/model_check_v3*.log|json`, `model_check_rerun.log`; `01_Experiments/formal_analysis/FORMAL_ANALYSIS_REPORT.md`; `formal_assurance_boundary.png|pdf`.

**Manuscript changes.**
- §V: new M4 paragraph; Table III updated; Table IV now has 32 checks (28 in v3, 4 new in v4).
- Algorithm 1 updated: atomic anti-replay window, re-validation, fail-closed.
- Discussion, "What is guaranteed…", separates cryptographic, model-checked, implementation-tested and assumed properties.
- Supp. S6: boundary diagram and property map (Table S20, with bounds and limitations).

**Further work in this round (v4).** Two new sub-models address the interval between a decision and forwarding:
- **M4f:** a segment expires while a request is in flight.
- **M4g:** a quarantine is acknowledged while a request is in flight.

Both violate their property unless the PEP re-checks at enforcement. Both re-checked configurations hold, and both negative controls produce counterexamples. That brings the total to 32 checks, all as expected.

What changed in the manuscript:
- Algorithm 1 now re-checks segment validity, quarantine status and policy version before forwarding.
- Table IV includes the new rows.
- A new property map (`property_map_v4.csv`; Supp. Table S20) gives, for each property, the models, bounds, PoC tests, status and limitations.
- `FORMAL_ASSURANCE_REPORT.md` states that TLC was not executed, that no Alloy model exists, and what is not covered: replicas, partitions, Byzantine faults, liveness and code-level verification.

**Remaining limitation.**
- TLC was not run.
- The models are small and bounded.
- There is no code-level verification, liveness, timing or replicated-PDP consistency.

---

## Concern 5 — Integrated proof of concept

**Reviewer comment.** The PoC demonstrates selected workflows on one host but does not evaluate concurrency, failure behaviour or integrated interactions.

**Response.** We added a concurrency and failure test suite. **It found six defects in the v2 PoC, two of them security-relevant; a seventh was found in this round (see below).**
1. A shared HTTP client caused responses to be delivered to the wrong request; a misattributed "allow" was therefore possible.
2. A quarantined device regained access after a PDP restart.

All six defects were fixed. Every fix is switchable, so the v2 behaviour was re-run as a control under identical conditions.

**Actions taken.**
- PoC audit and a component mapping: implemented, mocked, abstracted or not implemented.
- Tests T-A to T-I on a fresh stack each, localhost only:
  - T-A: concurrency (1–16 clients);
  - T-B, T-C, T-D: provenance, PDP (also under load) and segmentation-controller failure;
  - T-E: revocation under load and IdP outage;
  - T-F: 16 concurrent replays;
  - T-G: segment revocation race;
  - T-H: PDP restart and recovery;
  - T-I: missing risk inputs.
- Measurements: p50, p95 and p99 latency, throughput, CPU, RSS and failure rate.
- Sequence diagram, with editable Mermaid source.

**Evidence.**
- `src/poc/ztas_poc_v3.py`.
- `01_Experiments/poc_failure_testing/`: tests, `run_all_poc_tests.sh`, `raw/*.json`, `poc_concurrency_processed.csv`, `poc_implementation_audit.md`, `POC_INTEGRATION_REPORT.md`, `poc_sequence_diagram.*`.

**Manuscript changes.**
- §VI: E4 test suite.
- §VII-I: new Table X and results.
- The text states that this is a controlled software demonstration on a 2-vCPU host, not an industrial deployment.
- Supp. S7: sequence diagram and full concurrency tables (S21–S23).

**Further work in this round (v4).** Following M4f/M4g, the PEP in `ztas_poc_v4.py` re-checks the segment and the quarantine list immediately before forwarding (`ZTAS_RECHECK_ENFORCE`). The new race tests, each with a control run:

| Test | Re-check on | Re-check off (control) |
|---|---|---|
| T-J (segment expiry) | 0/720 unsafe forwards | 24/720, up to 50 ms late |
| T-K (quarantine) | 0/36 | 18/36, up to 45 ms late |

This is the seventh defect found by testing.
- **Window.** The harness widens the window to 50 ms. The re-check narrows the race but does not close it; the manuscript says so.
- **Repeated T-A.** T-A was repeated three times. The re-check costs 0.4–1.3 ms median latency and 16–33% throughput at 1–4 clients. Run-to-run SD reaches about 20% of throughput.
- **Locations.** Table X; Supp. Tables S22–S23.
- **Not done.** A separate failure-propagation test was not run.

**Remaining limitation.**
- Single host.
- Mocked step-up and context; stub twin.
- No distributed ledger and no implemented two-person rule.
- One run per configuration.

---

## Concern 6 — Cryptographic benchmarking, queueing and deployment

**Reviewer comment.** The implementation details, queueing assumptions, portability claim and deployment implications need clarification.

**Response.**
- **The portability claim was incorrectly reasoned and is corrected.** The binary is stripped, so the absence of AVX2 symbols proves nothing. Disassembly shows 182 instructions on 256-bit registers and 11 `cpuid` instructions, i.e. a small amount of run-time-dispatched AVX2 code, probably hashing. The ML-DSA arithmetic is the crate's portable software backend.
- **The queueing model was re-analysed** with bursty arrivals and empirical service times.

**Actions taken.**
- Audit of the library, build (rustc 1.97.1, maturin, LLD 22.1.6; GCC 14.2.1 for the C parts), CPU flags, repetitions, warm-up and randomisation.
- Statistics recomputed from the raw samples: median with bootstrap CI, mean, p95, p99, outliers, throughput.
- **A new observation:** ML-DSA signing is right-skewed (mean 12% above the median). v2 fitted medians, which understates the mean service time that decides stability; per-record signing is already unstable at 100 records/s with empirical service times.
- A discrete-event queue covering Poisson, Markov-modulated bursty and clustered arrivals, deterministic versus empirical service, and 540 configurations. At 10⁴ records/s with B = 256, the p99 is 39 ms under Poisson arrivals but 1.6 s under bursts.
- A deployment discussion covering gateways, HSMs, acceleration, key rotation and revocation, ledger and network interruption, archival verification and migration.

**Evidence.** `01_Experiments/crypto/` (`crypto_reanalysis.py`, notebook, `CRYPTOGRAPHIC_BENCHMARK_REPORT.md`); `02_Data/processed/crypto/`.

**Manuscript changes.**
- §VI (E3): library description corrected.
- §VII-H: mean/median, CIs and burst results.
- Discussion: gateways, HSMs and interoperability.
- Supp. S8; the batching/queueing figure is now Supp. Fig. S6.

**Further work in this round (v4).** We made no new measurements, because we have no gateway or HSM hardware.
- The deployment discussion now compares our software-backend signing time with published ML-DSA-65 timings on Xeon, Cortex-A55 and Cortex-M33 (QZT-ICS, liboqs). It shows that our 9.3 ms is pessimistic for servers, while microcontroller gateways would sign fewer than ten records per second without batching.
- The batching figure moved to the supplement.

**Remaining limitation.** No gateway, HSM or ARM measurement, and no run with AVX2 disabled. The latencies are modelled, not measured industrial latencies.

---

## Concern 7 — Novelty and incremental contribution

**Reviewer comment.** The architecture combines established mechanisms; the novelty is integrative and must be justified.

**Response.** We agree that the components are not novel and now say so in the Introduction. We audited each contribution claim and searched for recent closest work. That search found two 2026 works, QZT-ICS (Qadri) and Humphrey's cyber-twin-informed ZT. Both are now cited and were read in full. QZT-ICS has stronger implementation evidence than ours (a hardware-in-the-loop testbed) but addresses transport- and process-level trust rather than lifecycle lineage, and does not compare against a provenance-verifying baseline; Humphrey is an early-stage report whose qualitative segmentation findings we cite in the Discussion. QZT-ICS's measured PQC costs on Cortex-M33/A55 hardware are cited to bound our server-only benchmarks.

The defensible contributions are:
1. the artifact- versus interface-mediated threat model;
2. the coupling of lineage verification with per-request ZT and flow-scoped segments;
3. a **counterfactual evaluation against a ZT+provenance baseline**, which identifies where the coupling stops helping;
4. supporting assurance.

A worked comparison of a compromised CAM service across all five architectures is aligned with the simulation boundary.

**Evidence.** `01_Experiments/novelty/` (`NOVELTY_AUDIT.md`, `RELATED_WORK_CRITICAL_COMPARISON.md`, `NOVELTY_AND_POSITIONING_REPORT.md`).

**Manuscript changes.**
- §I: contributions rewritten.
- §II: new works and positioning.
- Table I: two new rows.
- Discussion: worked example extended to zones and linked to the simulation boundary.

**Further work in this round (v4).** `NOVELTY_AND_RELATED_WORK_AUDIT.md` classifies each of claims N1–N9 as supported, partial, weak, integration or not claimed. The manuscript claims only the supported ones.

**Remaining limitation.** The novelty remains integrative and methodological. Evidence of benefit is model-based.

---

## Concern 8 — Statistical interpretation and practical significance

**Reviewer comment.** Strengthen the interpretation of graph-level variability, effect sizes and topology-dependent benefits.

**Actions taken.** The paired graph-level analysis was re-done against ZT and ZT+provenance. It reports:
- absolute and relative reductions;
- graph-level ranges;
- a **pre-declared practical-significance threshold** (0.05, about 3 of 56 entities) and the share of graphs reaching it;
- a variance partition (between-graph share 2–9%);
- an explanation of why d_z is not used as the benefit measure;
- a figure showing all 270 graph-level differences;
- topology-mechanism interpretation;
- explicit separation of statistical significance, effect size, robustness, practical significance and model-dependent evidence.

**Evidence.** `01_Experiments/statistics/` (`statistical_analysis.py`, notebook, `fig_graph_level_differences.*`, `STATISTICAL_VALIDATION_REPORT.md` with the audit); `02_Data/processed/statistics_*.csv`.

**Findings.** Every graph favours ZTAS-DTh. However, only 20% of sparse and 67% of multi-organisation graphs reach the practical threshold, against 100% in the other seven families. The relative reduction (52–72%) is similar across families; the absolute benefit depends on how much the baseline leaves exposed.

**Manuscript changes.**
- §VI: practical-significance criterion.
- Benefit section (§VII-B): graph-level figure, now Supp. Fig. S4 to shorten the main text.
- Threats to Validity.

**Further work in this round (v4).**
- **Ranking stability.** Kendall's coefficient of concordance of the five-way ranking was 0.95–1.0 per family. ZTAS-DTh ranked first in all 270 graphs (§VII-A; Supp. Table S12).
- **Paired comparisons.** Evidence-policy contrasts are reported as paired graph-level bootstrap differences.
- **Exception.** In the sparse family, static ZT and zones swap places in half of the graphs. We note that the ordering of the baselines reflects the assumed conduit parameters.

**Remaining limitation.** All evidence is about the simulator under assumed parameters.

---

## Concern 9 — Attack model and operational interpretation

**Actions taken.**
- **Adversary-model audit** covering capabilities, entry, credentials, exploit, movement, artifact and interface propagation, replay, stealth, detection and containment.
- Five attacker profiles: noisy, stealthy, rapid multi-step, **coordinated** (three footholds; new simulator capability, backward compatible with 72 v2 rows reproduced exactly) and credentialed. They were run on 90 fresh graphs.
- A mapping of seven representative industrial behaviours to the model, with ATT&CK-for-ICS technique names, no procedures, and the limitation of each abstraction.
- An explicit statement of what the model omits: adaptation, coordination between footholds, intra-entity stages, physical consequences.

**Evidence.** `01_Experiments/adversary/` (experiment, summary, `attack_scenario_mapping.csv`, `ADVERSARY_MODEL_VALIDATION_REPORT.md`); `02_Data/Raw/adversary_profiles_raw.csv.gz`.

**Findings.** Rapid, coordinated and credentialed attackers roughly double ZTAS-DTh's compromised fraction (0.28–0.31 vs 0.14) and its reach of the operations phase. Every graph still favours ZTAS-DTh over ZT+provenance.

**Manuscript changes.**
- §III: attacker profiles and the mapping.
- §VII-D: attacker-profile results.
- Threats to Validity.
- Supp. S3.

**Further work in this round (v4).**
- Burst and rapid multi-step profiles were added to the evidence study.
- The finding that stealthy and rapid attackers evade the evidence rule at every κ ≥ 2 is reported in §VII-G and the Limitations.
- The adversary experiment was re-run from scratch for two tasks: identical to within 1e-16.

**Remaining limitation.** Fixed probabilities and a non-adaptive attacker.

---

## Concern 10 — Reproducibility package

**Actions taken.**
- **Clean-checkout reproduction of release v1.0.0** (git tag; blobs previously verified against GitHub; Zenodo itself is not reachable from our build environment).
- Principal results re-run and compared with the archived data and the manuscript.
- Archive audit, reproduction checklist, and a manifest with SHA-256 checksums for every file of the v3 package.

**Evidence.** `01_Experiments/reproducibility/` (`reproducibility_archive_audit.csv`, `reproduction_checklist.csv`, `reproducibility_manifest.csv`, `REPRODUCIBILITY_VALIDATION_REPORT.md`, `repro_logs/`).

**Results.** A clean checkout of v1.0.0 reproduced E1 (main, recommended rule, p_v sweep, OAT), the processed statistics, E2, formal M1–M3 and all PoC scenario outcomes bit-identically, including the headline 0.138 [0.125, 0.152] vs 0.492 [0.454, 0.533]. Crypto timings were **not** reproducible beyond about a factor of two on the shared VM (medians 0.74–2.41× the archived values), so the manuscript now labels absolute costs as indicative. All 143 v3 numbers quoted in the manuscript were checked against the output files (`08_Final_Reports/NUMBER_CHECK.md`); four drafting mismatches were corrected.

**Manuscript changes.** Data and Code Availability: states what release v1.0.0 contains, that it was reproduced, and that the v3 experiments are archived as release v1.1.0 (doi:10.5281/zenodo.24379544).

**Further work in this round (v4).**
- **Re-execution from scratch.** Seven archived tasks were re-run: three joint-sensitivity units (bit-identical), two evidence tasks and two adversary tasks (≤ 4.5e-13, from CSV round-off). See Supp. Table S27.
- **New documents.**
  - `EXPERIMENT_EVIDENCE_MANIFEST.csv` links each manuscript result to its script, data, table or figure, and verification status.
  - `reproduction_checklist_v4.csv` adds a manuscript-claim column.
- **Number check.** `number_check.py` now checks 182 numbers, all passing.
- **Archiving.** The complete v4 package is archived as release v1.2.0: GitHub tag `v1.2.0` and Zenodo doi:10.5281/zenodo.24386844, under the same concept DOI 10.5281/zenodo.24372429. The Data Availability section cites it.

**Remaining limitation.** The v3 package is archived as release v1.1.0 (doi:10.5281/zenodo.24379544; concept DOI 10.5281/zenodo.24372429). The long v3 simulations were executed once (they are seeded and can be re-run). There is no container image or hashed lock file.
