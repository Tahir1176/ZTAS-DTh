"""Renders Fig. 1 (the TikZ block of ../main.tex) to arch.png for the Word version."""
import os, subprocess
os.chdir(os.path.dirname(os.path.abspath(__file__)))
s = open("../main.tex").read()
i = s.index(r"\begin{tikzpicture}"); j = s.index(r"\end{tikzpicture}", i) + len(r"\end{tikzpicture}")
doc = ("\\documentclass[border=4pt]{standalone}\n\\usepackage[T1]{fontenc}\\usepackage{amsmath,amssymb}\\usepackage[table]{xcolor}\\usepackage{tikz}\n"
       "\\usetikzlibrary{positioning,arrows.meta,fit,backgrounds,calc}\n\\begin{document}\n" + s[i:j] + "\n\\end{document}\n")
open("arch.tex", "w").write(doc)
subprocess.run(["pdflatex", "-interaction=nonstopmode", "arch.tex"], check=True, capture_output=True)
subprocess.run(["pdftoppm", "-r", "220", "-png", "-singlefile", "arch.pdf", "arch"], check=True)
print("arch.png written")
