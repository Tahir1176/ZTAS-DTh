"""Builds supplement.tex (v7) from the moved floats and the result files (no numbers typed by hand)."""
import json, csv, os
import pandas as pd, yaml
R = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")
E = lambda *p: os.path.join(R, "01_Experiments", *p)
D = lambda *p: os.path.join(R, "02_Data", *p)
blocks = json.load(open(os.path.join(R, "06_Manuscript", "moved_blocks_v5.json")))
UMAP = {"⇒": "$\\Rightarrow$", "∋": "$\\ni$", "∧": "$\\wedge$", "Δ": "$\\Delta$", "≤": "$\\le$", "≥": "$\\ge$", "→": "$\\rightarrow$",
        "κ": "$\\kappa$", "μ": "$\\mu$", "−": "-", "×": "$\\times$", "≈": "$\\approx$", "…": "...", "–": "--", "—": "---", "′": "'", "ᵃ": ""}
def tex(x):
    x = _tex(x)
    for k, v in UMAP.items(): x = x.replace(k, v)
    return x
def _tex(x): return str(x).replace("&", "\\&").replace("%", "\\%").replace("_", "\\_").replace("#", "\\#").replace("->", "$\\rightarrow$").replace("<=", "$\\le$").replace(">=", "$\\ge$").replace("~", "$\\sim$")
out = [r"""\documentclass[journal,onecolumn]{IEEEtran}
\usepackage[T1]{fontenc}\usepackage{amsmath,amssymb}\usepackage{graphicx}\usepackage{booktabs,array,longtable}\usepackage[hidelinks]{hyperref}
\renewcommand{\thetable}{S\arabic{table}}\renewcommand{\thefigure}{S\arabic{figure}}\renewcommand{\thesection}{S\arabic{section}}
\newcommand{\ztas}{ZTAS-DTh}
\begin{document}
\title{Supplementary Material for ``ZTAS-DTh: A Lifecycle-Spanning Zero-Trust Security Architecture for the Digital Thread''}
\author{Muhammad Tahir, Waqas Ahmed, Ammar Hassan, and Imran Rashid}
\maketitle
\noindent All numbers in this supplement are generated from the archived revision package (scripts in \texttt{src/} and \texttt{01\_Experiments/}, data in \texttt{02\_Data/}). Evidence type throughout: simulation, synthetic distributions, server-CPU benchmarks and a single-host software proof of concept; none is an industrial measurement.
"""]
def sec(t): out.append("\\section{%s}\n" % t)
def strip_label(b, lab, new):
    return b.replace("\\label{%s}" % lab, "\\label{%s}" % new).replace("table*", "table").replace("figure*", "figure").replace("[!t]", "[!h]")
# ---------------- S1 moved v2 material
sec("Material moved from the main text")
for lab in ["tab:lifecycle", "tab:e1metrics", "fig:sens", "tab:risk", "tab:evidence", "fig:risk", "tab:poc", "tab:stride", "tab:e1main", "fig:abl", "fig:graphs", "fig:evtime", "fig:crypto"]:
    num, kind, b = blocks[lab]
    out.append(strip_label(b, lab, "s" + lab) + "\n")
out.append("\\clearpage\n")
# ---------------- joint sensitivity configuration
sec("Joint sensitivity: parameter ranges, rationale and regimes")
cfg = yaml.safe_load(open(E("01_Joint_Sensitivity", "joint_sensitivity_config.yaml")))
rows = ["\\begin{longtable}{@{}p{2.4cm}p{2.2cm}p{11.2cm}@{}}\\caption{Jointly varied parameters (all ranges are exploratory assumptions)}\\\\\\toprule Parameter & Range & Rationale\\\\\\midrule"]
for k, v in cfg["parameters"].items():
    rows.append(f"\\texttt{{{tex(k)}}} & [{v['range'][0]}, {v['range'][1]}] & {tex(v['rationale'])}\\\\")
rows.append("\\midrule\\multicolumn{3}{@{}p{16cm}@{}}{Regimes restrict only defensive parameters: " + "; ".join(
    f"\\emph{{{r}}}: " + ", ".join(f"\\texttt{{{tex(k)}}} {v}" for k, v in spec.items()) for r, spec in cfg["regimes"].items()) + ".}\\\\\\bottomrule\\end{longtable}")
out.append("\n".join(rows) + "\n")
gi = pd.read_csv(E("01_Joint_Sensitivity", "joint_sensitivity_global_indices.csv"))
out.append("\\begin{table}[!h]\\centering\\caption{Global sensitivity of the paired difference frac(\\ztas{}) $-$ frac(ZT+prov): Sobol indices (reference topology, Saltelli $N=256$) and PRCC (continuous LHS, nine families)}\\small\\begin{tabular}{@{}lrrrrr@{}}\\toprule Parameter & $S_1$ & 95\\% CI & $S_T$ & 95\\% CI & PRCC\\\\\\midrule")
for _, r in gi.sort_values("ST_d", ascending=False).iterrows():
    out.append(f"\\texttt{{{tex(r.parameter)}}} & {r.S1_d:.3f} & $\\pm${r.S1conf_d:.3f} & {r.ST_d:.3f} & $\\pm${r.STconf_d:.3f} & {r.PRCC_d_prov:+.3f}\\\\")
out.append("\\bottomrule\\end{tabular}\\end{table}\n")
bt = pd.read_csv(E("01_Joint_Sensitivity", "joint_sensitivity_by_topology.csv"))
out.append("\\begin{table}[!h]\\centering\\caption{Paired difference by topology and design [95\\% two-way bootstrap CI]; share of points with an advantage of at least 0.05}\\small\\begin{tabular}{@{}llrrrr@{}}\\toprule Design & Topology & ZT+prov & \\ztas{} & Difference [CI] & $\\le-0.05$\\\\\\midrule")
for _, r in bt.iterrows():
    out.append(f"{r.design} & {tex(r.topology)} & {r.ztprov:.3f} & {r.ztas:.3f} & {r.d_prov:+.3f} [{r.lo:+.3f}, {r.hi:+.3f}] & {100*r.share_points_advantage_ge_0_05:.0f}\\%\\\\")
out.append("\\bottomrule\\end{tabular}\\end{table}\n")
out.append("\\begin{figure}[!h]\\centering\\includegraphics[width=0.8\\textwidth]{figs/fig_joint_by_topology.pdf}\\caption{Paired difference per topology and regime (95\\% CIs).}\\end{figure}\n")
tree = open(E("01_Joint_Sensitivity", "joint_sensitivity_vanishing_advantage_tree.txt")).read()
out.append("\\noindent\\textbf{Vanishing-advantage tree.}\\begin{verbatim}\n" + tree + "\\end{verbatim}\n")
li = pd.read_csv(D("Processed", "joint_legitimate_impact.csv"))
g = li.groupby("design").agg(d=("d_prov", "mean"), ff=("false_iso_field_device_heavy", "mean"), fs=("false_iso_field_device_heavy", lambda x: (x > 0.01).mean()), fh=("false_iso_human_operator_gauss", "mean"))
out.append("\\begin{table}[!h]\\centering\\caption{Legitimate cost over the joint design: false isolation per 8-h shift at 1 request/s implied by each point's evidence threshold and decay (field devices: heavy-tailed scores; operators: Gaussian), next to the attack-side advantage}\\label{stab:jointlegit}\\small\\begin{tabular}{@{}lrrrr@{}}\\toprule Design & Mean difference & Field devices & Points with $>1\\%$ & Operators\\\\\\midrule")
for k, r in g.iterrows():
    out.append(f"{k} & {r.d:+.3f} & {r.ff:.4f} & {100*r.fs:.1f}\\% & {r.fh:.4f}\\\\")
c = li[li.design == "continuous"]; both = ((c.d_prov <= -0.05) & (c.false_iso_field_device_heavy <= 0.01)).mean()
out.append("\\bottomrule\\end{tabular}\\end{table}\n")
out.append(f"In the continuous design, {100*both:.1f}\\% of point--topology cells combine an advantage of at least 0.05 with at most 1\\% false isolation of field devices per shift. Static ZT and ZT+prov have no evidence rule, so their false isolation from this mechanism is zero by construction; their legitimate cost from generic monitoring is not modelled.\n")
out.append("\\begin{figure}[!h]\\centering\\includegraphics[width=0.85\\textwidth]{figs/fig_joint_legitimate_impact.pdf}\\caption{Joint design: (a) false isolation of legitimate field devices by evidence threshold and decay; (b) attack-side advantage against legitimate false isolation per point.}\\label{sfig:jointlegit}\\end{figure}\n")
rs = pd.read_csv(D("Processed", "statistics_ranking_stability.csv")); rs = rs[rs.profile == "stealthy"]
out.append("\\begin{table}[!h]\\centering\\caption{Ranking stability across the 30 graphs of each family (stealthy attacker; baselines are profile-independent, so the noisy profile gives the same rankings). $W$: Kendall's coefficient of concordance}\\label{stab:rank}\\small\\begin{tabular}{@{}lrlrr@{}}\\toprule Topology & $W$ & Modal ranking (best first) & \\ztas{} first & Zones beat ZT\\\\\\midrule")
for _, r in rs.iterrows():
    out.append(f"{tex(r.topology)} & {r.kendall_W:.3f} & {tex(r.modal_ranking.replace('ztas_rec', 'ZTAS'))} & {100*r.rank1_ztas_rec:.0f}\\% & {100*r.share_graphs_zones_beats_zt:.0f}\\%\\\\")
out.append("\\bottomrule\\end{tabular}\\end{table}\n\\clearpage\n")
# ---------------- attacker profiles and scenario mapping
sec("Adversary model: attacker profiles and scenario mapping")
ap = pd.read_csv(E("08_Attack_Model", "adversary_profiles_summary.csv"))
out.append("\\begin{table}[!h]\\centering\\caption{Mean fraction compromised by attacker profile (9 families $\\times$ 10 fresh graphs $\\times$ 20 runs)}\\small\\begin{tabular}{@{}lrrrrrrrr@{}}\\toprule Profile & Perim. & Zones & ZT & ZT+prov & \\ztas{} & Difference & Graphs $<0$ & Graphs $\\le-0.05$\\\\\\midrule")
for _, r in ap.iterrows():
    out.append(f"{tex(r.profile)} & {r.perimeter:.2f} & {r.zones:.2f} & {r.zt:.2f} & {r.zt_prov:.2f} & {r.ztas:.2f} & {r.d_prov:+.3f} & {100*r.share_graphs_ztas_better:.0f}\\% & {100*r.share_practical:.0f}\\%\\\\")
out.append("\\bottomrule\\end{tabular}\\end{table}\n")
m = pd.read_csv(E("08_Attack_Model", "attack_scenario_mapping.csv"))
out.append("{\\scriptsize\\begin{longtable}{@{}p{2.2cm}p{2.0cm}p{1.6cm}p{2.0cm}p{2.6cm}p{2.7cm}p{2.7cm}@{}}\\caption{Representative industrial attack behaviours mapped to the model (ATT\\&CK for ICS technique names; no procedures)}\\\\\\toprule Scenario & Techniques & Movement & Artifact/interface & ZTAS-DTh controls & Model representation & Model limitation\\\\\\midrule")
for _, r in m.iterrows():
    out.append(" & ".join(tex(x) for x in [r.scenario, r.attck_ics_techniques, r.lifecycle_movement, r.artifact_or_interface, r.relevant_ztas_controls, r.model_representation, r.model_limitation]) + "\\\\")
out.append("\\bottomrule\\end{longtable}}\n\\clearpage\n")
# ---------------- risk engine
sec("Risk engine: operational measurement specification, calibration and prevalence")
sp = pd.read_csv(E("02_Risk_Engine", "risk_dimension_operational_specification.csv"))
out.append("{\\scriptsize\\begin{longtable}{@{}p{1.2cm}p{2.6cm}p{2.0cm}p{2.4cm}p{2.0cm}p{2.0cm}p{2.0cm}p{1.9cm}@{}}\\caption{Proposed operational specification of the risk dimensions (a deployment specification, not a measurement)}\\\\\\toprule Dimension & Signals & Source & Normalisation & Noise & Missing data & Manipulation & Calibration\\\\\\midrule")
for _, r in sp.iterrows():
    out.append(" & ".join(tex(x) for x in [r.dimension, r.observable_signals, r.data_source, r.normalisation_method, r.noise_sources, r.missing_data_problem, r.attacker_manipulation, r.calibration_requirement]) + "\\\\")
out.append("\\bottomrule\\end{longtable}}\n")
proto = open(E("02_Risk_Engine", "risk_calibration_protocol.md")).read()
out.append("\\subsection*{Proposed calibration protocol (not executed)}\n\\begin{itemize}\n" + "\n".join(
    "\\item " + tex(l.strip().lstrip("#").strip()) for l in proto.splitlines() if l.startswith("## ")) + "\n\\end{itemize}\nThe full protocol is in \\texttt{01\\_Experiments/risk\\_engine/risk\\_calibration\\_protocol.md}.\n")
pm = pd.read_csv(D("Processed", "risk_engine", "risk_engine_processed.csv"))
x = pm[(pm.tier == "step_up")]
out.append("{\\scriptsize\\begin{longtable}{@{}lrrrrrrrr@{}}\\caption{Step-up tier ($\\theta_1=30$) by family, attacker mean and prevalence ($10^5$ draws per class)}\\\\\\toprule Family & $\\mu_{mal}$ & Prev. & TPR & FPR & Precision & PR-AUC & False esc./$10^5$ & False per true\\\\\\midrule")
for _, r in x.iterrows():
    out.append(f"{tex(r.family)} & {r.mu_mal:.0f} & {100*r.prevalence:g}\\% & {r.TPR:.3f} & {r.FPR:.4f} & {r.precision:.3f} & {r.PR_AUC:.3f} & {r.false_alerts_per_1e5:.0f} & {r.false_alerts_per_true_alert:.2f}\\\\")
out.append("\\bottomrule\\end{longtable}}\n\\clearpage\n")
rb = pd.read_csv(D("Processed", "risk_engine_robustness", "risk_engine_robustness.csv"))
out.append("{\\scriptsize\\begin{longtable}{@{}llrrlrrrr@{}}\\caption{Risk-engine robustness (step-up tier $\\theta_1=30$): measurement noise ($\\sigma$), missing components ($q$, by imputation rule), adversarial withholding of the behavioural and system components ($q_a$), and attack intensity ($\\mu_{mal}$)}\\label{stab:riskrob}\\\\\\toprule Study & Family & $\\mu_{mal}$ & Level & Rule & TPR & FPR & ROC-AUC & False/true at 0.1\\%\\\\\\midrule")
for _, r in rb.iterrows():
    out.append(f"{r.study} & {tex(r.family)} & {r.mu_mal:.0f} & {r.level:g} & {tex(r.rule)} & {r.TPR:.3f} & {r.FPR:.4f} & {r.ROC_AUC:.3f} & {r.false_per_true_0_001 if False else r['false_per_true_0.001']:.1f}\\\\")
out.append("\\bottomrule\\end{longtable}}\n\\begin{figure}[!h]\\centering\\includegraphics[width=0.9\\textwidth]{figs/fig_risk_robustness.pdf}\\caption{Risk-engine robustness to noise, missing data, adversarial withholding and attack intensity.}\\label{sfig:riskrob}\\end{figure}\n\\clearpage\n")
# ---------------- evidence policy extension
sec("Evidence policies: threshold sensitivity and alternative responses")
ev = pd.read_csv(D("Processed", "evidence_policy_extension_summary.csv"))
lab = {"kappa1_decay": "$\\kappa=1$", "kappa2_decay": "$\\kappa=2$", "kappa3_decay": "$\\kappa=3$ (revised)", "kappa4_decay": "$\\kappa=4$", "kappa5_decay": "$\\kappa=5$",
       "revised_approval0s": "revised, approval 0 s", "revised_approval30s": "revised, approval 30 s", "revised_approval600s": "revised, approval 600 s",
       "emergency_isolation": "emergency isolation", "safe_state": "safe state", "propagation_aware": "propagation-aware"}
out.append("{\\scriptsize\\begin{longtable}{@{}llrrrr@{}}\\caption{Evidence-policy extension at 1000 requests/s (risk-only configuration; 10 graphs $\\times$ 30 runs; common random numbers). All policies use per-evaluation decay and outage awareness}\\label{stab:evx}\\\\\\toprule Profile & Policy & Compromised (of 56) [95\\% CI] & Contained before $\\mathsf{O}$ & Median $t$ to containment (s) & Median requests\\\\\\midrule")
order = list(lab)
for pr in ["moderate", "burst", "stealthy", "rapid_multistep"]:
    for pol in order:
        r = ev[(ev.profile == pr) & (ev.rate == 1000) & (ev.policy == pol)].iloc[0]
        ci = [r.ci_compromised_lo, r.ci_compromised_hi]
        t = "--" if pd.isna(r.median_t_containment_s) else f"{r.median_t_containment_s:.3f}"; q = "--" if pd.isna(r.median_requests_before_containment) else f"{r.median_requests_before_containment:.0f}"
        out.append(f"{tex(pr)} & {lab[pol]} & {r.mean_compromised:.1f} [{ci[0]:.1f}, {ci[1]:.1f}] & {r.p_contained_before_O:.3f} & {t} & {q}\\\\")
out.append("\\bottomrule\\end{longtable}}\n")
lw = pd.read_csv(D("Processed", "evidence_policy_extension_legitimate_wide.csv"))
out.append("\\begin{table}[!h]\\centering\\caption{Legitimate false isolation per 8-h shift by evidence threshold (2000 entities per cell; propagation-aware assumes the top out-degree quartile uses $\\kappa=2$)}\\label{stab:evxlegit}\\small\\begin{tabular}{@{}llrrrrrr@{}}\\toprule Class & Scores & Rate & $\\kappa=1$ & $\\kappa=2$ & $\\kappa=3$ & $\\kappa\\ge4$ & Prop.-aware\\\\\\midrule")
for _, r in lw.iterrows():
    out.append(f"{tex(r.cls)} & {tex(r.scenario)} & {r.rate:g} & {r.kappa1_decay:.4f} & {r.kappa2_decay:.4f} & {r.kappa3_decay:.4f} & {max(r.kappa4_decay, r.kappa5_decay):.4f} & {r.propagation_aware:.4f}\\\\")
out.append("\\bottomrule\\end{tabular}\\end{table}\n\\begin{figure}[!h]\\centering\\includegraphics[width=0.9\\textwidth]{figs/fig_evidence_policy_extension.pdf}\\caption{Evidence-policy extension: (a) mean compromised entities by policy and attacker profile; (b) legitimate false isolation by threshold.}\\label{sfig:evx}\\end{figure}\n\\clearpage\n")
# ---------------- formal
sec("Formal analysis: assurance boundary and property map")
out.append("\\begin{figure}[!h]\\centering\\includegraphics[width=\\textwidth]{figs/formal_assurance_boundary.pdf}\\caption{Assurance boundary: trusted, modelled, implemented, tested and unverified components.}\\end{figure}\n")
pmap = pd.read_csv(E("04_Formal_Assurance", "property_map_v6.csv"))
out.append("{\\scriptsize\\begin{longtable}{@{}p{1.2cm}p{2.3cm}p{1.4cm}p{1.3cm}p{1.6cm}p{2.1cm}p{2.0cm}p{1.4cm}p{2.3cm}@{}}\\caption{Property, enforcement, tool, bound and evidence map. Python BFS: purpose-written explicit-state checker; TLC: re-check of a TLA+ transcription (Table~\\ref{stab:tlc}). No property is verified on the implementation}\\label{stab:pmap}\\\\\\toprule Property & Statement & Component & Models & Tools & Bounds & PoC tests & Status & Limitations\\\\\\midrule")
for _, r in pmap.iterrows():
    out.append(" & ".join(tex(x) for x in [r.property + " " + r["name"], r.formal_statement, r.enforcing_component, r.models, r.tools, r.bounds, r.implementation_tests, r.status, r.limitations]) + "\\\\")
out.append("\\bottomrule\\end{longtable}}\n\\clearpage\n")
# ---------------- PoC
sec("Proof of concept: request sequence, component mapping and concurrency measurements")
out.append("\\begin{figure}[!h]\\centering\\includegraphics[width=0.95\\textwidth]{figs/poc_sequence_diagram.pdf}\\caption{Request sequence in the v3 proof of concept (editable Mermaid source in the package).}\\end{figure}\n")
pc = pd.read_csv(E("05_POC_Integration", "poc_concurrency_processed.csv"))
out.append("{\\scriptsize\\begin{longtable}{@{}llrrrrrrr@{}}\\caption{Concurrency test T-A (120 requests per client; single run per configuration)}\\\\\\toprule Run & Kind & Clients & Throughput (req/s) & p50 (ms) & p95 & p99 & Failure rate & PEP CPU (s)\\\\\\midrule")
for _, r in pc.iterrows():
    out.append(f"{tex(r.run)} & {r.kind} & {r.concurrency} & {r.throughput_rps:.0f} & {r.p50_ms:.2f} & {r.p95_ms:.2f} & {r.p99_ms:.2f} & {r.failure_rate:.3f} & {r.pep_cpu_s:.2f}\\\\")
out.append("\\bottomrule\\end{longtable}}\nThe v2-control \\emph{plain} rows are invalid: the run outlasted the 300-s token lifetime (timeouts caused by the shared-client defect), so the remaining requests were denied as expired.\n")
rt = pd.read_csv(E("05_POC_Integration", "poc_race_tests_v4.csv"))
out.append("\\begin{table}[!h]\\centering\\caption{Check-to-enforce race tests (v4 PEP with and without enforcement-time re-check; the harness injects a 50-ms delay between authorisation and forwarding)}\\label{stab:race}\\small\\begin{tabular}{@{}llrrrr@{}}\\toprule Test & Variant & Rounds & Requests & Unsafe forwards & Max. lateness (ms)\\\\\\midrule")
for _, r in rt.iterrows():
    out.append(f"{tex(r.test)} & {tex(r.variant)} & {r.rounds} & {r.requests} & {r.unsafe_forwards} & {r.max_lateness_ms:.1f}\\\\")
out.append("\\bottomrule\\end{tabular}\\end{table}\n")
cr = pd.read_csv(E("05_POC_Integration", "poc_concurrency_repeats_v4.csv"))
g = cr.groupby(["variant", "kind", "clients"]).agg(t=("thr", "mean"), ts=("thr", "std"), p=("p50", "mean"), ps=("p50", "std"), q=("p99", "mean"), f=("fail", "max")).reset_index()
out.append("{\\scriptsize\\begin{longtable}{@{}llrrrrr@{}}\\caption{T-A repeated three times with the v4 PEP: mean (SD) over repetitions}\\label{stab:tarep}\\\\\\toprule Re-check & Kind & Clients & Throughput (req/s) & p50 (ms) & p99 (ms) & Max. failure rate\\\\\\midrule")
for _, r in g.iterrows():
    out.append(f"{tex(r.variant)} & {r.kind} & {r.clients} & {r.t:.0f} ({r.ts:.0f}) & {r.p:.2f} ({r.ps:.2f}) & {r.q:.1f} & {r.f:.3f}\\\\")
out.append("\\bottomrule\\end{longtable}}\n\\clearpage\n")
# ---------------- crypto
sec("Cryptographic benchmark re-analysis and queueing")
cs = pd.read_csv(D("Processed", "crypto", "crypto_summary_recomputed.csv"))
cs = cs[~cs.op.str.contains("proof_|merkle_tree_|batch_sig_ver_(?:1|4|16|256|1024|4096)$|keygen", regex=True)]
out.append("{\\scriptsize\\begin{longtable}{@{}lrrrrrrr@{}}\\caption{Re-computed statistics from the raw v2 samples ($\\mu$s; median CI by 2000 bootstrap resamples)}\\\\\\toprule Operation & $n$ & Median & 95\\% CI & Mean & p95 & p99 & Far outliers\\\\\\midrule")
for _, r in cs.iterrows():
    out.append(f"{tex(r.op)} & {r.n} & {r.median_us:.1f} & [{r.median_ci_lo:.1f}, {r.median_ci_hi:.1f}] & {r.mean_us:.1f} & {r.p95_us:.1f} & {r.p99_us:.1f} & {r.far_outliers}\\\\")
out.append("\\bottomrule\\end{longtable}}\n")
q = pd.read_csv(D("Processed", "crypto", "queueing_reanalysis.csv"))
s2 = q[(q.timeout_ms == 100) & (q.service == "empirical") & (q.batch.isin([1, 16, 64, 256]))].pivot_table(index=["arrivals", "rate"], columns="batch", values="p99_ms")
out.append("\\begin{table}[!h]\\centering\\caption{Modelled 99th-percentile signing latency (ms), $\\tau_b=100$ ms, empirical service times; ``unst.'' = signer unstable}\\small\\begin{tabular}{@{}llrrrr@{}}\\toprule Arrivals & Rate (rec/s) & $B=1$ & $B=16$ & $B=64$ & $B=256$\\\\\\midrule")
st = q[(q.timeout_ms == 100) & (q.service == "empirical")].set_index(["arrivals", "rate", "batch"]).stable
for (a, rt), row in s2.iterrows():
    cells = [("unst." if not st[(a, rt, b)] else f"{row[b]:.0f}") for b in [1, 16, 64, 256]]
    out.append(f"{a} & {rt} & " + " & ".join(cells) + "\\\\")
out.append("\\bottomrule\\end{tabular}\\end{table}\n\\clearpage\n")
# ---------------- v5 analyses
sec("Additional analyses of this revision (v5)")
import json as _json
JR = D("Processed", "joint_robustness_v5")
alt = pd.read_csv(os.path.join(JR, "alternate_ranges_summary.csv")).merge(pd.read_csv(os.path.join(JR, "alternate_ranges_ci.csv"))[["design", "lower_lo", "lower_hi", "adv_lo", "adv_hi"]], on="design"); jr = _json.load(open(os.path.join(JR, "joint_robustness_v5.json")))
out.append("\\begin{table}[!h]\\centering\\caption{Joint design: interpretation and robustness. Cells are (point, topology) pairs averaged over 4 graphs $\\times$ 4 runs. The three alternate designs use ranges introduced in this revision (Section~VI) and the same graphs, runs and seeds}\\label{stab:jointrob}\\small\\begin{tabular}{@{}lrrrrrr@{}}\\toprule Design & Cells & Mean diff. & Median & Lower [95\\% CI] & $\\le-0.05$ [95\\% CI] & Worse $\\ge0.01$\\\\\\midrule")
for _, r in alt.iterrows():
    out.append(f"{tex(r.design)} & {r.n_cells} & {r.mean_d:+.3f} & {r.median_d:+.3f} & {100*r.share_lower:.1f}\\% [{100*r.lower_lo:.1f}, {100*r.lower_hi:.1f}] & {100*r.share_adv_ge_005:.1f}\\% [{100*r.adv_lo:.1f}, {100*r.adv_hi:.1f}] & {100*r.share_worse_ge_001:.1f}\\%\\\\")
cc = jr["concentration"]; tr = jr["tree"]
out.append("\\bottomrule\\end{tabular}\\end{table}\n")
out.append(f"Concentration (continuous design): the 10\\%, 25\\% and 50\\% of cells with the largest advantage contribute {100*cc['share_of_total_advantage_top_10pct_cells']:.0f}\\%, {100*cc['share_of_total_advantage_top_25pct_cells']:.0f}\\% and {100*cc['share_of_total_advantage_top_50pct_cells']:.0f}\\% of the total advantage. "
           f"Surrogate tree (depth 3, class: advantage below 0.05, base rate {tr['base_rate_class1']:.3f}): in-sample accuracy {tr['in_sample_accuracy']:.3f} (balanced {tr['in_sample_balanced']:.3f}); grouped 5-fold cross-validated accuracy {tr['cv_accuracy']:.3f} (balanced {tr['cv_balanced']:.3f}); majority-class accuracy {tr['majority_accuracy']:.3f}; root split on the sparse topology in {tr['root_split'][0]['count']} of 200 bootstrap resamples. "
           f"Sobol indices of the paired difference sum to {jr['sobol']['sum_S1_d']:.2f} (first order) and {jr['sobol']['sum_ST_d']:.2f} (total).\n")
si = pd.read_csv(os.path.join(JR, "sobol_interactions.csv"))
out.append("\\begin{table}[!h]\\centering\\caption{Sobol indices of the paired difference (reference topology, Saltelli $N=256$) and the interaction share $S_T-S_1$}\\small\\begin{tabular}{@{}lrrr@{}}\\toprule Parameter & $S_1$ & $S_T$ & $S_T-S_1$\\\\\\midrule")
for _, r in si.sort_values("ST_d", ascending=False).iterrows():
    out.append(f"{tex(r.parameter)} & {r.S1_d:.3f} & {r.ST_d:.3f} & {r.interaction_d:.3f}\\\\")
out.append("\\bottomrule\\end{tabular}\\end{table}\n")
bs = pd.read_csv(os.path.join(JR, "by_attacker_stealth.csv")); bt = pd.read_csv(os.path.join(JR, "by_topology.csv"))
out.append("\\begin{table}[!h]\\centering\\caption{Continuous design by attacker-stealth tertile and by topology family}\\small\\begin{tabular}{@{}lrrrr@{}}\\toprule Group & Cells & Mean diff. & Lower & $\\le-0.05$\\\\\\midrule")
for _, r in bs.iterrows():
    out.append(f"$\\mu_{{mal}}$ {tex(r.mu_tertile)} & {r.n_cells:.0f} & {r.mean_d:+.3f} & {100*r.share_lower:.1f}\\% & {100*r.share_adv_ge_005:.1f}\\%\\\\")
out.append("\\midrule")
for _, r in bt.iterrows():
    out.append(f"{tex(r.topology)} & {r.n_cells:.0f} & {r.mean_d:+.3f} & {100*r.share_lower:.1f}\\% & {100*r.share_adv_ge_005:.1f}\\%\\\\")
out.append("\\bottomrule\\end{tabular}\\end{table}\n\\begin{figure}[!h]\\centering\\includegraphics[width=0.9\\textwidth]{figs/fig_joint_robustness_v5.pdf}\\caption{Joint design: (a) distribution of cell differences; (b) by attacker stealth; (c) alternate parameter ranges (dark: reduction $\\ge0.05$; light: lower but $<0.05$).}\\label{sfig:jointrob}\\end{figure}\n\\clearpage\n")
es = pd.read_csv(D("Processed", "statistics_effect_sizes_v5.csv")); es = es[es.baseline == "zt_prov"]
out.append("{\\scriptsize\\begin{longtable}{@{}llrrrrrr@{}}\\caption{Graph-level paired differences \\ztas{} $-$ ZT+prov (E1, 30 graphs per family): effect size and Bonferroni-adjusted simultaneous 95\\% intervals over the nine families}\\label{stab:effsize}\\\\\\toprule Topology & Profile & Mean & SD (graphs) & $d_z$ & Graphs $\\le-0.05$ & 95\\% CI & Simultaneous CI\\\\\\midrule")
for _, r in es.iterrows():
    out.append(f"{tex(r.topology)} & {r.profile} & {r.mean_diff:+.3f} & {r.sd_graph:.3f} & {r.d_z:.2f} & {100*r.share_graphs_reduction_ge_005:.0f}\\% & [{r.ci95_lo:.3f}, {r.ci95_hi:.3f}] & [{r.ci_sim_lo:.3f}, {r.ci_sim_hi:.3f}]\\\\")
ts = pd.read_csv(D("Processed", "statistics_threshold_sensitivity_v5.csv"))
out.append("\\bottomrule\\end{longtable}}\nShare of joint continuous cells with a reduction of at least the threshold: " + "; ".join(f"{r.threshold:g}: {100*r.share_cells_reduction_ge:.1f}\\%" for _, r in ts.iterrows()) + ".\n")
ms = pd.read_csv(D("Processed", "risk_engine_missingness", "missingness_signal.csv"))
m2 = ms[(ms.mu_mal == 55) & (ms.q_a.isin([0.0, 0.9]))]
out.append("{\\scriptsize\\begin{longtable}{@{}llrrlrr@{}}\\caption{Missing telemetry as a signal (synthetic; $\\mu_{mal}=55$; step-up tier). $o$: probability of a correlated legitimate outage removing the behavioral and system components; withholding: attacker suppresses both (B+S) or only B with probability $q_a$}\\label{stab:miss}\\\\\\toprule Family & Rule & $o$ & $q_a$ & Withholding & FPR & TPR\\\\\\midrule")
for _, r in m2.sort_values(["family", "rule", "legit_outage", "q_a", "withhold"]).iterrows():
    out.append(f"{tex(r.family)} & {tex(r.rule)} & {r.legit_outage:g} & {r.q_a:g} & {'B+S' if r.withhold == 'both' else 'B only'} & {r.FPR:.3f} & {r.TPR:.3f}\\\\")
out.append("\\bottomrule\\end{longtable}}\n\\clearpage\n")
gr = pd.read_csv(D("Processed", "graded_response_summary.csv")); gl = pd.read_csv(D("Processed", "graded_response_legitimate.csv"))
out.append("{\\scriptsize\\begin{longtable}{@{}llrrrr@{}}\\caption{Graded responses at 1000 requests/s (10 graphs $\\times$ 30 runs; paired difference in compromised entities relative to isolation at $\\kappa=3$, graph-cluster bootstrap)}\\label{stab:graded}\\\\\\toprule Profile & Policy & Compromised & Difference [95\\% CI] & Contained before $\\mathsf{O}$ & Entities degraded\\\\\\midrule")
for _, r in gr[gr.rate == 1000].iterrows():
    out.append(f"{tex(r.profile)} & {tex(r.policy)} & {r.mean_compromised:.1f} & {r.diff_vs_revised:+.1f} [{r.diff_lo:+.1f}, {r.diff_hi:+.1f}] & {r.contained_before_O:.3f} & {r.mean_degraded:.1f}\\\\")
out.append("\\bottomrule\\end{longtable}}\n")
g1 = gl[gl.rate == 1].pivot_table(index=["cls", "scenario"], columns="policy", values="degraded_per_shift").reset_index()
out.append("\\begin{table}[!h]\\centering\\caption{Legitimate entities placed under a graded measure at least once per 8-h shift (1 request/s; no graded policy isolated any legitimate entity)}\\small\\begin{tabular}{@{}llrrrr@{}}\\toprule Class & Scores & Monitor & Priv. reduce & Rate limit & Graded\\\\\\midrule")
for _, r in g1.iterrows():
    out.append(f"{tex(r.cls)} & {tex(r.scenario)} & {r.monitor:.3f} & {r.priv_reduce:.3f} & {r.rate_limit:.3f} & {r.graded:.3f}\\\\")
out.append("\\bottomrule\\end{tabular}\\end{table}\n\\begin{figure}[!h]\\centering\\includegraphics[width=0.9\\textwidth]{figs/fig_graded_response.pdf}\\caption{Graded responses: (a) compromised entities by policy and attacker profile; (b) legitimate entities degraded or isolated per shift.}\\label{sfig:graded}\\end{figure}\n\\clearpage\n")
tlc = _json.load(open(os.path.join(R, "src", "formal", "tla", "logs", "tlc_M1_results.json")))["runs"] + _json.load(open(os.path.join(R, "src", "formal", "tla", "logs", "tlc_M4fg_results.json"))) + _json.load(open(os.path.join(R, "src", "formal", "tla", "logs", "tlc_M5_results.json")))
out.append("\\begin{table}[!h]\\centering\\caption{TLC re-check of TLA+ transcriptions (\\texttt{src/formal/tla/}; tla2tools rolling build of the v1.8.0 line, TLC2 version 2026.11.19, git bc1b506, jar SHA-256 fdffef24\\ldots6713; OpenJDK 21). Distinct states are compared with the Python checker where the property holds. COST: a state with an availability cost is expected to be reachable}\\label{stab:tlc}\\small\\begin{tabular}{@{}llllrr@{}}\\toprule Model & Configuration & Expected & TLC & TLC states & Python states\\\\\\midrule")
for r in tlc:
    out.append(f"{tex(r['model'])} & {tex(r['config']).replace('S=Delta=2', '$\\Delta_{{st}}=\\Delta=2$').replace('S=4 $>$ Delta', '$\\Delta_{{st}}=4>\\Delta$').replace('S=4 > Delta', '$\\Delta_{{st}}=4>\\Delta$').replace('(S=2)', '($\\Delta_{{st}}=2$)').replace('COST: S=2,', 'COST: $\\Delta_{{st}}=2$,')} & {r['expected']} & {r['result']} & {r['distinct_states']} & {r['python_states'] if r['python_states'] else '--'}\\\\")
out.append("\\bottomrule\\end{tabular}\\end{table}\n")
tj = pd.read_csv(E("05_POC_Integration", "poc_TJ_extended_v5.csv"))
out.append("\\begin{table}[!h]\\centering\\caption{T-J extended to 15 rounds per variant (8 threads $\\times$ 30 requests per round; 50-ms widened check-to-forward window)}\\label{stab:tjext}\\small\\begin{tabular}{@{}lrrrrr@{}}\\toprule Variant & Rounds & Requests & Allowed & Forwarded after expiry & Max. lateness (ms)\\\\\\midrule")
for _, r in tj.iterrows():
    out.append(f"{tex(r.variant)} & {r.rounds} & {r.requests} & {r.allowed} & {r.forwarded_after_expiry} & {r.max_lateness_ms:.2f}\\\\")
out.append("\\bottomrule\\end{tabular}\\end{table}\n")
import glob as _g
L5 = _json.load(open(E("05_POC_Integration", "raw_v5", "L_v5_freshness_off.json")))["result"]; L4 = _json.load(open(E("05_POC_Integration", "raw_v5", "L_v4control.json")))["result"]
M5 = _json.load(open(E("05_POC_Integration", "raw_v5", "M_v5.json")))["result"]; M4 = _json.load(open(E("05_POC_Integration", "raw_v5", "M_v4control.json")))["result"]
N5 = _json.load(open(E("05_POC_Integration", "raw_v5", "N_v5_freshness_off.json")))["result"]; N4 = _json.load(open(E("05_POC_Integration", "raw_v5", "N_v4control.json")))["result"]
rows = [("T-L forwarded without allow", L5["forwarded_without_allow"], L4["forwarded_without_allow"]), ("T-L requests without decision record", L5["requests_without_record"], L4["requests_without_record"]),
        ("T-L record/response mismatch", L5["record_decision_mismatch"], L4["record_decision_mismatch"]), ("T-L deny events logged", L5["deny_events_total"], L4["deny_events_total"])]
for k in ["fresh_ts", "stale_60s", "no_ts"]:
    rows.append((f"T-M {k.replace('_', ' ')}", f"{M5[k]['decision']} (r={M5[k]['risk']:.1f})", f"{M4[k]['decision']} (r={M4[k]['risk']:.1f})"))
for ph in ["before", "twin_down", "after_restart"]:
    rows.append((f"T-N {ph.replace('_', ' ')}", "; ".join(f"{k} x{v}" for k, v in N5[ph]["outcomes"].items()), "; ".join(f"{k} x{v}" for k, v in N4[ph]["outcomes"].items())))
out.append("{\\scriptsize\\begin{longtable}{@{}p{4.2cm}p{5.6cm}p{5.6cm}@{}}\\caption{Audit and degraded-operation tests: v5 prototype (decision audit on; context freshness bound 5 s for T-M) versus the v4 prototype}\\label{stab:pocv5}\\\\\\toprule Test & v5 & v4 (control)\\\\\\midrule")
for a, b, c in rows:
    out.append(f"{tex(a)} & {tex(b)} & {tex(c)}\\\\")
out.append("\\bottomrule\\end{longtable}}\n")
cr = pd.read_csv(E("06_Crypto_Benchmark", "crypto_rerun_v5_comparison.csv"))
out.append("{\\scriptsize\\begin{longtable}{@{}lrrr@{}}\\caption{Cryptographic micro-benchmark re-run during this revision (same script, same VM class) against the archived run: medians in $\\mu$s}\\label{stab:cryptorerun}\\\\\\toprule Operation & Archived & Re-run & Ratio\\\\\\midrule")
for _, r in cr.iterrows():
    out.append(f"{tex(r.operation)} & {r.archived_median_us:.1f} & {r.rerun_20261121_median_us:.1f} & {r.ratio:.2f}\\\\")
out.append("\\bottomrule\\end{longtable}}\n\\clearpage\n")

# ---------------- v6 analyses
sec("Additional analyses of this revision (v6)")
ts = pd.read_csv(D("Processed", "topology_statistics_v6", "topology_statistics_per_graph.csv")).drop(columns="graph").groupby("topology", sort=False).mean()
out.append("{\\scriptsize\\begin{longtable}{@{}lrrrrrrrrrr@{}}\\caption{Structure of the synthetic topology families (means over the 30 E1 graphs per family; out-degree CV: coefficient of variation; gate share: flows crossing a phase or owner boundary; O reach: share of entry points from which an operations entity is reachable; hops: shortest path from an entry point to operations). Synthetic; not fitted to any plant}\\label{stab:topostats}\\\\\\toprule Family & Nodes & Flows & Density & Mean out & Max out & Out CV & Clustering & Gate share & O reach & Hops\\\\\\midrule")
for t, r in ts.iterrows():
    out.append(f"{tex(t)} & {r.nodes:.0f} & {r.edges:.0f} & {r.density:.3f} & {r.mean_out:.2f} & {r.max_out:.1f} & {r.cv_out:.2f} & {r.clustering:.2f} & {r.gate_boundary_share:.2f} & {r.entry_reaches_O:.2f} & {r.hops_entry_to_O:.2f}\\\\")
out.append("\\bottomrule\\end{longtable}}\n")
fc = pd.read_csv(D("Processed", "factorial_ablation_v6", "cell_means.csv")); fk = pd.read_csv(D("Processed", "factorial_ablation_v6", "contributions.csv"))
order = ["zt", "zt_prov", "zt_seg", "zt_risk", "ztas_no_risk", "ztas_no_seg", "ztas_no_prov", "ztas"]
hd = ["ZT", "+P", "+S", "+R", "+P+S", "+P+R", "+S+R", "+P+S+R"]
out.append("{\\scriptsize\\begin{longtable}{@{}llrrrrrrrrrrrr@{}}\\caption{Factorial ablation over provenance gates (P), flow-scoped segments (S) and the risk engine (R) on top of static ZT (revised evidence rule; 30 graphs $\\times$ 50 runs per family; same seeds as E1). Left: mean fraction compromised. Right: Shapley contribution of each mechanism to the reduction relative to static ZT, and the interaction (total reduction minus the sum of single-mechanism reductions) with 95\\% graph-bootstrap CI}\\label{stab:factorial}\\\\\\toprule Profile & Family & " + " & ".join(hd) + " & $\\phi_P$ & $\\phi_S$ & $\\phi_R$ & Interaction\\\\\\midrule")
for (prof, topo), d in fc.groupby(["profile", "topology"], sort=False):
    v = d.set_index("config").frac; k = fk[(fk.profile == prof) & (fk.topology == topo)].iloc[0]
    out.append(f"{prof} & {tex(topo)} & " + " & ".join(f"{v[c]:.2f}" for c in order) + f" & {k.shapley_prov:.3f} & {k.shapley_seg:.3f} & {k.shapley_risk:.3f} & {k.interaction:+.3f} [{k.interaction_lo:+.3f}, {k.interaction_hi:+.3f}]\\\\")
out.append("\\bottomrule\\end{longtable}}\n")
cj = _json.load(open(D("Processed", "factorial_ablation_v6", "consistency.json")))
out.append("Consistency check: the ZT, ZT+provenance and \\ztas{} cells reproduce the archived E1 results on the same seeds exactly (" + ", ".join(f"{tex(k)}: {v['rows']} rows, max.\\ abs.\\ difference {v['max_abs_diff_frac']:g}" for k, v in cj.items()) + ").\n")
zm = pd.read_csv(D("Processed", "baseline_fairness_v6", "zones_monitoring_summary.csv"))
out.append("\\begin{table}[!h]\\centering\\caption{Baseline fairness: static zones with the same generic monitoring as the ZT baselines ($d=0.05$), stealthy attacker, E1 graphs and seeds. Differences with 95\\% graph-bootstrap CIs}\\label{stab:zonesmon}\\scriptsize\\begin{tabular}{@{}lrrrrrlll@{}}\\toprule Family & Zones & Zones+mon. & ZT & ZT+prov & \\ztas{} & Zones+mon.$-$zones & ZT+prov$-$zones+mon. & \\ztas{}$-$zones+mon.\\\\\\midrule")
for _, r in zm.iterrows():
    out.append(f"{tex(r.topology)} & {r.zones:.3f} & {r.zones_mon:.3f} & {r.zt:.3f} & {r.zt_prov:.3f} & {r.ztas:.3f} & {r.mon_minus_zones:+.3f} [{r.mon_minus_zones_lo:+.3f}, {r.mon_minus_zones_hi:+.3f}] & {r.ztprov_minus_zonesmon:+.3f} [{r.ztprov_minus_zonesmon_lo:+.3f}, {r.ztprov_minus_zonesmon_hi:+.3f}] & {r.ztas_minus_zonesmon:+.3f} [{r.ztas_minus_zonesmon_lo:+.3f}, {r.ztas_minus_zonesmon_hi:+.3f}]\\\\")
out.append("\\bottomrule\\end{tabular}\\end{table}\n")
ba = pd.read_csv(E("13_Baseline_Fairness", "baseline_audit.csv"))
out.append("{\\scriptsize\\begin{longtable}{@{}p{1.5cm}p{2.6cm}p{1.6cm}p{1.6cm}p{1.6cm}p{1.6cm}p{2.0cm}p{2.1cm}@{}}\\caption{Baseline comparison audit (E1). All configurations use the same graphs, seeds, horizon and attacker draws (common random numbers) and the same metrics}\\label{stab:baselineaudit}\\\\\\toprule Baseline & Description and mechanisms & Assumptions & Configuration & Strengths & Conditions & Potential bias & Corrective action\\\\\\midrule")
for _, r in ba.iterrows():
    out.append(" & ".join(tex(x) for x in [r.baseline, r.description_and_mechanisms, r.assumptions, r.configuration, r.strengths, r.evaluation_conditions, r.potential_bias, r.corrective_action]) + "\\\\")
out.append("\\bottomrule\\end{longtable}}\n")
m5 = _json.load(open(os.path.join(R, "src", "formal", "logs", "model_check_v6_results.json")))
out.append("\\begin{table}[!h]\\centering\\caption{Model M5 (Python checker): distributed revocation (M5a) and replay across gates (M5b)}\\label{stab:m5}\\scriptsize\\begin{tabular}{@{}llllr@{}}\\toprule Model & Configuration & Expected & Result & States\\\\\\midrule")
for r in m5:
    out.append(f"{r['model']} & {tex(r['config']).replace('S=Delta=2', '$\\Delta_{{st}}=\\Delta=2$').replace('S=4 $>$ Delta', '$\\Delta_{{st}}=4>\\Delta$').replace('S=4 > Delta', '$\\Delta_{{st}}=4>\\Delta$').replace('(S=2)', '($\\Delta_{{st}}=2$)').replace('COST: S=2,', 'COST: $\\Delta_{{st}}=2$,')} & {r['expected']} & {r['result']} & {r['states']}\\\\")
out.append("\\bottomrule\\end{tabular}\\end{table}\n")
rm = pd.read_csv(E("14_Deployment_Roadmap", "deployment_roadmap.csv"))
out.append("{\\scriptsize\\setlength{\\tabcolsep}{3pt}\\begin{longtable}{@{}p{0.4cm}p{1.5cm}p{1.9cm}p{1.8cm}p{1.6cm}p{1.6cm}p{1.5cm}p{1.8cm}p{1.6cm}p{1.5cm}@{}}\\caption{Proposed incremental deployment roadmap (not executed). Phases 1--4 change no access decision}\\label{stab:roadmap}\\\\\\toprule Phase & Name & Objective & Prerequisites & Components & Security risks & Operational risks & Validation & Success criteria & Limitations\\\\\\midrule")
for _, r in rm.iterrows():
    out.append(" & ".join(tex(x) for x in [r.phase, r["name"], r.objective, r.prerequisites, r.components, r.security_risks, r.operational_risks, r.validation, r.success_criteria, r.limitations]) + "\\\\")
out.append("\\bottomrule\\end{longtable}}\n\\clearpage\n")

# ---------------- v7 analyses
sec("Additional analyses of this revision (v7)")
fi = pd.read_csv(D("Processed", "e1_fidelity_v7", "stepup_decrement_summary.csv"))
out.append("{\\scriptsize\\begin{longtable}{@{}llrrlrl@{}}\\caption{E1 fidelity check: \\ztas{} (revised rule) with and without the Eq.~(2) decrement after a passed step-up, on the E1 graphs and seeds. Difference = with $-$ without; margin = \\ztas{} (with decrement) $-$ ZT+provenance; 95\\% graph-bootstrap CIs}\\label{stab:fidelity}\\\\\\toprule Family & Profile & Without & With & Difference & Margin & Graphs favouring \\ztas{}\\\\\\midrule")
for _, r in fi.iterrows():
    out.append(f"{tex(r.topology)} & {r.profile} & {r.frac_rec:.3f} & {r.frac_dec:.3f} & {r['diff']:+.4f} [{r.diff_lo:+.4f}, {r.diff_hi:+.4f}] & {r.adv_dec:+.3f} & {r.graphs_dec_better_than_ztprov:.2f}\\\\")
out.append("\\bottomrule\\end{longtable}}\n")
fx = pd.read_csv(D("Processed", "factorial_ablation_v6", "factorial_effects_v7.csv"))
out.append("{\\scriptsize\\setlength{\\tabcolsep}{3pt}\\begin{longtable}{@{}llrrrrrrrrrrr@{}}\\caption{Factorial effects (reduction in fraction compromised; positive = mechanism helps) and order dependence of attribution. Main: average effect of a mechanism over the four settings of the other two. Interactions: negative = overlap (redundancy), positive = reinforcement. Marginal: smallest and largest reduction a mechanism adds over the six orders in which P, S and R can be introduced}\\label{stab:factorialfx}\\\\\\toprule Family & Profile & Main P & Main S & Main R & P$\\times$S & P$\\times$R & S$\\times$R & P$\\times$S$\\times$R & Marg.\\ P & Marg.\\ S & Marg.\\ R\\\\\\midrule")
for _, r in fx.iterrows():
    out.append(f"{tex(r.topology)} & {r.profile} & {r.main_prov:.3f} & {r.main_seg:.3f} & {r.main_risk:.3f} & {r.int_prov_seg:+.3f} & {r.int_prov_risk:+.3f} & {r.int_seg_risk:+.3f} & {r.int_prov_seg_risk:+.3f} & {r.marg_min_prov:.2f}--{r.marg_max_prov:.2f} & {r.marg_min_seg:.2f}--{r.marg_max_seg:.2f} & {r.marg_min_risk:.2f}--{r.marg_max_risk:.2f}\\\\")
out.append("\\bottomrule\\end{longtable}}\n")
ws = pd.read_csv(D("Processed", "risk_engine_v7", "weights_summary.csv"))
out.append("{\\scriptsize\\begin{longtable}{@{}llrrrrrrr@{}}\\caption{Alternative risk weights (synthetic; 1000 Dirichlet draws per row; step-up tier). c20: concentration 20 around the production weights; uniform: arbitrary weights on the simplex. False/true: false escalations per true one at 0.1\\% prevalence}\\label{stab:riskv7}\\\\\\toprule Family & $\\mu_{mal}$ / scheme & AUC prod. & AUC 5\\% & AUC median & AUC 95\\% & Share $>$ prod. & False/true prod. & False/true median\\\\\\midrule")
for _, r in ws.iterrows():
    out.append(f"{tex(r.family)} & {r.mu_mal} / {'c20' if 'c20' in r.scheme else 'uniform'} & {r.auc_prod:.3f} & {r.auc_p05:.3f} & {r.auc_med:.3f} & {r.auc_p95:.3f} & {r.share_auc_above_prod:.2f} & {r.fpt_prod:.1f} & {r.fpt_med:.1f}\\\\")
out.append("\\bottomrule\\end{longtable}}\n")
ms = pd.read_csv(D("Processed", "risk_engine_v7", "manipulation_staleness.csv"))
mm = ms[ms.study == "mimicry"].pivot_table(index=["family", "mu_mal", "components"], columns="level", values="TPR").reset_index()
out.append("\\begin{table}[!h]\\centering\\caption{Manipulated telemetry (mimicry): step-up rate (TPR at $\\theta_1$) of malicious requests when the attacker supplies legitimate-looking values for the listed components with probability $q_m$ (FPR unchanged)}\\label{stab:mimicry}\\scriptsize\\begin{tabular}{@{}lllrrrr@{}}\\toprule Family & $\\mu_{mal}$ & Components & $q_m=0$ & 0.25 & 0.5 & 0.9\\\\\\midrule")
for _, r in mm.iterrows():
    out.append(f"{tex(r.family)} & {r.mu_mal} & {tex(r.components)} & {r[0.0]:.3f} & {r[0.25]:.3f} & {r[0.5]:.3f} & {r[0.9]:.3f}\\\\")
out.append("\\bottomrule\\end{tabular}\\end{table}\n")
st = ms[ms.study == "stale"]
out.append("{\\scriptsize\\begin{longtable}{@{}lrrrrrrr@{}}\\caption{Stale telemetry: malicious behavioral and system components are stale with probability $q_s$, legitimate ones with probability $o_s$. Accept: stale values used as fresh. Freshness: stale components treated as missing and imputed with 50 (PoC test T-M)}\\label{stab:stale}\\\\\\toprule Family & $\\mu_{mal}$ & $q_s$ & $o_s$ & TPR accept & TPR freshness & FPR accept & FPR freshness\\\\\\midrule")
for (fam, mu, qs, os_), d in st.groupby(["family", "mu_mal", "level", "legit_stale"]):
    a = d[d.rule == "accept"].iloc[0]; f = d[d.rule == "freshness"].iloc[0]
    out.append(f"{tex(fam)} & {mu} & {qs:g} & {os_:g} & {a.TPR:.3f} & {f.TPR:.3f} & {a.FPR:.3f} & {f.FPR:.3f}\\\\")
out.append("\\bottomrule\\end{longtable}}\n")
ps = pd.read_csv(D("Processed", "crypto_v7", "pqc_sizes.csv")); pm = pd.read_csv(D("Processed", "crypto_v7", "pqc_memory.csv")); po = pd.read_csv(D("Processed", "crypto_v7", "provenance_overhead.csv"))
out.append("\\begin{table}[!h]\\centering\\caption{Sizes in bytes measured from the library objects (pqcrypto 1.0.0; cryptography 50.0.1), and per-record provenance overhead of ML-DSA-65 signatures derived from them (32-byte hashes). Process-level peak resident set was "
           + f"{pm.peak_rss_kib_median.iloc[0]:,} KiB in every run, including the baseline without cryptographic operations (5 runs each), so the operations' memory use is below the resolution of this measurement"
           + "}\\label{stab:pqcsizes}\\scriptsize\\begin{tabular}{@{}llrrr@{\\hspace{1.2cm}}rrr@{}}\\toprule Algorithm & Kind & Public key & Secret key & Sig./ct. & Batch $B$ & Signature share & Proof\\\\\\midrule")
for i in range(max(len(ps), len(po))):
    a = ps.iloc[i] if i < len(ps) else None; b = po.iloc[i] if i < len(po) else None
    left = f"{a.algorithm} & {a.kind} & {a.public_key} & {a.secret_key} & {a.signature_or_ciphertext}" if a is not None else " & & & & "
    right = f"{b.batch_size} & {b.per_record_signature_share_bytes:.1f} & {b.inclusion_proof_bytes}" if b is not None else " & & "
    out.append(left + " & " + right + "\\\\")
out.append("\\bottomrule\\end{tabular}\\end{table}\n\\clearpage\n")
# ---------------- reproducibility
sec("Reproducibility")
rp = E("09_Reproducibility", "reproduction_checklist.csv")
if os.path.exists(rp):
    c = pd.read_csv(rp)
    out.append("{\\scriptsize\\begin{longtable}{@{}p{3.2cm}p{3.4cm}p{2.6cm}p{6.2cm}@{}}\\caption{Reproduction of principal results from a clean checkout of release v1.0.0 and from the revision package}\\\\\\toprule Experiment & Source script & Status & Result of reproduction\\\\\\midrule")
    for _, r in c.iterrows():
        out.append(f"{tex(r.experiment)} & {tex(r.source_script).replace('/', '/\\allowbreak{}')} & {tex(r.status)} & {tex(r.reproduced)}\\\\")
    out.append("\\bottomrule\\end{longtable}}\n")
rr = pd.concat([pd.read_csv(E("09_Reproducibility", "rerun_subset_joint_v4.csv")).rename(columns={"unit": "task"}).assign(task=lambda d: "joint " + d.task), pd.read_csv(E("09_Reproducibility", "rerun_subset_other_v4.csv"))])
out.append("\\begin{table}[!h]\\centering\\caption{Deterministic re-execution of archived tasks from scratch (v4)}\\label{stab:rerun}\\small\\begin{tabular}{@{}lrrr@{}}\\toprule Task & Rows & Max. abs. difference & Within $10^{-9}$\\\\\\midrule")
for _, r in rr.iterrows():
    out.append(f"{tex(r.task)} & {r.rows_matched} & {r.max_abs_diff:.1e} & {'yes' if r['within_1e-9'] else 'no'}\\\\")
out.append("\\bottomrule\\end{tabular}\\end{table}\nNon-zero differences arise only from writing floating-point values to CSV text and reading them back.\n")
out.append("\\end{document}\n")
open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "supplement.tex"), "w").write("\n".join(out))
print("ok")
