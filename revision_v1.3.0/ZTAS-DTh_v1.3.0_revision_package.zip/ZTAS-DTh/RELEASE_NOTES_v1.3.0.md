# ZTAS-DTh release v1.3.0

This release archives every analysis reported in manuscript revisions v5–v7 that was not part of v1.2.0
(doi:10.5281/zenodo.24386844). Archived scripts that were later modified (`src/dth_sim.py`,
`01_Experiments/05_POC_Integration/poc_failure_tests.py`) were changed additively only. Re-runs reproduce the
v1.2.0 E1 results exactly on the same seeds (`02_Data/Processed/factorial_ablation_v6/consistency.json`,
`02_Data/Processed/baseline_fairness_v6/consistency.json`). The manuscript source of v7 is in `06_Manuscript/v7`.

## Added since v1.2.0
- v5: alternate parameter ranges, surrogate validation, missing telemetry as a signal, monitoring step-up rate,
  graded responses, TLA+ transcriptions of M1/M4f/M4g checked with TLC, PoC tests T-L to T-N and extended T-J,
  effect sizes and simultaneous CIs, cryptographic re-run.
- v6: 2^3 factorial ablation (216,000 simulations), zones-with-monitoring fairness check, topology statistics,
  models M5a/M5b (Python + TLC), deployment roadmap, baseline audit.
- v7: risk-engine weight perturbation, manipulated and stale telemetry; factorial effects and order dependence of
  attribution; E1 fidelity check with the Eq. (2) step-up decrement; PQC sizes, process memory and per-record
  provenance overhead.

## Environment
Python 3.13; numpy, pandas, networkx, scipy, matplotlib; pqcrypto 1.0.0; cryptography 50.0.1;
OpenJDK 21 and tla2tools.jar (TLC2 2026.11.19, git bc1b506, sha256 fdffef247f563ef6edbfd44958d2a82db79e7564e07cb673262d896353fa6713) for the TLC runs.
All numbers in the manuscript are checked by `08_Final_Reports/number_check.py` (307/307 at packaging time).

## Evidence type
Simulation with assumed parameters, synthetic score distributions, server-VM micro-benchmarks, bounded model
checking of abstract models, and a single-host software proof of concept. No industrial data or deployment.
