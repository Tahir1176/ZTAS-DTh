"""
Bounded model checking, revision v6: distributed enforcement (reviewer concern 9).
Re-uses the BFS checker of model_check.py. Earlier models (M1-M4g) are unchanged.

  M5a  Revocation across two PEPs that may be partitioned from the identity provider (IdP).
       Each PEP holds a local copy of the revocation list, refreshes it from the IdP when connected
       (a connected PEP must refresh at least every R ticks), and applies a staleness bound S:
       if its copy is older than S it denies (fails closed).
       Property P6-dist: no PEP allows a request of a revoked principal more than DELTA ticks after revocation.
       Cost witness: a request of a principal that was never revoked is denied (expected to be reachable
       under partition when the staleness bound is enforced).
  M5b  Replay of one provenance record to two gates (adversary forwards a copy to the second gate).
       Modes: 'local'  each gate keeps its own seen-set;
              'shared' gates use one atomic shared seen-set and deny when it is unreachable;
              'failopen' shared seen-set, but a gate that cannot reach it falls back to its local set.
       Property P3-dist: the record is accepted at most once across gates.
       Cost witness: the genuine record is denied before it has been accepted anywhere.
Bounds: clock <= TMAX, two PEPs/gates, one principal, one record.
Usage: python3 model_check_v6.py logs/model_check_v6_results.json > logs/model_check_v6.log
"""
import json, sys, time
from model_check import bfs, fmt_trace

TMAX, DELTA, R = 6, 2, 1
NOBOUND = 100          # "no staleness bound"


# M5a state: (clk, tr, known0, known1, last0, last1, part0, part1, viol, denied_legit); tr = -1 if not revoked
def m5a(S):
    init = (0, -1, False, False, 0, 0, False, False, False, False)

    def succ(s):
        clk, tr, k0, k1, l0, l1, p0, p1, viol, dl = s
        known, last, part = [k0, k1], [l0, l1], [p0, p1]
        out = []

        def mk(clk=clk, tr=tr, known=known, last=last, part=part, viol=viol, dl=dl):
            return (clk, tr, known[0], known[1], last[0], last[1], part[0], part[1], viol, dl)
        if clk < TMAX and not any((not part[i]) and clk - last[i] >= R for i in range(2)):
            out.append(("tick", mk(clk=clk + 1)))
        if tr == -1:
            out.append(("revoke", mk(tr=clk)))
        for i in range(2):
            if not part[i]:
                k2 = list(known); k2[i] = tr != -1; l2 = list(last); l2[i] = clk
                out.append((f"refresh{i}", mk(known=k2, last=l2)))
                p2 = list(part); p2[i] = True; out.append((f"partition{i}", mk(part=p2)))
            else:
                p2 = list(part); p2[i] = False; out.append((f"heal{i}", mk(part=p2)))
            allow = (not known[i]) and (clk - last[i] <= S)
            v2 = viol or (allow and tr != -1 and clk - tr > DELTA)
            d2 = dl or ((not allow) and tr == -1)
            out.append((f"request{i}", mk(viol=v2, dl=d2)))
        return out
    return init, succ


# M5b state: (reach0, reach1, seen_shared, local0, local1, pend0, pend1, accepted, denied_unseen)
def m5b(mode):
    init = (True, True, False, False, False, True, True, 0, False)

    def succ(s):
        r0, r1, sh, lo0, lo1, pe0, pe1, acc, du = s
        reach, local, pend = [r0, r1], [lo0, lo1], [pe0, pe1]
        out = []

        def mk(reach=reach, sh=sh, local=local, pend=pend, acc=acc, du=du):
            return (reach[0], reach[1], sh, local[0], local[1], pend[0], pend[1], acc, du)
        for i in range(2):
            rr = list(reach); rr[i] = not reach[i]
            out.append((("cut" if reach[i] else "restore") + str(i), mk(reach=rr)))
            if pend[i]:
                sh2, lo2 = sh, list(local)
                if mode == "local":
                    ok = not local[i]; lo2[i] = True
                elif mode == "shared":
                    ok = reach[i] and not sh
                    if reach[i]: sh2 = True
                else:  # failopen
                    if reach[i]:
                        ok = not sh; sh2 = True; lo2[i] = True
                    else:
                        ok = not local[i]; lo2[i] = True
                pe2 = list(pend); pe2[i] = False
                out.append((f"process{i}", mk(sh=sh2, local=lo2, pend=pe2, acc=min(acc + int(ok), 2),
                                             du=du or ((not ok) and acc == 0))))
        return out
    return init, succ


if __name__ == "__main__":
    runs = []

    def rec(model, cfg, expect, res, bounds):
        res = dict(res); tr = res.pop("trace", None)
        ok = (res["result"] == "OK") == (expect == "OK")
        runs.append(dict(model=model, config=cfg, expected=expect, bounds=bounds, **res, matches_expectation=ok,
                         counterexample=fmt_trace(tr, 20) if tr else None))
        print(f"[{model}] {cfg}: {res['result']} {res.get('invariant','')} states={res.get('states')} distinct={res.get('distinct')} expected={expect} -> {'PASS' if ok else 'UNEXPECTED'}")
        if tr:
            for x in fmt_trace(tr, 20): print("    ", x)
    t0 = time.time()
    B = f"clock<={TMAX}, Delta={DELTA}, refresh<={R}, 2 PEPs"
    safe = {"no_allow_beyond_delta_after_revocation": lambda s: not s[8]}
    avail = {"no_denial_of_unrevoked_principal": lambda s: not s[9]}
    rec("M5a", "staleness bound S=Delta=2, fail closed when stale", "OK", bfs(*m5a(2), safe), B)
    rec("M5a", "NEG: no staleness bound (partitioned PEP keeps cached list)", "VIOLATION", bfs(*m5a(NOBOUND), safe), B)
    rec("M5a", "NEG: staleness bound S=4 > Delta", "VIOLATION", bfs(*m5a(4), safe), B)
    rec("M5a", "COST: S=2, unrevoked principal denied under partition", "VIOLATION", bfs(*m5a(2), avail), B)
    B2 = "2 gates, 1 record replayed to both, store reachability toggles"
    once = {"accepted_at_most_once": lambda s: s[7] <= 1}
    rec("M5b", "shared atomic seen-set, deny if unreachable", "OK", bfs(*m5b("shared"), once), B2)
    rec("M5b", "NEG: per-gate local seen-sets", "VIOLATION", bfs(*m5b("local"), once), B2)
    rec("M5b", "NEG: shared seen-set, fail open to local set when unreachable", "VIOLATION", bfs(*m5b("failopen"), once), B2)
    rec("M5b", "COST: shared, genuine record denied while store unreachable", "VIOLATION",
        bfs(*m5b("shared"), {"genuine_record_never_denied": lambda s: not s[8]}), B2)
    print(f"total time {time.time()-t0:.2f}s; all match expectation: {all(r['matches_expectation'] for r in runs)}")
    json.dump(runs, open(sys.argv[1] if len(sys.argv) > 1 else "logs/model_check_v6_results.json", "w"), indent=1, default=str)
