--------------------------- MODULE ProvenanceGateM1 ---------------------------
(***************************************************************************)
(* TLA+ transcription of model M1 (provenance gate) of model_check.py,     *)
(* written to match the Python successor function step for step, so that   *)
(* TLC can independently re-check the M1 results (v5 revision round).      *)
(* Messages: seq, payload ("g" genuine / "b" attacker), key epoch, sv       *)
(* (signature verifies under that epoch's key), au (produced by the honest  *)
(* gateway; ground truth not visible to the verifier).                      *)
(* The verifier does not remove processed messages from the channel, so    *)
(* replay and reordering are possible.                                     *)
(***************************************************************************)
EXTENDS Naturals, Sequences, FiniteSets

CONSTANTS N, CheckSeq, CheckSig, CheckRev, AllowKeyCompromise, MaxAcc

VARIABLES nxt, ch, kc, rev, ep, last, acc, alarm, revviol

vars == <<nxt, ch, kc, rev, ep, last, acc, alarm, revviol>>

M(s, p, e, sv, au) == [seq |-> s, pl |-> p, ep |-> e, sv |-> sv, au |-> au]

Init == /\ nxt = 1 /\ ch = {} /\ kc = FALSE /\ rev = {} /\ ep = 0
        /\ last = 0 /\ acc = <<>> /\ alarm = FALSE /\ revviol = FALSE

\* honest gateway signs the next record
Sign == /\ nxt <= N
        /\ ch' = ch \cup {M(nxt, "g", ep, TRUE, TRUE)}
        /\ nxt' = nxt + 1
        /\ UNCHANGED <<kc, rev, ep, last, acc, alarm, revviol>>

\* adversary replaces genuine content; the signature verifies only if the key is compromised
Tamper(m) == /\ m.pl = "g"
             /\ ch' = (ch \ {m}) \cup {M(m.seq, "b", m.ep, kc /\ m.ep = ep, FALSE)}
             /\ UNCHANGED <<nxt, kc, rev, ep, last, acc, alarm, revviol>>

Drop(m) == /\ ch' = ch \ {m}
           /\ UNCHANGED <<nxt, kc, rev, ep, last, acc, alarm, revviol>>

\* strict sequence mode: a gap raises an alarm and the record is held
GapAlarm(m) == /\ CheckSeq /\ m.seq # last + 1
               /\ alarm' = TRUE
               /\ UNCHANGED <<nxt, ch, kc, rev, ep, last, acc, revviol>>

Ok(m) == /\ (CheckSig => m.sv)
         /\ (CheckRev => m.ep \notin rev)
         /\ (CheckSeq => m.seq = last + 1)

Accept(m) == /\ Ok(m)
             /\ Len(acc) < MaxAcc
             /\ acc' = Append(acc, m)
             /\ last' = IF m.seq > last THEN m.seq ELSE last
             /\ revviol' = (revviol \/ m.ep \in rev)   \* accepted after its epoch was revoked
             /\ UNCHANGED <<nxt, ch, kc, rev, ep, alarm>>

Compromise == /\ AllowKeyCompromise /\ ~kc /\ kc' = TRUE
              /\ UNCHANGED <<nxt, ch, rev, ep, last, acc, alarm, revviol>>

\* attacker injects arbitrary content signed under the compromised epoch
Inject(s) == /\ kc /\ M(s, "b", ep, TRUE, FALSE) \notin ch
             /\ ch' = ch \cup {M(s, "b", ep, TRUE, FALSE)}
             /\ UNCHANGED <<nxt, kc, rev, ep, last, acc, alarm, revviol>>

\* detection: revoke the compromised epoch and rekey (one rekey in the bound)
RevokeRekey == /\ kc /\ ep \notin rev /\ ep < 1
               /\ rev' = rev \cup {ep} /\ ep' = ep + 1 /\ kc' = FALSE
               /\ UNCHANGED <<nxt, ch, last, acc, alarm, revviol>>

Next == \/ Sign \/ Compromise \/ RevokeRekey
        \/ \E m \in ch : Tamper(m) \/ Drop(m) \/ GapAlarm(m) \/ Accept(m)
        \/ \E s \in 1..N : Inject(s)

Spec == Init /\ [][Next]_vars

\* ---------------- properties (invariants) ----------------
Integrity          == \A i \in 1..Len(acc) : acc[i].au
NoReplay           == \A i, j \in 1..Len(acc) : i # j => acc[i].seq # acc[j].seq
InOrder            == \A i \in 1..(Len(acc) - 1) : acc[i].seq < acc[i + 1].seq
RevocationEnforced == ~revviol
TypeOK == /\ nxt \in 1..(N + 1) /\ kc \in BOOLEAN /\ ep \in 0..1 /\ last \in 0..N
=============================================================================
