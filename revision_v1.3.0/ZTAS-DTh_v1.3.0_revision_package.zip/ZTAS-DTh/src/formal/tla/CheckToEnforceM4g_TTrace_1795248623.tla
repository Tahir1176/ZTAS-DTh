---- MODULE CheckToEnforceM4g_TTrace_1795248623 ----
EXTENDS Sequences, TLCExt, Toolbox, Naturals, TLC, CheckToEnforceM4g

_expression ==
    LET CheckToEnforceM4g_TEExpression == INSTANCE CheckToEnforceM4g_TEExpression
    IN CheckToEnforceM4g_TEExpression!expression
----

_trace ==
    LET CheckToEnforceM4g_TETrace == INSTANCE CheckToEnforceM4g_TETrace
    IN CheckToEnforceM4g_TETrace!trace
----

_inv ==
    ~(
        TLCGet("level") = Len(_TETrace)
        /\
        q = (TRUE)
        /\
        viol = (TRUE)
        /\
        k = (TRUE)
        /\
        req = ((0 :> "done" @@ 1 :> "new"))
    )
----

_init ==
    /\ k = _TETrace[1].k
    /\ req = _TETrace[1].req
    /\ q = _TETrace[1].q
    /\ viol = _TETrace[1].viol
----

_next ==
    /\ \E i,j \in DOMAIN _TETrace:
        /\ \/ /\ j = i + 1
              /\ i = TLCGet("level")
        /\ k  = _TETrace[i].k
        /\ k' = _TETrace[j].k
        /\ req  = _TETrace[i].req
        /\ req' = _TETrace[j].req
        /\ q  = _TETrace[i].q
        /\ q' = _TETrace[j].q
        /\ viol  = _TETrace[i].viol
        /\ viol' = _TETrace[j].viol

\* Uncomment the ASSUME below to write the states of the error trace
\* to the given file in Json format. Note that you can pass any tuple
\* to `JsonSerialize`. For example, a sub-sequence of _TETrace.
    \* ASSUME
    \*     LET J == INSTANCE Json
    \*         IN J!JsonSerialize("CheckToEnforceM4g_TTrace_1795248623.json", _TETrace)

=============================================================================

 Note that you can extract this module `CheckToEnforceM4g_TEExpression`
  to a dedicated file to reuse `expression` (the module in the 
  dedicated `CheckToEnforceM4g_TEExpression.tla` file takes precedence 
  over the module `CheckToEnforceM4g_TEExpression` below).

---- MODULE CheckToEnforceM4g_TEExpression ----
EXTENDS Sequences, TLCExt, Toolbox, Naturals, TLC, CheckToEnforceM4g

expression == 
    [
        \* To hide variables of the `CheckToEnforceM4g` spec from the error trace,
        \* remove the variables below.  The trace will be written in the order
        \* of the fields of this record.
        k |-> k
        ,req |-> req
        ,q |-> q
        ,viol |-> viol
        
        \* Put additional constant-, state-, and action-level expressions here:
        \* ,_stateNumber |-> _TEPosition
        \* ,_kUnchanged |-> k = k'
        
        \* Format the `k` variable as Json value.
        \* ,_kJson |->
        \*     LET J == INSTANCE Json
        \*     IN J!ToJson(k)
        
        \* Lastly, you may build expressions over arbitrary sets of states by
        \* leveraging the _TETrace operator.  For example, this is how to
        \* count the number of times a spec variable changed up to the current
        \* state in the trace.
        \* ,_kModCount |->
        \*     LET F[s \in DOMAIN _TETrace] ==
        \*         IF s = 1 THEN 0
        \*         ELSE IF _TETrace[s].k # _TETrace[s-1].k
        \*             THEN 1 + F[s-1] ELSE F[s-1]
        \*     IN F[_TEPosition - 1]
    ]

=============================================================================



Parsing and semantic processing can take forever if the trace below is long.
 In this case, it is advised to uncomment the module below to deserialize the
 trace from a generated binary file.

\*
\*---- MODULE CheckToEnforceM4g_TETrace ----
\*EXTENDS IOUtils, TLC, CheckToEnforceM4g
\*
\*trace == IODeserialize("CheckToEnforceM4g_TTrace_1795248623.bin", TRUE)
\*
\*=============================================================================
\*

---- MODULE CheckToEnforceM4g_TETrace ----
EXTENDS TLC, CheckToEnforceM4g

trace == 
    <<
    ([q |-> FALSE,viol |-> FALSE,k |-> FALSE,req |-> (0 :> "new" @@ 1 :> "new")]),
    ([q |-> FALSE,viol |-> FALSE,k |-> FALSE,req |-> (0 :> "allow" @@ 1 :> "new")]),
    ([q |-> TRUE,viol |-> FALSE,k |-> FALSE,req |-> (0 :> "allow" @@ 1 :> "new")]),
    ([q |-> TRUE,viol |-> FALSE,k |-> TRUE,req |-> (0 :> "allow" @@ 1 :> "new")]),
    ([q |-> TRUE,viol |-> TRUE,k |-> TRUE,req |-> (0 :> "done" @@ 1 :> "new")])
    >>
----


=============================================================================

---- CONFIG CheckToEnforceM4g_TTrace_1795248623 ----
CONSTANTS
    Recheck = FALSE

INVARIANT
    _inv

CHECK_DEADLOCK
    \* CHECK_DEADLOCK off because of PROPERTY or INVARIANT above.
    FALSE

INIT
    _init

NEXT
    _next

CONSTANT
    _TETrace <- _trace

ALIAS
    _expression
=============================================================================
\* Generated on Sat Nov 21 13:10:24 PKT 2026