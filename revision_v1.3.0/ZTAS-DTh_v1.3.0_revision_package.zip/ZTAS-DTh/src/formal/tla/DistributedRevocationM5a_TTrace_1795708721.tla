---- MODULE DistributedRevocationM5a_TTrace_1795708721 ----
EXTENDS Sequences, TLCExt, Toolbox, Naturals, TLC, DistributedRevocationM5a

_expression ==
    LET DistributedRevocationM5a_TEExpression == INSTANCE DistributedRevocationM5a_TEExpression
    IN DistributedRevocationM5a_TEExpression!expression
----

_trace ==
    LET DistributedRevocationM5a_TETrace == INSTANCE DistributedRevocationM5a_TETrace
    IN DistributedRevocationM5a_TETrace!trace
----

_inv ==
    ~(
        TLCGet("level") = Len(_TETrace)
        /\
        clk = (3)
        /\
        last = ((0 :> 0 @@ 1 :> 0))
        /\
        known = ((0 :> FALSE @@ 1 :> FALSE))
        /\
        part = ((0 :> TRUE @@ 1 :> TRUE))
        /\
        viol = (FALSE)
        /\
        dl = (TRUE)
        /\
        tr = (-1)
    )
----

_init ==
    /\ clk = _TETrace[1].clk
    /\ part = _TETrace[1].part
    /\ tr = _TETrace[1].tr
    /\ last = _TETrace[1].last
    /\ known = _TETrace[1].known
    /\ viol = _TETrace[1].viol
    /\ dl = _TETrace[1].dl
----

_next ==
    /\ \E i,j \in DOMAIN _TETrace:
        /\ \/ /\ j = i + 1
              /\ i = TLCGet("level")
        /\ clk  = _TETrace[i].clk
        /\ clk' = _TETrace[j].clk
        /\ part  = _TETrace[i].part
        /\ part' = _TETrace[j].part
        /\ tr  = _TETrace[i].tr
        /\ tr' = _TETrace[j].tr
        /\ last  = _TETrace[i].last
        /\ last' = _TETrace[j].last
        /\ known  = _TETrace[i].known
        /\ known' = _TETrace[j].known
        /\ viol  = _TETrace[i].viol
        /\ viol' = _TETrace[j].viol
        /\ dl  = _TETrace[i].dl
        /\ dl' = _TETrace[j].dl

\* Uncomment the ASSUME below to write the states of the error trace
\* to the given file in Json format. Note that you can pass any tuple
\* to `JsonSerialize`. For example, a sub-sequence of _TETrace.
    \* ASSUME
    \*     LET J == INSTANCE Json
    \*         IN J!JsonSerialize("DistributedRevocationM5a_TTrace_1795708721.json", _TETrace)

=============================================================================

 Note that you can extract this module `DistributedRevocationM5a_TEExpression`
  to a dedicated file to reuse `expression` (the module in the 
  dedicated `DistributedRevocationM5a_TEExpression.tla` file takes precedence 
  over the module `DistributedRevocationM5a_TEExpression` below).

---- MODULE DistributedRevocationM5a_TEExpression ----
EXTENDS Sequences, TLCExt, Toolbox, Naturals, TLC, DistributedRevocationM5a

expression == 
    [
        \* To hide variables of the `DistributedRevocationM5a` spec from the error trace,
        \* remove the variables below.  The trace will be written in the order
        \* of the fields of this record.
        clk |-> clk
        ,part |-> part
        ,tr |-> tr
        ,last |-> last
        ,known |-> known
        ,viol |-> viol
        ,dl |-> dl
        
        \* Put additional constant-, state-, and action-level expressions here:
        \* ,_stateNumber |-> _TEPosition
        \* ,_clkUnchanged |-> clk = clk'
        
        \* Format the `clk` variable as Json value.
        \* ,_clkJson |->
        \*     LET J == INSTANCE Json
        \*     IN J!ToJson(clk)
        
        \* Lastly, you may build expressions over arbitrary sets of states by
        \* leveraging the _TETrace operator.  For example, this is how to
        \* count the number of times a spec variable changed up to the current
        \* state in the trace.
        \* ,_clkModCount |->
        \*     LET F[s \in DOMAIN _TETrace] ==
        \*         IF s = 1 THEN 0
        \*         ELSE IF _TETrace[s].clk # _TETrace[s-1].clk
        \*             THEN 1 + F[s-1] ELSE F[s-1]
        \*     IN F[_TEPosition - 1]
    ]

=============================================================================



Parsing and semantic processing can take forever if the trace below is long.
 In this case, it is advised to uncomment the module below to deserialize the
 trace from a generated binary file.

\*
\*---- MODULE DistributedRevocationM5a_TETrace ----
\*EXTENDS IOUtils, TLC, DistributedRevocationM5a
\*
\*trace == IODeserialize("DistributedRevocationM5a_TTrace_1795708721.bin", TRUE)
\*
\*=============================================================================
\*

---- MODULE DistributedRevocationM5a_TETrace ----
EXTENDS TLC, DistributedRevocationM5a

trace == 
    <<
    ([clk |-> 0,last |-> (0 :> 0 @@ 1 :> 0),known |-> (0 :> FALSE @@ 1 :> FALSE),part |-> (0 :> FALSE @@ 1 :> FALSE),viol |-> FALSE,dl |-> FALSE,tr |-> -1]),
    ([clk |-> 1,last |-> (0 :> 0 @@ 1 :> 0),known |-> (0 :> FALSE @@ 1 :> FALSE),part |-> (0 :> FALSE @@ 1 :> FALSE),viol |-> FALSE,dl |-> FALSE,tr |-> -1]),
    ([clk |-> 1,last |-> (0 :> 0 @@ 1 :> 0),known |-> (0 :> FALSE @@ 1 :> FALSE),part |-> (0 :> TRUE @@ 1 :> FALSE),viol |-> FALSE,dl |-> FALSE,tr |-> -1]),
    ([clk |-> 1,last |-> (0 :> 0 @@ 1 :> 0),known |-> (0 :> FALSE @@ 1 :> FALSE),part |-> (0 :> TRUE @@ 1 :> TRUE),viol |-> FALSE,dl |-> FALSE,tr |-> -1]),
    ([clk |-> 2,last |-> (0 :> 0 @@ 1 :> 0),known |-> (0 :> FALSE @@ 1 :> FALSE),part |-> (0 :> TRUE @@ 1 :> TRUE),viol |-> FALSE,dl |-> FALSE,tr |-> -1]),
    ([clk |-> 3,last |-> (0 :> 0 @@ 1 :> 0),known |-> (0 :> FALSE @@ 1 :> FALSE),part |-> (0 :> TRUE @@ 1 :> TRUE),viol |-> FALSE,dl |-> FALSE,tr |-> -1]),
    ([clk |-> 3,last |-> (0 :> 0 @@ 1 :> 0),known |-> (0 :> FALSE @@ 1 :> FALSE),part |-> (0 :> TRUE @@ 1 :> TRUE),viol |-> FALSE,dl |-> TRUE,tr |-> -1])
    >>
----


=============================================================================

---- CONFIG DistributedRevocationM5a_TTrace_1795708721 ----
CONSTANTS
    TMAX = 6
    DELTA = 2
    R = 1
    S = 2

INVARIANT
    _inv

CHECK_DEADLOCK
    \* CHECK_DEADLOCK off because of PROPERTY or INVARIANT above.
    FALSE

INIT
    _init

NEXT
    _next

CONSTANT
    _TETrace <- _trace

ALIAS
    _expression
=============================================================================
\* Generated on Thu Nov 26 20:58:43 PKT 2026