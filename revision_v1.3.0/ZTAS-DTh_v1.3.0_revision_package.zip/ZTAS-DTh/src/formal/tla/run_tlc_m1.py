"""
Runs TLC (tla2tools.jar, official TLA+ tools) on ProvenanceGateM1.tla in the same seven configurations as model M1 in
model_check.py and compares the outcome (and, for configurations where the property holds, the number of distinct
states) with the Python explicit-state checker.
Usage: python3 run_tlc_m1.py /path/to/tla2tools.jar
"""
import os, re, sys, json, subprocess, hashlib
HERE = os.path.dirname(os.path.abspath(__file__))
JAR = sys.argv[1]
B = lambda b: "TRUE" if b else "FALSE"
# name, N, CheckSeq, CheckSig, CheckRev, AllowKeyCompromise, invariants, expected, python_states (OK runs only)
CFG = [
    ("full checks, key never compromised", 3, 1, 1, 1, 0, ["Integrity", "NoReplay", "InOrder", "RevocationEnforced"], "OK", 280),
    ("full checks, key compromise allowed (assumption violated)", 2, 1, 1, 1, 1, ["Integrity"], "VIOLATION", None),
    ("full checks, key compromise allowed: replay/order", 2, 1, 1, 1, 1, ["NoReplay", "InOrder"], "OK", 11760),
    ("NEG: no sequence check", 3, 0, 1, 1, 0, ["NoReplay"], "VIOLATION", None),
    ("NEG: no signature check", 3, 1, 0, 1, 0, ["Integrity"], "VIOLATION", None),
    ("revocation enforcement", 2, 1, 1, 1, 1, ["RevocationEnforced"], "OK", 11760),
    ("NEG: no revocation check", 2, 1, 1, 0, 1, ["RevocationEnforced"], "VIOLATION", None),
]
os.makedirs(os.path.join(HERE, "cfg"), exist_ok=True); os.makedirs(os.path.join(HERE, "logs"), exist_ok=True)
ver = subprocess.run(["java", "-cp", JAR, "tlc2.TLC", "-version"], capture_output=True, text=True)
runs = []
for k, (name, n, cs, cg, cr, ak, inv, exp, pys) in enumerate(CFG, 1):
    cfg = os.path.join(HERE, "cfg", f"M1_{k}.cfg")
    open(cfg, "w").write(f"CONSTANTS\n  N = {n}\n  CheckSeq = {B(cs)}\n  CheckSig = {B(cg)}\n  CheckRev = {B(cr)}\n"
                         f"  AllowKeyCompromise = {B(ak)}\n  MaxAcc = {n + 1}\nSPECIFICATION Spec\n" + "".join(f"INVARIANT {i}\n" for i in inv))
    p = subprocess.run(["java", "-XX:+UseParallelGC", "-cp", JAR, "tlc2.TLC", "-deadlock", "-workers", "1", "-config", cfg,
                        "-metadir", os.path.join("/tmp", f"tlc_states_{k}"), "ProvenanceGateM1.tla"], cwd=HERE, capture_output=True, text=True)
    out = p.stdout + p.stderr
    open(os.path.join(HERE, "logs", f"tlc_M1_{k}.log"), "w").write(out)
    viol = re.search(r"Error: Invariant (\w+) is violated", out)
    ok = "Model checking completed. No error has been found." in out
    m = re.search(r"(\d[\d,]*) states generated, (\d[\d,]*) distinct states found", out)
    distinct = int(m.group(2).replace(",", "")) if m else None
    depth = re.search(r"depth of the complete state graph search is (\d+)", out)
    res = "OK" if ok else ("VIOLATION" if viol else "ERROR")
    runs.append(dict(model="M1 (TLA+)", config=name, N=n, invariants=" ".join(inv), expected=exp, result=res,
                     violated=viol.group(1) if viol else "", distinct_states=distinct, depth=int(depth.group(1)) if depth else None,
                     python_states=pys, states_match_python=(distinct == pys) if pys else None, matches_expectation=res == exp))
    print(runs[-1], flush=True)
json.dump(dict(tool="TLC " + (ver.stdout + ver.stderr).strip().splitlines()[-1] if (ver.stdout + ver.stderr).strip() else "TLC",
               jar_sha256=hashlib.sha256(open(JAR, "rb").read()).hexdigest(), runs=runs),
          open(os.path.join(HERE, "logs", "tlc_M1_results.json"), "w"), indent=1)
print("all match:", all(r["matches_expectation"] for r in runs))
