---- MODULE CheckToEnforceM4f_TTrace_1795248622 ----
EXTENDS Sequences, TLCExt, Toolbox, Naturals, TLC, CheckToEnforceM4f

_expression ==
    LET CheckToEnforceM4f_TEExpression == INSTANCE CheckToEnforceM4f_TEExpression
    IN CheckToEnforceM4f_TEExpression!expression
----

_trace ==
    LET CheckToEnforceM4f_TETrace == INSTANCE CheckToEnforceM4f_TETrace
    IN CheckToEnforceM4f_TETrace!trace
----

_inv ==
    ~(
        TLCGet("level") = Len(_TETrace)
        /\
        clk = (1)
        /\
        hasExp = (TRUE)
        /\
        viol = (TRUE)
        /\
        exp = (1)
        /\
        req = ((0 :> "done" @@ 1 :> "new"))
    )
----

_init ==
    /\ clk = _TETrace[1].clk
    /\ exp = _TETrace[1].exp
    /\ hasExp = _TETrace[1].hasExp
    /\ req = _TETrace[1].req
    /\ viol = _TETrace[1].viol
----

_next ==
    /\ \E i,j \in DOMAIN _TETrace:
        /\ \/ /\ j = i + 1
              /\ i = TLCGet("level")
        /\ clk  = _TETrace[i].clk
        /\ clk' = _TETrace[j].clk
        /\ exp  = _TETrace[i].exp
        /\ exp' = _TETrace[j].exp
        /\ hasExp  = _TETrace[i].hasExp
        /\ hasExp' = _TETrace[j].hasExp
        /\ req  = _TETrace[i].req
        /\ req' = _TETrace[j].req
        /\ viol  = _TETrace[i].viol
        /\ viol' = _TETrace[j].viol

\* Uncomment the ASSUME below to write the states of the error trace
\* to the given file in Json format. Note that you can pass any tuple
\* to `JsonSerialize`. For example, a sub-sequence of _TETrace.
    \* ASSUME
    \*     LET J == INSTANCE Json
    \*         IN J!JsonSerialize("CheckToEnforceM4f_TTrace_1795248622.json", _TETrace)

=============================================================================

 Note that you can extract this module `CheckToEnforceM4f_TEExpression`
  to a dedicated file to reuse `expression` (the module in the 
  dedicated `CheckToEnforceM4f_TEExpression.tla` file takes precedence 
  over the module `CheckToEnforceM4f_TEExpression` below).

---- MODULE CheckToEnforceM4f_TEExpression ----
EXTENDS Sequences, TLCExt, Toolbox, Naturals, TLC, CheckToEnforceM4f

expression == 
    [
        \* To hide variables of the `CheckToEnforceM4f` spec from the error trace,
        \* remove the variables below.  The trace will be written in the order
        \* of the fields of this record.
        clk |-> clk
        ,exp |-> exp
        ,hasExp |-> hasExp
        ,req |-> req
        ,viol |-> viol
        
        \* Put additional constant-, state-, and action-level expressions here:
        \* ,_stateNumber |-> _TEPosition
        \* ,_clkUnchanged |-> clk = clk'
        
        \* Format the `clk` variable as Json value.
        \* ,_clkJson |->
        \*     LET J == INSTANCE Json
        \*     IN J!ToJson(clk)
        
        \* Lastly, you may build expressions over arbitrary sets of states by
        \* leveraging the _TETrace operator.  For example, this is how to
        \* count the number of times a spec variable changed up to the current
        \* state in the trace.
        \* ,_clkModCount |->
        \*     LET F[s \in DOMAIN _TETrace] ==
        \*         IF s = 1 THEN 0
        \*         ELSE IF _TETrace[s].clk # _TETrace[s-1].clk
        \*             THEN 1 + F[s-1] ELSE F[s-1]
        \*     IN F[_TEPosition - 1]
    ]

=============================================================================



Parsing and semantic processing can take forever if the trace below is long.
 In this case, it is advised to uncomment the module below to deserialize the
 trace from a generated binary file.

\*
\*---- MODULE CheckToEnforceM4f_TETrace ----
\*EXTENDS IOUtils, TLC, CheckToEnforceM4f
\*
\*trace == IODeserialize("CheckToEnforceM4f_TTrace_1795248622.bin", TRUE)
\*
\*=============================================================================
\*

---- MODULE CheckToEnforceM4f_TETrace ----
EXTENDS TLC, CheckToEnforceM4f

trace == 
    <<
    ([clk |-> 0,hasExp |-> FALSE,viol |-> FALSE,exp |-> 0,req |-> (0 :> "new" @@ 1 :> "new")]),
    ([clk |-> 0,hasExp |-> TRUE,viol |-> FALSE,exp |-> 1,req |-> (0 :> "new" @@ 1 :> "new")]),
    ([clk |-> 0,hasExp |-> TRUE,viol |-> FALSE,exp |-> 1,req |-> (0 :> "chkT" @@ 1 :> "new")]),
    ([clk |-> 1,hasExp |-> TRUE,viol |-> FALSE,exp |-> 1,req |-> (0 :> "chkT" @@ 1 :> "new")]),
    ([clk |-> 1,hasExp |-> TRUE,viol |-> TRUE,exp |-> 1,req |-> (0 :> "done" @@ 1 :> "new")])
    >>
----


=============================================================================

---- CONFIG CheckToEnforceM4f_TTrace_1795248622 ----
CONSTANTS
    TMAX = 4
    Recheck = FALSE

INVARIANT
    _inv

CHECK_DEADLOCK
    \* CHECK_DEADLOCK off because of PROPERTY or INVARIANT above.
    FALSE

INIT
    _init

NEXT
    _next

CONSTANT
    _TETrace <- _trace

ALIAS
    _expression
=============================================================================
\* Generated on Sat Nov 21 13:10:22 PKT 2026