"""Runs TLC on the TLA+ transcriptions of M4f and M4g (positive configuration and negative control) and compares with
model_check_v4.py. Usage: python3 run_tlc_m4fg.py /path/to/tla2tools.jar"""
import os, re, sys, json, subprocess
HERE = os.path.dirname(os.path.abspath(__file__)); JAR = sys.argv[1]
CFG = [("M4f", "CheckToEnforceM4f", "segment validity re-checked at enforcement", "TMAX = 4\n  Recheck = TRUE", "NoDeliveryOnExpiredSegment", "OK", 250),
       ("M4f", "CheckToEnforceM4f", "NEG: segment checked only before enforcement", "TMAX = 4\n  Recheck = FALSE", "NoDeliveryOnExpiredSegment", "VIOLATION", None),
       ("M4g", "CheckToEnforceM4g", "quarantine status re-checked at enforcement", "Recheck = TRUE", "NoDeliveryAfterQuarantineAcknowledged", "OK", 41),
       ("M4g", "CheckToEnforceM4g", "NEG: decision enforced without quarantine re-check", "Recheck = FALSE", "NoDeliveryAfterQuarantineAcknowledged", "VIOLATION", None)]
runs = []
for k, (mod, spec, name, consts, inv, exp, pys) in enumerate(CFG, 1):
    cfg = os.path.join(HERE, "cfg", f"{mod}_{k}.cfg"); os.makedirs(os.path.dirname(cfg), exist_ok=True)
    open(cfg, "w").write(f"CONSTANTS\n  {consts}\nSPECIFICATION Spec\nINVARIANT {inv}\n")
    p = subprocess.run(["java", "-cp", JAR, "tlc2.TLC", "-deadlock", "-workers", "1", "-config", cfg, "-metadir", f"/tmp/tlc_{mod}_{k}", spec + ".tla"], cwd=HERE, capture_output=True, text=True)
    out = p.stdout + p.stderr; open(os.path.join(HERE, "logs", f"tlc_{mod}_{k}.log"), "w").write(out)
    v = re.search(r"Error: Invariant (\w+) is violated", out); ok = "No error has been found" in out
    m = re.search(r"(\d[\d,]*) distinct states found", out); d = int(m.group(1).replace(",", "")) if m else None
    res = "OK" if ok else ("VIOLATION" if v else "ERROR")
    runs.append(dict(model=mod + " (TLA+)", config=name, expected=exp, result=res, distinct_states=d, python_states=pys,
                     states_match_python=(d == pys) if pys else None, matches_expectation=res == exp)); print(runs[-1])
json.dump(runs, open(os.path.join(HERE, "logs", "tlc_M4fg_results.json"), "w"), indent=1)
print("all match:", all(r["matches_expectation"] for r in runs))
