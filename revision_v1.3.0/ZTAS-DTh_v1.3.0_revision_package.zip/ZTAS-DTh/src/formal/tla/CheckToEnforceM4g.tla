--------------------------- MODULE CheckToEnforceM4g ---------------------------
(* TLA+ transcription of model M4g (model_check_v4.py): a quarantine is       *)
(* committed between the PDP decision and enforcement; two in-flight requests.*)
EXTENDS Naturals
CONSTANTS Recheck
VARIABLES q, k, req, viol
vars == <<q, k, req, viol>>
R == {0, 1}
Init == q = FALSE /\ k = FALSE /\ req = [i \in R |-> "new"] /\ viol = FALSE
Quarantine == ~q /\ q' = TRUE /\ UNCHANGED <<k, req, viol>>
Ack == q /\ ~k /\ k' = TRUE /\ UNCHANGED <<q, req, viol>>
Decide(i) == req[i] = "new" /\ req' = [req EXCEPT ![i] = IF ~q THEN "allow" ELSE "deny"] /\ UNCHANGED <<q, k, viol>>
Enforce(i) == req[i] \in {"allow", "deny"}
              /\ LET a == req[i] = "allow" /\ (Recheck => ~k) IN viol' = (viol \/ (a /\ k))
              /\ req' = [req EXCEPT ![i] = "done"] /\ UNCHANGED <<q, k>>
Next == Quarantine \/ Ack \/ \E i \in R : Decide(i) \/ Enforce(i)
Spec == Init /\ [][Next]_vars
NoDeliveryAfterQuarantineAcknowledged == ~viol
=============================================================================
