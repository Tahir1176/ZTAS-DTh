--------------------------- MODULE CrossGateReplayM5b ---------------------------
(* TLA+ transcription of model M5b (model_check_v6.py): one provenance record   *)
(* replayed to two gates; seen-state local, shared, or shared with fail-open.   *)
EXTENDS Integers
CONSTANTS Mode
VARIABLES reach, sh, local, pend, acc, du
vars == <<reach, sh, local, pend, acc, du>>
G == {0, 1}
Min(a, b) == IF a < b THEN a ELSE b
Init == reach = [i \in G |-> TRUE] /\ sh = FALSE /\ local = [i \in G |-> FALSE]
        /\ pend = [i \in G |-> TRUE] /\ acc = 0 /\ du = FALSE
Toggle(i) == reach' = [reach EXCEPT ![i] = ~reach[i]] /\ UNCHANGED <<sh, local, pend, acc, du>>
Ok(i) == CASE Mode = "local"  -> ~local[i]
           [] Mode = "shared" -> reach[i] /\ ~sh
           [] OTHER           -> IF reach[i] THEN ~sh ELSE ~local[i]
NewSh(i) == IF Mode = "local" THEN sh ELSE (IF reach[i] THEN TRUE ELSE sh)
NewLocal(i) == IF Mode = "shared" THEN local ELSE [local EXCEPT ![i] = TRUE]
Process(i) == pend[i]
              /\ sh' = NewSh(i) /\ local' = NewLocal(i) /\ pend' = [pend EXCEPT ![i] = FALSE]
              /\ acc' = Min(acc + (IF Ok(i) THEN 1 ELSE 0), 2)
              /\ du' = (du \/ (~Ok(i) /\ acc = 0))
              /\ UNCHANGED reach
Next == \E i \in G : Toggle(i) \/ Process(i)
Spec == Init /\ [][Next]_vars
AcceptedAtMostOnce == acc <= 1
GenuineRecordNeverDenied == ~du
=============================================================================
