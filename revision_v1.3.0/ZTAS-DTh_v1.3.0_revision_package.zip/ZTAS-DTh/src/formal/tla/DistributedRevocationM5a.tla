------------------------- MODULE DistributedRevocationM5a -------------------------
(* TLA+ transcription of model M5a (model_check_v6.py): revocation across two   *)
(* PEPs that may be partitioned from the IdP. tr = -1 means "not revoked".     *)
EXTENDS Integers
CONSTANTS TMAX, DELTA, R, S
VARIABLES clk, tr, known, last, part, viol, dl
vars == <<clk, tr, known, last, part, viol, dl>>
P == {0, 1}
Init == clk = 0 /\ tr = -1 /\ known = [i \in P |-> FALSE] /\ last = [i \in P |-> 0]
        /\ part = [i \in P |-> FALSE] /\ viol = FALSE /\ dl = FALSE
Tick == clk < TMAX /\ ~(\E i \in P : ~part[i] /\ clk - last[i] >= R)
        /\ clk' = clk + 1 /\ UNCHANGED <<tr, known, last, part, viol, dl>>
Revoke == tr = -1 /\ tr' = clk /\ UNCHANGED <<clk, known, last, part, viol, dl>>
Refresh(i) == ~part[i] /\ known' = [known EXCEPT ![i] = (tr # -1)] /\ last' = [last EXCEPT ![i] = clk]
              /\ UNCHANGED <<clk, tr, part, viol, dl>>
Partition(i) == ~part[i] /\ part' = [part EXCEPT ![i] = TRUE] /\ UNCHANGED <<clk, tr, known, last, viol, dl>>
Heal(i) == part[i] /\ part' = [part EXCEPT ![i] = FALSE] /\ UNCHANGED <<clk, tr, known, last, viol, dl>>
Request(i) == LET allow == ~known[i] /\ clk - last[i] <= S IN
              /\ viol' = (viol \/ (allow /\ tr # -1 /\ clk - tr > DELTA))
              /\ dl' = (dl \/ (~allow /\ tr = -1))
              /\ UNCHANGED <<clk, tr, known, last, part>>
Next == Tick \/ Revoke \/ \E i \in P : Refresh(i) \/ Partition(i) \/ Heal(i) \/ Request(i)
Spec == Init /\ [][Next]_vars
NoAllowBeyondDeltaAfterRevocation == ~viol
NoDenialOfUnrevokedPrincipal == ~dl
=============================================================================
