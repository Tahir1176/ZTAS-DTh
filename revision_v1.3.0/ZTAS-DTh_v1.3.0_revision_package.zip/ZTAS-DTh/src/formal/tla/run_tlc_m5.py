"""Runs TLC on the TLA+ transcriptions of M5a and M5b and compares with model_check_v6.py.
Usage: python3 run_tlc_m5.py /path/to/tla2tools.jar"""
import os, re, sys, json, subprocess
HERE = os.path.dirname(os.path.abspath(__file__)); JAR = sys.argv[1]
A = "TMAX = 6\n  DELTA = 2\n  R = 1\n  S = {}"
CFG = [("M5a", "DistributedRevocationM5a", "staleness bound S=Delta=2", A.format(2), "NoAllowBeyondDeltaAfterRevocation", "OK", 7336),
       ("M5a", "DistributedRevocationM5a", "NEG: no staleness bound", A.format(100), "NoAllowBeyondDeltaAfterRevocation", "VIOLATION", None),
       ("M5a", "DistributedRevocationM5a", "NEG: S=4 > Delta", A.format(4), "NoAllowBeyondDeltaAfterRevocation", "VIOLATION", None),
       ("M5a", "DistributedRevocationM5a", "COST: unrevoked principal denied (S=2)", A.format(2), "NoDenialOfUnrevokedPrincipal", "VIOLATION", None),
       ("M5b", "CrossGateReplayM5b", "shared atomic seen-set", 'Mode = "shared"', "AcceptedAtMostOnce", "OK", 32),
       ("M5b", "CrossGateReplayM5b", "NEG: per-gate local seen-sets", 'Mode = "local"', "AcceptedAtMostOnce", "VIOLATION", None),
       ("M5b", "CrossGateReplayM5b", "NEG: fail open to local set", 'Mode = "failopen"', "AcceptedAtMostOnce", "VIOLATION", None),
       ("M5b", "CrossGateReplayM5b", "COST: genuine record denied (shared)", 'Mode = "shared"', "GenuineRecordNeverDenied", "VIOLATION", None)]
runs = []
for k, (mod, spec, name, consts, inv, exp, pys) in enumerate(CFG, 1):
    cfg = os.path.join(HERE, "cfg", f"{mod}_{k}.cfg"); os.makedirs(os.path.dirname(cfg), exist_ok=True)
    open(cfg, "w").write(f"CONSTANTS\n  {consts}\nSPECIFICATION Spec\nINVARIANT {inv}\n")
    p = subprocess.run(["java", "-cp", JAR, "tlc2.TLC", "-deadlock", "-workers", "1", "-config", cfg, "-metadir", f"/tmp/tlc_{mod}_{k}", spec + ".tla"], cwd=HERE, capture_output=True, text=True)
    out = p.stdout + p.stderr; os.makedirs(os.path.join(HERE, "logs"), exist_ok=True); open(os.path.join(HERE, "logs", f"tlc_{mod}_{k}.log"), "w").write(out)
    v = re.search(r"Error: Invariant (\w+) is violated", out); ok = "No error has been found" in out
    m = re.search(r"(\d[\d,]*) distinct states found", out); d = int(m.group(1).replace(",", "")) if m else None
    res = "OK" if ok else ("VIOLATION" if v else "ERROR")
    runs.append(dict(model=mod + " (TLA+)", config=name, expected=exp, result=res, distinct_states=d, python_states=pys,
                     states_match_python=(d == pys) if pys else None, matches_expectation=res == exp)); print(runs[-1])
json.dump(runs, open(os.path.join(HERE, "logs", "tlc_M5_results.json"), "w"), indent=1)
print("all match:", all(r["matches_expectation"] for r in runs), "| states match:", all(r["states_match_python"] for r in runs if r["python_states"]))
