---- MODULE ProvenanceGateM1_TTrace_1795248596 ----
EXTENDS Sequences, TLCExt, Toolbox, Naturals, TLC, ProvenanceGateM1

_expression ==
    LET ProvenanceGateM1_TEExpression == INSTANCE ProvenanceGateM1_TEExpression
    IN ProvenanceGateM1_TEExpression!expression
----

_trace ==
    LET ProvenanceGateM1_TETrace == INSTANCE ProvenanceGateM1_TETrace
    IN ProvenanceGateM1_TETrace!trace
----

_inv ==
    ~(
        TLCGet("level") = Len(_TETrace)
        /\
        acc = (<<[ep |-> 0, sv |-> TRUE, au |-> TRUE, seq |-> 1, pl |-> "g"]>>)
        /\
        rev = ({0})
        /\
        last = (1)
        /\
        ch = ({[ep |-> 0, sv |-> TRUE, au |-> TRUE, seq |-> 1, pl |-> "g"]})
        /\
        revviol = (TRUE)
        /\
        alarm = (FALSE)
        /\
        kc = (FALSE)
        /\
        nxt = (2)
        /\
        ep = (1)
    )
----

_init ==
    /\ last = _TETrace[1].last
    /\ nxt = _TETrace[1].nxt
    /\ alarm = _TETrace[1].alarm
    /\ rev = _TETrace[1].rev
    /\ ch = _TETrace[1].ch
    /\ revviol = _TETrace[1].revviol
    /\ acc = _TETrace[1].acc
    /\ kc = _TETrace[1].kc
    /\ ep = _TETrace[1].ep
----

_next ==
    /\ \E i,j \in DOMAIN _TETrace:
        /\ \/ /\ j = i + 1
              /\ i = TLCGet("level")
        /\ last  = _TETrace[i].last
        /\ last' = _TETrace[j].last
        /\ nxt  = _TETrace[i].nxt
        /\ nxt' = _TETrace[j].nxt
        /\ alarm  = _TETrace[i].alarm
        /\ alarm' = _TETrace[j].alarm
        /\ rev  = _TETrace[i].rev
        /\ rev' = _TETrace[j].rev
        /\ ch  = _TETrace[i].ch
        /\ ch' = _TETrace[j].ch
        /\ revviol  = _TETrace[i].revviol
        /\ revviol' = _TETrace[j].revviol
        /\ acc  = _TETrace[i].acc
        /\ acc' = _TETrace[j].acc
        /\ kc  = _TETrace[i].kc
        /\ kc' = _TETrace[j].kc
        /\ ep  = _TETrace[i].ep
        /\ ep' = _TETrace[j].ep

\* Uncomment the ASSUME below to write the states of the error trace
\* to the given file in Json format. Note that you can pass any tuple
\* to `JsonSerialize`. For example, a sub-sequence of _TETrace.
    \* ASSUME
    \*     LET J == INSTANCE Json
    \*         IN J!JsonSerialize("ProvenanceGateM1_TTrace_1795248596.json", _TETrace)

=============================================================================

 Note that you can extract this module `ProvenanceGateM1_TEExpression`
  to a dedicated file to reuse `expression` (the module in the 
  dedicated `ProvenanceGateM1_TEExpression.tla` file takes precedence 
  over the module `ProvenanceGateM1_TEExpression` below).

---- MODULE ProvenanceGateM1_TEExpression ----
EXTENDS Sequences, TLCExt, Toolbox, Naturals, TLC, ProvenanceGateM1

expression == 
    [
        \* To hide variables of the `ProvenanceGateM1` spec from the error trace,
        \* remove the variables below.  The trace will be written in the order
        \* of the fields of this record.
        last |-> last
        ,nxt |-> nxt
        ,alarm |-> alarm
        ,rev |-> rev
        ,ch |-> ch
        ,revviol |-> revviol
        ,acc |-> acc
        ,kc |-> kc
        ,ep |-> ep
        
        \* Put additional constant-, state-, and action-level expressions here:
        \* ,_stateNumber |-> _TEPosition
        \* ,_lastUnchanged |-> last = last'
        
        \* Format the `last` variable as Json value.
        \* ,_lastJson |->
        \*     LET J == INSTANCE Json
        \*     IN J!ToJson(last)
        
        \* Lastly, you may build expressions over arbitrary sets of states by
        \* leveraging the _TETrace operator.  For example, this is how to
        \* count the number of times a spec variable changed up to the current
        \* state in the trace.
        \* ,_lastModCount |->
        \*     LET F[s \in DOMAIN _TETrace] ==
        \*         IF s = 1 THEN 0
        \*         ELSE IF _TETrace[s].last # _TETrace[s-1].last
        \*             THEN 1 + F[s-1] ELSE F[s-1]
        \*     IN F[_TEPosition - 1]
    ]

=============================================================================



Parsing and semantic processing can take forever if the trace below is long.
 In this case, it is advised to uncomment the module below to deserialize the
 trace from a generated binary file.

\*
\*---- MODULE ProvenanceGateM1_TETrace ----
\*EXTENDS IOUtils, TLC, ProvenanceGateM1
\*
\*trace == IODeserialize("ProvenanceGateM1_TTrace_1795248596.bin", TRUE)
\*
\*=============================================================================
\*

---- MODULE ProvenanceGateM1_TETrace ----
EXTENDS TLC, ProvenanceGateM1

trace == 
    <<
    ([acc |-> <<>>,rev |-> {},last |-> 0,ch |-> {},revviol |-> FALSE,alarm |-> FALSE,kc |-> FALSE,nxt |-> 1,ep |-> 0]),
    ([acc |-> <<>>,rev |-> {},last |-> 0,ch |-> {[ep |-> 0, sv |-> TRUE, au |-> TRUE, seq |-> 1, pl |-> "g"]},revviol |-> FALSE,alarm |-> FALSE,kc |-> FALSE,nxt |-> 2,ep |-> 0]),
    ([acc |-> <<>>,rev |-> {},last |-> 0,ch |-> {[ep |-> 0, sv |-> TRUE, au |-> TRUE, seq |-> 1, pl |-> "g"]},revviol |-> FALSE,alarm |-> FALSE,kc |-> TRUE,nxt |-> 2,ep |-> 0]),
    ([acc |-> <<>>,rev |-> {0},last |-> 0,ch |-> {[ep |-> 0, sv |-> TRUE, au |-> TRUE, seq |-> 1, pl |-> "g"]},revviol |-> FALSE,alarm |-> FALSE,kc |-> FALSE,nxt |-> 2,ep |-> 1]),
    ([acc |-> <<[ep |-> 0, sv |-> TRUE, au |-> TRUE, seq |-> 1, pl |-> "g"]>>,rev |-> {0},last |-> 1,ch |-> {[ep |-> 0, sv |-> TRUE, au |-> TRUE, seq |-> 1, pl |-> "g"]},revviol |-> TRUE,alarm |-> FALSE,kc |-> FALSE,nxt |-> 2,ep |-> 1])
    >>
----


=============================================================================

---- CONFIG ProvenanceGateM1_TTrace_1795248596 ----
CONSTANTS
    N = 2
    CheckSeq = TRUE
    CheckSig = TRUE
    CheckRev = FALSE
    AllowKeyCompromise = TRUE
    MaxAcc = 3

INVARIANT
    _inv

CHECK_DEADLOCK
    \* CHECK_DEADLOCK off because of PROPERTY or INVARIANT above.
    FALSE

INIT
    _init

NEXT
    _next

CONSTANT
    _TETrace <- _trace

ALIAS
    _expression
=============================================================================
\* Generated on Sat Nov 21 13:09:57 PKT 2026