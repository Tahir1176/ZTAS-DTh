--------------------------- MODULE CheckToEnforceM4f ---------------------------
(* TLA+ transcription of model M4f (model_check_v4.py): a segment expires    *)
(* between the segment check and enforcement; two concurrent requests.       *)
EXTENDS Naturals
CONSTANTS TMAX, Recheck
VARIABLES clk, hasExp, exp, req, viol
vars == <<clk, hasExp, exp, req, viol>>
R == {0, 1}
Valid(t) == ~hasExp \/ t < exp
Init == clk = 0 /\ hasExp = FALSE /\ exp = 0 /\ req = [i \in R |-> "new"] /\ viol = FALSE
Tick == clk < TMAX /\ clk' = clk + 1 /\ UNCHANGED <<hasExp, exp, req, viol>>
SetExpiry == ~hasExp /\ hasExp' = TRUE /\ exp' = clk + 1 /\ UNCHANGED <<clk, req, viol>>
Check(i) == req[i] = "new" /\ req' = [req EXCEPT ![i] = IF Valid(clk) THEN "chkT" ELSE "chkF"]
            /\ UNCHANGED <<clk, hasExp, exp, viol>>
Enforce(i) == req[i] \in {"chkT", "chkF"}
              /\ LET ok == req[i] = "chkT" /\ (Recheck => Valid(clk)) IN
                 viol' = (viol \/ (ok /\ ~Valid(clk)))
              /\ req' = [req EXCEPT ![i] = "done"] /\ UNCHANGED <<clk, hasExp, exp>>
Next == Tick \/ SetExpiry \/ \E i \in R : Check(i) \/ Enforce(i)
Spec == Init /\ [][Next]_vars
NoDeliveryOnExpiredSegment == ~viol
=============================================================================
