---- MODULE CrossGateReplayM5b_TTrace_1795708728 ----
EXTENDS Sequences, TLCExt, CrossGateReplayM5b, Toolbox, Naturals, TLC

_expression ==
    LET CrossGateReplayM5b_TEExpression == INSTANCE CrossGateReplayM5b_TEExpression
    IN CrossGateReplayM5b_TEExpression!expression
----

_trace ==
    LET CrossGateReplayM5b_TETrace == INSTANCE CrossGateReplayM5b_TETrace
    IN CrossGateReplayM5b_TETrace!trace
----

_inv ==
    ~(
        TLCGet("level") = Len(_TETrace)
        /\
        acc = (0)
        /\
        du = (TRUE)
        /\
        sh = (FALSE)
        /\
        reach = ((0 :> FALSE @@ 1 :> TRUE))
        /\
        local = ((0 :> FALSE @@ 1 :> FALSE))
        /\
        pend = ((0 :> FALSE @@ 1 :> TRUE))
    )
----

_init ==
    /\ sh = _TETrace[1].sh
    /\ reach = _TETrace[1].reach
    /\ pend = _TETrace[1].pend
    /\ acc = _TETrace[1].acc
    /\ du = _TETrace[1].du
    /\ local = _TETrace[1].local
----

_next ==
    /\ \E i,j \in DOMAIN _TETrace:
        /\ \/ /\ j = i + 1
              /\ i = TLCGet("level")
        /\ sh  = _TETrace[i].sh
        /\ sh' = _TETrace[j].sh
        /\ reach  = _TETrace[i].reach
        /\ reach' = _TETrace[j].reach
        /\ pend  = _TETrace[i].pend
        /\ pend' = _TETrace[j].pend
        /\ acc  = _TETrace[i].acc
        /\ acc' = _TETrace[j].acc
        /\ du  = _TETrace[i].du
        /\ du' = _TETrace[j].du
        /\ local  = _TETrace[i].local
        /\ local' = _TETrace[j].local

\* Uncomment the ASSUME below to write the states of the error trace
\* to the given file in Json format. Note that you can pass any tuple
\* to `JsonSerialize`. For example, a sub-sequence of _TETrace.
    \* ASSUME
    \*     LET J == INSTANCE Json
    \*         IN J!JsonSerialize("CrossGateReplayM5b_TTrace_1795708728.json", _TETrace)

=============================================================================

 Note that you can extract this module `CrossGateReplayM5b_TEExpression`
  to a dedicated file to reuse `expression` (the module in the 
  dedicated `CrossGateReplayM5b_TEExpression.tla` file takes precedence 
  over the module `CrossGateReplayM5b_TEExpression` below).

---- MODULE CrossGateReplayM5b_TEExpression ----
EXTENDS Sequences, TLCExt, CrossGateReplayM5b, Toolbox, Naturals, TLC

expression == 
    [
        \* To hide variables of the `CrossGateReplayM5b` spec from the error trace,
        \* remove the variables below.  The trace will be written in the order
        \* of the fields of this record.
        sh |-> sh
        ,reach |-> reach
        ,pend |-> pend
        ,acc |-> acc
        ,du |-> du
        ,local |-> local
        
        \* Put additional constant-, state-, and action-level expressions here:
        \* ,_stateNumber |-> _TEPosition
        \* ,_shUnchanged |-> sh = sh'
        
        \* Format the `sh` variable as Json value.
        \* ,_shJson |->
        \*     LET J == INSTANCE Json
        \*     IN J!ToJson(sh)
        
        \* Lastly, you may build expressions over arbitrary sets of states by
        \* leveraging the _TETrace operator.  For example, this is how to
        \* count the number of times a spec variable changed up to the current
        \* state in the trace.
        \* ,_shModCount |->
        \*     LET F[s \in DOMAIN _TETrace] ==
        \*         IF s = 1 THEN 0
        \*         ELSE IF _TETrace[s].sh # _TETrace[s-1].sh
        \*             THEN 1 + F[s-1] ELSE F[s-1]
        \*     IN F[_TEPosition - 1]
    ]

=============================================================================



Parsing and semantic processing can take forever if the trace below is long.
 In this case, it is advised to uncomment the module below to deserialize the
 trace from a generated binary file.

\*
\*---- MODULE CrossGateReplayM5b_TETrace ----
\*EXTENDS IOUtils, CrossGateReplayM5b, TLC
\*
\*trace == IODeserialize("CrossGateReplayM5b_TTrace_1795708728.bin", TRUE)
\*
\*=============================================================================
\*

---- MODULE CrossGateReplayM5b_TETrace ----
EXTENDS CrossGateReplayM5b, TLC

trace == 
    <<
    ([acc |-> 0,du |-> FALSE,sh |-> FALSE,reach |-> (0 :> TRUE @@ 1 :> TRUE),local |-> (0 :> FALSE @@ 1 :> FALSE),pend |-> (0 :> TRUE @@ 1 :> TRUE)]),
    ([acc |-> 0,du |-> FALSE,sh |-> FALSE,reach |-> (0 :> FALSE @@ 1 :> TRUE),local |-> (0 :> FALSE @@ 1 :> FALSE),pend |-> (0 :> TRUE @@ 1 :> TRUE)]),
    ([acc |-> 0,du |-> TRUE,sh |-> FALSE,reach |-> (0 :> FALSE @@ 1 :> TRUE),local |-> (0 :> FALSE @@ 1 :> FALSE),pend |-> (0 :> FALSE @@ 1 :> TRUE)])
    >>
----


=============================================================================

---- CONFIG CrossGateReplayM5b_TTrace_1795708728 ----
CONSTANTS
    Mode = "shared"

INVARIANT
    _inv

CHECK_DEADLOCK
    \* CHECK_DEADLOCK off because of PROPERTY or INVARIANT above.
    FALSE

INIT
    _init

NEXT
    _next

CONSTANT
    _TETrace <- _trace

ALIAS
    _expression
=============================================================================
\* Generated on Thu Nov 26 20:58:49 PKT 2026