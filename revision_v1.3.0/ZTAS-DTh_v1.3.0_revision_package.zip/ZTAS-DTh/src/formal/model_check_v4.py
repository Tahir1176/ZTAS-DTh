"""
Bounded model checking, revision v4: segment-expiry and quarantine races (concern 4 gap).
Re-uses the BFS checker of model_check.py. M1-M3 (model_check.py) and M4a-e (model_check_v3.py) are unchanged.

  M4f  segment expiry between the segment check and enforcement: two concurrent requests, a segment that
       expires at a nondeterministic tick, enforcement possibly delayed by one tick.
       Property: no delivery at a tick at or after the segment's expiry.
  M4g  quarantine committed between the PDP decision and enforcement for a subject with two in-flight requests.
       Property: no delivery for a subject after its quarantine has been acknowledged to the PEP.
Each has a negative control (no re-check at enforcement). Bounds: clock <= 4, two requests.
Usage: python3 model_check_v4.py logs/model_check_v4_results.json > logs/model_check_v4.log
"""
import json, sys, time
from model_check import bfs, fmt_trace

TMAX = 4


# M4f state: (clk, exp(None|int), req: tuple of ('new'|('checked',ok)|'done'), viol)
def m4f(recheck=True):
    init = (0, None, ("new", "new"), False)

    def succ(s):
        clk, exp, req, viol = s
        out = []
        valid = lambda t: exp is None or t < exp
        if clk < TMAX:
            out.append(("tick", (clk + 1, exp, req, viol)))
        if exp is None:
            out.append(("set_expiry_now_plus1", (clk, clk + 1, req, viol)))
        for i in range(2):
            r = list(req)
            if req[i] == "new":
                r[i] = ("checked", valid(clk)); out.append((f"check_r{i}", (clk, exp, tuple(r), viol)))
            elif isinstance(req[i], tuple):
                ok = req[i][1] and (valid(clk) if recheck else True)
                r[i] = "done"
                out.append((f"enforce_r{i}", (clk, exp, tuple(r), viol or (ok and not valid(clk)))))
        return out

    return init, succ, {"no_delivery_on_expired_segment": lambda s: not s[3]}


# M4g state: (quarantined_at_pdp, pep_knows_quarantine, req: tuple('new'|('decided',allow)|'done'), viol)
def m4g(recheck=True):
    init = (False, False, ("new", "new"), False)

    def succ(s):
        q, k, req, viol = s
        out = []
        if not q: out.append(("pdp_quarantine", (True, k, req, viol)))
        if q and not k: out.append(("pep_ack_quarantine", (q, True, req, viol)))
        for i in range(2):
            r = list(req)
            if req[i] == "new":
                r[i] = ("decided", not q); out.append((f"decide_r{i}", (q, k, tuple(r), viol)))
            elif isinstance(req[i], tuple):
                allow = req[i][1] and (not k if recheck else True)
                r[i] = "done"
                out.append((f"enforce_r{i}", (q, k, tuple(r), viol or (allow and k))))
        return out

    return init, succ, {"no_delivery_after_quarantine_acknowledged": lambda s: not s[3]}


if __name__ == "__main__":
    runs = []

    def rec(model, cfg, expect, res, bounds):
        res = dict(res); tr = res.pop("trace", None)
        ok = (res["result"] == "OK") == (expect == "OK")
        runs.append(dict(model=model, config=cfg, expected=expect, bounds=bounds, **res, matches_expectation=ok,
                         counterexample=fmt_trace(tr, 20) if tr else None))
        print(f"[{model}] {cfg}: {res['result']} {res.get('invariant','')} states={res.get('states')} expected={expect} -> {'PASS' if ok else 'UNEXPECTED'}")
        if tr:
            for x in fmt_trace(tr, 20): print("    ", x)
    t0 = time.time()
    rec("M4f", "segment validity re-checked at enforcement", "OK", bfs(*m4f(True)), f"clock<={TMAX}, 2 requests")
    rec("M4f", "NEG: segment checked only before enforcement", "VIOLATION", bfs(*m4f(False)), f"clock<={TMAX}, 2 requests")
    rec("M4g", "quarantine status re-checked at enforcement", "OK", bfs(*m4g(True)), "2 in-flight requests")
    rec("M4g", "NEG: decision enforced without quarantine re-check", "VIOLATION", bfs(*m4g(False)), "2 in-flight requests")
    print(f"total time {time.time()-t0:.2f}s; all match expectation: {all(r['matches_expectation'] for r in runs)}")
    json.dump(runs, open(sys.argv[1] if len(sys.argv) > 1 else "logs/model_check_v4_results.json", "w"), indent=1, default=str)
