"""
Bounded explicit-state model checking, revision v3: interaction properties (reviewer concern 4).

Re-uses the BFS checker of model_check.py (M1-M3 unchanged) and adds model M4 with five sub-models of
asynchronous, distributed enforcement. Every sub-model is checked in its intended configuration and in at
least one NEGATIVE CONTROL in which a design element is removed; each negative control must yield a
counterexample (otherwise the property would be vacuous in the model).

  M4a  revocation with cached decisions and asynchronous revocation-list refresh (bound DELTA ticks)
  M4b  component failure: PDP, provenance service and segmentation controller can fail and recover
  M4c  policy-update race: decision computed under policy v, policy v+1 committed before enforcement (TOCTOU)
  M4d  replay under concurrency: two PEP workers process two copies of the same signed record
  M4e  administrative trust root: policy change by a compromised administrator; two-person rule

Scope: these are abstract models with bounded clocks and at most 2-3 concurrent requests. They establish
that, IN THE MODEL, the stated design rules are sufficient and that removing each rule breaks the property.
They do not verify the proof-of-concept code, network timing, or unbounded behaviour.
Usage: python3 model_check_v3.py logs/model_check_v3_results.json > logs/model_check_v3.log
"""
import json, sys, time
from model_check import bfs, fmt_trace

DELTA = 2      # revocation / policy propagation bound (ticks)
TMAX = 6       # clock bound


# ---------------------------------------------------------------- M4a revocation + cache + async refresh
# state: (clock, revoked_at(None|int), pep_knows(bool), cache_exp(None|int: cached allow for 'dev' valid until),
#         last_refresh(int), viol(bool))
def m4a(cache_ttl=DELTA, refresh_every=DELTA, check_cache_against_crl=True):
    init = (0, None, False, None, 0, False)

    def succ(s):
        clk, rev, knows, cexp, lref, viol = s
        out = []
        if clk < TMAX:
            # time passes; PEP MUST refresh if refresh_every elapsed (bounded staleness)
            nl, nk = lref, knows
            if clk + 1 - lref >= refresh_every:
                nl, nk = clk + 1, rev is not None
            out.append(("tick", (clk + 1, rev, nk, cexp if (cexp is None or cexp > clk + 1) else None, nl, viol)))
            # PEP may also refresh early (asynchronous)
            out.append(("refresh", (clk, rev, rev is not None, cexp, clk, viol)))
        if rev is None:
            out.append(("revoke_at_idp", (clk, clk, knows, cexp, lref, viol)))
        # request from 'dev': served from cache if valid, else PDP decision (PDP is always fresh)
        cache_ok = cexp is not None and cexp > clk and (not (check_cache_against_crl and knows))
        if cache_ok:
            allow = True
        else:
            allow = rev is None
        if allow:
            late = rev is not None and clk - rev > DELTA
            ncexp = cexp if cache_ok else clk + cache_ttl
            out.append(("deliver_dev", (clk, rev, knows, ncexp, lref, viol or late)))
        return out

    return init, succ, {"revocation_effective_within_DELTA": lambda s: not s[5]}


# ---------------------------------------------------------------- M4b component failures
# state: (pdp_up, prov_up, seg_ctl_up, seg_open, delivered tuple of (kind, pdp_up, prov_ok, seg_confirmed))
def m4b(pdp_fail_closed=True, prov_fail_closed=True, seg_fail_closed=True, max_deliv=2):
    init = (True, True, True, False, ())

    def succ(s):
        pdp, prov, segc, seg, deliv = s
        out = [("pdp_toggle", (not pdp, prov, segc, seg, deliv)), ("prov_toggle", (pdp, not prov, segc, seg, deliv)),
               ("segctl_toggle", (pdp, prov, not segc, seg, deliv)), ("seg_toggle", (pdp, prov, segc, not seg, deliv))]
        if len(deliv) < max_deliv:
            for kind in ("plain", "artifact"):
                # PDP decision
                if pdp: dec = True
                else: dec = not pdp_fail_closed           # fail-open = allow when PDP unreachable
                # segment confirmation
                if segc: seg_ok, conf = seg, True
                else: seg_ok, conf = (not seg_fail_closed), False   # fail-open assumes segment open
                # provenance
                if kind == "artifact":
                    if prov: pv, pok = True, True
                    else: pv, pok = (not prov_fail_closed), False
                else:
                    pv, pok = True, True
                if dec and seg_ok and pv:
                    out.append(("deliver_" + kind, (pdp, prov, segc, seg, deliv + ((kind, pdp, pok, conf and seg),))))
        return out

    inv = {
        "no_delivery_without_pdp_decision": lambda s: all(d[1] for d in s[4]),
        "no_artifact_without_verified_provenance": lambda s: all(d[2] for d in s[4]),
        "no_delivery_without_confirmed_open_segment": lambda s: all(d[3] for d in s[4]),
    }
    return init, succ, inv


# ---------------------------------------------------------------- M4c policy-update race (TOCTOU)
# Two requests r0, r1 each go through: decide (records version) -> enforce. Policy v0 allows, v1 denies.
# state: (committed_version, pep_version, decided: tuple(version|None per request), done: tuple(bool), viol)
def m4c(revalidate=True):
    init = (0, 0, (None, None), (False, False), False)

    def succ(s):
        cv, pv, dec, done, viol = s
        out = []
        if cv == 0:
            out.append(("commit_v1", (1, pv, dec, done, viol)))
        if pv < cv:
            out.append(("pep_learns_v1", (cv, cv, dec, done, viol)))
        for i in range(2):
            if dec[i] is None and not done[i]:
                d = list(dec); d[i] = cv              # PDP evaluates under committed policy
                out.append((f"decide_r{i}", (cv, pv, tuple(d), done, viol)))
            elif dec[i] is not None and not done[i]:
                dn = list(done); dn[i] = True
                if revalidate and dec[i] < pv:        # decision older than PEP's policy version: re-decide (deny)
                    d = list(dec); d[i] = None
                    out.append((f"reject_stale_r{i}", (cv, pv, tuple(d), done, viol)))
                else:
                    allowed = dec[i] == 0
                    # violation: delivered under v0 although the PEP already knew v1
                    out.append((f"enforce_r{i}", (cv, pv, dec, tuple(dn), viol or (allowed and pv == 1))))
        return out

    return init, succ, {"no_enforcement_of_superseded_decision": lambda s: not s[4]}


# ---------------------------------------------------------------- M4d replay race between two PEP workers
# Both workers receive the SAME record (seq=1). hw = accepted high-water mark.
# atomic: check-and-set in one step; non-atomic: read hw, (other worker may run), then write.
# state: (hw, w0_state, w1_state, accepted_count); worker state in {'idle','read0','read1','done'}
def m4d(atomic=True):
    init = (0, "idle", "idle", 0)

    def succ(s):
        hw, w0, w1, acc = s
        ws = [w0, w1]; out = []
        for i in range(2):
            w = ws[i]
            def put(nw, nhw=hw, nacc=acc):
                x = list(ws); x[i] = nw
                return (nhw, x[0], x[1], nacc)
            if w == "idle":
                if atomic:
                    if hw < 1: out.append((f"cas_accept_w{i}", put("done", 1, acc + 1)))
                    else: out.append((f"cas_reject_w{i}", put("done")))
                else:
                    out.append((f"read_w{i}", put(f"read{hw}")))
            elif w.startswith("read"):
                seen = int(w[4:])
                if seen < 1: out.append((f"write_accept_w{i}", put("done", 1, acc + 1)))
                else: out.append((f"reject_w{i}", put("done")))
        return out

    return init, succ, {"record_accepted_at_most_once": lambda s: s[3] <= 1}


# ---------------------------------------------------------------- M4e administrative trust root
# Admins a1, a2 can be compromised. A policy change takes effect when it has `quorum` approvals.
# Malicious change = proposed by a compromised admin. state: (comp(frozenset), approvals(frozenset), applied, malicious_applied)
def m4e(quorum=2, max_compromised=1):
    init = (frozenset(), frozenset(), False, False)

    def succ(s):
        comp, appr, applied, mal = s
        out = []
        for a in ("a1", "a2"):
            if a not in comp and len(comp) < max_compromised:
                out.append((f"compromise_{a}", (comp | {a}, appr, applied, mal)))
        if not applied:
            # a malicious proposal is approved by compromised admins; honest admins reject it
            for a in comp:
                if a not in appr:
                    na = appr | {a}
                    ok = len(na) >= quorum
                    out.append((f"approve_{a}", (comp, na, ok, mal or ok)))
        return out

    return init, succ, {"no_malicious_policy_change": lambda s: not s[3]}


if __name__ == "__main__":
    runs = []

    def rec(model, cfg, expect, res, bounds):
        res = dict(res); tr = res.pop("trace", None)
        ok = (res["result"] == "OK") == (expect == "OK")
        runs.append(dict(model=model, config=cfg, expected=expect, bounds=bounds, **res, matches_expectation=ok,
                         counterexample=fmt_trace(tr, 20) if tr else None))
        print(f"[{model}] {cfg}: {res['result']} {res.get('invariant','')} states={res.get('states')} "
              f"expected={expect} -> {'PASS' if ok else 'UNEXPECTED'}", flush=True)
        if tr:
            for x in fmt_trace(tr, 20): print("    ", x)

    t0 = time.time()
    b = f"DELTA={DELTA}, TMAX={TMAX}, one revocable principal"
    rec("M4a", "cache TTL=DELTA, refresh every DELTA, cache checked against CRL", "OK", bfs(*m4a()), b)
    rec("M4a", "cache TTL=DELTA, cache NOT checked against CRL (TTL alone bounds staleness)", "OK", bfs(*m4a(check_cache_against_crl=False)), b)
    rec("M4a", "NEG: cache TTL=4 > DELTA, cache not checked against CRL", "VIOLATION", bfs(*m4a(cache_ttl=4, check_cache_against_crl=False)), b)
    # attempt 1 used NEG "refresh every 4" with TTL=DELTA: no counterexample, because a fresh PDP plus TTL<=DELTA
    # already bounds staleness (see logs/model_check_v3_attempt1.log). The refresh bound matters only when TTL>DELTA:
    rec("M4a", "cache TTL=4 > DELTA, cache checked against CRL refreshed every DELTA", "OK", bfs(*m4a(cache_ttl=4)), b)
    rec("M4a", "NEG: cache TTL=4 > DELTA, CRL refreshed every 4 > DELTA", "VIOLATION", bfs(*m4a(cache_ttl=4, refresh_every=4)), b)
    b = "2 deliveries, PDP/provenance/segment-controller each fail and recover arbitrarily"
    rec("M4b", "all components fail closed", "OK", bfs(*m4b()), b)
    rec("M4b", "NEG: PEP fails open when PDP unreachable", "VIOLATION", bfs(*m4b(pdp_fail_closed=False)), b)
    rec("M4b", "NEG: provenance check skipped when provenance service down", "VIOLATION", bfs(*m4b(prov_fail_closed=False)), b)
    rec("M4b", "NEG: segment assumed open when controller unreachable", "VIOLATION", bfs(*m4b(seg_fail_closed=False)), b)
    b = "2 concurrent requests, one policy update"
    rec("M4c", "PEP re-validates decision version at enforcement", "OK", bfs(*m4c(True)), b)
    rec("M4c", "NEG: decision enforced without version re-validation", "VIOLATION", bfs(*m4c(False)), b)
    b = "2 PEP workers, 1 duplicated record"
    rec("M4d", "atomic check-and-set of sequence high-water mark", "OK", bfs(*m4d(True)), b)
    rec("M4d", "NEG: non-atomic read-then-write", "VIOLATION", bfs(*m4d(False)), b)
    b = "2 administrators"
    rec("M4e", "two-person rule, at most one admin compromised", "OK", bfs(*m4e(2, 1)), b)
    rec("M4e", "NEG: single-admin approval, one admin compromised", "VIOLATION", bfs(*m4e(1, 1)), b)
    rec("M4e", "two-person rule, BOTH admins compromised (assumption violated)", "VIOLATION", bfs(*m4e(2, 2)), b)
    print(f"total time {time.time()-t0:.2f}s; all match expectation: {all(r['matches_expectation'] for r in runs)}")
    json.dump(runs, open(sys.argv[1] if len(sys.argv) > 1 else "logs/model_check_v3_results.json", "w"), indent=1, default=str)
