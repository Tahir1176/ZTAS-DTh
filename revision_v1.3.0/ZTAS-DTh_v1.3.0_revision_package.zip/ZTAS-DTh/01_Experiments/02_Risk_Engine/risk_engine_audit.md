# risk_engine_audit.md — implementation audit of the 5-D risk engine (concern 2, Task 2.1; also feeds concern 3)

Artefacts inspected:
- manuscript Eq. (1) (risk score), Eq. (2) (evidence) and Algorithm 1;
- `src/dth_sim.py` (E1 simulator);
- `src/risk_engine_eval.py` (E2);
- `src/poc/ztas_poc.py` (PoC PDP, v2), and `ztas_poc_v3.py`.

| Element | Manuscript (v2) | E1 simulator | E2 study | PoC v2 | Consistent? / action in v3 |
|---|---|---|---|---|---|
| Dimensions | temporal, spatial, behavioural, system, business, each in [0, 100] | same; malicious requests shift the behavioural dimension, and the system dimension with p = 0.5 | same | same, read from the request context | ✔ |
| Normalisation | "normalised components" (method unspecified) | clip to [0, 100] | clip to [0, 100] | none (trusts the caller) | ✘ **No operational normalisation is defined.** v3 adds a measurement specification (`risk_dimension_operational_specification.csv`) and a calibration protocol. |
| Weights | production (0.10, 0.10, 0.35, 0.30, 0.15); mode-dependent | production only | production, uniform, maintenance | production only | ✔ The weights are expert-chosen, not fitted (stated). |
| Thresholds | θ = (30, 70, 90) → allow / step-up / block / isolate | same | same | same | ✔ |
| Block tier | deny + alert + evidence | deny + 2 evidence units | **not represented in the sequence model** (only step-up failures counted) | deny + 2 | Partial. The v3 time-based experiment includes the block tier. |
| Step-up | re-authentication / attestation; failure adds 1 unit | attacker fails with stepup_fail; no credit for success | legitimate failure by device class; success −1 (decay policies) | `stepup_ok` flag from the context; success −1 | ✘ **E1 gives no −1 credit for success.** For an attacker this makes E1 slightly *favourable to containment*. Documented; E1 not changed, so v2 results stay comparable. |
| Decay | half-life h = 30 **requests** | multiplicative 0.95 **per simulation step** (half-life 13.5 steps) | 0.5^(1/30) **per request** | half-life 30 **seconds** of wall time | ✘ **Three different clocks.** The manuscript now states the unit per artefact. The v3 evidence experiment compares request-based and time-based decay explicitly and shows that the choice matters for slow attackers (time-based decay never isolated a 0.1 req/s attacker). |
| Reset | none (v2 recommended policy); "reset on success" is a variant | none | variant | none | ✔ documented |
| Outage awareness | failures during a reported outage not counted | not modelled (no outages in E1) | modelled | `known_outage` flag from the context | Partial: the outage signal must come from an independent source (stated). |
| Isolation | quarantine; operations assets need operator approval | `approval_delay` steps | not modelled | pending → approve | ✔ |
| Missing data | not specified | not applicable | not applicable | **missing dimension = 0, i.e. lowest risk (fail-open)** | ✘ **Fixed in PoC v3:** a missing dimension is imputed as 50, so the request escalates to step-up. Verified by Scenario I: v2 allowed a request with all five dimensions missing at r = 0; v3 computes r = 50 and requires step-up. |
| PDP unreachable | Algorithm 1: "degraded mode" | – | – | fail-closed (deny) | ✘ **Text inconsistent with code.** Algorithm 1 is revised to *deny (fail-closed); time-critical commands use the separate path*. |
| Replay check | Algorithm 1: strict `seq ≤ last → deny` | – | – | strict | v3: strict ordering denies legitimate concurrent requests (PoC Scenario A: 18–77% denials at 2–16 concurrent clients). Algorithm 1 now offers a bounded anti-replay window as an alternative, with an explicit trade-off on P3's ordering guarantee. |
| TOCTOU between check and forward | – | – | – | none | v3 adds re-validation of the segment-policy version (model M4c; Scenario G). |

**Conclusion of the audit.** The core score and thresholds agree across artefacts. The inconsistencies concern decay units, step-up credit, block-tier evidence in E2, missing-data handling, and the PDP-failure wording. None changes a v2 headline number. The decay-unit and missing-data issues matter for deployment, so the manuscript now states them explicitly.
