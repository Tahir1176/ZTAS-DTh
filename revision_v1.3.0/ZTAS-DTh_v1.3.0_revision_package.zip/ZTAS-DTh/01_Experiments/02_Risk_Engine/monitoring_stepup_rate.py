"""v5: legitimate step-up rate at the normal (30) and monitoring (20) step-up thresholds, synthetic families of
src/risk_engine_eval.py, production weights. Supports the graded-response cost statement. Usage: python3 monitoring_stepup_rate.py"""
import os, sys
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "..", "..", "src"))
import risk_engine_eval as rv
rng = np.random.default_rng(1); W = rv.W["production"]; rows = []
for fam in ["gaussian", "heavy_tailed", "correlated"]:
    s = np.clip(rv.legit(rng, fam, 200000), 0, 100) @ W
    rows.append(dict(family=fam, stepup_rate_theta30=(s > 30).mean(), stepup_rate_theta20=(s > 20).mean()))
d = pd.DataFrame(rows); d.to_csv(os.path.join(HERE, "..", "..", "02_Data", "Processed", "monitoring_stepup_rate_v5.csv"), index=False); print(d.round(4))
