"""
Risk-engine extended evaluation (revision v3, reviewer concern 2). SYNTHETIC score distributions only.

Retains the v2 generators (src/risk_engine_eval.py: legit(), malicious(), FAMILIES) unchanged and adds:
  (a) prevalence sweep 0.1%-20% with operator workload per 10^5 requests at every decision tier;
  (b) Wilson 95% CIs on TPR/FPR at each tier;
  (c) score calibration: Platt (logistic) mapping fitted on a Gaussian calibration split, evaluated in-family
      and under distribution shift (ECE, Brier) -- shows a calibrated score does not stay calibrated;
  (d) cost-sensitive threshold selection under four cost scenarios, including an asset class where isolating
      a safety-critical asset is very costly; optimal thresholds per family x prevalence x scenario;
  (e) a constrained rule: lowest threshold whose expected false escalations stay below an operator budget.
Usage: python3 risk_engine_extended_experiment.py OUT_RAW_DIR OUT_PROC_DIR
"""
import sys, os, json
import numpy as np
import pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "src"))
import risk_engine_eval as rv
from sklearn.linear_model import LogisticRegression

N = 100_000
PREV = [0.001, 0.01, 0.05, 0.10, 0.20]
THETA = rv.THETA
W = rv.W["production"]
PER = 100_000            # workload normalisation: requests
COSTS = {
    # cost per error in arbitrary consistent units (exploratory, not measured)
    "fp_costly":       dict(c_fn=10, c_fp=1),      # nuisance alarms expensive relative to misses
    "fn_costly":       dict(c_fn=1000, c_fp=1),    # missed intrusion very costly
    "both_costly":     dict(c_fn=200, c_fp=5),
    "safety_critical": dict(c_fn=200, c_fp=5, c_iso_legit=5000),  # isolating a legit safety asset dominates
}


def wilson(k, n, z=1.96):
    p = k / n; d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d; h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return c - h, c + h


def ece(p, y, bins=15):
    edges = np.linspace(0, 1, bins + 1); idx = np.clip(np.digitize(p, edges) - 1, 0, bins - 1)
    e = 0.0
    for b in range(bins):
        m = idx == b
        if m.any():
            e += m.mean() * abs(p[m].mean() - y[m].mean())
    return e


def mix(l, m, prev, rng):
    """Sample a request stream at given prevalence from the pools (with replacement)."""
    n_m = rng.binomial(N, prev); n_l = N - n_m
    s = np.concatenate([rng.choice(m, n_m), rng.choice(l, n_l)]); y = np.r_[np.ones(n_m), np.zeros(n_l)]
    return s, y


def main(out_raw, out_proc):
    rng = np.random.default_rng(20261119)
    pools = {}
    for fam, mu in rv.FAMILIES:
        pools[(fam, mu)] = (rv.legit(rng, fam, N) @ W, rv.malicious(rng, fam, mu, N) @ W)
    # ---------------- (a)(b) prevalence sweep and workload
    rows = []
    for (fam, mu), (l, m) in pools.items():
        auc = rv.auc(m, l)
        for prev in PREV:
            prauc = rv.pr_auc(m, l, prev)
            for tier, th in zip(["step_up", "block", "isolate"], THETA):
                tp_ = int((m > th).sum()); fp_ = int((l > th).sum())
                tpr, fpr = tp_ / N, fp_ / N
                tlo, thi = wilson(tp_, N); flo, fhi = wilson(fp_, N)
                n_mal = prev * PER; n_leg = (1 - prev) * PER
                prec = prev * tpr / (prev * tpr + (1 - prev) * fpr) if tpr + fpr > 0 else np.nan
                rows.append(dict(family=fam, mu_mal=mu, prevalence=prev, tier=tier, threshold=th,
                                 TPR=tpr, TPR_lo=tlo, TPR_hi=thi, FPR=fpr, FPR_lo=flo, FPR_hi=fhi, FNR=1 - tpr,
                                 precision=prec, F1=(2 * prec * tpr / (prec + tpr)) if prec and tpr else 0.0,
                                 ROC_AUC=auc, PR_AUC=prauc, PR_AUC_random=prev,
                                 alerts_per_1e5=n_mal * tpr + n_leg * fpr,
                                 false_alerts_per_1e5=n_leg * fpr, true_alerts_per_1e5=n_mal * tpr,
                                 false_alerts_per_true_alert=(n_leg * fpr) / (n_mal * tpr) if tpr > 0 else np.inf))
    met = pd.DataFrame(rows); met.to_csv(os.path.join(out_proc, "risk_engine_processed.csv"), index=False)
    # confusion matrices per 1e5 requests at each tier
    os.makedirs(os.path.join(out_proc, "risk_engine_confusion_matrices"), exist_ok=True)
    cm = met.assign(TP=lambda d: d.prevalence * PER * d.TPR, FN=lambda d: d.prevalence * PER * (1 - d.TPR),
                    FP=lambda d: (1 - d.prevalence) * PER * d.FPR, TN=lambda d: (1 - d.prevalence) * PER * (1 - d.FPR))
    cm[["family", "mu_mal", "prevalence", "tier", "threshold", "TP", "FN", "FP", "TN"]].round(1).to_csv(
        os.path.join(out_proc, "risk_engine_confusion_matrices", "confusion_per_1e5_requests.csv"), index=False)
    # ---------------- (c) calibration: Platt fitted on gaussian mu=28 at 1% prevalence
    l0, m0 = pools[("gaussian", 28)]
    s_cal, y_cal = mix(l0[: N // 2], m0[: N // 2], 0.01, rng)
    lr = LogisticRegression(C=1e6).fit(s_cal[:, None], y_cal)
    cal = []
    for (fam, mu), (l, m) in pools.items():
        for prev in PREV:
            s, y = mix(l[N // 2:], m[N // 2:], prev, rng)
            p = lr.predict_proba(s[:, None])[:, 1]
            cal.append(dict(family=fam, mu_mal=mu, prevalence=prev, ECE=ece(p, y), Brier=float(np.mean((p - y) ** 2)),
                            mean_pred=float(p.mean()), observed_rate=float(y.mean()),
                            in_calibration_condition=(fam == "gaussian" and mu == 28 and prev == 0.01)))
    pd.DataFrame(cal).to_csv(os.path.join(out_proc, "risk_engine_calibration.csv"), index=False)
    # ---------------- (d) cost-sensitive thresholds and (e) budget-constrained threshold
    ths = np.arange(0, 100.5, 0.5)
    th_rows, curve_rows = [], []
    for (fam, mu), (l, m) in pools.items():
        ls, ms = np.sort(l), np.sort(m)
        tpr = 1 - np.searchsorted(ms, ths, side="right") / N
        fpr = 1 - np.searchsorted(ls, ths, side="right") / N
        for th, a, b in zip(ths, tpr, fpr):
            curve_rows.append(dict(family=fam, mu_mal=mu, threshold=th, TPR=a, FPR=b))
        for prev in PREV:
            for scen, c in COSTS.items():
                cost = prev * (1 - tpr) * c["c_fn"] + (1 - prev) * fpr * c["c_fp"]
                if "c_iso_legit" in c:     # the isolation tier sits at th + 60 (same offsets as 30/90)
                    fpr_iso = 1 - np.searchsorted(ls, np.minimum(ths + 60, 100.0), side="right") / N
                    cost = cost + (1 - prev) * fpr_iso * c["c_iso_legit"]
                k = int(np.argmin(cost))
                th_rows.append(dict(family=fam, mu_mal=mu, prevalence=prev, scenario=scen, opt_threshold=ths[k],
                                    TPR=tpr[k], FPR=fpr[k], exp_cost=cost[k],
                                    cost_at_default30=cost[int(np.where(ths == 30)[0][0])]))
            for budget in (10, 100, 1000):          # max false escalations per 1e5 requests
                fa = (1 - prev) * PER * fpr
                ok = np.where(fa <= budget)[0]; k = int(ok[0]) if len(ok) else len(ths) - 1
                th_rows.append(dict(family=fam, mu_mal=mu, prevalence=prev, scenario=f"budget_{budget}_per_1e5",
                                    opt_threshold=ths[k], TPR=tpr[k], FPR=fpr[k], exp_cost=np.nan, cost_at_default30=np.nan))
    pd.DataFrame(th_rows).to_csv(os.path.join(out_proc, "risk_engine_thresholds.csv"), index=False)
    pd.DataFrame(curve_rows).to_csv(os.path.join(out_raw, "risk_engine_raw.csv.gz"), index=False, compression="gzip")
    json.dump(dict(N=N, seed=20261119, weights=W.tolist(), theta=THETA, prevalences=PREV, costs=COSTS,
                   platt=dict(coef=float(lr.coef_[0, 0]), intercept=float(lr.intercept_[0]))),
              open(os.path.join(out_proc, "risk_engine_meta.json"), "w"), indent=1)
    s1 = met[(met.tier == "step_up")][["family", "mu_mal", "prevalence", "TPR", "FPR", "precision", "ROC_AUC", "PR_AUC",
                                       "false_alerts_per_1e5", "false_alerts_per_true_alert"]]
    print(s1.round(4).to_string())


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
