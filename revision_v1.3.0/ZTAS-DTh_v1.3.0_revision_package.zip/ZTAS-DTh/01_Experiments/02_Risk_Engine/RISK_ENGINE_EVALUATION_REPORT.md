# RISK_ENGINE_EVALUATION_REPORT.md

> v4 report. Sections 'v4 additions' are new in this round; the v3 content below them is kept unchanged for traceability (original file `RISK_ENGINE_VALIDATION_REPORT.md` is also kept).

## v4 additions

**Robustness study** — script `risk_engine_robustness_experiment.py` (seed 20261120). Outputs: `02_Data/Processed/risk_engine_robustness/` and Supp. Table S17 / Fig. S9. All scores are synthetic; no plant telemetry was used.

| Perturbation | Main finding |
|---|---|
| Gaussian noise σ = 0→20 | The FPR rose from 5×10⁻⁵ to 0.10 (Gaussian). ROC-AUC for the stealthy attacker (μ = 28) fell from 0.80 to 0.66. False escalations per true escalation at 0.1% prevalence rose from 0.46 to 356. |
| Missing components, by imputation rule | Mid-scale (50), the default, raised the Gaussian FPR to 0.022 at 5% missing and to 0.17 at 20% missing. Zero imputation and legitimate-mean imputation keep the FPR low but lower the TPR (fail-open). |
| Attacker withholds behavioural and system components (q_a = 0.9, Gaussian, μ = 55) | TPR: zero 0.06, legit_mean 0.065, reweight 0.07, mid50 0.97 (with FPR 0.022). |
| Attack intensity μ_mal 16→70 (heavy-tailed) | False escalations per true escalation at 0.1% prevalence went from 249 to 20. |

**Conclusion.** No imputation rule is both workload-friendly and evasion-resistant. The manuscript recommends treating missing signals as evidence, for example a step-up on telemetry loss, rather than imputing them silently.

**Operational specification.** `RISK_SIGNAL_OPERATIONAL_SPECIFICATION.csv` adds three columns:
- `prototype_status`: every dimension is THEORETICAL in the PoC, where values are injected by the test client;
- `sampling_frequency`;
- `measurement_limitations`.

**Not done:** calibration on real data. It is blocked because no plant data is available.

---

## v3 content (unchanged)

# RISK_ENGINE_VALIDATION_REPORT.md — concern 2

**The risk engine has been evaluated with SYNTHETIC score distributions only.** No industrial calibration has been demonstrated. The results describe how the model behaves in the evaluated scenarios. They are not operational detection performance.

## 1. Audit
See `risk_engine_audit.md`. The score, weights and thresholds agree across artefacts. The audit found:
- the decay unit differs between E1 (simulation step), E2 (request) and the PoC (seconds);
- E1 gives no evidence credit for a successful step-up;
- E2 omits block-tier evidence;
- the PoC treated a missing dimension as zero risk (fail-open; fixed in v3 and verified by Scenario I);
- Algorithm 1 said "degraded mode" while the code fails closed (text corrected).

## 2. Extended experiment (`risk_engine_extended_experiment.py`)
- The v2 generators are reused unchanged: Gaussian, skewed (gamma/lognormal), heavy-tailed (t₃), correlated (ρ = 0.6 plus a latent attack factor), overlapping (μ_mal = 20), and shift (night-shift and remote-maintenance displacement).
- Two attacker profiles: μ_mal = 55 (noisy) and 28 (stealthy).
- 10⁵ legitimate and 10⁵ malicious requests per family.
- Prevalence {0.1, 1, 5, 10, 20}%; three tiers; Wilson CIs.
- The v2 results at 1% and 10% are retained in `../../02_Data/processed/` of v2 (`e2_metrics.csv`) and reproduce exactly (Stage 9).

## 3. Discrimination is not operational performance

Step-up tier (θ₁ = 30), production weights. The full table is in `risk_engine_processed.csv`.

| Family | μ_mal | ROC-AUC | FPR | Precision at 0.1% / 1% / 20% | False escalations per 10⁵ requests | False alerts per true alert at 0.1% |
|---|---|---|---|---|---|---|
| Gaussian | 55 | 0.987 | 0.0001 | 0.86 / 0.98 / 1.00 | 11 | 0.16 |
| Gaussian | 28 | 0.797 | 0.0001 | 0.61 / 0.94 / 1.00 | 7 | 0.64 |
| Skewed | 55 | 0.966 | 0.0125 | 0.05 / 0.36 / 0.93 | 1247 | 18 |
| Heavy-tailed | 55 | 0.952 | 0.0174 | 0.04 / 0.28 / 0.91 | 1733 | 26 |
| Heavy-tailed | 28 | 0.746 | 0.0168 | 0.01 / 0.10 / 0.73 | 1674 | 94 |
| Correlated | 28 | 0.750 | 0.0130 | 0.01 / 0.13 / 0.78 | 1296 | 71 |
| Shift (unadapted) | 28 | 0.594 | 0.0046 | 0.02 / 0.19 / 0.86 | 463 | 42 |
| Overlapping | 20 | 0.634 | 0.0001 | 0.17 / 0.68 / 0.98 | 15 | 4.8 |

**Interpretation.**
- ROC-AUC does not depend on prevalence. It stays between 0.75 and 0.95 for the heavy-tailed, skewed and correlated families, which looks favourable.
- At 0.1% malicious prevalence the same families produce 26–94 false escalations per true one, with precision of 1–6%.
- Gaussian legitimate scores make the engine look nearly perfect (FPR 10⁻⁴). Light-tailed assumptions are therefore the optimistic case, not a neutral one.
- At θ₁ the operator workload is dominated by the legitimate tail: 1200–1700 false step-ups per 10⁵ requests with non-Gaussian scores.
- Single malicious requests almost never reach the block or isolate tiers (TPR ≤ 6·10⁻⁴), so quarantine depends on evidence accumulation (concern 3).
- PR-AUC falls from 0.43 to 0.13 for heavy-tailed noisy requests as prevalence goes from 1% to 0.1%. It must be reported at the deployment prevalence.

## 4. Calibration (synthetic transfer test)
- A Platt mapping was fitted on Gaussian μ = 28 scores at 1% prevalence. In that condition the ECE is 0.0026.
- At 1% prevalence but with different families, the mapping over-predicts. The mean predicted probability is 0.030–0.039 against an observed 0.010, and the ECE is 0.014–0.029.
- At 20% prevalence the ECE rises to 0.04–0.18 (0.14–0.18 for the stealthy and overlapping families) because of prior shift.
- A calibrated score therefore does not stay calibrated under distribution or prevalence change. This motivates the drift-monitoring stage of `risk_calibration_protocol.md`.

## 5. Threshold selection under asymmetric costs (`risk_engine_thresholds.csv`)
Four cost scenarios were tested: false positives costly; false negatives costly; both costly; and safety-critical, where wrongly isolating a legitimate safety asset costs 5000.

The cost-minimising step-up threshold moves strongly:
- Heavy-tailed, FP-costly: 64.5 → 33 → 23 → 19 → 14 as prevalence rises from 0.1% to 20%.
- The FN-costly optimum collapses to ≈ 0 (step-up everything) once prevalence reaches 1%.
- Budget-constrained thresholds keep the false escalations at or below 10, 100 or 1000 per 10⁵ requests. They depend mainly on the legitimate distribution: 30 for Gaussian, 52 for heavy-tailed at a budget of 10.

**Why no universal threshold exists:** the optimum depends on
1. the prevalence;
2. the cost ratio, which differs between a design workstation and a safety-instrumented controller;
3. the legitimate score distribution of the device class;
4. the operator budget.

The safety-critical scenario barely changed the optimum. With θ₃ = θ₁ + 60, legitimate scores almost never reach the isolation tier, so isolation costs bind only through the evidence rule. That rule is analysed in `EVIDENCE_ACCUMULATION_REPORT.md`.

## 6. Operational measurement and calibration
- `risk_dimension_operational_specification.csv` gives, for each dimension, the signals, source, frequency, normalisation, noise, missing-data rule, privacy concern, attacker manipulation and calibration need. It is a proposed specification, not a measurement.
- `risk_calibration_protocol.md` covers shadow mode, labelled data, constrained logistic fitting, cost- and budget-constrained thresholds, drift monitoring and recalibration triggers.

## 7. Claims allowed in the manuscript
- **Supported:** under the synthetic families evaluated, light-tailed legitimate scores give very low false-escalation rates. Heavy-tailed, skewed or correlated legitimate behaviour raises them by two orders of magnitude, and at low prevalence most escalations are false.
- **Not supported:** any detection rate for real industrial telemetry, or calibrated weights or thresholds.
