"""
Missing telemetry as a signal (v5, concern 2). SYNTHETIC data only; generators of src/risk_engine_eval.py unchanged.

The v4 manuscript recommends treating missing signals as evidence instead of imputing them silently. This script
tests that recommendation. Scores use legitimate-mean imputation (low workload); in addition, missingness triggers
a step-up according to a rule:
  impute_mid50     : v3/v4 PoC rule (missing -> 50), no flag            (reference)
  impute_legitmean : missing -> legitimate mean, no flag                (reference, evasion-prone)
  flag_any_BS      : step-up if the behavioural OR the system component is missing
  flag_both_BS     : step-up if the behavioural AND the system component are missing
  flag_count2      : step-up if >= 2 of the 5 components are missing
Legitimate missingness: each component independently missing with q_l = 0.05, plus a correlated telemetry outage
that removes the behavioural and system components together with probability o in {0, 0.01, 0.05}.
Attacker: baseline missingness 0.05, and suppresses BOTH B and S (q_a) or ONLY B (partial evasion).
Metrics at theta1 = 30 (step-up): TPR, FPR, false step-ups per true at prevalence 0.1%.
Usage: python3 missingness_signal_experiment.py OUT_DIR
"""
import os, sys
import numpy as np
import pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "..", "..", "src"))
import risk_engine_eval as rv
N = 100_000; W = rv.W["production"]; TH = rv.THETA[0]; rng = np.random.default_rng(20261121)
B, S = 2, 3


def decide(X, miss, rule, lm):
    X = X.copy()
    X[miss] = 50.0 if rule == "impute_mid50" else np.broadcast_to(lm, X.shape)[miss]
    step = (np.clip(X, 0, 100) @ W) > TH
    if rule == "flag_any_BS": step |= miss[:, B] | miss[:, S]
    elif rule == "flag_both_BS": step |= miss[:, B] & miss[:, S]
    elif rule == "flag_count2": step |= miss.sum(axis=1) >= 2
    return step


rows = []
for fam in ["gaussian", "heavy_tailed"]:
    L = rv.legit(rng, fam, N); lm = L.mean(axis=0)
    for mu in (28, 55):
        M = rv.malicious(rng, fam, mu, N)
        for o in (0.0, 0.01, 0.05):
            ml = rng.random(L.shape) < 0.05; out = rng.random(N) < o; ml[out, B] = True; ml[out, S] = True
            for mode in ("both", "only_B"):
                for qa in (0.0, 0.5, 0.9):
                    mm = rng.random(M.shape) < 0.05; sup = rng.random(N) < qa
                    mm[sup, B] = True
                    if mode == "both": mm[sup, S] = True
                    for rule in ("impute_mid50", "impute_legitmean", "flag_any_BS", "flag_both_BS", "flag_count2"):
                        tpr = decide(M, mm, rule, lm).mean(); fpr = decide(L, ml, rule, lm).mean()
                        rows.append(dict(family=fam, mu_mal=mu, legit_outage=o, withhold=mode, q_a=qa, rule=rule, TPR=tpr, FPR=fpr,
                                         false_per_true_0001=(0.999 * fpr) / (0.001 * tpr) if tpr > 0 else np.inf))
out = sys.argv[1]; os.makedirs(out, exist_ok=True)
d = pd.DataFrame(rows); d.to_csv(os.path.join(out, "missingness_signal.csv"), index=False)
pd.set_option("display.width", 220)
print(d[(d.family == "gaussian") & (d.mu_mal == 55) & (d.q_a == 0.9)].pivot_table(index=["legit_outage", "withhold"], columns="rule", values=["TPR", "FPR"]).round(3).to_string())
