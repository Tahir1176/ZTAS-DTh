"""
Risk-engine robustness, revision v7 (reviewer concern 4). SYNTHETIC score distributions only; nothing here is a
measurement of industrial telemetry or a validated detection rate. Uses the unchanged generators of
src/risk_engine_eval.py and the production weights / theta of the paper.

(a) Alternative weights. 1000 weight vectors per condition drawn from a Dirichlet distribution
    - centred on the production weights with concentration 20 (moderate expert disagreement), and
    - uniform on the simplex (alpha = 1: arbitrary weights).
    For each: ROC-AUC, TPR and FPR at theta1 = 30, false escalations per true escalation at 0.1% prevalence.
(b) Manipulated telemetry (mimicry). With probability q_m, the attacker replaces the k components it can influence
    by values drawn from the legitimate distribution of the same family, so they are present and look legitimate
    (unlike withholding, which leaves them missing). k = behavioural only; behavioural + system.
(c) Stale telemetry. With probability q_s, the behavioural and system components of a malicious request are stale:
    they carry values from before the compromise (a legitimate draw) and an old timestamp. Rule 'accept': the PEP
    uses stale values as fresh. Rule 'freshness': stale components are treated as missing and imputed with 50
    (the PoC's 5-s freshness bound, test T-M). Legitimate requests are stale with probability o_s (telemetry lag),
    which under the freshness rule raises their score as well.
Usage: python3 risk_engine_v7_experiment.py OUT_DIR
"""
import os, sys
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "src"))
import risk_engine_eval as rv

W0 = rv.W["production"]; TH = rv.THETA[0]; FAMS = ["gaussian", "heavy_tailed", "correlated"]; MUS = (28, 55)
rng = np.random.default_rng(20261126)


def mets(sm, sl, **kw):
    tpr = float((sm > TH).mean()); fpr = float((sl > TH).mean())
    fpt = ((1 - 1e-3) * fpr) / (1e-3 * tpr) if tpr > 0 else np.inf
    return dict(kw, TPR=tpr, FPR=fpr, ROC_AUC=rv.auc(sm, sl), false_per_true_0001=fpt)


def main(out):
    os.makedirs(out, exist_ok=True)
    # ---------------- (a) weights
    rows = []; N = 20_000
    for fam in FAMS:
        L = rv.legit(rng, fam, N)
        for mu in MUS:
            M = rv.malicious(rng, fam, mu, N)
            rows.append(mets(M @ W0, L @ W0, family=fam, mu_mal=mu, scheme="production", draw=-1, **{f"w{i}": W0[i] for i in range(5)}))
            for scheme, alpha in [("dirichlet_c20", 20 * W0), ("dirichlet_uniform", np.ones(5))]:
                for d in range(1000):
                    w = rng.dirichlet(alpha)
                    rows.append(mets(M @ w, L @ w, family=fam, mu_mal=mu, scheme=scheme, draw=d, **{f"w{i}": w[i] for i in range(5)}))
    A = pd.DataFrame(rows); A.to_csv(os.path.join(out, "weights_draws.csv"), index=False)
    s = []
    for (fam, mu, sc), d in A[A.scheme != "production"].groupby(["family", "mu_mal", "scheme"]):
        p = A[(A.scheme == "production") & (A.family == fam) & (A.mu_mal == mu)].iloc[0]
        s.append(dict(family=fam, mu_mal=mu, scheme=sc, auc_prod=p.ROC_AUC, auc_p05=d.ROC_AUC.quantile(.05), auc_med=d.ROC_AUC.median(), auc_p95=d.ROC_AUC.quantile(.95),
                      share_auc_above_prod=float((d.ROC_AUC > p.ROC_AUC).mean()), fpt_prod=p.false_per_true_0001,
                      fpt_med=d.false_per_true_0001.median(), fpt_p05=d.false_per_true_0001.quantile(.05), fpt_p95=d.false_per_true_0001.quantile(.95),
                      tpr_prod=p.TPR, tpr_med=d.TPR.median(), fpr_prod=p.FPR, fpr_med=d.FPR.median()))
    pd.DataFrame(s).to_csv(os.path.join(out, "weights_summary.csv"), index=False)
    # ---------------- (b) mimicry and (c) staleness
    rows = []; N = 100_000
    for fam in FAMS:
        L = rv.legit(rng, fam, N)
        for mu in MUS:
            M = rv.malicious(rng, fam, mu, N); base = mets(M @ W0, L @ W0)
            for comps, name in [([2], "behavioural"), ([2, 3], "behavioural+system")]:
                for q in (0.0, 0.25, 0.5, 0.9):
                    Mm = M.copy(); hit = rng.random(N) < q; Lr = rv.legit(rng, fam, N)
                    for c in comps: Mm[hit, c] = Lr[hit, c]
                    rows.append(mets(Mm @ W0, L @ W0, study="mimicry", family=fam, mu_mal=mu, components=name, level=q, rule="-"))
            for qs in (0.25, 0.5, 0.9):
                for os_ in (0.01, 0.05):
                    hit = rng.random(N) < qs; Lr = rv.legit(rng, fam, N); Ms = M.copy()
                    Ms[hit, 2] = Lr[hit, 2]; Ms[hit, 3] = Lr[hit, 3]                    # stale = pre-compromise values
                    lh = rng.random(N) < os_; Lold = rv.legit(rng, fam, N); Ls = L.copy()
                    Ls[lh, 2] = Lold[lh, 2]; Ls[lh, 3] = Lold[lh, 3]                     # legitimate stale values (still legitimate)
                    rows.append(mets(Ms @ W0, Ls @ W0, study="stale", family=fam, mu_mal=mu, components="behavioural+system", level=qs, legit_stale=os_, rule="accept"))
                    Mf = Ms.copy(); Mf[hit, 2] = 50.0; Mf[hit, 3] = 50.0
                    Lf = Ls.copy(); Lf[lh, 2] = 50.0; Lf[lh, 3] = 50.0
                    rows.append(mets(Mf @ W0, Lf @ W0, study="stale", family=fam, mu_mal=mu, components="behavioural+system", level=qs, legit_stale=os_, rule="freshness"))
            rows.append(dict(base, study="baseline", family=fam, mu_mal=mu, components="-", level=0, rule="-"))
    B = pd.DataFrame(rows); B.to_csv(os.path.join(out, "manipulation_staleness.csv"), index=False)
    print(pd.DataFrame(s).round(3).to_string()); print(B.round(3).to_string())


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "..", "..", "02_Data", "Processed", "risk_engine_v7"))
