# risk_calibration_protocol.md — proposed calibration protocol for the 5-D risk engine

**Status: PROPOSED, NOT EXECUTED.** No industrial or labelled testbed data were available, so no calibration of weights or thresholds has been carried out. Everything below is a protocol for a future deployment. The only calibration experiment actually run is the synthetic Platt-scaling transfer test in `RISK_ENGINE_VALIDATION_REPORT.md` §4. It shows *why* recalibration is needed, not that calibration works on real data.

## Stage 0 — Instrumentation (before any fitting)
1. Implement the measurements in `risk_dimension_operational_specification.csv` for each device class: human operator, field device, edge service, twin.
2. Log raw signals, the five component values, the decision, the step-up outcome, the outage flag, and the asset criticality for every request. Retention and minimisation follow the privacy column of the specification.
3. Missing-data rule: a missing component is imputed with the conservative default and flagged. It is never imputed as 0.

## Stage 1 — Expert initialisation (shadow mode)
- Start from the expert weights (0.10, 0.10, 0.35, 0.30, 0.15) and θ = (30, 70, 90). Run the engine in **shadow mode** for at least 4 weeks per site: decisions are logged, not enforced.
- Estimate, per device class, the legitimate score distribution, the escalation rate per 10⁵ requests, and the step-up failure rate with and without outages.

## Stage 2 — Labelled data
- **Negatives:** shadow-mode traffic that passed incident review. It is label-noisy, because undetected attacks may be present.
- **Positives:** red-team campaigns and replayed attack scenarios in a site testbed or digital-twin replica, mapped to ATT&CK-for-ICS techniques. Synthetic positives must not be mixed with real negatives without stating so.
- Hold out complete weeks and complete campaigns (grouped splits) so that temporal leakage is avoided.

## Stage 3 — Fitting
1. **Weights:** constrained logistic regression, with w ≥ 0, Σw = 1 (score scale preserved), class-weighting for prevalence, and L2 regularisation towards the expert weights. Report the coefficient uncertainty (bootstrap over weeks).
2. **Probability calibration:** Platt or isotonic regression on a separate calibration fold. Report the ECE and Brier score **at the deployment prevalence**, not at a balanced prevalence.
3. **Thresholds:** cost-sensitive selection per asset class. Use the expected cost C(θ) = π·FNR(θ)·c_FN + (1 − π)·FPR(θ)·c_FP (+ the legitimate-isolation cost of safety assets). The minimisation is subject to an **operator budget**, a maximum number of false escalations per 10⁵ requests per shift, and to a hard cap on false isolation of safety-relevant assets. `risk_engine_thresholds.csv` shows that the optimum moves with prevalence and cost ratio (for the heavy-tailed family, from 64.5 down to 14 as prevalence rises from 0.1% to 20% when false positives are costly). No single threshold is optimal for every asset.
4. **Evidence rule:** choose κ, the decay unit and the half-life per device class. The objective is false-isolation probability per shift and per year below an agreed target (for example < 10⁻³ per device-year), with time-to-containment for the attacker profiles in `EVIDENCE_ACCUMULATION_REPORT.md` as the secondary objective.

## Stage 4 — Validation before enforcement
- Prospective validation on new weeks: precision at the deployment prevalence, false escalations per shift, false isolations per device-year, and time to containment in testbed campaigns.
- Graduated enforcement: step-up first, then block, and isolation of safety-relevant assets only with operator approval.

## Stage 5 — Operation: drift monitoring and recalibration
- Monitor per device class:
  - the population stability index of each component, alarm at > 0.2;
  - the escalation rate, by control chart against the shadow baseline;
  - step-up failure rates;
  - the calibration gap (mean predicted vs observed incident rate).
- Mandatory recalibration triggers: change-management events (new product, recipe or line), firmware fleet updates, mode changes, and any drift alarm.
- Periodic re-fitting (for example quarterly) on a rolling window, with the expert weights as the regularisation anchor. Every weight or threshold change is a control-plane policy change under the two-person rule (model M4e).

## What this protocol cannot provide
- It does not establish detection performance against unknown attacks.
- Label noise in the negatives biases precision estimates upward.
- Testbed attacks may not represent real adversaries.
- Calibration is site-specific and does not transfer between plants without re-validation. The synthetic transfer test shows that calibration is lost under distribution change.
