"""
Risk-engine robustness to telemetry quality and attack intensity (v4, concern 2 gap). SYNTHETIC data only.

Uses the unchanged generators of src/risk_engine_eval.py (component matrices, production weights, theta).
(a) Noisy telemetry: zero-mean Gaussian noise of s.d. sigma added to every component of both classes, then clipped.
(b) Missing telemetry: each component independently missing with probability q (both classes), with four
    imputation rules: 'zero' (v2 PoC behaviour), 'mid50' (v3 PoC rule), 'legit_mean' (population mean of legitimate
    traffic), 'reweight' (drop missing components and renormalise the remaining weights).
(c) Adversarial withholding: malicious requests suppress the behavioural and system components with probability
    q_a (telemetry tampering / evasion); legitimate requests have baseline missingness 0.05.
(d) Attack intensity: malicious behavioural/system mean mu_mal swept from 16 to 70.
Metrics at the step-up threshold theta1 = 30: TPR, FPR, ROC-AUC, precision and false alerts per true alert at
prevalence 1% and 0.1%. Usage: python3 risk_engine_robustness_experiment.py OUT_DIR
"""
import os, sys
import numpy as np
import pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "src"))
import risk_engine_eval as rv

N = 100_000
W = rv.W["production"]; TH = rv.THETA[0]
rng = np.random.default_rng(20261120)


def score(X, miss, rule, legit_mean):
    X = X.copy(); w = np.broadcast_to(W, X.shape).copy()
    if miss is not None:
        if rule == "zero": X[miss] = 0.0
        elif rule == "mid50": X[miss] = 50.0
        elif rule == "legit_mean": X[miss] = np.broadcast_to(legit_mean, X.shape)[miss]
        elif rule == "reweight":
            w[miss] = 0.0; s = w.sum(axis=1, keepdims=True); s[s == 0] = 1.0; w = w / s; X[miss] = 0.0
    return (np.clip(X, 0, 100) * w).sum(axis=1)


def metrics(sm, sl, **kw):
    tpr = float((sm > TH).mean()); fpr = float((sl > TH).mean()); auc = rv.auc(sm, sl)
    out = dict(kw, TPR=tpr, FPR=fpr, ROC_AUC=auc)
    for prev in (0.01, 0.001):
        prec = prev * tpr / (prev * tpr + (1 - prev) * fpr) if tpr + fpr > 0 else np.nan
        out[f"precision_{prev}"] = prec
        out[f"false_per_true_{prev}"] = ((1 - prev) * fpr) / (prev * tpr) if tpr > 0 else np.inf
    return out


def main(out):
    os.makedirs(out, exist_ok=True); rows = []
    for fam in ["gaussian", "heavy_tailed", "correlated"]:
        L = rv.legit(rng, fam, N); lm = L.mean(axis=0)
        for mu in (28, 55):
            M = rv.malicious(rng, fam, mu, N)
            for sig in (0, 5, 10, 20):                                            # (a)
                nl = np.clip(L + rng.normal(0, sig, L.shape), 0, 100); nm = np.clip(M + rng.normal(0, sig, M.shape), 0, 100)
                rows.append(metrics(score(nm, None, None, lm), score(nl, None, None, lm), study="noise", family=fam, mu_mal=mu, level=sig, rule="-"))
            for q in (0.05, 0.2, 0.5):                                            # (b)
                ml = rng.random(L.shape) < q; mm = rng.random(M.shape) < q
                for rule in ("zero", "mid50", "legit_mean", "reweight"):
                    rows.append(metrics(score(M, mm, rule, lm), score(L, ml, rule, lm), study="missing", family=fam, mu_mal=mu, level=q, rule=rule))
            for qa in (0.0, 0.25, 0.5, 0.9):                                      # (c)
                ml = rng.random(L.shape) < 0.05
                mm = rng.random(M.shape) < 0.05
                sup = rng.random(len(M)) < qa; mm[sup, 2] = True; mm[sup, 3] = True
                for rule in ("zero", "mid50", "legit_mean", "reweight"):
                    rows.append(metrics(score(M, mm, rule, lm), score(L, ml, rule, lm), study="withholding", family=fam, mu_mal=mu, level=qa, rule=rule))
        for mu in range(16, 71, 6):                                               # (d)
            M = rv.malicious(rng, fam, float(mu), N)
            rows.append(metrics(M @ W, L @ W, study="intensity", family=fam, mu_mal=mu, level=mu, rule="-"))
    d = pd.DataFrame(rows); d.to_csv(os.path.join(out, "risk_engine_robustness.csv"), index=False)
    fig, ax = plt.subplots(1, 3, figsize=(7.2, 2.4))
    for fam, c in zip(["gaussian", "heavy_tailed", "correlated"], ["#2a6f97", "#c8553d", "#8d99ae"]):
        s = d[(d.study == "intensity") & (d.family == fam)]
        ax[0].plot(s.level, s.TPR, "o-", ms=2.5, color=c, label=fam)
        s = d[(d.study == "noise") & (d.family == fam) & (d.mu_mal == 28)]
        ax[1].plot(s.level, s.FPR, "o-", ms=2.5, color=c)
    for rule, ls in zip(["zero", "mid50", "legit_mean", "reweight"], ["-", "--", ":", "-."]):
        s = d[(d.study == "withholding") & (d.family == "gaussian") & (d.mu_mal == 55) & (d.rule == rule)]
        ax[2].plot(s.level, s.TPR, ls, marker="o", ms=2.5, color="k", label=rule)
    ax[0].set_xlabel(r"attack intensity $\mu_{mal}$"); ax[0].set_ylabel("TPR at step-up threshold"); ax[0].legend(frameon=False, fontsize=6)
    ax[1].set_xlabel("telemetry noise s.d."); ax[1].set_ylabel("FPR (legitimate step-ups)")
    ax[2].set_xlabel("share of malicious requests withholding\nbehavioural + system telemetry"); ax[2].set_ylabel("TPR (Gaussian, noisy attacker)"); ax[2].legend(frameon=False, fontsize=6)
    for a, t in zip(ax, ["(a)", "(b)", "(c)"]): a.set_title(t, fontsize=8)
    fig.tight_layout(); fig.savefig(os.path.join(out, "fig_risk_robustness.pdf")); fig.savefig(os.path.join(out, "fig_risk_robustness.png"), dpi=200)
    pd.set_option("display.width", 220)
    print(d[d.study == "noise"][["family", "mu_mal", "level", "TPR", "FPR", "ROC_AUC", "false_per_true_0.001"]].round(4).to_string())
    print(d[(d.study == "missing") & (d.level == 0.2)][["family", "mu_mal", "rule", "TPR", "FPR", "ROC_AUC"]].round(4).to_string())
    print(d[(d.study == "withholding") & (d.mu_mal == 55)][["family", "level", "rule", "TPR", "FPR"]].round(4).to_string())
    print(d[d.study == "intensity"][["family", "mu_mal", "TPR", "FPR", "ROC_AUC", "false_per_true_0.01", "false_per_true_0.001"]].round(3).to_string())


if __name__ == "__main__":
    main(sys.argv[1])
