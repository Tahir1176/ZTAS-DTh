"""Assurance-boundary diagram (concern 4): which component is trusted, modelled, implemented, tested, verified."""
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
C = [  # name, x, y, trusted, model, poc, tested, note
    ("Administrative trust roots\n(key ceremony, policy admins)", 0.5, 8.6, "assumed", "M4e (quorum)", "partial: one admin role", "no", "two-person rule modelled only"),
    ("Identity provider (IdP)\n+ revocation list", 0.5, 6.6, "assumed", "M1 rev., M4a", "yes (Ed25519 tokens, CRL)", "S7, E", "CRL bound 1 s; stale-CRL fail-closed"),
    ("Policy decision point (PDP)\n5-D risk, evidence, quarantine", 0.5, 4.6, "trusted", "M2, M4b, M4c", "yes", "S6, S9, C, H", "risk weights not calibrated"),
    ("Segmentation controller\nflow-scoped segments", 0.5, 2.6, "trusted", "M2, M4b, M4c", "yes (versioned)", "S8, D, G", "no network enforcement (L7 only)"),
    ("Policy enforcement point (PEP)", 5.2, 5.6, "trusted", "M2, M4a-d", "yes", "A-H", "code NOT verified; tested only"),
    ("Provenance gate / service\nseq., hash chain, Merkle, ML-DSA", 5.2, 3.0, "trusted", "M1, M3, M4d", "yes", "S2-S5, B, F", "malicious-but-signed content passes"),
    ("Twin service / MES endpoint", 9.9, 5.6, "untrusted data", "-", "stub", "forward log", "physical process not modelled"),
    ("Gateways / signing keys\n(software keys in PoC)", 9.9, 3.0, "assumed", "M1 (key compr. = assumption)", "software keys", "-", "no HSM"),
    ("Network / transport", 9.9, 8.6, "untrusted", "abstract channel (M1)", "localhost HTTP, no TLS", "-", "no distributed deployment"),
]
col = {"assumed": "#f2d0a4", "trusted": "#cfe1ef", "untrusted data": "#e6e6e6", "untrusted": "#e6e6e6"}
fig, ax = plt.subplots(figsize=(10.5, 6.6)); ax.set_xlim(0, 14.6); ax.set_ylim(0.5, 10.2); ax.axis("off")
ax.add_patch(FancyBboxPatch((4.95, 2.0), 4.4, 5.6, boxstyle="round,pad=0.1", fill=False, ls="--", lw=1.2, ec="#2a6f97"))
ax.text(7.15, 7.75, "boundary of the bounded abstract models (M1-M4)", ha="center", color="#2a6f97", fontsize=8)
for n, x, y, tr, mdl, poc, tst, note in C:
    ax.add_patch(FancyBboxPatch((x, y - 0.75), 4.0, 1.5, boxstyle="round,pad=0.05", fc=col[tr], ec="k", lw=0.6))
    ax.text(x + 0.1, y + 0.5, n, va="top", fontsize=7.2, weight="bold")
    ax.text(x + 0.1, y - 0.15, f"trust: {tr} | model: {mdl}\nPoC: {poc} | tested: {tst}\nlimit: {note}", va="top", fontsize=5.8)
for (x1, y1, x2, y2) in [(4.5, 6.6, 5.2, 5.9), (4.5, 4.6, 5.2, 5.4), (4.5, 2.6, 5.2, 5.2), (9.2, 5.6, 9.9, 5.6), (7.2, 3.75, 7.2, 4.85), (9.9, 3.0, 9.2, 3.0)]:
    ax.annotate("", (x2, y2), (x1, y1), arrowprops=dict(arrowstyle="->", lw=0.7))
ax.text(0.5, 0.85, "Verified = exhaustively checked bounded ABSTRACT model only (not code, not unbounded systems). Cryptographic guarantees (EUF-CMA of ML-DSA/Ed25519, SHA-256 collision resistance)\n"
        "are assumed from the literature, not proved here. Implementation evidence = scenario tests of the localhost PoC. Colours: orange = assumed trust root, blue = trusted component under analysis, grey = untrusted.", fontsize=6.2)
fig.savefig("formal_assurance_boundary.png", dpi=200, bbox_inches="tight"); fig.savefig("formal_assurance_boundary.pdf", bbox_inches="tight")
print("ok")
