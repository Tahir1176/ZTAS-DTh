# FORMAL_SECURITY_MODEL.md: property, enforcement and evidence map (concern 4, Task 4.3)

Excerpt of `FORMAL_ANALYSIS_REPORT.md`.

## 3. Property → enforcement → evidence map (FORMAL_SECURITY_MODEL table)

| Property | Formal statement (abstract) | Enforcing component | Key assumption | Verification method | Status |
|---|---|---|---|---|---|
| P1 Flow authorisation | Delivery on e ⇒ unexpired segment ∋ (e, s) ∧ PDP allow at delivery time | PEP, segmentation controller, PDP | Complete mediation; PEP not compromised | M2, M4b, M4c (bounded model checking); PoC S8, D, G | Model-checked (abstract); implementation-tested (PoC) |
| P2 Provenance integrity | Accepted record and artifact = what an uncompromised gateway signed | Gate, provenance service | EUF-CMA (ML-DSA), SHA-256 collision resistance, key not compromised | Proposition 1 (reduction, informal proof); M1; M4b (fail-closed); PoC S2, B | Crypto: assumed. Abstract: model-checked. Implementation: tested |
| P3 Freshness / replay | Each record accepted at most once; strict mode also in increasing order | Gate | Per-gateway verifier state; atomic check-and-set | M1 (strict), M4d (concurrency); PoC S3, F (16 concurrent copies, 20 rounds → 1 accept each) | Model-checked; tested. **Window mode** (v3) guarantees at-most-once but only bounded reordering |
| P4 Lineage consistency | Accepted artifacts satisfy the type's lineage policy | Gate, lineage policy | Policy correct and complete | PoC S4, S4b | Implementation-tested only (not model-checked) |
| P5 Batch binding | Distinct leaf lists → distinct signed headers | Provenance service | Collision resistance | M3 (exhaustive to 5 leaves) | Model-checked (bounded) |
| P6 Revocation | No acceptance under a revoked key epoch or principal later than Δ after revocation | IdP, PEP, gate | CRL delivered within the refresh bound; cache TTL ≤ Δ or checked against the CRL | M1, M4a; PoC S7, E (last allow 0.51 s after revocation; bound 1 s); IdP outage fail-closed after 4.6 s (bound 5 s) | Model-checked; tested (timing measured, not verified) |
| P7 Containment after compromise | After quarantine takes effect, no request of s is allowed | PDP, PEP | No decision caching across quarantine; quarantine state durable | M2; PoC S6, H (persisted quarantine survives PDP restart; v2 lost it) | Model-checked; tested |
| P8 Plane separation | Only control-plane administrators change policy | Policy administration | Admin credentials uncompromised, or < quorum compromised | M2, M4e | Model-checked. Two-person rule **not implemented** in the PoC (specified only) |

Properties that are **assumed** rather than verified: the cryptographic hardness assumptions, complete mediation, PEP integrity, correctness of the lineage policy, and timely outage reports.

