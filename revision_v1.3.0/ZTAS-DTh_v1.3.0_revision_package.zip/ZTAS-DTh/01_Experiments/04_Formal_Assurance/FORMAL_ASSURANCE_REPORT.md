# FORMAL_ASSURANCE_REPORT.md: concern 4 (v4)

This report supersedes `FORMAL_ANALYSIS_REPORT.md` (v3). The v3 report is kept unchanged for traceability.

## 1. Scope

**What was done**
- We ran bounded, exhaustive, explicit-state checks of **abstract** models.
- The checker is a purpose-written Python breadth-first search: `src/formal/model_check*.py`.

**Tools not used**
- TLA+/TLC could not be installed in the build environment. `src/formal/ProvenanceGate.tla` (model M1) is supplied but **was not executed**.
- No Alloy model exists.

**What none of this verifies**
- the PoC code;
- unbounded behaviour or liveness;
- real-time behaviour;
- the cryptographic primitives.

## 2. Model inventory and results: 32 checks, all match expectation

| Model | Interaction | Positive configurations (property holds) | Negative controls (counterexample expected) | Log |
|---|---|---|---|---|
| M1 | Provenance gate: tamper, replay, reorder, revocation, key compromise | 3 | 4 | `logs/model_check_rerun.log` |
| M2 | Segments, per-request decisions, isolation, plane separation | 1 | 2 | same |
| M3 | Merkle encoding uniqueness | 1 | 1 (v1 encoding) | same |
| M4a | Revocation with cached decisions and asynchronous CRL | 3 | 2 | `logs/model_check_v3.log` |
| M4b | Component failure and recovery (fail-closed) | 1 | 3 | same |
| M4c | Policy update between decision and enforcement | 1 | 1 | same |
| M4d | Concurrent replay across two PEP workers | 1 | 1 | same |
| M4e | Administrator compromise (two-person rule) | 1 | 2 (single admin; both admins compromised) | same |
| **M4f (new, v4)** | Segment expiry between authorisation and enforcement | 1 (re-check at enforcement; 250 states) | 1 (63 states) | `logs/model_check_v4.log` |
| **M4g (new, v4)** | Quarantine raised while requests are in flight | 1 (re-check at enforcement; 41 states) | 1 (30 states) | same |

- Total: 14 positive and 18 negative runs, 32 in all.
- All 32 match their expected outcome. M4f/M4g were re-run on 2026-11-20 with identical results.
- One v3 negative control was mis-specified and gave no counterexample. It is kept in `model_check_v3_attempt1.log` and explained in the v3 report.

## 3. Property map

The full table is `property_map_v4.csv`. Its columns are: property, formal statement, enforcing component, assumptions, models, **bounds**, implementation tests, status and **limitations**.

| Property | Models (bounds) | PoC evidence | Status |
|---|---|---|---|
| P1 Flow authorisation | M2, M4b, M4c, M4f (≤3 deliveries / clock ≤ 4) | S8, D, G, **T-J** | model-checked + tested |
| P2 Provenance integrity | Prop. 1 (informal), M1, M4b | S2, B | crypto assumed |
| P3 Freshness / replay | M1, M4d | S3, F | model-checked + tested |
| P4 Lineage consistency | none | S4, S4b | tested only |
| P5 Batch binding | M3 (≤ 5 leaves) | unit tests | bounded model-checked |
| P6 Revocation | M1, M4a (Δ = 2, clock ≤ 6) | S7, E | timing measured, not verified |
| P7 Containment after quarantine | M2, M4g (2 in-flight requests) | S6, H, **T-K** | model-checked + tested |
| P8 Plane separation | M2, M4e | none | specified, **not implemented** |
| F1 Fail-closed | M4b | C, D, I | model-checked + tested |

## 4. New in v4: the check-to-enforce gap and its implementation

**What the models found**
- M4f and M4g model the interval between the PDP decision and the PEP forwarding the request.
- Without a re-check at enforcement, both models produce counterexamples:
  - **M4f:** a segment expires mid-request, and the request is still forwarded.
  - **M4g:** a quarantine is acknowledged, and an in-flight request is still forwarded.

**What changed in the PoC**
- The design rule was implemented in `src/poc/ztas_poc_v4.py` (`ZTAS_RECHECK_ENFORCE=1`).
- Before forwarding, the PEP re-queries the segmentation controller and the PDP quarantine list. It fails closed on error.

**PoC tests** (`05_POC_Integration/poc_race_tests_v4.csv`)

| Test | Re-check on | Re-check off |
|---|---|---|
| T-J | 0 of 720 requests forwarded after expiry | 24 of 720 (≤ 50 ms late) |
| T-K | 0 of 36 forwarded after quarantine was observed | 18 of 36 (≤ 45 ms late) |

**Cost** (`poc_concurrency_repeats_v4.csv`, 3 repetitions)
- **Median latency** rises by 0.4–1.3 ms at 1–4 clients, and by 4.5–6.5 ms at 16 clients.
- **Throughput** falls by 16–33% at 1–4 clients and by 11–18% at 16 clients.
- For plain requests at 8 clients, the difference lies within run-to-run variability.

**Limitations**
- The test harness injects a 50 ms delay between authorisation and forwarding to make the race observable.
- The re-check shrinks the window to the interval between the re-check and the forward call. It does not remove it; removing it would need the PEP and the segment state to be atomic.
- This residual window is stated in the manuscript.

## 5. Not covered

**Formal limits**
- replicated PDPs and quarantine consistency across replicas;
- network partitions and clock skew;
- Byzantine (non-crash) component faults;
- unbounded numbers of principals or records;
- liveness;
- code-level verification.

**Not implemented in the PoC**
- the two-person rule (P8).

## 6. Files
- **Model checkers:** `src/formal/model_check.py`, `model_check_v3.py`, `model_check_v4.py`; logs and JSON results in `src/formal/logs/`.
- **Property map and boundary figure:** `property_map_v4.csv`, `formal_assurance_boundary.pdf/png`.
- **PoC:** `src/poc/ztas_poc_v4.py`; tests in `01_Experiments/05_POC_Integration/poc_failure_tests.py` (scenarios J, K).
