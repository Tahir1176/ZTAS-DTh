# formal_model_audit.md (concern 4, Task 4.1)

Excerpt of `FORMAL_ANALYSIS_REPORT.md`.

## 1. Audit of the v2 formal material (formal_model_audit)

| Item | Finding |
|---|---|
| Properties P1–P8, Propositions 1–3 | Stated with assumptions and non-guarantees (Table V in v2, Table IV in v3). Proofs are informal reductions to EUF-CMA and collision resistance. |
| M1 | Provenance gate: tamper, replay, reorder, drop, inject, key compromise, revocation. N ≤ 3 records. Up to 11 760 states. |
| M2 | Segments, per-request decisions, isolation, plane separation. Up to 3 deliveries; one policy change. |
| M3 | Exhaustive Merkle encodings over a 3-letter alphabet, up to 5 leaves. |
| Negative controls | 7, all producing counterexamples. Re-run in v3: identical results (`logs/model_check_rerun.log`). |
| Gaps relevant to the reviewer | No asynchrony between components; PDP/PEP always available; revocation either known or not (no propagation bound); no cached decisions with TTL; no concurrent workers; administrators trusted by assumption; no policy-update race. |
| Inconsistency found | Algorithm 1 said "degraded mode" when the PDP is unreachable, but the PoC fails closed. P3 promised strict ordering, but the PoC concurrency test shows strict ordering denies legitimate concurrent requests (Scenario A). Both are addressed in v3. |

