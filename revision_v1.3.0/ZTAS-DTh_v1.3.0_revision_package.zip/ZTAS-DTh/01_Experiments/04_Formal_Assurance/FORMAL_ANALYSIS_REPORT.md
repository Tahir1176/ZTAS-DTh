# FORMAL_ANALYSIS_REPORT.md — concern 4 (formal_model_audit + FORMAL_SECURITY_MODEL property map + results)

**Scope statement used in the manuscript.** Bounded, exhaustive, explicit-state checking of *abstract* models with a purpose-written Python checker. TLA+/TLC could not be downloaded in this environment; the TLA+ specification of M1 is provided but **was not executed**. Nothing here verifies the PoC code, unbounded behaviour, timing, or the cryptographic primitives.

## 1. Audit of the v2 formal material (formal_model_audit)

| Item | Finding |
|---|---|
| Properties P1–P8, Propositions 1–3 | Stated with assumptions and non-guarantees (Table V in v2, Table IV in v3). Proofs are informal reductions to EUF-CMA and collision resistance. |
| M1 | Provenance gate: tamper, replay, reorder, drop, inject, key compromise, revocation. N ≤ 3 records. Up to 11 760 states. |
| M2 | Segments, per-request decisions, isolation, plane separation. Up to 3 deliveries; one policy change. |
| M3 | Exhaustive Merkle encodings over a 3-letter alphabet, up to 5 leaves. |
| Negative controls | 7, all producing counterexamples. Re-run in v3: identical results (`logs/model_check_rerun.log`). |
| Gaps relevant to the reviewer | No asynchrony between components; PDP/PEP always available; revocation either known or not (no propagation bound); no cached decisions with TTL; no concurrent workers; administrators trusted by assumption; no policy-update race. |
| Inconsistency found | Algorithm 1 said "degraded mode" when the PDP is unreachable, but the PoC fails closed. P3 promised strict ordering, but the PoC concurrency test shows strict ordering denies legitimate concurrent requests (Scenario A). Both are addressed in v3. |

## 2. New model M4 (`src/formal/model_check_v3.py`; log `logs/model_check_v3.log`)

| Sub-model | Interaction represented | Property | Intended configuration | Negative control(s) |
|---|---|---|---|---|
| M4a | Revocation with cached allow decisions and asynchronous CRL refresh (bound Δ = 2 ticks, clock ≤ 6) | P6′: no delivery to a revoked principal more than Δ after revocation | OK (159 / 255 states) for cache TTL ≤ Δ, **or** TTL > Δ with the cache checked against a CRL refreshed every Δ | VIOLATION for TTL 4 > Δ without a CRL check (153 states); VIOLATION for TTL > Δ with CRL refresh 4 > Δ (232 states) |
| M4b | PDP, provenance service and segmentation controller fail and recover arbitrarily; two deliveries | P1/P2 under failure: no delivery without a PDP decision, a verified provenance record, or a confirmed open segment | OK (112 states) when every component fails closed | 3 controls, each VIOLATION: fail-open PDP (17), skipped provenance (19), assumed-open segment (12) |
| M4c | Policy update committed between decision and enforcement; two concurrent requests | P1′: no enforcement of a decision computed under a policy version older than the PEP's current version | OK (59 states) with version re-validation | VIOLATION without re-validation (32 states; trace: decide under v0 → commit v1 → PEP learns v1 → enforce) |
| M4d | Two PEP workers process copies of the same signed record concurrently | P3 (at-most-once) under concurrency | OK (4 states) with an atomic check-and-set | VIOLATION for non-atomic read-then-write (12 states; both workers read hw = 0 and both accept) |
| M4e | Administrative trust root; compromise of administrators | P8: no malicious policy change | OK (5 states) with a two-person rule and ≤ 1 compromised admin | VIOLATION with single-admin approval (4); VIOLATION when both admins are compromised (9) — documents the assumption |

**A negative control that failed (reported for transparency).** In the first M4a run (`logs/model_check_v3_attempt1.log`), the control "CRL refresh slower than Δ" produced **no** counterexample. The reason is that with a fresh PDP and cache TTL ≤ Δ, staleness is already bounded by the TTL. The control was mis-specified, not the model. It was replaced by two configurations with TTL > Δ: one with a CRL check (holds) and one with a slow CRL (violates). This also yields a design rule: **revocation latency ≤ min(cache TTL, CRL refresh interval)** when cached decisions are checked against the CRL.

All 16 M4 runs and all 12 re-run M1–M3 runs match their expected outcome. Total checking time is under 1 s.

## 3. Property → enforcement → evidence map (FORMAL_SECURITY_MODEL table)

| Property | Formal statement (abstract) | Enforcing component | Key assumption | Verification method | Status |
|---|---|---|---|---|---|
| P1 Flow authorisation | Delivery on e ⇒ unexpired segment ∋ (e, s) ∧ PDP allow at delivery time | PEP, segmentation controller, PDP | Complete mediation; PEP not compromised | M2, M4b, M4c (bounded model checking); PoC S8, D, G | Model-checked (abstract); implementation-tested (PoC) |
| P2 Provenance integrity | Accepted record and artifact = what an uncompromised gateway signed | Gate, provenance service | EUF-CMA (ML-DSA), SHA-256 collision resistance, key not compromised | Proposition 1 (reduction, informal proof); M1; M4b (fail-closed); PoC S2, B | Crypto: assumed. Abstract: model-checked. Implementation: tested |
| P3 Freshness / replay | Each record accepted at most once; strict mode also in increasing order | Gate | Per-gateway verifier state; atomic check-and-set | M1 (strict), M4d (concurrency); PoC S3, F (16 concurrent copies, 20 rounds → 1 accept each) | Model-checked; tested. **Window mode** (v3) guarantees at-most-once but only bounded reordering |
| P4 Lineage consistency | Accepted artifacts satisfy the type's lineage policy | Gate, lineage policy | Policy correct and complete | PoC S4, S4b | Implementation-tested only (not model-checked) |
| P5 Batch binding | Distinct leaf lists → distinct signed headers | Provenance service | Collision resistance | M3 (exhaustive to 5 leaves) | Model-checked (bounded) |
| P6 Revocation | No acceptance under a revoked key epoch or principal later than Δ after revocation | IdP, PEP, gate | CRL delivered within the refresh bound; cache TTL ≤ Δ or checked against the CRL | M1, M4a; PoC S7, E (last allow 0.51 s after revocation; bound 1 s); IdP outage fail-closed after 4.6 s (bound 5 s) | Model-checked; tested (timing measured, not verified) |
| P7 Containment after compromise | After quarantine takes effect, no request of s is allowed | PDP, PEP | No decision caching across quarantine; quarantine state durable | M2; PoC S6, H (persisted quarantine survives PDP restart; v2 lost it) | Model-checked; tested |
| P8 Plane separation | Only control-plane administrators change policy | Policy administration | Admin credentials uncompromised, or < quorum compromised | M2, M4e | Model-checked. Two-person rule **not implemented** in the PoC (specified only) |

Properties that are **assumed** rather than verified: the cryptographic hardness assumptions, complete mediation, PEP integrity, correctness of the lineage policy, and timely outage reports.

## 4. Concurrency and asynchrony: what is and is not covered
- **Covered abstractly:**
  - bounded revocation propagation with cached decisions (M4a);
  - component failure and recovery (M4b);
  - check-to-enforce races on policy updates (M4c);
  - concurrent replay (M4d).
- **Covered by tests only:** concurrent request handling, interleaving, timeouts and recovery (PoC Scenarios A–I).
- **Not covered:**
  - real network delay distributions and partitions between replicated PDPs;
  - distributed state consistency of quarantine across multiple PDP replicas;
  - clock skew;
  - unbounded numbers of principals or records;
  - liveness: whether a legitimate request is eventually served;
  - the code of the PEP/PDP (no code-level verification).
- The models are small by design. They are meant to reveal missing design rules (each negative control does), not to prove the deployed system correct.

## 5. Assurance boundary
`formal_assurance_boundary.png|pdf` shows, for each component — administrative trust roots, IdP and revocation, PDP, segmentation controller, PEP, provenance gate, twin service, gateway keys, network — whether it is assumed trusted, modelled (which model), implemented in the PoC, tested (which scenarios), and what is not verified. The dashed boundary encloses the components inside the abstract models.

## 6. Files
- `src/formal/model_check_v3.py` and `logs/model_check_v3.log`, `model_check_v3_results.json`, `model_check_v3_attempt1.log`
- `src/formal/model_check.py` and `logs/model_check_rerun.log`
- `formal_assurance_boundary.png|pdf`, `make_assurance_boundary.py`
