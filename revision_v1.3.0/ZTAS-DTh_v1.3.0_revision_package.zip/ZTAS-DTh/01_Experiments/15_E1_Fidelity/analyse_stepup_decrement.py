"""v7: paired comparison of ZTAS-DTh with and without the Eq. (2) step-up decrement (E1 graphs/seeds), and of each
against static ZT + provenance. Graph means; 2000 graph-bootstrap resamples."""
import os, numpy as np, pandas as pd
R = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")
d = pd.read_csv(os.path.join(R, "02_Data/Raw/v7/stepup_decrement_raw.csv"))
a = pd.read_csv(os.path.join(R, "02_Data/Raw/v2/e1_main_rec.csv")); z = pd.read_csv(os.path.join(R, "02_Data/Raw/v2/e1_main.csv"))
k = ["topology", "graph", "run", "profile"]
m = d[k + ["frac", "reach_O"]].merge(a[a.config == "ztas_rec"][k + ["frac", "reach_O"]], on=k, suffixes=("_dec", "_rec")).merge(
    z[z.config == "zt_prov"][k + ["frac"]].rename(columns={"frac": "frac_ztprov"}), on=k)
g = m.groupby(["topology", "profile", "graph"]).mean(numeric_only=True).reset_index()
rng = np.random.default_rng(11); rows = []
for (t, p), x in g.groupby(["topology", "profile"], sort=False):
    n = len(x); idx = rng.integers(n, size=(2000, n))
    diff = (x.frac_dec - x.frac_rec).to_numpy(); adv_dec = (x.frac_dec - x.frac_ztprov).to_numpy(); adv_rec = (x.frac_rec - x.frac_ztprov).to_numpy()
    ci = lambda v: np.percentile(v[idx].mean(1), [2.5, 97.5])
    rows.append(dict(topology=t, profile=p, frac_rec=x.frac_rec.mean(), frac_dec=x.frac_dec.mean(), diff=diff.mean(), diff_lo=ci(diff)[0], diff_hi=ci(diff)[1],
                     adv_rec=adv_rec.mean(), adv_dec=adv_dec.mean(), adv_dec_lo=ci(adv_dec)[0], adv_dec_hi=ci(adv_dec)[1],
                     graphs_dec_better_than_ztprov=float((adv_dec < 0).mean()), reachO_rec=x.reach_O_rec.mean(), reachO_dec=x.reach_O_dec.mean()))
o = pd.DataFrame(rows); os.makedirs(os.path.join(R, "02_Data/Processed/e1_fidelity_v7"), exist_ok=True)
o.to_csv(os.path.join(R, "02_Data/Processed/e1_fidelity_v7/stepup_decrement_summary.csv"), index=False)
print(len(m), "paired rows"); print(o.round(3).to_string())
