"""
v7 fidelity check (independent audit finding). Eq. (2) of the paper subtracts one unit of evidence after a
successful step-up; the PoC implements this, but the E1 simulator (dth_sim.py) never did, so an attacker that passes
a step-up kept its evidence in E1. This run re-evaluates ZTAS-DTh (revised rule, kappa=3, decay 0.95) with the
decrement on the E1 graphs and seeds and compares it, paired, with the archived ztas_rec and zt_prov results.
Usage: python3 stepup_decrement_experiment.py OUT.csv
"""
import sys, os, csv
from multiprocessing import Pool
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "src"))
import topologies as tp, dth_sim as ds
from run_e1 import TOPOS, PROFILES, METRICS, N_GRAPHS, N_RUNS, gseed, rseed
REC = dict(kappa=3.0, decay=0.95)

def task(args):
    ti, g = args; topo = TOPOS[ti]; gs = gseed(ti, g)
    prep = ds.Prepared(tp.build(topo, gs)); rows = []
    for r in range(N_RUNS):
        rs = rseed(gs, r); D = ds.draws(prep, ds.DEFAULTS["T"], rs)
        for prof, mu in PROFILES.items():
            P = dict(ds.DEFAULTS, mu_mal=mu, success_decrement=True, **REC); S = ds.scores(D, P, ds.W_ADAPT)
            res = ds.simulate(prep, D, "ztas", P, S)
            rows.append([topo, g, gs, r, rs, prof, "ztas_rec_dec"] + [res[m] for m in METRICS])
    return rows

if __name__ == "__main__":
    with open(sys.argv[1], "w", newline="") as f:
        w = csv.writer(f); w.writerow(["topology", "graph", "graph_seed", "run", "run_seed", "profile", "config"] + METRICS)
        with Pool(2) as p:
            for rows in p.imap_unordered(task, [(ti, g) for ti in range(len(TOPOS)) for g in range(N_GRAPHS)]):
                w.writerows(rows)
    print("done", flush=True)
