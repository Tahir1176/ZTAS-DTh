"""
Attacker-profile experiment (revision v3, concern 9). Same simulator and defaults as E1; ZTAS-DTh uses the
recommended evidence rule (kappa=3, decay 0.95). Profiles (MODELLING ASSUMPTIONS, not mapped to real actors):
  noisy        mu_mal=55 (v2)                         -- anomalous requests, frequent escalation
  stealthy     mu_mal=28 (v2)                         -- requests close to legitimate behaviour
  rapid        mu_mal=40, p_exploit=0.60, stepup_fail=0.40   -- exploits quickly, holds some step-up material
  coordinated  mu_mal=28, three simultaneous footholds in different entities (entry pool D/M/S/X)
  insider_cred mu_mal=22, p_auth=0.10, stepup_fail=0.20       -- valid credentials and second factor
Usage: python3 adversary_profiles_experiment.py OUT.csv.gz
"""
import os, sys
from multiprocessing import Pool
import numpy as np
import pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "src"))
import topologies as tp, dth_sim as ds

PROFILES = {
    "noisy": dict(mu_mal=55.0), "stealthy": dict(mu_mal=28.0),
    "rapid": dict(mu_mal=40.0, p_exploit=0.60, stepup_fail=0.40),
    "coordinated": dict(mu_mal=28.0, _entries=3),
    "insider_cred": dict(mu_mal=22.0, p_auth=0.10, stepup_fail=0.20),
}
CFGS = ["perimeter", "zones", "zt", "zt_prov", "ztas"]
MET = ["frac", "reach_O", "n_phases", "path_len", "detected", "contained", "residual", "t_reach_O"]
REC = dict(kappa=3.0, decay=0.95)


def task(args):
    topo, g = args; ti = list(tp.TOPOLOGIES).index(topo); gs = 10000 * ti + g + 700
    prep = ds.Prepared(tp.build(topo, gs)); out = []
    for r in range(20):
        rs = 1000003 * gs + r; D = ds.draws(prep, 60, rs)
        rng = np.random.default_rng(rs + 1)
        for prof, spec in PROFILES.items():
            P = dict(ds.DEFAULTS, **REC); P.update({k: v for k, v in spec.items() if not k.startswith("_")})
            Dp = dict(D)
            if spec.get("_entries"):
                Dp["entry"] = list(rng.choice(prep.entry_pool, spec["_entries"], replace=False))
            S = ds.scores(Dp, P, ds.W_ADAPT)
            for c in CFGS:
                res = ds.simulate(prep, Dp, c, P, S)
                out.append([topo, g, gs, r, rs, prof, c] + [res[m] for m in MET])
    return out


if __name__ == "__main__":
    tasks = [(t, g) for t in tp.TOPOLOGIES for g in range(10)]
    rows = []
    with Pool(2) as p:
        for k, x in enumerate(p.imap_unordered(task, tasks)):
            rows += x
    pd.DataFrame(rows, columns=["topology", "graph", "graph_seed", "run", "run_seed", "profile", "config"] + MET).to_csv(
        sys.argv[1], index=False, compression="gzip")
    print("done")
