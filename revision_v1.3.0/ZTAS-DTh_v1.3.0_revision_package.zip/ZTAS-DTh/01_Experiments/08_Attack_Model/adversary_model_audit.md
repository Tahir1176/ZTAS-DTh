# adversary_model_audit.md (concern 9, Task 9.1)

Excerpt of `ADVERSARY_MODEL_VALIDATION_REPORT.md`.

## 1. Audit of the adversary model (adversary_model_audit)

| Element | How it is modelled (E1 simulator, v2) | Abstraction |
|---|---|---|
| Capabilities | Network-level attacker; may hold some credentials (p_auth < 1 defeats authorisation with probability 1 − p_auth); may pass step-up (1 − stepup_fail) | No privilege escalation inside an entity; no physical access |
| Initial compromise | One entry, uniform over external, design, manufacturing and service entities. v3 adds three simultaneous entries | Operations assets are never the entry point |
| Credential possession | Implicit in p_auth and stepup_fail | Constant over time (no harvesting) |
| Exploit probability | p_exploit per attempted move per step | Identical for every entity and flow; no vulnerability heterogeneity |
| Movement | Each step, every active compromised entity attempts every outgoing flow | Breadth-first, non-adaptive; no target selection |
| Artifact modification | Moves on artifact-mediated flows (share f_art) cross provenance gates; rejection with p_v | p_v per scenario (Table III); content semantics not modelled |
| Interface propagation | Remaining flows bypass provenance | – |
| Replay / reordering | Not in E1. Covered by the formal model M1/M4d and PoC S3/F | – |
| Stealth | Malicious behavioural and system scores centred on mu_mal | Static; no learning of thresholds |
| Detection | Generic monitoring isolates with d_generic per step; zone conduit detection; provenance rejection isolates; risk tiers | Detection is a probability, not a sensor model |
| Containment | Isolation stops an entity's moves; operations assets after an approval delay | – |

