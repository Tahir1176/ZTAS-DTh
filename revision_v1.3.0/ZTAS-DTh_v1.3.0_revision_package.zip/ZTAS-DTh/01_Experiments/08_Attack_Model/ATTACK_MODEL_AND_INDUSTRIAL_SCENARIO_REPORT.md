# ATTACK_MODEL_AND_INDUSTRIAL_SCENARIO_REPORT.md

> v4 report. Sections 'v4 additions' are new in this round; the v3 content below them is kept unchanged for traceability (original file `ADVERSARY_MODEL_VALIDATION_REPORT.md` is also kept).

## v4 additions

- **Profiles in the continuous-time evidence extension.** It adds a burst profile and a rapid multi-step profile.
- **Stealthy and rapid attackers** evade every evidence threshold above κ = 1 (EVIDENCE report). Their containment therefore depends on segments, provenance and generic detection.
- **Re-execution.** The adversary-profile experiment was re-run from scratch for two tasks (reference g0, multi_org g9). The results are identical to within 1e-16 (`09_Reproducibility/rerun_subset_other_v4.csv`).
- **Unchanged limitations.** The attacker is non-adaptive. There is no communication between footholds, no privilege escalation inside an entity, and no physical consequence model. The scenario mapping uses ATT&CK for ICS technique names only.

---

## v3 content (unchanged)

# ADVERSARY_MODEL_VALIDATION_REPORT.md — concern 9 (includes adversary_model_audit)

## 1. Audit of the adversary model (adversary_model_audit)

| Element | How it is modelled (E1 simulator, v2) | Abstraction |
|---|---|---|
| Capabilities | Network-level attacker; may hold some credentials (p_auth < 1 defeats authorisation with probability 1 − p_auth); may pass step-up (1 − stepup_fail) | No privilege escalation inside an entity; no physical access |
| Initial compromise | One entry, uniform over external, design, manufacturing and service entities. v3 adds three simultaneous entries | Operations assets are never the entry point |
| Credential possession | Implicit in p_auth and stepup_fail | Constant over time (no harvesting) |
| Exploit probability | p_exploit per attempted move per step | Identical for every entity and flow; no vulnerability heterogeneity |
| Movement | Each step, every active compromised entity attempts every outgoing flow | Breadth-first, non-adaptive; no target selection |
| Artifact modification | Moves on artifact-mediated flows (share f_art) cross provenance gates; rejection with p_v | p_v per scenario (Table III); content semantics not modelled |
| Interface propagation | Remaining flows bypass provenance | – |
| Replay / reordering | Not in E1. Covered by the formal model M1/M4d and PoC S3/F | – |
| Stealth | Malicious behavioural and system scores centred on mu_mal | Static; no learning of thresholds |
| Detection | Generic monitoring isolates with d_generic per step; zone conduit detection; provenance rejection isolates; risk tiers | Detection is a probability, not a sensor model |
| Containment | Isolation stops an entity's moves; operations assets after an approval delay | – |

## 2. Operational attacker profiles (`adversary_profiles_experiment.py`)
Same simulator, defaults and recommended evidence rule. 9 families × 10 fresh graphs × 20 runs, common random numbers.

| Profile | Parameters | Interpretation (not a mapping to real actors) | Perimeter | Zones | ZT | ZT+prov | ZTAS-DTh | Δ vs ZT+prov | Graphs favouring | Graphs with Δ ≤ −0.05 |
|---|---|---|---|---|---|---|---|---|---|---|
| A Noisy | mu_mal 55 | Anomalous, tool-driven behaviour | 0.92 | 0.60 | 0.75 | 0.40 | 0.04 | −0.36 | 100% | 91% |
| B Stealthy | mu_mal 28 | Behaviour close to legitimate | 0.92 | 0.60 | 0.75 | 0.40 | 0.14 | −0.25 | 100% | 87% |
| C Rapid multi-step | mu_mal 40, p_exploit 0.6, stepup_fail 0.4 | Prepared exploit chain, partial credential material | 0.92 | 0.76 | 0.82 | 0.57 | 0.31 | −0.25 | 100% | 91% |
| D Coordinated | 3 simultaneous footholds, mu_mal 28 | Several compromised entities at once | 0.95 | 0.79 | 0.89 | 0.65 | 0.31 | −0.33 | 100% | 94% |
| E Credentialed insider-like | mu_mal 22, p_auth 0.10, stepup_fail 0.20 | Valid credentials and second factor | 0.92 | 0.60 | 0.82 | 0.49 | 0.28 | −0.21 | 100% | 84% |

- Rapid, coordinated and credentialed attackers roughly double ZTAS-DTh's compromised fraction compared with the stealthy profile (0.28–0.31 vs 0.14). The reach of the operations phase rises from 0.14 to 0.28–0.31.
- In the dense topology the rapid attacker reaches 0.67 under ZTAS-DTh, against 0.81 under ZT+prov.
- In the sparse topology the difference against ZT+prov is only 0.03–0.08 for every profile.
- Detection is about 1.0 for every ZT-family configuration under every profile, so the differences come from **speed of containment**, not detection. This is a property of the generic-monitoring abstraction.

## 3. Mapping to representative industrial attack behaviours (`attack_scenario_mapping.csv`)
Seven scenarios are mapped. Each row gives the source already cited in the manuscript, the ATT&CK-for-ICS technique names, the initial access, compromised asset, objective, lifecycle movement, artifact or interface interaction, ZTAS-DTh controls, model representation and model limitation. The scenarios are:
1. Stuxnet-type manipulation of controller logic through engineering artefacts.
2. A validly signed malicious supplier component.
3. Credential-based lateral movement.
4. A tampered design artefact.
5. Remote-maintenance abuse.
6. Twin data or model manipulation.
7. Coordinated footholds.

No offensive procedures are described. The purpose is to validate the abstraction: each scenario corresponds to an entry phase, a flow type (artifact or interface), a p_v case and a profile.

## 4. What the model does not represent
- **Fixed probabilities.** They abstract vulnerability heterogeneity, patch state, exploit reliability and defender response quality.
- **No adaptation.** The attacker does not learn thresholds, wait for segment windows or time actions to outages (the outage-evasion risk is discussed qualitatively).
- **Coordination.** Only independent simultaneous footholds; no communication between attacker instances or division of labour.
- **Multi-stage behaviour.** Reconnaissance, privilege escalation and impact stages inside an entity are collapsed into a single compromise event. Physical consequences and view manipulation are not modelled.
- **Initial compromise.** Uniform over non-operations entities; insider compromise of the control plane is analysed only in the formal model (M4e).
- **Progression.** Breadth-first attempts on every outgoing flow each step, which is an upper bound on attempt rate. A selective attacker would make fewer, better-chosen attempts.

## 5. Files
`adversary_profiles_experiment.py`, `adversary_profiles_summary.csv`, raw `02_Data/raw/adversary_profiles_raw.csv.gz`, `attack_scenario_mapping.csv`. The simulator change in v3 is backward compatible (multi-entry); regression test: 72 v2 rows reproduced exactly.
