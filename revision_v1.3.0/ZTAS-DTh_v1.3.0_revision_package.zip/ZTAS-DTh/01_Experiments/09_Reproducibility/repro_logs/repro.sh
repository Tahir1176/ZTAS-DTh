#!/usr/bin/env bash
# Clean-checkout reproduction of tag v1.0.0 (revision v3, concern 10). Times each step.
cd "$(dirname "$0")"
for s in e1 e2 formal e3 e4; do
  t0=$(date +%s); echo "== step $s start $(date '+%F %T')"
  bash run_all.sh $s > logs_$s.txt 2>&1; rc=$?
  echo "== step $s rc=$rc seconds=$(( $(date +%s)-t0 ))"
done
