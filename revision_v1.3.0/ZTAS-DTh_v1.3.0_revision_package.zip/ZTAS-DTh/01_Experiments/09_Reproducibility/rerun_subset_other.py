"""
Deterministic re-execution check (v4, concern 10) for the evidence-policy extension and the adversary-profile experiments:
re-runs selected tasks from scratch and compares with the archived raw files (exact equality expected).
Usage: python3 rerun_subset_other.py
"""
import os, sys, importlib.util
import numpy as np
import pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, "..", "..")


def load(path, name):
    sys.argv = [path]
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m


def cmp(old, new, key, cols, label):
    m = old.merge(new, on=key, suffixes=("_a", "_n"))
    diff = 0.0
    for c in cols:
        a, b = m[c + "_a"], m[c + "_n"]
        if pd.api.types.is_numeric_dtype(a):
            dd = np.abs(a.astype(float) - b.astype(float)); dd = dd[~(a.isna() & b.isna())]
            diff = max(diff, float(np.nanmax(dd)) if len(dd) else 0.0)
            if (a.isna() != b.isna()).any(): diff = np.inf
        elif (a.astype(str) != b.astype(str)).any(): diff = np.inf
    return dict(task=label, rows_archived=len(old), rows_rerun=len(new), rows_matched=len(m), max_abs_diff=diff, identical=diff == 0 and len(m) == len(old) == len(new))


rows = []
ev = load(os.path.join(ROOT, "01_Experiments", "03_Evidence_Accumulation", "evidence_policy_extension_experiment.py"), "evx")
arch = pd.read_csv(os.path.join(ROOT, "02_Data", "Raw", "evidence_policy_extension_raw.csv.gz"))
for g, prof, rate in [(0, "moderate", 1000), (7, "burst", 10)]:
    new = pd.DataFrame(ev.attack_task((g, prof, rate, "risk_only", 30)))
    old = arch[(arch.graph == g) & (arch.profile == prof) & (arch.rate == rate)]
    cols = [c for c in old.columns if c not in ("graph", "run", "policy", "profile", "rate")]
    rows.append(cmp(old, new, ["graph", "run", "policy", "profile", "rate"], cols, f"evidence_ext g{g} {prof} {rate}")); print(rows[-1], flush=True)
ad = load(os.path.join(ROOT, "01_Experiments", "08_Attack_Model", "adversary_profiles_experiment.py"), "adv")
arch = pd.read_csv(os.path.join(ROOT, "02_Data", "Raw", "adversary_profiles_raw.csv.gz"))
cols_all = list(arch.columns)
for topo, g in [("reference", 0), ("multi_org", 9)]:
    new = pd.DataFrame(ad.task((topo, g)), columns=cols_all)
    old = arch[(arch[cols_all[0]] == topo) & (arch[cols_all[1]] == g)]
    key = cols_all[:7]
    rows.append(cmp(old, new, key, cols_all[7:], f"adversary {topo} g{g}")); print(rows[-1], flush=True)
out = pd.DataFrame(rows); out.to_csv(os.path.join(HERE, "rerun_subset_other_v4.csv"), index=False); print(out.to_string(index=False))
