"""
Deterministic re-execution check (v4, concern 10): re-runs a subset of evaluation units of the joint-sensitivity
LHS design from scratch and compares every metric with the archived raw results (exact equality expected,
because each unit uses fixed graph/run seeds and common random numbers).
Usage: python3 rerun_subset_joint.py [unit ...]   e.g. reference_0_0 sparse_1_2
"""
import sys, os, tempfile, importlib.util
import numpy as np
import pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, "..", "..")
JS = os.path.join(ROOT, "01_Experiments", "01_Joint_Sensitivity", "joint_sensitivity_experiment.py")
spec = importlib.util.spec_from_file_location("jse", JS); jse = importlib.util.module_from_spec(spec); spec.loader.exec_module(jse)
units = sys.argv[1:] or ["reference_0_0", "sparse_1_2", "hub_3_1"]
arch = pd.read_csv(os.path.join(ROOT, "02_Data", "Raw", "joint_sensitivity_raw.csv.gz"))
points = jse.design_lhs(False)
tmp = tempfile.mkdtemp()
rows = []
for u in units:
    t, g, r = u.rsplit("_", 2); g, r = int(g), int(r)
    if t not in arch.topology.unique():
        print("skip unknown topology", t); continue
    fn = jse.run_unit((t, g, r, points, jse.ARCH, tmp))
    new = pd.read_csv(fn); old = arch[(arch.topology == t) & (arch.graph == g) & (arch.run == r)]
    key = ["point", "config"]; m = old.merge(new, on=key, suffixes=("_a", "_n"))
    mets = [c for c in jse.METRICS if pd.api.types.is_numeric_dtype(old[c])]
    diff = max(float(np.nanmax(np.abs(m[c + "_a"].astype(float) - m[c + "_n"].astype(float)))) for c in mets)
    rows.append(dict(unit=u, rows_archived=len(old), rows_rerun=len(new), rows_matched=len(m), max_abs_diff=diff, identical=diff == 0 and len(m) == len(old) == len(new)))
    print(rows[-1], flush=True)
out = pd.DataFrame(rows); out.to_csv(os.path.join(HERE, "rerun_subset_joint_v4.csv"), index=False); print(out.to_string(index=False))
