"""
v6 (reviewer concern 3): structural statistics of the nine synthetic DTh topology families,
computed on exactly the 30 graphs per family used by E1 (graph_seed = 10000*ti + g).
Descriptive only: these graphs are synthetic and are not claimed to represent a real plant.
"""
import sys, os, json
import numpy as np, networkx as nx, pandas as pd
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "src"))
import topologies as tp, dth_sim as ds
from run_e1 import TOPOS, N_GRAPHS, gseed

rows = []
for ti, topo in enumerate(TOPOS):
    for g in range(N_GRAPHS):
        G = tp.build(topo, gseed(ti, g)); prep = ds.Prepared(G)
        n = G.number_of_nodes(); m = G.number_of_edges()
        outd = np.array([d for _, d in G.out_degree()]); ind = np.array([d for _, d in G.in_degree()])
        bnd = np.mean([prep.boundary[e] for e in prep.boundary])
        org = np.mean([prep.org[a] != prep.org[b] for (a, b) in prep.boundary])
        cross_phase = np.mean([prep.phase[a] != prep.phase[b] for (a, b) in prep.boundary])
        # reachability: share of entry candidates from which some O entity is reachable, and shortest hop count to O
        O = [v for v in G.nodes if G.nodes[v]["phase"] == "O"]
        entries = [prep.nodes[i] for i in prep.entry_pool]
        dists = []
        for e in entries:
            L = nx.single_source_shortest_path_length(G, e)
            d = [L[o] for o in O if o in L]
            dists.append(min(d) if d else np.nan)
        dists = np.array(dists, float)
        und = G.to_undirected()
        rows.append(dict(topology=topo, graph=g, nodes=n, internal=int(prep.internal.sum()), edges=m,
                         density=m / (n * (n - 1)), mean_out=outd.mean(), max_out=outd.max(), max_in=ind.max(),
                         cv_out=outd.std() / outd.mean(), clustering=nx.average_clustering(und),
                         gate_boundary_share=bnd, cross_phase_share=cross_phase, cross_org_share=org,
                         entry_reaches_O=float(np.mean(~np.isnan(dists))), hops_entry_to_O=float(np.nanmean(dists)),
                         scc_largest=max(len(c) for c in nx.strongly_connected_components(G)) / n))
df = pd.DataFrame(rows)
out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "02_Data", "Processed", "topology_statistics_v6")
os.makedirs(out, exist_ok=True)
df.to_csv(os.path.join(out, "topology_statistics_per_graph.csv"), index=False)
summ = df.drop(columns="graph").groupby("topology", sort=False).agg(["mean", "min", "max"])
summ.columns = ["_".join(c) for c in summ.columns]; summ.to_csv(os.path.join(out, "topology_statistics_summary.csv"))
print(df.drop(columns="graph").groupby("topology", sort=False).mean().round(3).to_string())
