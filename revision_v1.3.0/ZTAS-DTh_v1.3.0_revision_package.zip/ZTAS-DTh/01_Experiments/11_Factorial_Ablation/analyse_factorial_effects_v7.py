"""
v7 (reviewer concern 7): classical factorial effects and order-dependence of attribution, from the v6 factorial run.
For the 2^3 design over P (provenance), S (segments), R (risk engine) on top of static ZT, with outcome
y = fraction compromised (graph means over 50 runs):
  main effect of X      = mean over the 4 settings of the other two factors of [y(X off) - y(X on)]  (reduction)
  two-way interaction XY = half the difference between the effect of X with Y on and with Y off
  three-way interaction PSR (standard contrast)
  marginal contribution of X when added 1st / 2nd / 3rd (min and max over the six orders): shows how much the
  attribution depends on the order in which mechanisms are introduced. Shapley values (v6) are the average.
CIs: 2000 graph-level bootstrap resamples. Output: 02_Data/Processed/factorial_ablation_v6/factorial_effects_v7.csv
"""
import os, itertools
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, "..", "..")
raw = pd.read_csv(os.path.join(ROOT, "02_Data", "Raw", "v6", "factorial_ablation_raw.csv"))
g = raw.groupby(["topology", "profile", "graph", "prov", "seg", "risk"]).frac.mean().reset_index()
rng = np.random.default_rng(20261127); B = 2000
F = ["prov", "seg", "risk"]


def effects(Y):
    """Y: dict (p,s,r) -> array over graphs. Returns dict of effect arrays (reduction = positive)."""
    y = lambda p, s, r: Y[(p, s, r)]
    out = {}
    for i, f in enumerate(F):
        acc = 0
        for o in itertools.product([0, 1], repeat=2):
            on = list(o); on.insert(i, 1); off = list(o); off.insert(i, 0)
            acc = acc + (y(*off) - y(*on))
        out[f"main_{f}"] = acc / 4
    for i, j in itertools.combinations(range(3), 2):
        k = 3 - i - j; acc = 0
        for zk in (0, 1):
            def val(a, b):
                v = [0, 0, 0]; v[i] = a; v[j] = b; v[k] = zk; return y(*v)
            eff_i_j1 = val(0, 1) - val(1, 1); eff_i_j0 = val(0, 0) - val(1, 0)
            acc = acc + (eff_i_j1 - eff_i_j0) / 2
        out[f"int_{F[i]}_{F[j]}"] = acc / 2
    s = 0
    for p, s_, r in itertools.product([0, 1], repeat=3):
        s = s + (-1) ** (3 - (p + s_ + r)) * y(p, s_, r)
    out["int_prov_seg_risk"] = -s / 4
    # marginal contribution of each factor by position in the order of introduction
    for i, f in enumerate(F):
        vals = []
        for order in itertools.permutations(range(3)):
            pos = order.index(i); before = set(order[:pos])
            st = [1 if k in before else 0 for k in range(3)]; on = list(st); on[i] = 1
            vals.append(y(*st) - y(*on))
        out[f"marg_min_{f}"] = np.minimum.reduce(vals); out[f"marg_max_{f}"] = np.maximum.reduce(vals)
    return out


rows = []
for (topo, prof), d in g.groupby(["topology", "profile"], sort=False):
    piv = d.pivot_table(index="graph", columns=["prov", "seg", "risk"], values="frac")
    Y = {k: piv[k].to_numpy() for k in piv.columns}; n = len(piv)
    est = {k: float(np.mean(v)) for k, v in effects(Y).items()}
    idx = rng.integers(n, size=(B, n)); boots = {k: [] for k in est}
    for ii in idx:
        e = effects({k: v[ii] for k, v in Y.items()})
        for k in est: boots[k].append(float(np.mean(e[k])))
    r = dict(topology=topo, profile=prof)
    for k in est:
        r[k] = est[k]; r[k + "_lo"], r[k + "_hi"] = np.percentile(boots[k], [2.5, 97.5])
    rows.append(r)
out = pd.DataFrame(rows)
out.to_csv(os.path.join(ROOT, "02_Data", "Processed", "factorial_ablation_v6", "factorial_effects_v7.csv"), index=False)
pd.set_option("display.width", 250)
print(out[["topology", "profile", "main_prov", "main_seg", "main_risk", "int_prov_seg", "int_prov_risk", "int_seg_risk", "int_prov_seg_risk",
           "marg_min_risk", "marg_max_risk", "marg_min_seg", "marg_max_seg", "marg_min_prov", "marg_max_prov"]].round(3).to_string())
