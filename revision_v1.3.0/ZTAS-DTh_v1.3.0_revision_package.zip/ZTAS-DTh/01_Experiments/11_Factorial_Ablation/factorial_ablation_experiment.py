"""
v6 factorial ablation (reviewer concern 5 / Part III-B).
2^3 factorial over {provenance gates, flow-scoped segments, risk engine} on top of static ZT
(per-request authorization + generic monitoring), on all 9 topology families x 30 graphs x 50 runs,
two attacker profiles. Same graph and run seeds as run_e1.py (common random numbers), revised
evidence rule (kappa=3, per-step decay 0.95) as in run_e1_rec.py. All parameters: DEFAULTS (assumptions).
Usage: python3 factorial_ablation_experiment.py OUT.csv
"""
import sys, os, csv
from multiprocessing import Pool
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "src"))
import topologies as tp, dth_sim as ds
from run_e1 import TOPOS, PROFILES, METRICS, N_GRAPHS, N_RUNS, gseed, rseed
REC = dict(kappa=3.0, decay=0.95)
CELLS = {  # (prov, seg, risk) -> config name
    (0, 0, 0): "zt", (1, 0, 0): "zt_prov", (0, 1, 0): "zt_seg", (0, 0, 1): "zt_risk",
    (1, 1, 0): "ztas_no_risk", (1, 0, 1): "ztas_no_seg", (0, 1, 1): "ztas_no_prov", (1, 1, 1): "ztas"}

def task(args):
    ti, g = args; topo = TOPOS[ti]; gs = gseed(ti, g)
    prep = ds.Prepared(tp.build(topo, gs)); rows = []
    for r in range(N_RUNS):
        rs = rseed(gs, r); D = ds.draws(prep, ds.DEFAULTS["T"], rs)
        for prof, mu in PROFILES.items():
            P = dict(ds.DEFAULTS, mu_mal=mu, **REC); S = ds.scores(D, P, ds.W_ADAPT)
            for (pv, sg, rk), c in CELLS.items():
                res = ds.simulate(prep, D, c, P, S)
                rows.append([topo, g, gs, r, rs, prof, c, pv, sg, rk] + [res[m] for m in METRICS])
    return rows

if __name__ == "__main__":
    with open(sys.argv[1], "w", newline="") as f:
        w = csv.writer(f); w.writerow(["topology", "graph", "graph_seed", "run", "run_seed", "profile", "config", "prov", "seg", "risk"] + METRICS)
        with Pool(2) as p:
            for i, rows in enumerate(p.imap_unordered(task, [(ti, g) for ti in range(len(TOPOS)) for g in range(N_GRAPHS)])):
                w.writerows(rows)
                if i % 27 == 0: print(i, flush=True)
    print("done", flush=True)
