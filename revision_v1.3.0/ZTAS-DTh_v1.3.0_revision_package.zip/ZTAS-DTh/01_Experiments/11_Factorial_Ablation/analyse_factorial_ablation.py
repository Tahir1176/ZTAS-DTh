"""
v6 factorial ablation analysis.
Inputs : 02_Data/Raw/v6/factorial_ablation_raw.csv (this experiment), 02_Data/Raw/v2/e1_main*.csv (archived E1, consistency check)
Outputs: 02_Data/Processed/factorial_ablation_v6/{cell_means.csv, contributions.csv, consistency.json}
Unit of analysis: graph (mean over 50 runs); CIs from 2000 graph-level bootstrap resamples (percentile).
Contribution of a mechanism = Shapley value of the reduction in compromised fraction relative to static ZT
(average marginal reduction over the six orders in which the three mechanisms can be added).
"""
import os, json, itertools, math
import numpy as np, pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, "..", "..")
raw = pd.read_csv(os.path.join(ROOT, "02_Data", "Raw", "v6", "factorial_ablation_raw.csv"))
OUT = os.path.join(ROOT, "02_Data", "Processed", "factorial_ablation_v6"); os.makedirs(OUT, exist_ok=True)
B = 2000; rng = np.random.default_rng(20261126)
MECH = ["prov", "seg", "risk"]
NAME = {(0, 0, 0): "zt", (1, 0, 0): "zt_prov", (0, 1, 0): "zt_seg", (0, 0, 1): "zt_risk",
        (1, 1, 0): "ztas_no_risk", (1, 0, 1): "ztas_no_seg", (0, 1, 1): "ztas_no_prov", (1, 1, 1): "ztas"}

# ---- consistency with archived E1 (same seeds): zt, zt_prov (rule-independent) and ztas (revised rule)
cons = {}
a = pd.read_csv(os.path.join(ROOT, "02_Data", "Raw", "v2", "e1_main.csv"))
ar = pd.read_csv(os.path.join(ROOT, "02_Data", "Raw", "v2", "e1_main_rec.csv"))
k = ["topology", "graph", "run", "profile"]
for cfg, ref, refcfg in [("zt", a, "zt"), ("zt_prov", a, "zt_prov"), ("ztas", ar, "ztas_rec")]:
    m = raw[raw.config == cfg][k + ["frac", "reach_O"]].merge(ref[ref.config == refcfg][k + ["frac", "reach_O"]], on=k, suffixes=("", "_arch"))
    cons[cfg] = dict(rows=int(len(m)), max_abs_diff_frac=float((m.frac - m.frac_arch).abs().max()),
                     max_abs_diff_reachO=float((m.reach_O - m.reach_O_arch).abs().max()))
json.dump(cons, open(os.path.join(OUT, "consistency.json"), "w"), indent=1); print("consistency", cons)

g = raw.groupby(["topology", "profile", "graph", "config"])[["frac", "reach_O"]].mean().reset_index()
W = {0: 1 / 3, 1: 1 / 6, 2: 1 / 3}   # Shapley weights |S|!(n-|S|-1)!/n! for n=3


def stats(F):
    """F: dict config -> array over graphs (frac). Returns dict of statistics."""
    v = lambda S: F["zt"] - F[NAME[tuple(int(m in S) for m in MECH)]]   # reduction vs static ZT
    out = {}
    for i in MECH:
        rest = [m for m in MECH if m != i]; phi = 0
        for r in range(3):
            for S in itertools.combinations(rest, r):
                phi = phi + W[r] * (v(set(S) | {i}) - v(set(S)))
        out[f"shapley_{i}"] = phi
        out[f"alone_{i}"] = v({i})                       # adding i alone to static ZT
        out[f"removal_{i}"] = v(set(MECH)) - v(set(MECH) - {i})   # removing i from ZTAS-DTh
    out["total"] = v(set(MECH))
    out["interaction"] = v(set(MECH)) - sum(v({i}) for i in MECH)
    out["beyond_ztprov"] = F["zt_prov"] - F["ztas"]
    return out


cell_rows, con_rows = [], []
for (topo, prof), d in g.groupby(["topology", "profile"], sort=False):
    piv = d.pivot(index="graph", columns="config", values="frac"); pO = d.pivot(index="graph", columns="config", values="reach_O")
    n = len(piv)
    for c in NAME.values():
        x = piv[c].to_numpy(); bs = np.array([x[rng.integers(n, size=n)].mean() for _ in range(B)])
        cell_rows.append(dict(topology=topo, profile=prof, config=c, frac=x.mean(), frac_lo=np.percentile(bs, 2.5),
                              frac_hi=np.percentile(bs, 97.5), reach_O=pO[c].mean()))
    F = {c: piv[c].to_numpy() for c in NAME.values()}
    est = {kk: float(np.mean(vv)) for kk, vv in stats(F).items()}
    idx = rng.integers(n, size=(B, n)); boots = [stats({c: F[c][ii] for c in F}) for ii in idx]
    row = dict(topology=topo, profile=prof, graphs=n)
    for kk in est:
        arr = np.array([np.mean(b[kk]) for b in boots]); row[kk] = est[kk]
        row[kk + "_lo"], row[kk + "_hi"] = np.percentile(arr, [2.5, 97.5])
    con_rows.append(row)
pd.DataFrame(cell_rows).to_csv(os.path.join(OUT, "cell_means.csv"), index=False)
C = pd.DataFrame(con_rows); C.to_csv(os.path.join(OUT, "contributions.csv"), index=False)
pd.set_option("display.width", 250)
print(C[["topology", "profile", "total", "shapley_prov", "shapley_seg", "shapley_risk", "interaction", "interaction_lo", "interaction_hi",
         "alone_risk", "removal_risk", "removal_risk_lo", "removal_risk_hi", "beyond_ztprov"]].round(3).to_string())
