"""
Legitimate requests affected across the joint parameter space (v4, concern 1 gap).

The E1 simulator models only the attacker. For each of the 850 joint-sensitivity points, this script applies the
point's evidence configuration (kappa, decay factor per risk-engine evaluation; outage-aware rule as in the revised
policy) to LEGITIMATE entities, using the legitimate-side model of the v3 evidence study:
  escalations are a Poisson process with rate = request rate x escalation probability (v2 E2 values: Gaussian
  0.02006, heavy-tailed 0.03728); legitimate step-up failures by device class (higher during outages, 5% outage time,
  mean 300 s); evidence decays per evaluation; isolation at e >= kappa.
Static ZT and ZT+provenance have no evidence rule, so their legitimate false-isolation rate from this mechanism is
zero by construction; their legitimate cost (generic-monitoring false positives) is not modelled.
Output per point: false isolation per 8-h shift for heavy-tailed field devices and Gaussian human operators at
1 request/s, joined with the point's paired attack-side difference (ZTAS - ZT+prov).
Usage: python3 joint_legitimate_impact.py
"""
import os
import numpy as np
import pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, "..", "..")
CLASSES = {"field_device_heavy": dict(fail=0.005, fail_out=0.40, esc=0.03728), "human_operator_gauss": dict(fail=0.02, fail_out=0.02, esc=0.02006)}


def legit_iso(kappa, lam, cls, rate=1.0, n=2000, shift=8 * 3600, seed=0):
    rng = np.random.default_rng(seed); c = CLASSES[cls]; lr = rate * c["esc"]
    a_r, b_r, pi = (1 / 300) * 0.05 / 0.95, 1 / 300, 0.05
    t = np.zeros(n); ev = np.zeros(n); out = rng.random(n) < pi; iso = np.zeros(n, bool)
    while True:
        dt = rng.exponential(1 / lr, n); t += dt
        alive = (t < shift) & ~iso
        if not alive.any(): break
        e = np.exp(-(a_r + b_r) * dt); out = rng.random(n) < np.where(out, pi + (1 - pi) * e, pi * (1 - e))
        ev = np.where(alive, ev * lam ** (dt * rate), ev)
        fail = rng.random(n) < np.where(out, c["fail_out"], c["fail"])
        ev = ev + (alive & fail & ~out)
        ev = np.where(alive & ~fail, np.maximum(0, ev - 1), ev)
        iso |= alive & (ev >= kappa)
    return float(iso.mean())


def main():
    pts = pd.read_csv(os.path.join(ROOT, "02_Data", "Raw", "joint_sensitivity_raw_points.csv"))
    proc = pd.read_csv(os.path.join(ROOT, "02_Data", "Processed", "joint_sensitivity_processed.csv"))
    w = proc.pivot_table(index=["point", "design"], columns="config", values="frac").reset_index()
    w = w.groupby(["point", "design"])[["zt_prov", "ztas"]].mean().reset_index(); w["d_prov"] = w.ztas - w.zt_prov
    rows = []
    for _, p in pts.iterrows():
        r = dict(point=p.point, design=p.design, kappa=p.kappa, decay=p.decay)
        for i, cls in enumerate(CLASSES):
            r[f"false_iso_{cls}"] = legit_iso(p.kappa, p.decay, cls, seed=int(p.point) * 7 + i)
        rows.append(r)
    d = pd.DataFrame(rows).merge(w, on=["point", "design"])
    d.to_csv(os.path.join(ROOT, "02_Data", "Processed", "joint_legitimate_impact.csv"), index=False)
    s = d.groupby("design").agg(mean_d_prov=("d_prov", "mean"), fi_field_mean=("false_iso_field_device_heavy", "mean"),
                                fi_field_share_gt_1pct=("false_iso_field_device_heavy", lambda x: (x > 0.01).mean()),
                                fi_human_mean=("false_iso_human_operator_gauss", "mean"))
    c = d[d.design == "continuous"]
    both = ((c.d_prov <= -0.05) & (c.false_iso_field_device_heavy <= 0.01)).mean()
    fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.6))
    sc = ax[0].scatter(c.kappa, c.decay, c=c.false_iso_field_device_heavy, s=8, cmap="viridis", vmin=0, vmax=1)
    ax[0].set_xlabel(r"evidence threshold $\kappa$"); ax[0].set_ylabel("decay factor per evaluation"); fig.colorbar(sc, ax=ax[0], fraction=0.05, label="false isolation / shift")
    ax[0].set_title("(a) legitimate field devices (heavy-tailed, 1 req/s)", fontsize=7)
    ax[1].scatter(c.false_iso_field_device_heavy, c.d_prov, s=6, color="#2a6f97", alpha=0.6)
    ax[1].axhline(-0.05, color="k", lw=0.5, ls=":"); ax[1].axvline(0.01, color="k", lw=0.5, ls=":")
    ax[1].set_xlabel("legitimate false isolation per shift"); ax[1].set_ylabel("frac(ZTAS) - frac(ZT+prov)")
    ax[1].set_title("(b) security vs availability per joint point", fontsize=7)
    fig.tight_layout(); fig.savefig(os.path.join(HERE, "joint_sensitivity_figures", "fig_joint_legitimate_impact.pdf")); fig.savefig(os.path.join(HERE, "joint_sensitivity_figures", "fig_joint_legitimate_impact.png"), dpi=200)
    print(s.round(3).to_string()); print("continuous: share of points with advantage>=0.05 AND field false isolation <=1%/shift:", round(both, 3))
    print(c.groupby(pd.cut(c.kappa, [1, 2, 3, 4, 6]), observed=False)[["false_iso_field_device_heavy", "d_prov"]].mean().round(3))


if __name__ == "__main__":
    main()
