# JOINT_SENSITIVITY_REPORT.md — reviewer concern 1

**Status:** experiment completed, analysis completed, verified against the raw data.
**Evidence type:** simulation under assumed parameters. These are not measured industrial properties.

## 1. What was audited
`parameter_audit.csv` classifies every simulator parameter:
- **No parameter is measured.** All attacker and defence probabilities are modelling assumptions.
- κ, decay, the thresholds and the weights are configuration choices.
- Graph structure and entry points are derived or randomised.
- v2 varied parameters one at a time (OAT) on the reference topology, plus a p_v × f_art grid. The reviewer's point that this is insufficient is correct.

## 2. Design (`joint_sensitivity_config.yaml`, `joint_sensitivity_experiment.py`)

**Parameters.** Eleven are varied jointly: p_exploit, p_auth, d_generic, p_act, f_art, p_v, mu_mal (stealth), stepup_fail, κ, decay and approval delay. Each range and its rationale is given in the YAML file. All ranges are exploratory assumptions.

**Continuous joint sampling.** 400 Latin-hypercube points over the full ranges.

**Regimes.** Three regimes of 150 LHS points each: **optimistic**, **moderate** and **adverse**.
- Only the six defensive-effectiveness parameters are restricted to regime-specific sub-ranges. For example, p_auth is 0.6–0.8 / 0.35–0.6 / 0.1–0.35, and p_v is 0.9–0.99 / 0.6–0.9 / 0–0.6.
- Attacker parameters (p_exploit, f_art, mu_mal) and the evidence configuration span their full ranges in every regime.
- The regimes are defined by explicit distributions, not narrative labels.

**Evaluation units.** Every point is evaluated on the same 144 units: 9 topology families × 4 fresh graph instances × 4 runs.
- Graph seeds are disjoint from v2.
- Common random numbers are shared across all points and all five architectures, so every comparison is exactly paired.
- 850 points × 144 units × 5 architectures gives 612 000 simulations.

**Sobol design.** Saltelli/Sobol (SALib, N = 256, k = 11, 3328 points) on the reference topology, 16 fixed units, for ZT + provenance and ZTAS-DTh. These are variance-based indices of the paired difference.

**Uncertainty.** A two-way cluster bootstrap resamples parameter points and graph instances (within topology) independently. Runs inside a graph are never treated as independent graphs.

**Pilot.** 70 points × 36 units. It confirmed that the lazily evaluated risk score equals the v2 vectorised score element-wise (maximum absolute difference 7·10⁻¹⁵) and that `simulate()` outputs are identical.

## 3. Results (`joint_sensitivity_results.csv`, `_by_topology.csv`, `_global_indices.csv`)

Mean compromised fraction over all cells:

| Design | Perimeter | Zones | Static ZT | ZT + prov | ZTAS-DTh | Δ(ZTAS − ZT+prov) [95% CI] | Cells ZTAS < ZT+prov | Cells with advantage ≥ 0.05 | Cells ZTAS worse by ≥ 0.01 | Cells ZTAS ranked 1st of 5 |
|---|---|---|---|---|---|---|---|---|---|---|
| Optimistic | 0.92 | 0.61 | 0.40 | 0.18 | 0.03 | −0.149 [−0.172, −0.126] | 99.5% | 62.9% | 0.0% | 100% |
| Moderate | 0.92 | 0.62 | 0.74 | 0.44 | 0.21 | −0.232 [−0.262, −0.204] | 98.5% | 80.7% | 0.8% | 97.2% |
| Adverse | 0.92 | 0.63 | 0.90 | 0.74 | 0.62 | −0.119 [−0.146, −0.096] | 80.8% | 55.9% | 3.8% | **43.9%** |
| Continuous | 0.92 | 0.62 | 0.68 | 0.48 | 0.25 | −0.229 [−0.251, −0.209] | 96.7% | 75.5% | 1.2% | 90.9% |

The other metrics in the continuous design (ZTAS − ZT+prov, 95% CI):
- reach of the operations phase: −0.23 [−0.25, −0.20]
- containment: +0.20 [+0.18, +0.22]
- path length: −2.1 [−2.3, −1.9] hops
- phases reached: −0.69 [−0.75, −0.62]
- residual active compromise: −0.014 [−0.020, −0.008]
- detection probability: essentially equal (−0.004). Every configuration with generic monitoring eventually detects, so detection is not a discriminating metric in this model.

**Answers to the reviewer's questions:**
1. *Does ZTAS-DTh consistently beat ZT+prov?* Not universally. It was lower in 96.7% of point × topology cells of the continuous design and practically lower (by ≥ 0.05) in 75.5%. In 1.2% of cells (43 of 3600) it was worse by ≥ 0.01. Those cells have a median p_act of 0.79, against 0.55 overall, and a median mu_mal of 25, against 39 overall: segments are almost always open and the attacker is stealthy, so the extra controls rarely act.

The simulator also has a mechanism by which ZTAS-DTh can do worse. A segment or risk-tier denial pre-empts a move that, under ZT+prov, would have reached the provenance gate and isolated the attacker. The denied attacker stays active and can succeed later.

With 16 units per cell, part of these small differences is Monte-Carlo noise.
2. *Is the advantage stable under adverse combinations?* It shrinks but does not vanish on average: −0.12 [−0.15, −0.10]. However, in the adverse regime ZTAS-DTh ranks first in only 43.9% of cells. In the rest, **static zones** has a lower compromised fraction, because the adverse regime degrades the ZT-family controls while the zones baseline keeps its default effectiveness. This comparison is therefore biased in favour of zones and should not be read as "zones beat ZTAS-DTh". It does show that under degraded controls ZTAS-DTh loses its decisive margin.
3. *Which parameters matter most?* Sobol total indices of the paired difference on the reference topology:
   - p_act (segment duty cycle) 0.35
   - p_exploit 0.30
   - mu_mal (stealth) 0.29
   - p_auth 0.22
   - d_generic 0.22
   - f_art 0.19
   - p_v 0.13
   - stepup_fail 0.13
   - κ 0.06
   - approval delay and decay < 0.01

   First-order indices are small (sum ≈ 0.38) compared with the total indices (sum ≈ 1.9), so the advantage depends on **interactions** between parameters. The PRCC on the continuous LHS across all nine families gives the same ordering: p_act +0.61, mu_mal −0.50, stepup_fail −0.34, p_v +0.34, f_art +0.30, p_exploit −0.30.
4. *Which combinations reduce the advantage?* A depth-3 decision tree (training accuracy 0.82) finds that "advantage < 0.05" occurs mainly in three cases:
   - the **sparse** topology (almost always);
   - **p_act > 0.83** with **mu_mal < 39**: segments almost always open and a stealthy attacker;
   - **very low p_exploit (< 0.12)**: little propagation, so little to prevent.

   Higher p_v and f_art also *reduce* the margin, because they strengthen ZT+prov more than ZTAS-DTh, which already isolates through its other controls.
5. *Does the advantage disappear in any meaningful region?* Yes:
   - **sparse topologies**, with a mean Δ of only −0.044 and an advantage ≥ 0.05 in 31% of points;
   - **always-open segments facing a stealthy attacker**;
   - **adverse control effectiveness in dense or multi-supplier graphs**, where only 32–49% of points show an advantage ≥ 0.05.
6. *Regimes of poor absolute performance?* In the adverse regime ZTAS-DTh still loses 62% of the thread on average (dense: 84%). The architecture does not compensate for broken authorisation, near-useless provenance and permanently open segments.
7. *Is the result topology-dependent?* Strongly. In the continuous design, mean Δ ranges from −0.32 (dense, reference) to −0.04 (sparse). Graph-level means within a family vary by about 0.05–0.16, for example reference −0.38 to −0.22.

## 4. Interpretation and limits
- The robustness claim the evidence supports: *under joint variation of all eleven assumed parameters, ZTAS-DTh had a lower simulated compromised fraction than static ZT with provenance in most of the explored space. The margin depends mainly on segment duty cycle, attacker stealth and exploit rate, and on topology. It is small in sparse threads and with always-open segments.*
- **Not supported:** universal superiority, or any statement about real detection rates.
- The joint ranges are themselves assumptions. A region of the parameter space that the ranges exclude, for example p_auth < 0.1, is not covered.
- Zones and perimeter parameters were not varied, because they are baselines, not the system under test. As noted above, this biases the adverse-regime comparison with zones.

## 5. Files
- `joint_sensitivity_experiment.py`, `joint_sensitivity_config.yaml`, `joint_sensitivity_analysis.py`, `joint_sensitivity_analysis.ipynb` (executed)
- Raw: `02_Data/raw/joint_sensitivity_raw.csv.gz`, `joint_sensitivity_sobol_raw.csv.gz` (+ `_points.csv`, `_meta.json`)
- Processed: `02_Data/processed/joint_sensitivity_processed.csv`
- Results: `joint_sensitivity_results.csv`, `joint_sensitivity_by_topology.csv`, `joint_sensitivity_global_indices.csv`, `joint_sensitivity_graph_level.csv`, `joint_sensitivity_vanishing_advantage_tree.txt`
- Figures: `joint_sensitivity_figures/fig_joint_sensitivity*.pdf|png`, `fig_joint_by_topology.pdf|png`


## v4 additions

**Legitimate impact.** Each joint point's κ and decay were applied to legitimate entities (`joint_legitimate_impact.py`; `02_Data/Processed/joint_legitimate_impact.csv`; Supp. Table S11, Fig. S8).

| Design | Mean diff (ZTAS − ZT+prov) | Field-device false isolation / shift (mean) | Points > 1% | Operators |
|---|---|---|---|---|
| continuous | −0.229 | 0.002 | 9.0% | 0.013 |
| optimistic | −0.149 | 0.002 | 8.0% | 0.011 |
| moderate | −0.232 | 0.002 | 8.7% | 0.011 |
| adverse | −0.119 | 0.002 | 8.7% | 0.012 |

- In the continuous design, 79.5% of cells have both an advantage ≥ 0.05 and at most 1% false isolation of field devices per shift.
- False isolation is concentrated at κ ≤ 2: mean 0.011, where the advantage is −0.27 (−0.20 for κ > 4).
- The baselines have no evidence rule, and their generic-monitoring false positives are not modelled.

**Parameter audit.** `parameter_audit.csv` (both copies) now has `justification` and `recommended_range` columns.

**Re-execution.** Three units were re-run from scratch and are bit-identical.
