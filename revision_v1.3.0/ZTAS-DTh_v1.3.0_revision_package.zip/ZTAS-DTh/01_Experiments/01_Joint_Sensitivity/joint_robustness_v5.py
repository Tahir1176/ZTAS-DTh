"""
Concern 1 (v5): interpretation and robustness of the joint-sensitivity result. Reads the archived joint-sensitivity raw
data (unchanged) and the new alternate-range run.
 (1) denominator of the headline shares (points, cells, graphs, runs);
 (2) concentration: is the mean advantage driven by a small subset of cells?
 (3) interactions: ST - S1 from the archived Sobol indices;
 (4) surrogate tree: in-sample vs out-of-sample (5-fold CV grouped by LHS point), majority baseline, and
     stability of the root split over 200 bootstrap resamples of points;
 (5) dependence on attacker stealth (mu_mal tertiles) and topology;
 (6) alternate ranges (alternate_range_experiment.py).
Usage: python3 joint_robustness_v5.py
"""
import os
import numpy as np
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import GroupKFold
from sklearn.metrics import balanced_accuracy_score
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, "..", "..")
RAW = os.path.join(ROOT, "02_Data", "Raw"); PROC = os.path.join(ROOT, "02_Data", "Processed")
OUT = os.path.join(PROC, "joint_robustness_v5"); os.makedirs(OUT, exist_ok=True)
NAMES = ["p_exploit", "p_auth", "d_generic", "p_act", "f_art", "p_v", "mu_mal", "stepup_fail", "kappa", "decay", "approval_delay"]


def cells_of(raw, pts, design):
    g = raw[raw.design == design].groupby(["point", "topology", "graph", "config"]).frac.mean().reset_index()
    w = g.pivot_table(index=["point", "topology", "graph"], columns="config", values="frac").reset_index()
    w["d_prov"] = w.ztas - w.zt_prov
    c = w.groupby(["point", "topology"])[["d_prov", "ztas", "zt_prov", "zt", "zones", "perimeter"]].mean().reset_index()
    return w, c.merge(pts[["point"] + NAMES], on="point")


def shares(c):
    return dict(n_cells=len(c), n_points=c.point.nunique(), mean_d=c.d_prov.mean(), share_lower=(c.d_prov < 0).mean(),
                share_adv_ge_005=(c.d_prov <= -0.05).mean(), share_worse_ge_001=(c.d_prov >= 0.01).mean(),
                median_d=c.d_prov.median(), p10=c.d_prov.quantile(0.1), p90=c.d_prov.quantile(0.9))


def main():
    raw = pd.read_csv(os.path.join(RAW, "joint_sensitivity_raw.csv.gz"))
    pts = pd.read_csv(os.path.join(RAW, "joint_sensitivity_raw_points.csv"))
    rep = {}
    # (1) denominator
    w, c = cells_of(raw, pts, "continuous")
    rep["denominator"] = dict(points=int(c.point.nunique()), topologies=int(c.topology.nunique()), cells=len(c),
                              graphs_per_topology=int(w.groupby("topology").graph.nunique().max()),
                              runs_per_graph=int(raw[raw.design == "continuous"].groupby(["topology", "graph"]).run.nunique().max()))
    # (2) concentration of the advantage
    adv = (-c.d_prov).clip(lower=0).sort_values(ascending=False).to_numpy()
    tot = adv.sum()
    rep["concentration"] = {f"share_of_total_advantage_top_{q}pct_cells": float(adv[: int(len(adv) * q / 100)].sum() / tot) for q in (10, 25, 50)}
    rep["concentration"].update(shares(c))
    # (3) interactions from archived Sobol indices
    gi = pd.read_csv(os.path.join(HERE, "joint_sensitivity_global_indices.csv"))
    inter = gi[["parameter", "S1_d", "ST_d", "S1_ztas", "ST_ztas", "S1_zt_prov", "ST_zt_prov"]].copy()
    inter["interaction_d"] = inter.ST_d - inter.S1_d
    inter.to_csv(os.path.join(OUT, "sobol_interactions.csv"), index=False)
    rep["sobol"] = dict(sum_S1_d=float(gi.S1_d.sum()), sum_ST_d=float(gi.ST_d.sum()),
                        top_interaction=inter.sort_values("interaction_d", ascending=False).head(4)[["parameter", "S1_d", "ST_d", "interaction_d"]].round(3).to_dict("records"))
    # (4) surrogate tree
    y = (c.d_prov > -0.05).astype(int).to_numpy()
    X = pd.get_dummies(c[NAMES + ["topology"]], columns=["topology"]).astype(float)
    groups = c.point.to_numpy()
    mk = lambda: DecisionTreeClassifier(max_depth=3, min_samples_leaf=40, random_state=0)
    ins = mk().fit(X, y)
    pred = np.zeros_like(y)
    for tr, te in GroupKFold(5).split(X, y, groups):
        pred[te] = mk().fit(X.iloc[tr], y[tr]).predict(X.iloc[te])
    rng = np.random.default_rng(5); P = c.point.unique(); roots = []
    for b in range(200):
        sel = rng.choice(P, len(P)); idx = np.concatenate([np.flatnonzero(groups == p) for p in sel])
        t = mk().fit(X.iloc[idx], y[idx]); f = t.tree_.feature[0]
        roots.append((X.columns[f], float(t.tree_.threshold[0])))
    rt = pd.DataFrame(roots, columns=["root_feature", "threshold"])
    rs = rt.groupby("root_feature").threshold.agg(["count", "median", lambda s: s.quantile(0.05), lambda s: s.quantile(0.95)]).reset_index()
    rs.columns = ["root_feature", "count", "median_threshold", "q05", "q95"]; rs.to_csv(os.path.join(OUT, "tree_root_stability.csv"), index=False)
    rep["tree"] = dict(base_rate_class1=float(y.mean()), majority_accuracy=float(max(y.mean(), 1 - y.mean())),
                       in_sample_accuracy=float(ins.score(X, y)), in_sample_balanced=float(balanced_accuracy_score(y, ins.predict(X))),
                       cv_accuracy=float((pred == y).mean()), cv_balanced=float(balanced_accuracy_score(y, pred)),
                       root_split=rs.sort_values("count", ascending=False).round(3).to_dict("records"))
    # (5) dependence on stealth and topology
    c["mu_tertile"] = pd.qcut(c.mu_mal, 3, labels=["stealthy (18-32)", "middle (32-46)", "noisy (46-60)"])
    st = c.groupby("mu_tertile", observed=True).apply(lambda d: pd.Series(shares(d))).reset_index()
    st.to_csv(os.path.join(OUT, "by_attacker_stealth.csv"), index=False)
    tp = c.groupby("topology").apply(lambda d: pd.Series(shares(d))).reset_index()
    tp.to_csv(os.path.join(OUT, "by_topology.csv"), index=False)
    rep["by_stealth"] = st[["mu_tertile", "mean_d", "share_lower", "share_adv_ge_005"]].round(3).to_dict("records")
    rep["by_topology_range"] = dict(share_adv_ge_005_min=float(tp.share_adv_ge_005.min()), share_adv_ge_005_max=float(tp.share_adv_ge_005.max()),
                                    share_lower_min=float(tp.share_lower.min()))
    # (6) alternate ranges
    altf = os.path.join(RAW, "joint_alternate_ranges_raw.csv.gz")
    rows = [dict(design="original continuous", **shares(c))]
    if os.path.exists(altf):
        ar = pd.read_csv(altf); ap = pd.read_csv(altf.replace(".csv.gz", "_points.csv"))
        for d in ["narrow_central", "strong_attacker", "strong_baseline"]:
            _, cc = cells_of(ar, ap, d); rows.append(dict(design=d, **shares(cc)))
    alt = pd.DataFrame(rows); alt.to_csv(os.path.join(OUT, "alternate_ranges_summary.csv"), index=False)
    rep["alternate_ranges"] = alt.round(3).to_dict("records")
    # figure: (a) distribution of cell differences with concentration; (b) by stealth tertile; (c) alternate ranges
    fig, ax = plt.subplots(1, 3, figsize=(7.2, 2.4))
    ax[0].hist(c.d_prov, bins=np.linspace(-0.9, 0.2, 45), color="#2a6f97"); ax[0].axvline(-0.05, color="k", lw=0.6, ls=":"); ax[0].axvline(0, color="k", lw=0.6)
    ax[0].set_xlabel("frac(ZTAS) - frac(ZT+prov) per cell"); ax[0].set_ylabel("cells"); ax[0].set_title("(a) continuous design, 3600 cells", fontsize=7)
    ax[1].bar(range(3), st.share_adv_ge_005, color="#2a6f97", label=r"advantage $\geq$0.05"); ax[1].bar(range(3), st.share_lower - st.share_adv_ge_005, bottom=st.share_adv_ge_005, color="#9fc5e8", label="lower, <0.05")
    ax[1].set_xticks(range(3)); ax[1].set_xticklabels(["stealthy", "middle", "noisy"], fontsize=7); ax[1].set_ylabel("share of cells"); ax[1].legend(fontsize=6, frameon=False); ax[1].set_title(r"(b) by attacker stealth ($\mu_{mal}$ tertile)", fontsize=7)
    ax[2].bar(range(len(alt)), alt.share_adv_ge_005, color="#2a6f97"); ax[2].bar(range(len(alt)), alt.share_lower - alt.share_adv_ge_005, bottom=alt.share_adv_ge_005, color="#9fc5e8")
    ax[2].set_xticks(range(len(alt))); ax[2].set_xticklabels(["original", "narrow", "strong\nattacker", "strong\nbaseline"][: len(alt)], fontsize=6); ax[2].set_title("(c) alternate parameter ranges", fontsize=7)
    for a in ax[1:]: a.set_ylim(0, 1)
    fig.tight_layout(); fig.savefig(os.path.join(HERE, "joint_sensitivity_figures", "fig_joint_robustness_v5.pdf")); fig.savefig(os.path.join(HERE, "joint_sensitivity_figures", "fig_joint_robustness_v5.png"), dpi=200)
    import json; json.dump(rep, open(os.path.join(OUT, "joint_robustness_v5.json"), "w"), indent=1, default=str)
    print(json.dumps(rep, indent=1, default=str))


if __name__ == "__main__":
    main()
