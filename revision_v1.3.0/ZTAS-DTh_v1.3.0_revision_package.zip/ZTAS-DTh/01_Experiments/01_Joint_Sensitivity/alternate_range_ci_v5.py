"""v5: point-cluster bootstrap CIs (2000 resamples of LHS points) for the shares of cells in the original continuous
design and the three alternate-range designs. Usage: python3 alternate_range_ci_v5.py"""
import os, sys
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from joint_robustness_v5 import cells_of, RAW, OUT
rng = np.random.default_rng(12)
def boot(c, B=2000):
    pts = c.point.unique(); g = {p: d.d_prov.to_numpy() for p, d in c.groupby("point")}; res = []
    for _ in range(B):
        x = np.concatenate([g[p] for p in rng.choice(pts, len(pts))])
        res.append(((x < 0).mean(), (x <= -0.05).mean()))
    r = np.array(res); return np.percentile(r, [2.5, 97.5], axis=0)
rows = []
raw = pd.read_csv(os.path.join(RAW, "joint_sensitivity_raw.csv.gz")); pts = pd.read_csv(os.path.join(RAW, "joint_sensitivity_raw_points.csv"))
_, c = cells_of(raw, pts, "continuous"); ci = boot(c)
rows.append(dict(design="original continuous", share_lower=(c.d_prov < 0).mean(), lower_lo=ci[0, 0], lower_hi=ci[1, 0], share_adv=(c.d_prov <= -0.05).mean(), adv_lo=ci[0, 1], adv_hi=ci[1, 1]))
ar = pd.read_csv(os.path.join(RAW, "joint_alternate_ranges_raw.csv.gz")); ap = pd.read_csv(os.path.join(RAW, "joint_alternate_ranges_raw_points.csv"))
for d in ["narrow_central", "strong_attacker", "strong_baseline"]:
    _, c = cells_of(ar, ap, d); ci = boot(c)
    rows.append(dict(design=d, share_lower=(c.d_prov < 0).mean(), lower_lo=ci[0, 0], lower_hi=ci[1, 0], share_adv=(c.d_prov <= -0.05).mean(), adv_lo=ci[0, 1], adv_hi=ci[1, 1]))
d = pd.DataFrame(rows); d.to_csv(os.path.join(OUT, "alternate_ranges_ci.csv"), index=False); print(d.round(3).to_string(index=False))
