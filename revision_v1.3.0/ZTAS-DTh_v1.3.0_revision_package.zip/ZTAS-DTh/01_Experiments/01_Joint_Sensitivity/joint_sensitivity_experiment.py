"""
Joint sensitivity experiment (revision v3, reviewer concern 1).

Design
  * Parameters varied jointly: see joint_sensitivity_config.yaml (11 parameters; ranges and rationale).
  * Design 1 ("lhs"): Latin-hypercube samples over the full ranges (continuous joint sampling), plus three
    defensive-control regimes (optimistic / moderate / adverse) in which the six DEFENSIVE parameters are
    restricted to regime-specific sub-ranges while attacker and evidence parameters span their full ranges.
    Every parameter point is evaluated on the SAME 144 evaluation units (9 topology families x 4 graphs x
    4 runs) with common random numbers, for all five architectures -> exactly paired comparisons.
  * Design 2 ("sobol"): Saltelli/Sobol design (SALib) on the reference topology, 16 fixed units, for
    variance-based first-order and total indices of the paired difference ZTAS - ZT+prov.
Usage:
  python3 joint_sensitivity_experiment.py lhs   OUT.csv.gz [--pilot]
  python3 joint_sensitivity_experiment.py sobol OUT.csv.gz [--pilot]
Checkpointing: results are written per evaluation unit to OUT.parts/<unit>.csv; finished units are skipped
on restart; the final file is assembled only from complete parts.
"""
import sys, os, glob, json
from multiprocessing import Pool
import numpy as np
import pandas as pd
import yaml
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "src"))
import topologies as tp
import dth_sim as ds
from scipy.stats import qmc

CFG = yaml.safe_load(open(os.path.join(HERE, "joint_sensitivity_config.yaml")))
PAR = CFG["parameters"]
NAMES = list(PAR)
ARCH = ["perimeter", "zones", "zt", "zt_prov", "ztas"]
METRICS = ["frac", "reach_O", "n_phases", "path_len", "detected", "t_detect", "contained", "residual"]


class LazyScore:
    """Risk score of the malicious request on (t,u,v), computed only when the simulator asks for it.
    Identical to dth_sim.scores() element-wise (checked in the pilot)."""
    def __init__(self, D, P, w):
        self.z, self.deg, self.P, self.w = D["z"], D["sysdeg"] < P["p_sysdeg"], P, w

    def __getitem__(self, k):
        P = self.P; z = self.z[k]
        c = P["mu_legit"] + P["sd_legit"] * z
        c[2] = P["mu_mal"] + P["sd_mal"] * z[2]
        if self.deg[k]:
            c[3] = P["mu_mal"] + P["sd_mal"] * z[3]
        return float(np.clip(c, 0, 100) @ self.w)


def lhs_points(n, ranges, seed):
    s = qmc.LatinHypercube(d=len(NAMES), seed=seed).random(n)
    lo = np.array([ranges[k][0] for k in NAMES]); hi = np.array([ranges[k][1] for k in NAMES])
    X = lo + s * (hi - lo)
    return X


def design_lhs(pilot):
    n_cont = 40 if pilot else CFG["design"]["n_continuous"]
    n_reg = 10 if pilot else CFG["design"]["n_per_regime"]
    full = {k: PAR[k]["range"] for k in NAMES}
    rows = []
    X = lhs_points(n_cont, full, CFG["design"]["seed"])
    rows += [("continuous", x) for x in X]
    for i, (reg, spec) in enumerate(CFG["regimes"].items()):
        rr = dict(full); rr.update({k: v for k, v in spec.items()})
        X = lhs_points(n_reg, rr, CFG["design"]["seed"] + 1 + i)
        rows += [(reg, x) for x in X]
    return rows


def design_sobol(pilot):
    from SALib.sample import sobol as ssob
    prob = {"num_vars": len(NAMES), "names": NAMES, "bounds": [PAR[k]["range"] for k in NAMES]}
    X = ssob.sample(prob, 32 if pilot else CFG["sobol"]["N"], calc_second_order=False, seed=CFG["design"]["seed"])
    return [("sobol", x) for x in X], prob


def to_P(x):
    P = dict(ds.DEFAULTS)
    for k, v in zip(NAMES, x):
        P[k] = float(v)
    P["approval_delay"] = int(round(P["approval_delay"]))
    return P


def run_unit(args):
    topo, g, r, points, arch, outdir = args
    ti = list(tp.TOPOLOGIES).index(topo)
    gs = 10000 * ti + g + 500            # graph seeds disjoint from v2 (g+500) -> fresh graph instances
    rs = 1000003 * gs + r
    fn = os.path.join(outdir, f"{topo}_{g}_{r}.csv")
    if os.path.exists(fn):
        return fn
    prep = ds.Prepared(tp.build(topo, gs))
    D = ds.draws(prep, ds.DEFAULTS["T"], rs)
    out = []
    for pid, (design, x) in enumerate(points):
        P = to_P(x)
        S = LazyScore(D, P, ds.W_ADAPT)
        for c in arch:
            res = ds.simulate(prep, D, c, P, S)
            out.append([pid, design, topo, g, gs, r, rs, c] + [res[m] for m in METRICS])
    df = pd.DataFrame(out, columns=["point", "design", "topology", "graph", "graph_seed", "run", "run_seed", "config"] + METRICS)
    df.to_csv(fn + ".tmp", index=False); os.replace(fn + ".tmp", fn)
    return fn


def main():
    mode, out = sys.argv[1], sys.argv[2]
    pilot = "--pilot" in sys.argv
    if mode == "lhs":
        points = design_lhs(pilot)
        topos = list(tp.TOPOLOGIES); G = 2 if pilot else CFG["design"]["graphs_per_topology"]
        R = 2 if pilot else CFG["design"]["runs_per_graph"]; arch = ARCH
    else:
        points, prob = design_sobol(pilot)
        topos = ["reference"]; G = 2 if pilot else CFG["sobol"]["graphs"]; R = 2 if pilot else CFG["sobol"]["runs"]
        arch = ["zt_prov", "ztas"]
    outdir = out + ".parts"; os.makedirs(outdir, exist_ok=True)
    pts = pd.DataFrame([x for _, x in points], columns=NAMES)
    pts.insert(0, "design", [d for d, _ in points]); pts.insert(0, "point", range(len(points)))
    pts.to_csv(out.replace(".csv.gz", "_points.csv"), index=False)
    tasks = [(t, g, r, points, arch, outdir) for t in topos for g in range(G) for r in range(R)]
    print(f"{mode}: {len(points)} points x {len(tasks)} units x {len(arch)} configs", flush=True)
    with Pool(2) as pool:
        for k, fn in enumerate(pool.imap_unordered(run_unit, tasks)):
            if k % 8 == 0:
                print(k + 1, "/", len(tasks), os.path.basename(fn), flush=True)
    parts = [os.path.join(outdir, f"{t}_{g}_{r}.csv") for t, g, r, *_ in tasks]
    assert all(os.path.exists(p) for p in parts), "missing parts"
    pd.concat([pd.read_csv(p) for p in parts], ignore_index=True).to_csv(out, index=False, compression="gzip")
    json.dump(dict(mode=mode, pilot=pilot, n_points=len(points), n_units=len(tasks), configs=arch,
                   config_file="joint_sensitivity_config.yaml"), open(out.replace(".csv.gz", "_meta.json"), "w"), indent=1)
    print("done", out)


if __name__ == "__main__":
    main()
