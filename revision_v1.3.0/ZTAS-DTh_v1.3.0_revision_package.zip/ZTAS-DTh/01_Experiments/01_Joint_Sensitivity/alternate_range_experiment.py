"""
Concern 1 (v5): are the joint-sensitivity conclusions stable under ALTERNATE, equally defensible parameter ranges?
The original ranges (joint_sensitivity_config.yaml) are NOT changed. Three new LHS designs are drawn, each with
100 points, and run on the same topologies, graph instances and run seeds as the original continuous design
(common random numbers), with the same simulator (src/dth_sim.py) and architectures.

  narrow_central   : the central 50% of every original range (less extreme assumptions)
  strong_attacker  : p_exploit 0.30-0.80, mu_mal 18-35 (stealthy), stepup_fail 0.10-0.50, p_auth 0.05-0.50
  strong_baseline  : p_v 0.80-0.99, d_generic 0.05-0.20, p_auth 0.50-0.90 (generic controls shared by
                     ZT+prov and ZTAS-DTh are strong)

The new ranges are assumptions introduced in this revision round; they are reported as such.
Usage: python3 alternate_range_experiment.py ../../02_Data/Raw/joint_alternate_ranges_raw.csv.gz
"""
import os, sys, json
from multiprocessing import Pool
import numpy as np
import pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import joint_sensitivity_experiment as jse

ALT = {
    "narrow_central": {k: [v["range"][0] + 0.25 * (v["range"][1] - v["range"][0]), v["range"][0] + 0.75 * (v["range"][1] - v["range"][0])] for k, v in jse.PAR.items()},
    "strong_attacker": {"p_exploit": [0.30, 0.80], "mu_mal": [18.0, 35.0], "stepup_fail": [0.10, 0.50], "p_auth": [0.05, 0.50]},
    "strong_baseline": {"p_v": [0.80, 0.99], "d_generic": [0.05, 0.20], "p_auth": [0.50, 0.90]},
}
N_PER = 100


def design():
    full = {k: jse.PAR[k]["range"] for k in jse.NAMES}
    rows = []
    for i, (name, spec) in enumerate(ALT.items()):
        rr = dict(full); rr.update(spec)
        X = jse.lhs_points(N_PER, rr, jse.CFG["design"]["seed"] + 100 + i)
        rows += [(name, x) for x in X]
    return rows


def main():
    out = sys.argv[1]
    points = design()
    G, R = jse.CFG["design"]["graphs_per_topology"], jse.CFG["design"]["runs_per_graph"]
    outdir = out + ".parts"; os.makedirs(outdir, exist_ok=True)
    pts = pd.DataFrame([x for _, x in points], columns=jse.NAMES)
    pts.insert(0, "design", [d for d, _ in points]); pts.insert(0, "point", range(len(points)))
    pts.to_csv(out.replace(".csv.gz", "_points.csv"), index=False)
    tasks = [(t, g, r, points, jse.ARCH, outdir) for t in jse.tp.TOPOLOGIES for g in range(G) for r in range(R)]
    print(f"{len(points)} points x {len(tasks)} units", flush=True)
    with Pool(2) as pool:
        for k, fn in enumerate(pool.imap_unordered(jse.run_unit, tasks)):
            if k % 16 == 0: print(k + 1, "/", len(tasks), flush=True)
    parts = [os.path.join(outdir, f"{t}_{g}_{r}.csv") for t, g, r, *_ in tasks]
    pd.concat([pd.read_csv(p) for p in parts], ignore_index=True).to_csv(out, index=False, compression="gzip")
    json.dump(dict(ranges=ALT, n_per_design=N_PER, seed_offset=100, units=len(tasks)), open(out.replace(".csv.gz", "_meta.json"), "w"), indent=1)
    print("done", out)


if __name__ == "__main__":
    main()
