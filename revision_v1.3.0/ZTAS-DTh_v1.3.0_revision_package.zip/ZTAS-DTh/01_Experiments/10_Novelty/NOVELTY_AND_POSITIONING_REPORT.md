# NOVELTY_AND_POSITIONING_REPORT.md — concern 7

## 1. Where the genuine contribution lies (Task 7.4)
The candidate sources of novelty were checked against the evidence.

| Candidate | Supported? | Why |
|---|---|---|
| Lifecycle-aware policy enforcement | Partly | Enforcement on lifecycle flows between phases and owners is the organising idea. The individual controls are standard. |
| Interaction of provenance with context-aware authorisation | **Yes, as an integrative design.** | Provenance decides *what* may cross a boundary; ZT decides *who* and *when*. The paired evaluation shows each covers the other's blind spot: interface pivots for provenance, authorised but tampered artifacts for ZT. Ablations show that removing segments raises the stealthy-attacker fraction from 0.13 to 0.39 on the reference topology, and removing provenance raises it to 0.25. |
| Lifecycle-specific flow segmentation | Yes, as a design element | Segments are defined over lifecycle flows and purposes. The joint analysis finds the segment duty cycle p_act to be the most influential parameter (Sobol S_T = 0.35). |
| Cross-phase propagation containment | Evaluated, not novel as a concept | – |
| Evidence accumulation | No (standard), but the **trade-off analysis** is informative | Revised rule: 0.43 → 0.11 early containment against ~100% → 0% legitimate false isolation per shift. |
| Formal modelling | Supporting, not headline | Bounded abstract models. The design rules found (fail-closed, re-validation, atomic replay, TTL/CRL bound) are known engineering practice. |
| Evaluation methodology | **Yes.** | Counterfactual, paired comparison against a static ZT + provenance baseline, joint sensitivity over 11 assumed parameters and 9 topology families, graph-level reporting, and explicit vanishing-advantage regions. We did not find this combination in the surveyed industrial ZT literature. |

## 2. Rewritten contribution statements (used in the v3 Introduction)
1. **Threat model.** A lifecycle-flow threat model that separates artifact-mediated from interface-mediated propagation and states, for eight provenance-adversary scenarios, which mechanism can detect each.
2. **Architecture (integrative).** A zero-trust architecture that couples per-request decisions to lineage verification at phase and organisational boundaries and scopes segments to lifecycle flows and purposes. We claim the coupling, not the components.
3. **Counterfactual evaluation.** A paired evaluation against a static ZT + provenance baseline with joint sensitivity analysis. It identifies where the added mechanisms reduce simulated compromise and where they do not: sparse threads, always-open segments with stealthy attackers, and degraded controls. It also quantifies the evidence-rule trade-off in wall-clock time.
4. **Supporting assurance.** Eight properties with explicit assumptions; bounded model checking of abstract models, including asynchronous enforcement, with negative controls; and a software proof of concept. Its concurrency and failure tests exposed six defects, each corresponding to a design rule.

## 3. Worked comparison: a compromised CAM service in manufacturing (Task 7.5)
**Scenario.** The CAM service that turns released designs into machine instructions is compromised. The attacker holds its credentials and signing role. It attempts to:
- (a) send manipulated instructions to operations-phase controllers over the legitimate program-download flow (artifact-mediated);
- (b) pivot through the MES API to a historian and to controllers (interface-mediated).

This matches the simulator's artifact/interface flows, PoC scenarios S2/S4/S5, and model M1.

| Architecture | Detects | Prevents | Assumes | Cannot prevent |
|---|---|---|---|---|
| Perimeter | Nothing inside the plant | Nothing once inside | The inside is trusted | (a) and (b) |
| Static zones (IEC 62443 zones/conduits) | Some zone-crossing attempts (conduit inspection; z_d) | Moves through non-conduit paths | Flows within a zone are trusted; conduits are permanently open for legitimate flows | (a) uses the open M→O program conduit; (b) succeeds inside the zone |
| Static ZT | Anomalies, eventually (generic monitoring) | Requests by principals without rights | A valid identity with rights is benign | (a) and (b): the CAM service is authorised for both flows |
| Static ZT + provenance | A post-signing alteration of instructions (hash, S2); instructions derived from an unreleased design or recorded by the wrong role (lineage, S4/S4b) | Tampered or out-of-lineage artifacts at the O boundary | The signer's content is benign | Instructions *signed by the compromised CAM service itself* from a released design (validly signed malicious content, S5/S7). (b) entirely, because interface pivots bypass gates |
| ZTAS-DTh | As above, plus unusual request context (step-up; evidence) | Program download outside the release activity's segment window; requests from a quarantined source; pivots on flows not in an active segment | Segments are open only for the activity; the outage signal is independent; operator approval is available | A stealthy attacker who issues malicious but validly signed instructions *inside* an open release segment with normal-looking context. The model reproduces this: the advantage vanishes when p_act → 1 and mu_mal is low (joint sensitivity §3). Process-level consequence detection is out of scope |

**Why ZTAS-DTh differs.** It does not detect malicious content better than ZT + provenance. What it adds is that the *time and path window* in which a compromised but authorised component can use a lifecycle flow is restricted, and that repeated anomalous use accumulates evidence. The benefit is therefore conditional on flows actually being closed most of the time and on attackers deviating from normal context. The evaluation quantifies exactly these conditions.
