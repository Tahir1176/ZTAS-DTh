# NOVELTY_AND_RELATED_WORK_AUDIT.md — concern 7 (v4)

This file consolidates the v3 audit (`NOVELTY_AUDIT.md`), the comparison (`RELATED_WORK_CRITICAL_COMPARISON.md`) and the positioning (`NOVELTY_AND_POSITIONING_REPORT.md`, which includes the worked scenario). v4 adds the claim-by-claim classification that this round asks for.

## 1. Classification of every novelty-type claim in the manuscript

| # | Claim (where it appears) | Classification | Evidence / reason |
|---|---|---|---|
| N1 | "A lifecycle-flow threat model that separates artifact- from interface-mediated propagation and states which mechanism can detect each of eight scenarios" (Intro C1; §III) | **Partially supported** | STRIDE and DT threat taxonomies exist. The artifact/interface split and the per-scenario detectability table are not found in the surveyed works, but they are analytical and not validated on incidents |
| N2 | "Couples per-request decisions to lineage verification at phase and organisational boundaries and scopes segments to lifecycle flows and purposes" (Abstract; Intro C2; §IV) | **Integration-based, supported as integration** | Each component is established. The coupling is specific to this work. Its benefit is shown only in simulation: ablations (no segments 0.39, no provenance 0.25, full 0.13; stealthy, reference topology) and the joint sensitivity analysis |
| N3 | "Counterfactual evaluation against a ZT+provenance baseline that identifies where the coupling stops paying off" (Intro C3; §VI–VII) | **Strongly supported** (as a methodological contribution) | 612 000 paired simulations, Sobol indices, a vanishing-advantage tree, and 270 graph-level paired differences. No surveyed work (Table I) compares against a provenance-verifying ZT baseline |
| N4 | "Quantifies the security cost of an evidence rule that avoids false isolation, in wall-clock time" (Intro C3; §VII) | **Supported (model-based)** | Continuous-time study with 52 500 runs, plus the v4 extension (κ sweep, approval delay, emergency, safe-state, propagation-aware). Not operationally validated |
| N5 | "Eight properties with explicit assumptions; bounded model checking of abstract models including asynchronous enforcement" (Intro C4; §V) | **Weakly supported as novelty; supported as assurance** | The design rules found (fail-closed, re-validation, atomic replay, TTL/CRL bound, two-person rule, re-check at enforcement) are known engineering practice. The value lies in documenting them with negative controls, not in a new formal method |
| N6 | "Concurrency and failure tests exposed six defects" (Abstract; §VII-PoC) | **Supported (engineering evidence, not novelty)** | Tests T-A to T-I, plus T-J and T-K in v4, each with switchable controls |
| N7 | PQ cryptography (ML-DSA/ML-KEM/SLH-DSA), Merkle batching | **Not novel; not claimed** | Standard primitives; the paper reports costs only. QZT-ICS (Qadri 2026) covers PQ crypto-agility for OT more extensively |
| N8 | "Twin identity / twin as security subject" (Table I column) | **Partially supported** | The architecture treats twins as principals bound to model hashes, but the PoC twin is a stub, and QZT-ICS goes further, using the twin as the PDP |
| N9 | Any "first" or "only" wording | **Removed** (v3) | Coverage of all six capabilities is a design property, not evidence of benefit (§II) |

**Conclusion.** The defensible contribution is a combination of independently established mechanisms (N2) with demonstrated, *conditional*, model-based benefit, together with a counterfactual evaluation methodology (N3, N4) that identifies the boundary conditions. The manuscript states this explicitly (Introduction, "Contributions").

## 2. Literature comparison
See `RELATED_WORK_CRITICAL_COMPARISON.md` (v3, updated after reading Qadri 2026 and Humphrey 2026 in full). The manuscript's Table I has evidence-type columns (concept, prototype, simulation, laboratory experiment, formal, industrial), so other architectures are not presented as deficient merely for lacking a mechanism. Where another work has stronger evidence (Fogli 2025 field test; QZT-ICS hardware-in-the-loop testbed), the text says so.

## 3. Worked industrial scenario
See `NOVELTY_AND_POSITIONING_REPORT.md` §3: a compromised CAM service, compared across all five architectures. The scenario is illustrative and grounded in the cited Stuxnet-type and supply-chain literature. It does not represent a real deployment. It matches the simulation boundary: no advantage when segments are open and attacker behaviour looks legitimate.
