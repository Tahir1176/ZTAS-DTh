# NOVELTY_AUDIT.md — concern 7, Task 7.1

## Contribution statements in v2 (Introduction, "Contributions")

| # | v2 statement | Type | Novel on its own? | Assessment |
|---|---|---|---|---|
| C1 | DTh threat model mapping STRIDE to propagation channels; eight provenance-adversary scenarios separated by the mechanism that can detect each | Analytical | Partly. STRIDE and DT threat taxonomies exist (alcaraz2022dt, mun2025survey); separating artifact- from interface-mediated propagation and mapping detectability per scenario is specific to this work. | Keep, narrowed: the new element is the artifact/interface split and the per-scenario detectability table, not STRIDE. |
| C2 | ZTAS-DTh architecture, with a corrected provenance construction and a revised evidence rule | Architectural / integrative | Zero trust (rose2020zta), ABAC (hu2014abac), micro-segmentation (basta2022microseg), Merkle batching (merkle1987sig, crosby2009log) and ML-DSA (fips204) are all known. The Merkle fix is a correction, not a contribution. | Integrative. The defensible element is *coupling* access decisions to lineage checks at phase/organisation boundaries and scoping segments to lifecycle flows and purposes. |
| C3 | Eight properties, three propositions, bounded model checking with negative controls | Formal (modest) | The properties are standard in kind. Their contribution is the explicit assumption/non-guarantee boundary. M4 (v3) adds design rules for asynchronous enforcement, but these are known engineering practice (fail-closed, TOCTOU re-validation, atomic replay check). | Keep as supporting evidence, not as a headline novelty. |
| C4 | Evaluation explicit about evidence type: paired hierarchical Monte-Carlo, risk-engine study, benchmarks, PoC | Methodological | Using simulation is not novel. A *paired comparison against a static-ZT-plus-provenance baseline* that isolates what flow-scoping and evidence add, with joint sensitivity (v3), is uncommon in the industrial ZT literature, which mostly reports architectures or prototypes without counterfactual baselines. | Promote: in v3 this is the strongest defensible contribution, together with the conditions under which the integration stops paying off. |

## Not claimed as novel (v3)
Using zero trust, Merkle trees, ML-DSA/ML-KEM, simulation or STRIDE. "First" claims are removed.
