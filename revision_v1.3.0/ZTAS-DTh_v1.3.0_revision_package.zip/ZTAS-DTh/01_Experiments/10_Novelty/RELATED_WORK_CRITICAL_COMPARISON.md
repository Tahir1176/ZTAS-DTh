# RELATED_WORK_CRITICAL_COMPARISON.md — concern 7, Tasks 7.2–7.3

**Sources.** The references already verified in v2 (refs.bib), plus two 2026 works found in the v3 search (web search, 19 Nov 2026), whose bibliographic details were checked on the publisher pages:
- S. M. Qadri, "Crypto-Agile Zero Trust Architecture for IT-OT Convergence in Industrial Control Systems: A Digital Twin-Driven Framework over 5G/TSN with Post-Quantum Cryptography," *Frontiers in Computer Science and Artificial Intelligence* 5(9):13–58, 2026, doi:10.32996/fcsai.2026.5.9.2 (QZT-ICS).
- B. A. Humphrey, "Cyber Digital Twin-Informed Zero Trust: A Synergistic Framework for Securing Operational Technology in Defense Logistics Infrastructure," Acquisition Research Program, Naval Postgraduate School, SYM-AM-26-074, 30 Apr 2026.

Both papers were read in full (PDFs supplied by the authors on 19 Nov 2026); the rows below reflect the full texts. No other references were added: the remaining search hits were vendor pages, news or unrefereed blogs.

| Work | Problem | ZT implementation | Risk adaptation | Provenance | Lifecycle scope | Segmentation | Crypto | Formal | Simulation | Prototype | Industrial deployment | Evidence type |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Fogli et al. 2025 (fogli2025zta)ᵃ | ZT access to machines via DTs in distributed smart factories | PDP/PEP with NGFW | Context-based policies | – | Operations | Network (NGFW) | Classical | – | – | ✓ | ✓ (tested in a real industrial environment) | Prototype + field test |
| Zanasi et al. 2022 (zanasi2022ztics)ᵃ | ZT for ICS | Prototype ZT for ICS | Limited | – | Operations | Discussed | Classical | – | – | ✓ | – | Lab prototype |
| Paul & Rao 2023 (paul2023zt) | ZT for smart manufacturing | Conceptual | Discussed | – | Manufacturing | Micro-segmentation | – | – | – | – | – | Conceptual |
| Basta et al. 2022 (basta2022microseg)ᵃ | Effect of micro-segmentation | – | – | – | – | Quantified on attack graphs | – | – | ✓ | – | – | Simulation |
| Krima et al. 2019; Joannou et al. 2020; Kuo & Yang 2026 | DTh traceability / provenance | – | – | Blockchain ledgers | Lifecycle | – | Classical | – | – | ✓ (Kuo) | – | Concept / prototype |
| Qadri 2026 (QZT-ICS) | ZT for IT-OT convergence in ICS over 5G/TSN | TEE-hosted twin as PDP (Go policy engine, Redis decision cache) | Trust score from identity, posture, process residuals, behaviour, threat intel; default weights not tuned | Signed firmware/bitstreams (SLH-DSA); no lineage across phases | Operations (Purdue levels); 5-level adoption maturity model | Slice-aware micro-segmentation + per-flow trust predicate in 802.1Qbv GCL (P4 on FPGA) | ML-KEM, ML-DSA, SLH-DSA, hybrid X25519+ML-KEM; liboqs; Cortex-M33/A55/Xeon measured | Formal threat model only | Simulated process (Simulink) | ✓ hardware-in-the-loop (5G, TSN switches, S7-1500 PLCs) | – | HIL testbed: F1 0.956, FP 1.5%, vs identity-only ZT, Snort, twin IDS; code on request |
| Humphrey 2026 | Cyber-twin-informed ZT for defence-logistics OT (DLA, SBIR Phase I) | ZT micro-segmentation via SDN | Planned: twin-trained anomaly models ("operational signatures") | – | Operations | Device-level trust zones (deployed in OT test environment) | – | – | Planned | Partial (segmentation only) | – | Qualitative early results: feasible without disruption; legacy firmware and broadcast discovery need policy exceptions; no quantitative evaluation |
| **ZTAS-DTh** | ZT over the lifecycle thread | PDP/PEP per request | 5-D score + evidence (synthetic) | Signed, sequenced, lineage at phase/org boundaries | D–M–O–S + suppliers | Flow- and purpose-scoped | ML-DSA, ML-KEM, SLH-DSA | Bounded abstract MC (M1–M4) | ✓ paired, joint sensitivity | ✓ single-host software | – | Simulation + benchmark + PoC |



**Critical reading.**
- Fogli et al. have the strongest evidence (field test). ZTAS-DTh does not match it.
- QZT-ICS is the closest recent work and has stronger implementation evidence (HIL testbed with real 5G/TSN/PLC hardware). It targets real-time OT transport and process-aware trust, not lifecycle lineage; its baselines do not include a provenance-verifying ZT configuration; its reported 1.5% false-positive rate would, at low malicious prevalence, produce the alert burden quantified in our risk-engine study; software is available only on request. Its PQC measurements on Cortex-M33/A55 complement our server-only benchmarks and are cited in the manuscript.
- Humphrey is an early-stage practitioner report; its qualitative finding that device-level OT segmentation requires individually validated exceptions supports our observation that ZTAS-DTh's benefit depends on keeping segments closed.
- DTh provenance works provide lineage but not request-level ZT enforcement.
- None of the surveyed works reports a counterfactual comparison against a ZT-plus-provenance baseline, or the conditions under which added mechanisms stop helping.
