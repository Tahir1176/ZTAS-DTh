"""
v6 baseline-fairness check (reviewer concern 5). In E1 the static-zones baseline has conduit inspection and
conduit detection but, unlike the ZT baselines, no generic monitoring (d). A real IEC 62443 deployment would
usually run OT intrusion detection, so this omission may weaken the zones baseline. This run adds the same
generic monitoring (d=0.05) to zones ('zones_mon') on the E1 graphs and seeds (common random numbers).
Baselines are profile-independent (no risk engine), so only the stealthy-profile seed stream is needed.
Usage: python3 zones_monitoring_experiment.py OUT.csv
"""
import sys, os, csv
from multiprocessing import Pool
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "src"))
import topologies as tp, dth_sim as ds
from run_e1 import TOPOS, METRICS, N_GRAPHS, N_RUNS, gseed, rseed
CFGS = ["zones", "zones_mon", "zt", "zt_prov"]

def task(args):
    ti, g = args; topo = TOPOS[ti]; gs = gseed(ti, g)
    prep = ds.Prepared(tp.build(topo, gs)); rows = []
    for r in range(N_RUNS):
        rs = rseed(gs, r); D = ds.draws(prep, ds.DEFAULTS["T"], rs); P = dict(ds.DEFAULTS, mu_mal=28.0)
        for c in CFGS:
            res = ds.simulate(prep, D, c, P, None)
            rows.append([topo, g, gs, r, rs, c] + [res[m] for m in METRICS])
    return rows

if __name__ == "__main__":
    with open(sys.argv[1], "w", newline="") as f:
        w = csv.writer(f); w.writerow(["topology", "graph", "graph_seed", "run", "run_seed", "config"] + METRICS)
        with Pool(2) as p:
            for rows in p.imap_unordered(task, [(ti, g) for ti in range(len(TOPOS)) for g in range(N_GRAPHS)]):
                w.writerows(rows)
    print("done", flush=True)
