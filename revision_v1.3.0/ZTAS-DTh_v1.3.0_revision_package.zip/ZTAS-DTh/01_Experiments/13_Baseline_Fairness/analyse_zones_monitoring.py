"""v6 baseline-fairness analysis: zones vs zones + generic monitoring, against ZT and ZT+prov and ZTAS-DTh
(revised rule, from the factorial run; stealthy profile). Graph-level means; 2000 graph bootstrap resamples.
Also checks that zones, zt and zt_prov reproduce the archived E1 values exactly."""
import os, json
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, "..", "..")
z = pd.read_csv(os.path.join(ROOT, "02_Data", "Raw", "v6", "zones_monitoring_raw.csv"))
a = pd.read_csv(os.path.join(ROOT, "02_Data", "Raw", "v2", "e1_main.csv")); a = a[a.profile == "stealthy"]
k = ["topology", "graph", "run"]; cons = {}
for c in ["zones", "zt", "zt_prov"]:
    m = z[z.config == c][k + ["frac"]].merge(a[a.config == c][k + ["frac"]], on=k, suffixes=("", "_a"))
    cons[c] = dict(rows=int(len(m)), max_abs_diff=float((m.frac - m.frac_a).abs().max()))
f = pd.read_csv(os.path.join(ROOT, "02_Data", "Raw", "v6", "factorial_ablation_raw.csv"))
f = f[(f.profile == "stealthy") & (f.config == "ztas")][k + ["config", "frac", "reach_O"]]
allr = pd.concat([z[k + ["config", "frac", "reach_O"]], f])
g = allr.groupby(["topology", "graph", "config"])[["frac", "reach_O"]].mean().reset_index()
rng = np.random.default_rng(7); rows = []
for topo, d in g.groupby("topology", sort=False):
    P = d.pivot(index="graph", columns="config", values="frac"); n = len(P)
    idx = rng.integers(n, size=(2000, n))
    def ci(x): b = x[idx].mean(1); return np.percentile(b, [2.5, 97.5])
    r = dict(topology=topo)
    for c in ["zones", "zones_mon", "zt", "zt_prov", "ztas"]:
        r[c] = P[c].mean()
    for nm, x in [("mon_minus_zones", P.zones_mon - P.zones), ("ztas_minus_zonesmon", P.ztas - P.zones_mon), ("ztprov_minus_zonesmon", P.zt_prov - P.zones_mon)]:
        x = x.to_numpy(); lo, hi = ci(x); r[nm], r[nm + "_lo"], r[nm + "_hi"] = x.mean(), lo, hi
    r["ztas_better_than_zonesmon_graphs"] = float(((P.ztas - P.zones_mon) < 0).mean())
    r["zonesmon_better_than_ztprov_graphs"] = float(((P.zones_mon - P.zt_prov) < 0).mean())
    rows.append(r)
out = os.path.join(ROOT, "02_Data", "Processed", "baseline_fairness_v6"); os.makedirs(out, exist_ok=True)
R = pd.DataFrame(rows); R.to_csv(os.path.join(out, "zones_monitoring_summary.csv"), index=False)
json.dump(cons, open(os.path.join(out, "consistency.json"), "w"), indent=1)
print(cons); print(R.round(3).to_string())
