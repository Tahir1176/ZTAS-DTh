"""
Evidence accumulation in wall-clock time (revision v3, reviewer concern 3).

Why not divide request counts by a rate: two quantities in the response are defined in WALL TIME, not in
requests -- operator approval latency for isolating an operations-phase (safety-relevant) asset, and (for one
policy) time-based evidence decay -- and attack progression is itself request-driven (each allowed request may
compromise a new entity, which then issues its own requests). Request rate therefore changes how many
propagation steps happen before a time-defined response takes effect. This script simulates that coupling
with a continuous-time event simulation on reference-topology graphs.

ATTACK side: each compromised, unisolated entity issues requests as a point process whose rate and pattern
are set by the attacker profile x base rate r. Every request targets a random not-yet-compromised successor.
Request handling (configuration "risk_only": per-request authorisation + flow-scoped segment + risk engine;
provenance and generic monitoring are OFF so that the evidence rule is what contains the attacker; a
secondary "full" configuration adds provenance gates and is reported separately):
    authorisation denies with p_auth; closed segment denies with 1-p_act; risk score s (v2 score model):
    s > 90 -> isolate; 70 < s <= 90 -> deny + 2 evidence units; 30 < s <= 70 -> step-up, attacker fails with
    stepup_fail -> +1 unit; otherwise the move succeeds with p_exploit.
LEGITIMATE side: escalation events per entity form a Poisson process (rate = request rate x escalation
probability); a legitimate step-up fails with a device-class probability, higher during network outages
(two-state Markov outage process, 5% of time, mean 300 s); outage-aware policies ignore outage failures.

All rates, delays and probabilities are EXPLORATORY MODELLING ASSUMPTIONS, not measurements.
Usage: python3 evidence_accumulation_experiment.py OUT_RAW.csv.gz OUT_LEGIT.csv [--pilot]
"""
import sys, os, heapq, itertools
from multiprocessing import Pool
import numpy as np
import pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "src"))
import topologies as tp

LAM_REQ = 0.5 ** (1 / 30)          # v2 per-request decay (half-life 30 requests)
POLICIES = {
    # name: kappa, decay kind, outage-aware, criticality-aware
    "original_k2":        dict(kappa=2, decay=None, outage=False, crit=False),
    "revised_k3_decay":   dict(kappa=3, decay="request", outage=True, crit=False),
    "alt_k3_nodecay":     dict(kappa=3, decay=None, outage=True, crit=False),
    "time_decay_k3":      dict(kappa=3, decay="time", outage=True, crit=False, half_life_s=60.0),
    "criticality_aware":  dict(kappa=3, decay="request", outage=True, crit=True, restrict_at=2),
}
APPROVAL_S = 120.0                  # operator approval latency for isolating an operations asset (assumption)
HORIZON_S = 3600.0
MAX_EVENTS = 300_000
RATES = [1, 10, 100, 1000]           # base attacker request rate per compromised entity (req/s), exploratory
PROFILES = {
    # rate multiplier, malicious score mean, stepup_fail, p_exploit, pattern
    "low_intensity":   dict(mult=0.1, mu=40.0, sf=0.7, pe=0.30, pattern="poisson"),
    "moderate":        dict(mult=1.0, mu=40.0, sf=0.7, pe=0.30, pattern="poisson"),
    "high_intensity":  dict(mult=10.0, mu=40.0, sf=0.7, pe=0.30, pattern="poisson"),
    "burst":           dict(mult=10.0, mu=40.0, sf=0.7, pe=0.30, pattern="burst"),        # 50-request bursts, exp(300 s) gaps
    "intermittent":    dict(mult=1.0, mu=40.0, sf=0.7, pe=0.30, pattern="intermittent"),  # 60 s on / 600 s off
    "stealthy":        dict(mult=1.0, mu=28.0, sf=0.7, pe=0.30, pattern="poisson"),       # v2 stealthy profile
    "rapid_multistep": dict(mult=10.0, mu=40.0, sf=0.4, pe=0.60, pattern="poisson"),      # holds some step-up material
}
BASE = dict(p_auth=0.5, p_act=0.3, p_v=0.9, f_art=0.5, mu_legit=15.0, sd_legit=8.0, sd_mal=15.0, p_sysdeg=0.5)
W = np.array([0.10, 0.10, 0.35, 0.30, 0.15])


def score(rng, mu):
    c = BASE["mu_legit"] + BASE["sd_legit"] * rng.standard_normal(5)
    c[2] = mu + BASE["sd_mal"] * rng.standard_normal()
    if rng.random() < BASE["p_sysdeg"]:
        c[3] = mu + BASE["sd_mal"] * rng.standard_normal()
    return float(np.clip(c, 0, 100) @ W)


class Pattern:
    def __init__(self, rng, kind, rate):
        self.rng, self.kind, self.rate = rng, kind, rate
        self.left = 0

    def next_after(self, t):
        r = self.rng
        if self.kind == "poisson":
            return t + r.exponential(1 / self.rate)
        if self.kind == "burst":
            if self.left > 0:
                self.left -= 1; return t + r.exponential(1 / self.rate)
            self.left = 49; return t + r.exponential(300.0)
        # intermittent: active windows [k*660, k*660+60)
        nt = t + r.exponential(1 / self.rate)
        ph = nt % 660.0
        return nt if ph < 60.0 else nt - ph + 660.0


def attack_run(G, phase, succ, prof, rate, pol, cfg, seed):
    rng = np.random.default_rng(seed)
    P = POLICIES[pol]; pr = PROFILES[prof]
    nodes = list(G.nodes)
    pool = [v for v in nodes if phase[v] in ("X", "D", "M", "S")]
    entry = pool[rng.integers(len(pool))]
    comp = {entry: 0.0}; ev = {entry: 0.0}; last = {entry: 0.0}
    iso, restricted, pending = {}, {}, {}
    pats = {entry: Pattern(rng, pr["pattern"], rate * pr["mult"])}
    heap = [(pats[entry].next_after(0.0), entry)]
    reach_O = None; n_req = 0; first_resp = None

    def can_act(u, t):
        return u not in iso and u not in restricted

    def respond(u, t, severe=False):
        nonlocal first_resp
        if first_resp is None: first_resp = t
        if phase[u] == "O":
            if P["crit"] and not severe:
                restricted.setdefault(u, t); return
            pending.setdefault(u, t + APPROVAL_S)
        else:
            iso[u] = t

    while heap and n_req < MAX_EVENTS:
        t, u = heapq.heappop(heap)
        if t > HORIZON_S: break
        for x, tt in list(pending.items()):
            if tt <= t: iso[x] = tt; del pending[x]
        if not can_act(u, t): continue
        targets = [v for v in succ[u] if v not in comp]
        if not targets: continue                       # nothing left to attack from u: entity idles
        n_req += 1
        v = targets[rng.integers(len(targets))]
        # evidence decay since last request of u
        if P["decay"] == "time": ev[u] *= 0.5 ** ((t - last[u]) / P["half_life_s"])
        last[u] = t
        nxt = lambda: heapq.heappush(heap, (pats[u].next_after(t), u))
        if rng.random() < BASE["p_auth"]: nxt(); continue
        if rng.random() > BASE["p_act"]: nxt(); continue
        if cfg == "full" and (phase[u] != phase[v]) and rng.random() < BASE["f_art"] and rng.random() < BASE["p_v"]:
            respond(u, t, severe=True); nxt(); continue
        if P["decay"] == "request": ev[u] *= LAM_REQ     # v2 semantics: decay per risk-engine evaluation
        s = score(rng, pr["mu"])
        if s > 90: respond(u, t, severe=True); nxt(); continue
        if s > 70 or (s > 30 and rng.random() < pr["sf"]):
            ev[u] += 2.0 if s > 70 else 1.0
            if P["crit"] and phase[u] == "O" and ev[u] >= P["restrict_at"]:
                respond(u, t, severe=ev[u] >= P["kappa"] + 2)
            elif ev[u] >= P["kappa"]:
                respond(u, t)
            nxt(); continue
        if rng.random() < pr["pe"]:
            comp[v] = t; ev[v] = 0.0; last[v] = t
            pats[v] = Pattern(rng, pr["pattern"], rate * pr["mult"])
            heapq.heappush(heap, (pats[v].next_after(t), v))
            if phase[v] == "O" and reach_O is None: reach_O = t
        nxt()
    # containment: every compromised entity isolated or restricted (pending approval does NOT count)
    blocked = lambda x: x in iso or x in restricted
    contained = all(blocked(x) for x in comp)
    t_cont = max((iso.get(x, restricted.get(x, np.inf)) for x in comp)) if contained else np.nan
    n_int = sum(1 for x in comp if phase[x] != "X")
    return dict(profile=prof, rate=rate, policy=pol, cfg=cfg, seed=seed,
                n_requests=n_req, censored=n_req >= MAX_EVENTS,
                t_first_response=first_resp if first_resp is not None else np.nan,
                contained=float(contained), t_containment=t_cont,
                requests_before_containment=n_req if contained else np.nan,
                n_compromised=n_int, reached_O=float(reach_O is not None),
                t_reach_O=reach_O if reach_O is not None else np.nan,
                contained_before_O=float(contained and (reach_O is None or reach_O > t_cont)),
                n_isolated=len(iso), n_restricted=len(restricted))


def attack_task(args):
    g, prof, rate, cfg, runs = args
    G = tp.build("reference", 9000 + g)
    phase = {v: G.nodes[v]["phase"] for v in G}; succ = {v: list(G.successors(v)) for v in G}
    out = []
    for pol in POLICIES:
        for r in range(runs):     # same seed for all policies -> common random numbers within the run
            out.append(dict(graph=g, run=r, **attack_run(G, phase, succ, prof, rate, pol, cfg, 7_000_003 * g + 1009 * r + 17)))
    return out


# ---------------------------------------------------------------- legitimate side (vectorised over entities)
CLASSES = {"human_operator": dict(fail=0.02, fail_out=0.02, crit=False),
           "field_device": dict(fail=0.005, fail_out=0.40, crit=True),
           "edge_service": dict(fail=0.001, fail_out=0.20, crit=False)}
ESC = {"gaussian": 0.02006, "heavy_tailed": 0.03728}    # v2 per-request escalation probabilities (incl. routine 2%)


def legit(cls, scen, rate, pol, n_ent, seed, shift_s=8 * 3600):
    rng = np.random.default_rng(seed); P = POLICIES[pol]; c = CLASSES[cls]
    lam = rate * ESC[scen]
    a_rate = (1 / 300) * 0.05 / 0.95; b_rate = 1 / 300; pi = 0.05
    t = np.zeros(n_ent); ev = np.zeros(n_ent); out = rng.random(n_ent) < pi
    iso = np.zeros(n_ent, bool); restr = np.zeros(n_ent, bool)
    while True:
        dt = rng.exponential(1 / lam, n_ent); t = t + dt
        alive = (t < shift_s) & ~iso
        if not alive.any(): break
        e = np.exp(-(a_rate + b_rate) * dt)
        p_out = np.where(out, pi + (1 - pi) * e, pi * (1 - e)); out = rng.random(n_ent) < p_out
        if P["decay"] == "request": ev = np.where(alive, ev * LAM_REQ ** (dt * rate), ev)
        elif P["decay"] == "time": ev = np.where(alive, ev * 0.5 ** (dt / P["half_life_s"]), ev)
        fail = rng.random(n_ent) < np.where(out, c["fail_out"], c["fail"])
        counted = alive & fail & ~(out & P["outage"])
        ev = ev + counted
        succ_ = alive & ~fail
        if P["decay"] is not None: ev = np.where(succ_, np.maximum(0, ev - 1), ev)
        if P["crit"] and c["crit"]:
            restr |= alive & (ev >= P["restrict_at"])
            iso |= alive & (ev >= P["kappa"] + 2)
        else:
            iso |= alive & (ev >= P["kappa"])
    return dict(cls=cls, scenario=scen, rate=rate, policy=pol, n_entities=n_ent,
                false_isolation_per_shift=float(iso.mean()), false_restriction_per_shift=float(restr.mean()),
                escalations_per_shift=lam * shift_s)


def main():
    out_raw, out_leg = sys.argv[1], sys.argv[2]; pilot = "--pilot" in sys.argv
    G_N, RUNS = (2, 5) if pilot else (10, 30)
    tasks = [(g, p, r, "risk_only", RUNS) for g in range(G_N) for p in PROFILES for r in RATES]
    tasks += [(g, p, 10, "full", RUNS) for g in range(G_N) for p in PROFILES]
    rows = []
    with Pool(2) as pool:
        for k, res in enumerate(pool.imap_unordered(attack_task, tasks)):
            rows += res
            if k % 40 == 0: print("attack", k, "/", len(tasks), flush=True)
    pd.DataFrame(rows).to_csv(out_raw, index=False, compression="gzip")
    L = []
    for i, (cls, scen, rate, pol) in enumerate(itertools.product(CLASSES, ESC, [0.1, 1, 10], POLICIES)):
        L.append(legit(cls, scen, rate, pol, 200 if pilot else 2000, 31337 + i))
    pd.DataFrame(L).to_csv(out_leg, index=False)
    print("done")


if __name__ == "__main__":
    main()
