"""Analyse graded_response_experiment.py output (graph-cluster bootstrap; paired differences vs revised_k3).
Usage: python3 analyse_graded_response.py"""
import os
import numpy as np
import pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, "..", "..")
r = pd.read_csv(os.path.join(ROOT, "02_Data", "Raw", "graded_response_raw.csv.gz"))
l = pd.read_csv(os.path.join(ROOT, "02_Data", "Processed", "graded_response_legitimate.csv"))
ORDER = ["alert_only", "revised_k3", "priv_reduce", "rate_limit", "monitor", "graded"]
rng = np.random.default_rng(7)


def boot(x, B=4000):
    x = np.asarray(x, float); return tuple(np.percentile([rng.choice(x, len(x)).mean() for _ in range(B)], [2.5, 97.5]))


rows = []
for (pr, rate), g in r.groupby(["profile", "rate"]):
    ref = g[g.policy == "revised_k3"].set_index(["graph", "run"]).n_compromised
    for pol in ORDER:
        x = g[g.policy == pol]; xi = x.set_index(["graph", "run"]).n_compromised
        d = (xi - ref).groupby("graph").mean().values
        lo, hi = boot(d)
        rows.append(dict(profile=pr, rate=rate, policy=pol, mean_compromised=x.n_compromised.mean(), diff_vs_revised=d.mean(), diff_lo=lo, diff_hi=hi,
                         contained_before_O=x.contained_before_O.mean(), mean_degraded=x.n_degraded.mean(), censored=x.censored.mean()))
s = pd.DataFrame(rows); s.to_csv(os.path.join(ROOT, "02_Data", "Processed", "graded_response_summary.csv"), index=False)
lw = l.pivot_table(index=["cls", "scenario", "rate"], columns="policy", values=["false_isolation_per_shift", "degraded_per_shift"])
lw.columns = [f"{a}__{b}" for a, b in lw.columns]; lw = lw.reset_index(); lw.to_csv(os.path.join(ROOT, "02_Data", "Processed", "graded_response_legitimate_wide.csv"), index=False)
pd.set_option("display.width", 250)
print(s[s.rate == 1000].round(3).to_string(index=False))
print(lw[lw.rate == 1].round(3).to_string(index=False))
print("max abs diff rate 10 vs 1000:", (s[s.rate == 10].set_index(["profile", "policy"]).mean_compromised - s[s.rate == 1000].set_index(["profile", "policy"]).mean_compromised).abs().max())
fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.6))
lab = ["alert\nonly", "isolate\n(k=3)", "priv.\nreduce", "rate\nlimit", "monitor", "graded"]
for pr, m in zip(["moderate", "burst", "stealthy", "rapid_multistep"], ["o", "D", "s", "^"]):
    d = s[(s.profile == pr) & (s.rate == 1000)].set_index("policy").reindex(ORDER)
    ax[0].plot(range(6), d.mean_compromised, marker=m, ms=4, lw=1, label=pr)
ax[0].set_xticks(range(6)); ax[0].set_xticklabels(lab, fontsize=6); ax[0].set_ylabel("mean compromised entities"); ax[0].legend(fontsize=6, frameon=False); ax[0].set_title("(a) attack side, 1000 req/s", fontsize=7)
d1 = l[(l.rate == 1)].groupby("policy")[["degraded_per_shift", "false_isolation_per_shift"]].max().reindex(ORDER)
ax[1].bar(np.arange(6) - 0.2, d1.degraded_per_shift, 0.4, color="#9fc5e8", label="degraded (max over classes)")
ax[1].bar(np.arange(6) + 0.2, d1.false_isolation_per_shift, 0.4, color="#2a6f97", label="isolated (max over classes)")
ax[1].set_xticks(range(6)); ax[1].set_xticklabels(lab, fontsize=6); ax[1].set_ylabel("legitimate entities per 8-h shift"); ax[1].legend(fontsize=6, frameon=False); ax[1].set_title("(b) legitimate side, 1 req/s", fontsize=7)
fig.tight_layout(); fig.savefig(os.path.join(HERE, "fig_graded_response.pdf")); fig.savefig(os.path.join(HERE, "fig_graded_response.png"), dpi=200)
