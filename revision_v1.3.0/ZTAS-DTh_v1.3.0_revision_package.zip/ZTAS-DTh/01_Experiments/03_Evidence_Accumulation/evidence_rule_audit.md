# evidence_rule_audit.md (concern 3, Task 3.1)

## 1. Audit of the evidence mechanism (`evidence_rule_audit` = §1 of this report together with `../risk_engine/risk_engine_audit.md`)

| Element | Implementation | Note |
|---|---|---|
| Counter | One per subject; +1 for a failed step-up outside an outage, +2 for a block decision; −1 for a successful step-up (decay policies, PoC) | E1 gives no −1 credit; E2 has no block events |
| Threshold | κ = 2 (original) or 3 (revised) | Configuration |
| Decay | Revised rule: half-life 30 risk-engine evaluations. PoC: 30 s wall clock. E1: 0.95 per step | Units differ between artefacts (now stated) |
| Reset | None; "reset on success" is a variant | – |
| Step-up failure | Attacker fails with probability stepup_fail. Legitimate failure depends on device class and rises during outages | – |
| Segment expiry | Independent of evidence: an expired segment denies the request but adds no evidence | – |
| Isolation | Immediate for non-operations assets. Operations assets: isolation is requested and takes effect after operator approval (120 s here) | – |
| Emergency override | Not implemented: an approver can only confirm, not pre-empt | Gap, stated |
| Asset criticality | Only the operations-phase flag. The v3 criticality-aware policy adds restriction | – |
| Operator approval | Required for operations assets | – |

