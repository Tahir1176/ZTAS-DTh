"""
GRADED RESPONSES (v5, concern 3): does a graded response ladder below isolation shorten the containment delay
of the revised evidence rule (kappa = 3) at an acceptable legitimate cost?

Re-uses, unchanged, the attacker model, score model, request patterns, base parameters, reference-topology graphs
and seeds of evidence_policy_extension_experiment.py (v4). Only the response to evidence differs:

  revised_k3       isolation at e >= 3 (operations assets after APPROVAL_S operator approval) -- v4 reference
  alert_only       e >= 3 raises an alert, no enforcement (lower bound: what the evidence rule alone buys)
  monitor          e >= 1: heightened monitoring = step-up threshold lowered from 30 to 20 for that entity
                   (more of its requests are challenged); isolation at e >= 3
  priv_reduce      e >= 2: privileges reduced = authorisation denies with 0.9 instead of p_auth = 0.5;
                   isolation at e >= 3
  rate_limit       e >= 2: request rate of the entity cut by 10x; isolation at e >= 3
  graded           monitor at e >= 1, privilege reduction + rate limit at e >= 2, isolation at e >= 3

"Contained" requires every compromised entity to be ISOLATED (degraded entities can still act). Legitimate cost:
fraction of legitimate entities per 8-h shift that are degraded (e >= 1 or 2, depending on policy) and isolated
(e >= 3), with the v4 legitimate escalation/failure model. ALL rates and effect sizes of the degradation measures
are exploratory assumptions.
Usage: python3 graded_response_experiment.py OUT_RAW.csv.gz OUT_LEGIT.csv [--pilot]
"""
import sys, os, heapq, itertools
from multiprocessing import Pool
import numpy as np
import pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)); sys.argv_backup = list(sys.argv)
sys.path.insert(0, HERE)
import evidence_policy_extension_experiment as X   # noqa: E402 (re-use model pieces unchanged)
tp = X.tp

POL = {
    "revised_k3":  dict(),
    "alert_only":  dict(alert_only=True),
    "monitor":     dict(monitor_at=1),
    "priv_reduce": dict(priv_at=2),
    "rate_limit":  dict(rate_at=2),
    "graded":      dict(monitor_at=1, priv_at=2, rate_at=2),
}
KAPPA = 3
P_AUTH_REDUCED = 0.9
RATE_FACTOR = 0.1
THETA1_MON = 20.0


def attack_run(G, phase, succ, prof, rate, pol, seed):
    rng = np.random.default_rng(seed); P = POL[pol]; pr = X.PROFILES[prof]; B = X.BASE
    nodes = list(G.nodes); pool = [v for v in nodes if phase[v] in ("X", "D", "M", "S")]
    entry = pool[rng.integers(len(pool))]
    comp = {entry: 0.0}; ev = {entry: 0.0}
    iso, pending, degraded = {}, {}, {}
    pats = {entry: X.Pattern(rng, pr["pattern"], rate * pr["mult"])}
    heap = [(pats[entry].next_after(0.0), entry)]
    reach_O = None; n_req = 0; first_alert = None

    def respond(u, t):
        nonlocal first_alert
        if first_alert is None: first_alert = t
        if P.get("alert_only"): return
        if phase[u] == "O": pending.setdefault(u, t + X.APPROVAL_S)
        else: iso[u] = t

    while heap and n_req < X.MAX_EVENTS:
        t, u = heapq.heappop(heap)
        if t > X.HORIZON_S: break
        for x, tt in list(pending.items()):
            if tt <= t: iso[x] = tt; del pending[x]
        if u in iso: continue
        targets = [v for v in succ[u] if v not in comp]
        if not targets: continue
        n_req += 1
        v = targets[rng.integers(len(targets))]
        e = ev[u]
        lim = "rate_at" in P and e >= P["rate_at"]
        nxt = lambda: heapq.heappush(heap, (pats[u].next_after(t) if not lim else t + (pats[u].next_after(t) - t) / RATE_FACTOR, u))
        if e >= P.get("monitor_at", 99) or e >= P.get("priv_at", 99) or lim: degraded.setdefault(u, t)
        p_auth = P_AUTH_REDUCED if e >= P.get("priv_at", 99) else B["p_auth"]
        if rng.random() < p_auth: nxt(); continue
        if rng.random() > B["p_act"]: nxt(); continue
        ev[u] *= X.LAM_REQ
        s = X.score(rng, pr["mu"])
        th1 = THETA1_MON if e >= P.get("monitor_at", 99) else 30.0
        if s > 90: respond(u, t); nxt(); continue
        if s > 70 or (s > th1 and rng.random() < pr["sf"]):
            ev[u] += 2.0 if s > 70 else 1.0
            if ev[u] >= KAPPA: respond(u, t)
            nxt(); continue
        if rng.random() < pr["pe"]:
            comp[v] = t; ev[v] = 0.0
            pats[v] = X.Pattern(rng, pr["pattern"], rate * pr["mult"])
            heapq.heappush(heap, (pats[v].next_after(t), v))
            if phase[v] == "O" and reach_O is None: reach_O = t
        nxt()
    contained = all(x in iso for x in comp)
    t_cont = max(iso[x] for x in comp) if contained else np.nan
    return dict(profile=prof, rate=rate, policy=pol, seed=seed, n_requests=n_req, censored=n_req >= X.MAX_EVENTS,
                contained=float(contained), t_containment=t_cont, n_compromised=sum(1 for x in comp if phase[x] != "X"),
                reached_O=float(reach_O is not None), contained_before_O=float(contained and (reach_O is None or reach_O > t_cont)),
                n_degraded=len(degraded), t_first_alert=first_alert if first_alert is not None else np.nan)


def attack_task(args):
    g, prof, rate, runs = args
    G = tp.build("reference", 9000 + g)
    phase = {v: G.nodes[v]["phase"] for v in G}; succ = {v: list(G.successors(v)) for v in G}
    return [dict(graph=g, run=r, **attack_run(G, phase, succ, prof, rate, pol, 7_000_003 * g + 1009 * r + 17))
            for pol in POL for r in range(runs)]


def legit(cls, scen, rate, pol, n_ent, seed, shift_s=8 * 3600):
    """v4 legitimate model; records first time an entity is degraded and whether it is isolated (e >= 3)."""
    rng = np.random.default_rng(seed); P = POL[pol]; c = X.CLASSES[cls]
    lam = rate * X.ESC[scen]; a_rate = (1 / 300) * 0.05 / 0.95; b_rate = 1 / 300; pi = 0.05
    t = np.zeros(n_ent); ev = np.zeros(n_ent); out = rng.random(n_ent) < pi
    iso = np.zeros(n_ent, bool); deg = np.zeros(n_ent, bool)
    dthr = min(P.get("monitor_at", 99), P.get("priv_at", 99), P.get("rate_at", 99))
    while True:
        dt = rng.exponential(1 / lam, n_ent); t = t + dt
        alive = (t < shift_s) & ~iso
        if not alive.any(): break
        ee = np.exp(-(a_rate + b_rate) * dt); out = rng.random(n_ent) < np.where(out, pi + (1 - pi) * ee, pi * (1 - ee))
        ev = np.where(alive, ev * X.LAM_REQ ** (dt * rate), ev)
        fail = rng.random(n_ent) < np.where(out, c["fail_out"], c["fail"])
        ev = ev + (alive & fail & ~out)
        ev = np.where(alive & ~fail, np.maximum(0, ev - 1), ev)
        deg |= alive & (ev >= dthr)
        if not P.get("alert_only"): iso |= alive & (ev >= KAPPA)
    return dict(cls=cls, scenario=scen, rate=rate, policy=pol, n_entities=n_ent,
                false_isolation_per_shift=float(iso.mean()), degraded_per_shift=float(deg.mean()) if dthr < 99 else 0.0)


def main():
    out_raw, out_leg = sys.argv[1], sys.argv[2]; pilot = "--pilot" in sys.argv
    G_N, RUNS = (2, 5) if pilot else (10, 30)
    tasks = [(g, p, r, RUNS) for g in range(G_N) for p in ["moderate", "stealthy", "rapid_multistep", "burst"] for r in (10, 1000)]
    rows = []
    with Pool(2) as pool:
        for k, res in enumerate(pool.imap_unordered(attack_task, tasks)):
            rows += res
            if k % 10 == 0: print("attack", k, "/", len(tasks), flush=True)
    pd.DataFrame(rows).to_csv(out_raw, index=False, compression="gzip")
    L = [legit(cls, scen, rate, pol, 200 if pilot else 2000, 4242 + i)
         for i, (cls, scen, rate, pol) in enumerate(itertools.product(X.CLASSES, X.ESC, [0.1, 1, 10], POL))]
    pd.DataFrame(L).to_csv(out_leg, index=False)
    print("done")


if __name__ == "__main__":
    main()
