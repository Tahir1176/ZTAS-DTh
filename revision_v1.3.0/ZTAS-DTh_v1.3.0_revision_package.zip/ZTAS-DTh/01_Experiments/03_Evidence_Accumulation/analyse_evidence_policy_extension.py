"""Analyse the v4 evidence-policy extension run (attack + legitimate side). Usage: python3 analyse_evidence_policy_extension.py"""
import os
import numpy as np
import pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, "..", "..")
OUT = os.path.join(ROOT, "02_Data", "Processed")
r = pd.read_csv(os.path.join(ROOT, "02_Data", "Raw", "evidence_policy_extension_raw.csv.gz"))
l = pd.read_csv(os.path.join(OUT, "evidence_policy_extension_legitimate.csv"))
ORDER = ["kappa1_decay", "kappa2_decay", "kappa3_decay", "kappa4_decay", "kappa5_decay", "revised_approval0s", "revised_approval30s", "revised_approval600s", "emergency_isolation", "safe_state", "propagation_aware"]


def boot(x, B=2000, seed=1):
    x = np.asarray(x, float); x = x[~np.isnan(x)]
    if len(x) == 0: return (np.nan, np.nan)
    rng = np.random.default_rng(seed); m = [rng.choice(x, len(x)).mean() for _ in range(B)]
    return tuple(np.percentile(m, [2.5, 97.5]))


rows = []
for (pr, rate, pol), g in r.groupby(["profile", "rate", "policy"]):
    gm = g.groupby("graph")  # graph-level cluster bootstrap on graph means
    nc = gm.n_compromised.mean(); ro = gm.reached_O.mean(); cbo = gm.contained_before_O.mean()
    rows.append(dict(profile=pr, rate=rate, policy=pol, runs=len(g), mean_compromised=g.n_compromised.mean(), ci_compromised=boot(nc.values),
                     p_reach_O=g.reached_O.mean(), p_contained_before_O=g.contained_before_O.mean(), ci_contained_before_O=boot(cbo.values),
                     median_t_containment_s=g.t_containment.median(), median_requests_before_containment=g.requests_before_containment.median(),
                     mean_isolated=g.n_isolated.mean(), censored=g.censored.mean()))
s = pd.DataFrame(rows)
for c in ["ci_compromised", "ci_contained_before_O"]:
    s[c + "_lo"] = s[c].map(lambda t: float(t[0])); s[c + "_hi"] = s[c].map(lambda t: float(t[1])); s = s.drop(columns=c)
s["policy"] = pd.Categorical(s.policy, ORDER, ordered=True); s = s.sort_values(["profile", "rate", "policy"])
# legitimate side: prop-aware = 0.25*kappa2 + 0.75*kappa3 (hub quartile uses kappa=2); safe-state reported as transitions (production impact) = kappa2-level isolations on O assets
lg = l.pivot_table(index=["cls", "scenario", "rate"], columns="policy", values="false_isolation_per_shift").reset_index()
# the legitimate simulator applies only kappa/decay keys, so its propagation_aware column is the kappa=3 default for every entity;
# replace it with the hub-quartile mixture (hubs use kappa=2)
lg["propagation_aware_simulated_kappa3"] = lg["propagation_aware"]
lg["propagation_aware"] = 0.25 * lg["kappa2_decay"] + 0.75 * lg["kappa3_decay"]
s.to_csv(os.path.join(OUT, "evidence_policy_extension_summary.csv"), index=False)
lg.to_csv(os.path.join(OUT, "evidence_policy_extension_legitimate_wide.csv"), index=False)
pd.set_option("display.width", 250)
print(s[s.rate == 1000][["profile", "policy", "mean_compromised", "p_contained_before_O", "median_t_containment_s", "median_requests_before_containment"]].round(3).to_string(index=False))
print(s[s.rate == 10][["profile", "policy", "mean_compromised", "p_contained_before_O", "median_t_containment_s"]].round(3).to_string(index=False))
print(lg.round(4).to_string(index=False))
# figure
fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.7))
pols = ["kappa1_decay", "kappa2_decay", "kappa3_decay", "kappa4_decay", "kappa5_decay", "propagation_aware", "emergency_isolation", "safe_state"]
lab = [r"$\kappa$=1", "2", "3", "4", "5", "prop.", "emerg.", "safe"]
mk = dict(moderate="o", stealthy="s", rapid_multistep="^", burst="D")
for pr in ["moderate", "stealthy", "rapid_multistep", "burst"]:
    d = s[(s.profile == pr) & (s.rate == 1000)].set_index("policy").reindex(pols)
    ax[0].plot(range(len(pols)), d.mean_compromised.values, marker=mk[pr], ms=4, lw=1, label=pr)
ax[0].set_xticks(range(len(pols))); ax[0].set_xticklabels(lab, fontsize=7); ax[0].set_ylabel("mean compromised entities"); ax[0].legend(fontsize=6, frameon=False); ax[0].set_title("(a) attack side, 1000 req/s", fontsize=7)
for (cls, sc), d in lg[lg.rate == 1.0].groupby(["cls", "scenario"]):
    ax[1].plot(range(5), [d[f"kappa{k}_decay"].values[0] for k in range(1, 6)], marker="o", ms=3, lw=1, label=f"{cls} / {sc}")
ax[1].set_xticks(range(5)); ax[1].set_xticklabels([r"$\kappa$=1", "2", "3", "4", "5"], fontsize=7); ax[1].set_ylabel("false isolation per 8-h shift"); ax[1].legend(fontsize=5.5, frameon=False); ax[1].set_title("(b) legitimate side, 1 req/s", fontsize=7)
fig.tight_layout(); fig.savefig(os.path.join(HERE, "fig_evidence_policy_extension.pdf")); fig.savefig(os.path.join(HERE, "fig_evidence_policy_extension.png"), dpi=200)
