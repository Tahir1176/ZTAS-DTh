# EVIDENCE_ACCUMULATION_REPORT.md — concern 3 (delayed containment)

**Scope.** This is a continuous-time simulation. Request rates, approval delays, outage behaviour and attacker profiles are **exploratory assumptions**, not measurements of industrial systems. The revised evidence rule is **not operationally validated**.

## 1. Audit of the evidence mechanism (`evidence_rule_audit` = §1 of this report together with `../risk_engine/risk_engine_audit.md`)

| Element | Implementation | Note |
|---|---|---|
| Counter | One per subject; +1 for a failed step-up outside an outage, +2 for a block decision; −1 for a successful step-up (decay policies, PoC) | E1 gives no −1 credit; E2 has no block events |
| Threshold | κ = 2 (original) or 3 (revised) | Configuration |
| Decay | Revised rule: half-life 30 risk-engine evaluations. PoC: 30 s wall clock. E1: 0.95 per step | Units differ between artefacts (now stated) |
| Reset | None; "reset on success" is a variant | – |
| Step-up failure | Attacker fails with probability stepup_fail. Legitimate failure depends on device class and rises during outages | – |
| Segment expiry | Independent of evidence: an expired segment denies the request but adds no evidence | – |
| Isolation | Immediate for non-operations assets. Operations assets: isolation is requested and takes effect after operator approval (120 s here) | – |
| Emergency override | Not implemented: an approver can only confirm, not pre-empt | Gap, stated |
| Asset criticality | Only the operations-phase flag. The v3 criticality-aware policy adds restriction | – |
| Operator approval | Required for operations assets | – |

## 2. Why request counts cannot simply be divided by a rate
- Attack progression is **request-driven**: each allowed request may compromise a new entity, which then sends its own requests.
- The response contains **wall-clock** elements: operator approval latency, and time-based decay in one policy.
- `evidence_accumulation_experiment.py` therefore simulates both in continuous time:
  - 10 reference-topology graphs × 30 runs × 7 attacker profiles × 4 base rates × 5 policies, all on common random numbers;
  - plus a "full" configuration with provenance gates at 10 req/s;
  - 52 500 runs, none censored at the 300 000-event cap.

**The finding that justifies this design.** For request-based policies every outcome is **invariant to the rate** except time, which scales as 1/r. Examples:
- Moderate attacker, median time to first response under the revised rule: 78 s at 1 req/s, 7.8 s at 10, 0.78 s at 100, 0.078 s at 1000.
- Compromised entities: 49.0 at every rate.

Rate changes the outcome only through wall-clock elements:
- **Time-based decay with a slow attacker.** The low-intensity attacker sends 0.1 req/s per entity at a base rate of 1. Under time-based decay it was **never** contained: 0/300 runs, 54.8 of 56 entities compromised. Evidence decays between its requests.
- **Operator approval.** Its 120 s latency had no measurable effect here. Containment succeeded only when the initial foothold, never an operations asset, was isolated early. When the attacker reached the operations phase first, containment failed in all but 0.06% of runs, whatever the approval latency.

## 3. Attacker intensity profiles (operational relevance)

| Profile | Definition (per compromised entity) | Represents |
|---|---|---|
| Low-intensity | 0.1 × r, μ_mal = 40 | Slow reconnaissance or living-off-the-land |
| Moderate | r, μ_mal = 40 | Ordinary interactive intrusion |
| High-intensity | 10 × r, μ_mal = 40 | Scripted or automated pivoting |
| Burst | 50-request bursts at 10 × r, exponential 300 s gaps | Tool runs between pauses |
| Intermittent | r during 60 s of every 660 s | Activity confined to working-hour windows |
| Stealthy | r, μ_mal = 28 | Requests close to legitimate behaviour (v2 profile) |
| Rapid multi-step | 10 × r, μ_mal = 40, p_exploit = 0.6, stepup_fail = 0.4 | Prepared exploit chain, partial credential material |

## 4. Results (risk-only configuration: authorisation + segments + risk engine; `evidence_accumulation_processed.csv`)

| Policy | P(contained before operations phase) | Compromised of 56 (moderate) | Median requests to containment | False isolation per 8 h shift, field device, heavy-tailed, 1 req/s |
|---|---|---|---|---|
| Original (κ = 2, no decay) | **0.43** | **25.2** | 30 | **0.9995** |
| Revised (κ = 3, request decay, outage-aware) | 0.11 | 49.0 | 62.5 | 0.0000 |
| Alternative threshold (κ = 3, no decay) | 0.23 | 40.2 | 45.5 | 0.89 |
| Time-based decay (κ = 3, h = 60 s) | 0.11 (0.00 for low-intensity at r = 1) | 49.0 | 62.5 | 0.0000 |
| Criticality-aware (revised + restriction of operations assets at evidence ≥ 2) | 0.11 | 48.1 | 62.5 | 0.0000 isolation; 0.001 restriction |

These figures are for the moderate, burst, intermittent, low- and high-intensity profiles; they are identical up to time scaling. Against stealthy and rapid attackers **no** evidence policy contained more than 5% of runs in the risk-only configuration.

**Full configuration (with provenance gates, 10 req/s).** The original rule contained 58%, the revised rule 35% and the criticality-aware rule 35% of moderate-attacker runs. For stealthy attackers the figures were 25%, 21% and 21%.

**Paired differences in compromised entities against the revised rule (10 req/s, cluster bootstrap over graphs):**
- original: −23.8 [−26.1, −21.8]
- alternative κ = 3 without decay: −8.8 [−10.6, −6.8]
- criticality-aware: −0.84 [−1.25, −0.48]
- time decay: 0 (equal) for the moderate attacker; +1.5 [+0.6, +2.4] for the low-intensity attacker.

**Legitimate side** (`evidence_accumulation_legitimate.csv`; 2000 entities per cell; 8 h shift; 0.1–10 legitimate req/s):
- The original rule isolates 15–100% of legitimate entities per shift at ≥ 0.1 req/s. This is worse than the v2 estimate (up to 8%), which assumed 480 requests per shift.
- The κ = 3 rule without decay is just as unsafe at ≥ 1 req/s.
- The revised, time-decay and criticality-aware rules produced at most 2 false isolations in 2000 entities per shift (≤ 0.1%) in every cell. The maximum occurred for human operators at 10 req/s.

## 5. The security-versus-operational-safety trade-off
- The revised rule removes the false-isolation problem, but at a large security cost. In this model it roughly halves the probability of early containment (0.43 → 0.11) and doubles the number of compromised entities for ordinary attackers (25 → 49 of 56).
- No evidence rule examined contains a stealthy or rapid attacker by itself. Containment of these profiles depends on the other controls (provenance, segments) and on detection outside the risk engine.
- The criticality-aware policy restricts rather than isolates operations assets. It gives a small but statistically clear improvement (−0.8 entities) at negligible legitimate cost (0.1% restriction per shift for heavy-tailed field devices at 1 req/s). It is a simulation policy, not a demonstrated safety system.
- Time-based decay should not be used alone, because slow attackers evade it. A request-based decay unit, or a decay floor, is required.
- Therefore the revised rule is presented as one point on a trade-off curve, not as an operationally acceptable setting. The choice of κ and decay per asset class belongs to the calibration protocol (`../risk_engine/risk_calibration_protocol.md`). It must be made with plant safety engineering, because automatic isolation of an operations asset may itself be unsafe.

## 6. Files
- `evidence_accumulation_experiment.py`, `evidence_accumulation_analysis.py`, `evidence_accumulation_analysis.ipynb`
- Raw: `02_Data/raw/evidence_accumulation_raw.csv.gz`
- Processed: `02_Data/processed/evidence_accumulation_processed.csv`, `evidence_accumulation_legitimate.csv`
- `evidence_policy_paired_comparison.csv`, `evidence_accumulation_figures/fig_evidence_time.pdf|png`
