# POC_INTEGRATION_REPORT.md — concern 5

**This is a controlled software demonstration on one host (2 vCPU, localhost HTTP). It is not an industrial deployment.** The latency and throughput figures reflect Python services on a server CPU. They do not transfer to PLC networks, gateways or HSMs.

## 1. Audit and component mapping
See `poc_implementation_audit.md`. In summary:
- **Implemented:** IdP, PDP, PEP, segmentation decision, provenance with Merkle/ML-DSA, and lineage.
- **Mocked:** the twin, step-up outcomes, risk-context values, and the admin approver.
- **Abstracted:** segmentation at the network layer.
- **Not implemented:** distributed ledger, two-person rule, time-critical command path, and a tamper-evident log.

## 2. Test procedure
- `poc_failure_tests.py` starts a fresh six-process stack for every scenario and runs it against localhost only. The driver is `run_all_poc_tests.sh`.
- Every v3 fix is switchable, so the v2 behaviour can be run as a control under identical conditions. The flags are recorded in each `raw/*.json`.
- Latency is measured client-side end to end with `perf_counter`.
- CPU time and peak RSS are read from each service via `/stats` before and after a run.
- Scenarios B–I were run with the anti-replay window W = 64. Fewer than 64 records are in flight in those scenarios, so W does not affect them.

## 3. Results

### Scenario A — concurrent requests (v3, W = 1024; 120 requests per client)

| Clients | Artifact req: throughput (req/s) | p50 / p95 / p99 (ms) | Failures | Plain req: throughput | p50 / p95 / p99 (ms) |
|---|---|---|---|---|---|
| 1 | 337 | 2.35 / 5.78 / 11.62 | 0 | 642 | 1.40 / 2.09 / 3.04 |
| 2 | 488 | 3.99 / 6.30 / 6.83 | 0 | 838 | 2.31 / 3.14 / 3.58 |
| 4 | 559 | 6.47 / 11.83 / 18.51 | 0 | 933 | 3.96 / 6.66 / 9.13 |
| 8 | 560 | 13.39 / 23.44 / 28.37 | 0 | 907 | 7.97 / 14.52 / 18.85 |
| 16 | 489 | 27.61 / 46.26 / 58.02 | 0 | 829 | 13.60 / 29.61 / 39.12 |

- Throughput saturates at about 560 artifact-bearing or about 930 plain requests per second. Beyond that, latency grows linearly with concurrency, which is queueing on 2 vCPUs with the Python GIL.
- PEP and provenance-service CPU dominate: 2.9 s and 2.6 s for 1920 artifact requests.
- **Controls** (`poc_concurrency_processed.csv`):
  - Strict ordering (v2 gate rule) denied 18%, 33%, 56% and 77% of legitimate artifact requests at 2, 4, 8 and 16 clients.
  - A window of 64 still denied 23% at 16 clients.
  - The v2 shared client produced 51–94% failures at 2–16 clients, including misattributed responses ("content hash mismatch" on legitimate artifacts) and 10 s timeouts.
  - The v2-control *plain* rows are invalid. The run lasted longer than the 300 s token lifetime, so the remaining requests were denied as "token expired". They are reported but not interpreted.

### Scenarios B–I — failures, races, recovery

| Scenario | v3 result | v2-behaviour control |
|---|---|---|
| B: provenance service stopped | 30/30 artifact requests denied ("fail-closed", logged); 30/30 plain requests allowed | 30/30 artifact requests got no response (connection closed), nothing logged |
| C: PDP stopped (sequential) | 60/60 denied, p50 2.3 ms | (v2 already failed closed) |
| C-load: PDP stopped under 4-client load | 629 requests completed after the stop, **0 allowed** | – |
| D: segmentation controller stopped | 60/60 denied ("segment state unconfirmed") | 60/60 got no response |
| E: revocation under 4-client load | 227 requests allowed after revocation; the last 0.51 s after it (bound: 1 s CRL refresh). IdP stopped: requests allowed from the cached CRL until 4.6 s, then denied (bound 5 s) | – |
| F: 16 concurrent copies of one record, 20 rounds | Exactly 1 accepted per round (W = 64 and W = 1024) | Hung for > 8 min (shared-client deadlock); terminated |
| G: segment revoked during 8-client load with a 50 ms check-to-forward window, 5 rounds | **0** forwards after the revocation acknowledgement; 7–8 requests per round denied by re-validation | **37** forwards after acknowledgement (up to 0.47 s late) |
| H: PDP restart after quarantine | Recovery to first allowed request: 17 ms (fork on the same host); quarantined device still denied | Recovery 18 ms; **quarantined device allowed again** |
| I: missing risk dimensions | All missing → r = 50 → step-up; two missing → r = 37.5 → step-up | All missing → r = 0 → allow |

**Recovery-time caveat.** The 17 ms is the restart of a forked process on the same host. It excludes OS or container restart, state replication and network convergence.

## 4. Relation to the formal model
Each v3 fix corresponds to a design rule whose removal produced a counterexample in M4:
- fail-closed — M4b;
- re-validation — M4c;
- atomic anti-replay — M4d;
- CRL bound — M4a.

The tests show the PoC follows these rules in the exercised scenarios. They do not verify the code.

## 5. Remaining limitations
- Single host, 2 vCPU, Python; no network emulation, TLS, replicated PDP/PEP or failover.
- Context and step-up outcomes are injected by the test client.
- Results from 120–1920 requests per configuration. One run per configuration, so there is no between-run variance. Percentiles above p99 are not reported.
