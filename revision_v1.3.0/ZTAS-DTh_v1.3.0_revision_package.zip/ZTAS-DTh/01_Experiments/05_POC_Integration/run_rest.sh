#!/bin/sh
cd "$(dirname "$0")"
run() { name=$1; shift; sc=$1; shift; echo "== $name"; env "$@" timeout 600 python3 poc_failure_tests.py $sc raw/$name.json 2>>poc_stderr_rest.log | cut -c1-600; }
run G_v3 G
run G_noRevalidate G ZTAS_REVALIDATE=0
run H_v3 H
run H_v2control H ZTAS_PDP_PERSIST=0
