import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
P = ["Requester", "PEP", "IdP", "Segmentation\ncontroller", "Provenance\nservice", "PDP", "Twin / MES"]
M = [(0, 1, "1 request: token, flow D→M, artifact ref, context"), (1, 1, "2 verify token signature and expiry"),
     (1, 2, "2b CRL refresh if > 1 s old (IdP down and CRL > 5 s → deny)"), (1, 3, "5 segment check → ok, policy version v"),
     (1, 4, "6 inclusion proof, signed header, lineage parent"), (1, 1, "6b hash, Merkle, ML-DSA; atomic anti-replay; lineage"),
     (1, 5, "3–4 decide: 5-D risk, tier, evidence"), (1, 1, "7 re-validate if segment version > v (TOCTOU guard)"),
     (1, 6, "8 forward"), (1, 1, "9 log decision + reason"), (5, 1, "10 evidence ≥ κ → quarantine / pending operator approval")]
fig, ax = plt.subplots(figsize=(7.2, 4.6)); ax.axis("off"); xs = [i * 1.15 for i in range(len(P))]; H = len(M) + 1
for x, p in zip(xs, P):
    ax.text(x, H + 0.35, p, ha="center", va="bottom", fontsize=6.5, bbox=dict(boxstyle="round", fc="#cfe1ef", lw=0.5))
    ax.plot([x, x], [0.2, H + 0.3], color="#888", lw=0.5, ls="--")
for k, (a, b, t) in enumerate(M):
    y = H - 0.6 - k
    if a == b:
        ax.annotate("", (xs[a] + 0.02, y - 0.25), (xs[a] + 0.02, y), arrowprops=dict(arrowstyle="->", lw=0.6, connectionstyle="arc3,rad=-1.2"))
        ax.text(xs[a] + 0.2, y - 0.1, t, fontsize=5.6, va="center")
    else:
        ax.annotate("", (xs[b], y), (xs[a], y), arrowprops=dict(arrowstyle="->", lw=0.7))
        ax.text((xs[a] + xs[b]) / 2, y + 0.08, t, fontsize=5.6, ha="center", va="bottom")
ax.text(0, -0.2, "Any unreachable service (IdP beyond CRL staleness, segmentation controller, provenance service, PDP) → deny and log (fail-closed).", fontsize=5.8)
fig.savefig("poc_sequence_diagram.png", dpi=220, bbox_inches="tight"); fig.savefig("poc_sequence_diagram.pdf", bbox_inches="tight")
