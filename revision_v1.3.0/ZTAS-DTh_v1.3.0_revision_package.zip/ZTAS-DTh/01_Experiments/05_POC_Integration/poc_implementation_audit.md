# poc_implementation_audit.md — concern 5, Tasks 5.1–5.2

PoC: `src/poc/ztas_poc.py` (v2, 418 lines) and `src/poc/ztas_poc_v3.py` (v3).

**Setup.** Six Python processes (IdP, PDP, segmentation controller, provenance service, twin, PEP) run on one host and talk over localhost HTTP/1.1 with keep-alive and TCP_NODELAY. They are served by `ThreadingHTTPServer`, one thread per connection.

## Endpoints and request flow
- **IdP:** `/issue` (Ed25519-signed token, 300 s TTL), `/revoke`, `/crl`.
- **PDP:** `/decide` (5-D risk, tiers, decaying evidence, quarantine/pending), `/approve`, `/status`.
- **Segmentation controller:** `/create`, `/check`, and in v3 `/revoke` with a policy version pushed to the PEP's `/notify`.
- **Provenance service:**
  - `/record` (per-gateway sequence, hash chain, SQLite, Merkle batch with B = 64 or a 50 ms timeout, ML-DSA-65 header signature);
  - `/proof`, `/flush`.
- **Twin:** `/apply`, and in v3 `/log`.
- **PEP:** `/request`, `/events`, and in v3 `/notify`.

**Flow.** Token → CRL → segment → provenance and lineage → PDP → (v3: re-validation) → forward → log. Sequence diagram: `poc_sequence_diagram.png|pdf`; editable Mermaid source: `poc_sequence_diagram.mmd`.

## Defects found by the v3 tests in the v2 PoC

| # | Defect (v2) | How found | Consequence | v3 fix (switch) |
|---|---|---|---|---|
| 1 | The PEP shared one `http.client` connection per backend across all server threads | Scenario A/F at ≥ 2 concurrent clients | `CannotSendRequest`/`ResponseNotReady`/`BrokenPipe`; responses delivered to the **wrong request** (legitimate artifacts reported as "content hash mismatch"); 10 s stalls; the F control hung for > 8 min | One client per thread (`ZTAS_THREADLOCAL=1`) |
| 2 | Strict per-gateway ordering at the gate | Scenario A | 18% / 33% / 56% / 77% of legitimate artifact requests denied at 2 / 4 / 8 / 16 clients | Anti-replay window (`ZTAS_REPLAY=window`, W = 1024; W = 64 still denied 23% at 16 clients) |
| 3 | IdP, segmentation-controller and provenance outages raised exceptions inside the handler | Scenarios B, D | No response (connection closed), nothing logged; behaviour depended on the client | Fail-closed deny with a logged reason (`ZTAS_FAILCLOSED=1`); stale-CRL bound 5 s |
| 4 | No protection against a policy change between segment check and forwarding | Scenario G | 37 requests forwarded after the revocation was acknowledged (5 rounds × 240 requests; up to 0.47 s late) | Segment-policy version push and re-validation (`ZTAS_REVALIDATE=1`) → 0 |
| 5 | PDP quarantine state only in memory | Scenario H | Quarantined device **allowed again** after a PDP restart | SQLite persistence (`ZTAS_PDP_PERSIST=1`) → quarantine survives |
| 6 | A missing risk dimension was treated as 0 (lowest risk) | Scenario I / audit | Request with no context → r = 0 → allow | Conservative imputation (50) → step-up (`ZTAS_MISSING=conservative`) |

## Component mapping

| Architecture component | PoC implementation | Actual functionality | Tested? | Limitations |
|---|---|---|---|---|
| Identity service | IdP process, Ed25519 tokens, in-memory CRL | Implemented | S7, E, IdP outage | No MFA, PUF or HSM; static roster of 5 principals; no token binding |
| PDP / risk engine | PDP process | Implemented (score, tiers, evidence, decay in seconds, quarantine, approval) | S6, S9, C, Cload, H, I | Context values **supplied by the test client** (no telemetry); step-up outcome is a flag (**mocked**); weights not calibrated |
| PEP | PEP process | Implemented | A–I | Application-layer proxy only; no network-layer enforcement; single instance |
| Segmentation controller | Segment table with expiry and versions | Implemented (L7 decision) | S8, D, G | No switch/firewall programming (**abstracted**) |
| Provenance service / gate | SQLite ledger, Merkle batches, ML-DSA-65 signatures | Implemented | S2–S5, B, F | Single gateway key in software; no distributed ledger or consensus (**not implemented**); no anchoring timestamps |
| Lineage policy | Static table in the PEP | Implemented (4 artifact types) | S4, S4b, S5 | Malicious but correctly signed content passes (S5) |
| Twin service | Counter plus log | **Mocked** | Forward log only | No physical process, no twin model integrity |
| Revocation | CRL pull every 1 s | Implemented | S7, E | No OCSP-like push; key-epoch revocation for gateways not exercised in the PoC (model only) |
| Administrative plane / two-person rule | `/approve` with an admin role string | **Partly mocked** (role string, no authentication) | S6 | Two-person rule specified and modelled (M4e), **not implemented** |
| Logging | In-memory event list | Implemented | All scenarios | No tamper-evident audit log |
| Time-critical command path | — | **Not implemented** | — | Described in the architecture only |
