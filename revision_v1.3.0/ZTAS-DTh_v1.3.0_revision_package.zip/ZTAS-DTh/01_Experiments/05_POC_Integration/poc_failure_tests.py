"""
Proof-of-concept concurrency and failure tests (revision v3, reviewer concern 5). Localhost only.
Usage: ZTAS_... flags  python3 poc_failure_tests.py SCENARIO OUT.json      (SCENARIO in A..H)
Each invocation starts a fresh stack of the six services (separate OS processes), runs one scenario and
terminates the stack. The flags select v3 behaviour or the v2 behaviour used as a control (see ztas_poc_v3.py).
"""
import os, sys, json, time, threading, statistics, resource
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "src", "poc"))
os.environ.setdefault("ZTAS_TEST_HOOKS", "1")
import importlib
Z = importlib.import_module(os.environ.get("ZTAS_POC_MODULE", "ztas_poc_v4"))   # v4 default; v3 for controls
from multiprocessing import Process

FN = dict(idp=Z.idp, prov=Z.prov, pdp=Z.pdp, seg=Z.seg, twin=Z.twin, pep=Z.pep)
CTX = dict(temporal=10, spatial=10, behavioural=12, system=10, business=20)


class Stack:
    def __init__(self):
        os.makedirs(Z.KEYDIR, exist_ok=True)
        st = os.path.join(Z.KEYDIR, "pdp_state.sqlite")
        if os.path.exists(st): os.remove(st)
        self.p = {}
        for n in ["idp", "prov", "pdp", "seg", "twin"]: self.start(n)
        time.sleep(1.5); self.start("pep"); time.sleep(1.0)
        self.C = {k: Z.Client(Z.PORTS[k]) for k in Z.PORTS}
        c = self.C
        c["seg"].call("/create", {"id": "s-dm", "flows": [["D", "M"]], "principals": ["cam01", "eng01"], "purpose": "release", "ttl_s": 3600})
        c["seg"].call("/create", {"id": "s-oo", "flows": [["O", "O"]], "principals": ["plc07"], "purpose": "telemetry", "ttl_s": 3600})
        self.tk = {p: Z.token(c["idp"], p) for p in ["eng01", "cam01", "plc07", "sup03"]}
        self.design = Z.make_artifact(c["prov"], "gw-D", "design_rev", "eng01", "engineer", b"CAD rev B", status="released")
        c["prov"].call("/flush")

    def start(self, n):
        self.p[n] = Process(target=FN[n], daemon=True); self.p[n].start()

    def stop(self, n):
        self.p[n].terminate(); self.p[n].join(); time.sleep(0.2)

    def close(self):
        for p in self.p.values():
            if p.is_alive(): p.terminate()

    def arts(self, k):
        out = [Z.make_artifact(self.C["prov"], "gw-M", "machine_instructions", "cam01", "cam", f"G {time.time_ns()} {i}".encode(),
                               parent=self.design["record_id"]) for i in range(k)]
        self.C["prov"].call("/flush"); time.sleep(0.05); return out


def req(client, tk, p, src, dst, art=None, ctx=None, **extra):
    t0 = time.perf_counter()
    try:
        r = client.call("/request", dict({"token": tk[p][0], "sig": tk[p][1], "src": src, "dst": dst, "artifact": art, "ctx": ctx or CTX}, **extra))
    except Exception as e:
        r = {"decision": "no_response", "reason": f"handler exception / connection closed ({type(e).__name__})"}
    r["client_us"] = (time.perf_counter() - t0) * 1e6; r["t_done"] = time.time(); return r


def summ(xs):
    if not xs: return dict(n=0)
    xs = sorted(xs); q = lambda a: xs[min(len(xs) - 1, int(a * len(xs)))]
    return dict(n=len(xs), median_ms=statistics.median(xs) / 1e3, mean_ms=statistics.mean(xs) / 1e3, p95_ms=q(0.95) / 1e3, p99_ms=q(0.99) / 1e3)


def outcomes(rs):
    d = {}
    for r in rs: d[f"{r['decision']}: {r.get('reason', '')}"] = d.get(f"{r['decision']}: {r.get('reason', '')}", 0) + 1
    return d


def run_threads(nthreads, work):
    res = [[] for _ in range(nthreads)]; bar = threading.Barrier(nthreads)
    def w(i):
        cl = Z.Client(Z.PORTS["pep"]); bar.wait()
        for job in work[i]: res[i].append(job(cl))
    ts = [threading.Thread(target=w, args=(i,)) for i in range(nthreads)]
    t0 = time.perf_counter(); [t.start() for t in ts]; [t.join() for t in ts]
    return [x for r in res for x in r], time.perf_counter() - t0


def cpu(S):
    out = {}
    for k in ["idp", "seg", "prov", "twin", "pep", "pdp"]:
        try: out[k] = S.C[k].call("/stats")
        except Exception: out[k] = None
    return out


def scen_A(S):
    R = {}
    for kind in ["artifact", "plain"]:
        for c in [1, 2, 4, 8, 16]:
            per = 120
            arts = S.arts(per * c) if kind == "artifact" else [None] * (per * c)
            work = [[(lambda cl, a=arts[j]: req(cl, S.tk, "cam01", "D", "M", a)) for j in range(i, per * c, c)] for i in range(c)]
            c0 = cpu(S); rs, wall = run_threads(c, work); c1 = cpu(S)
            ok = [r["client_us"] for r in rs if r["decision"] == "allow"]
            R[f"{kind}_c{c}"] = dict(concurrency=c, requests=len(rs), wall_s=wall, throughput_rps=len(rs) / wall,
                                     latency_all=summ([r["client_us"] for r in rs]), latency_allowed=summ(ok),
                                     outcomes=outcomes(rs), failure_rate=1 - len(ok) / len(rs),
                                     cpu_s={k: (c1[k]["cpu_s"] - c0[k]["cpu_s"]) if c0[k] and c1[k] else None for k in c0},
                                     max_rss_kb={k: c1[k]["max_rss_kb"] if c1[k] else None for k in c1})
    return R


def scen_failure(S, svc):
    arts = S.arts(40); pc = Z.Client(Z.PORTS["pep"])
    before = [req(pc, S.tk, "cam01", "D", "M", a) for a in arts[:10]] + [req(pc, S.tk, "cam01", "D", "M") for _ in range(10)]
    S.stop(svc); t_kill = time.time()
    during = [req(pc, S.tk, "cam01", "D", "M", a) for a in arts[10:40]] + [req(pc, S.tk, "cam01", "D", "M") for _ in range(30)]
    return dict(service_stopped=svc, before=outcomes(before),
                during_artifact=outcomes(during[:30]), during_plain=outcomes(during[30:]),
                latency_during=summ([r["client_us"] for r in during]),
                allowed_during=sum(r["decision"] == "allow" for r in during),
                events_tail=[e for e in S.C["pep"].call("/events", {"n": 5})["events"]] if svc != "pep" else None)


def scen_C_under_load(S):
    """PDP stopped while 4 threads issue plain requests; count allows completed after the stop."""
    stop_at = {"t": None}
    def killer():
        time.sleep(0.5); S.stop("pdp"); stop_at["t"] = time.time()
    work = [[(lambda cl: req(cl, S.tk, "cam01", "D", "M")) for _ in range(400)] for _ in range(4)]
    th = threading.Thread(target=killer); th.start(); rs, wall = run_threads(4, work); th.join()
    after = [r for r in rs if r["t_done"] > stop_at["t"] + 0.05]
    return dict(requests=len(rs), completed_after_stop=len(after), allowed_after_stop=sum(r["decision"] == "allow" for r in after),
                outcomes_after_stop=outcomes(after))


def scen_E(S):
    """Revocation under concurrent load + IdP outage behaviour."""
    stop = {"x": False}; R = {}
    rev = {"t": None}
    def revoker():
        time.sleep(0.5); S.C["idp"].call("/revoke", {"principal": "eng01"}); rev["t"] = time.time()
    th = threading.Thread(target=revoker); th.start()
    work = [[(lambda cl: (time.sleep(0.005), req(cl, S.tk, "eng01", "D", "M"))[1]) for _ in range(500)] for _ in range(4)]
    rs, wall = run_threads(4, work); th.join()
    allowed_after = [r["t_done"] - rev["t"] for r in rs if r["decision"] == "allow" and r["t_done"] > rev["t"]]
    R["revocation"] = dict(requests=len(rs), allowed_after_revocation=len(allowed_after),
                           last_allow_after_revocation_s=max(allowed_after) if allowed_after else 0.0,
                           note="bound = PEP CRL refresh interval 1 s")
    # IdP outage: cached CRL used while younger than ZTAS_CRL_MAX_STALE, then fail-closed
    S.stop("idp"); t0 = time.time(); trace = []
    pc = Z.Client(Z.PORTS["pep"])
    while time.time() - t0 < Z.CRL_MAX_STALE + 2.0:
        r = req(pc, S.tk, "cam01", "D", "M"); trace.append((round(time.time() - t0, 2), r["decision"], r.get("reason")))
        time.sleep(0.25)
    first_deny = next((t for t, d, _ in trace if d != "allow"), None)
    R["idp_outage"] = dict(first_non_allow_after_s=first_deny, crl_max_stale_s=Z.CRL_MAX_STALE, trace=trace[::4])
    return R


def scen_F(S):
    rounds = []
    for k in range(20):
        a = S.arts(1)[0]
        work = [[(lambda cl, a=a: req(cl, S.tk, "cam01", "D", "M", a))] for _ in range(16)]
        rs, _ = run_threads(16, work)
        rounds.append(sum(r["decision"] == "allow" for r in rs))
    return dict(rounds=20, threads=16, accepted_per_round=rounds, max_accepted=max(rounds),
                rounds_with_more_than_one_accept=sum(x > 1 for x in rounds))


def scen_G(S):
    out = []
    for k in range(5):
        sid = f"s-race-{k}"
        S.C["seg"].call("/create", {"id": sid, "flows": [["S", "D"]], "principals": ["eng01"], "purpose": "feedback", "ttl_s": 600})
        ack = {"t": None}
        def revoker():
            time.sleep(0.6); r = S.C["seg"].call("/revoke", {"id": sid}); ack["t"] = r["t_ack"]
        th = threading.Thread(target=revoker); th.start()
        tag = f"race{k}"
        work = [[(lambda cl: req(cl, S.tk, "eng01", "S", "D", _test_delay_s=0.05, tag=tag)) for _ in range(30)] for _ in range(8)]
        rs, _ = run_threads(8, work); th.join()
        log = S.C["twin"].call("/log", {"n": 100000})["log"]
        late = [t - ack["t"] for t, frm, tg in log if tg == tag and t > ack["t"]]
        out.append(dict(round=k, requests=len(rs), forwarded_after_revocation_ack=len(late),
                        max_lateness_s=max(late) if late else 0.0, outcomes=outcomes(rs)))
    return dict(rounds=out, total_forwarded_after_ack=sum(r["forwarded_after_revocation_ack"] for r in out))


def scen_H(S):
    pc = Z.Client(Z.PORTS["pep"])
    bad = dict(temporal=40, spatial=30, behavioural=60, system=55, business=20, stepup_ok=False)
    seq = [req(pc, S.tk, "plc07", "O", "O", ctx=bad)["reason"] for _ in range(6)]
    S.C["pdp"].call("/approve", {"sub": "plc07", "approver_role": "admin"})
    pre = req(pc, S.tk, "plc07", "O", "O")["reason"]
    S.stop("pdp"); t_down = time.time()
    down = req(pc, S.tk, "cam01", "D", "M")
    t0 = time.time(); S.start("pdp"); polls = 0
    while True:
        r = req(pc, S.tk, "cam01", "D", "M"); polls += 1
        if r["decision"] == "allow": break
        time.sleep(0.01)
    rec = time.time() - t0
    post = req(pc, S.tk, "plc07", "O", "O")
    return dict(device_sequence=seq, plc07_before_restart=pre, while_down=down["reason"], recovery_time_s=rec, polls=polls,
                plc07_after_restart=dict(decision=post["decision"], reason=post.get("reason")),
                quarantine_survived_restart=post["decision"] != "allow")


def scen_I(S):
    """Missing context dimensions: v2 treated them as zero risk; v3 imputes 50 (step-up tier)."""
    pc = Z.Client(Z.PORTS["pep"]); out = {}
    for name, ctx in [("full_context", CTX), ("missing_all", {"_": 0}), ("missing_behavioural_system", dict(temporal=10, spatial=10, business=20))]:
        r = req(pc, S.tk, "cam01", "D", "M", ctx=ctx); out[name] = dict(decision=r["decision"], reason=r.get("reason"), risk=r.get("risk"))
    return out


def scen_J(S):
    """Segment expiry during in-flight requests (model M4f)."""
    out = []
    for k in range(3):
        sid = f"s-exp-{k}"; ttl = 1.0
        t_create = time.time()
        S.C["seg"].call("/create", {"id": sid, "flows": [["S", "D"]], "principals": ["eng01"], "purpose": "feedback", "ttl_s": ttl})
        t_exp = t_create + ttl; tag = f"exp{k}"
        work = [[(lambda cl: req(cl, S.tk, "eng01", "S", "D", _test_delay_s=0.05, tag=tag)) for _ in range(30)] for _ in range(8)]
        rs, _ = run_threads(8, work)
        log = S.C["twin"].call("/log", {"n": 100000})["log"]
        late = [t - t_exp for t, frm, tg in log if tg == tag and t > t_exp]
        out.append(dict(round=k, requests=len(rs), forwarded_after_expiry=len(late), max_lateness_s=max(late) if late else 0.0, outcomes=outcomes(rs)))
        time.sleep(0.3)
    return dict(rounds=out, total_forwarded_after_expiry=sum(r["forwarded_after_expiry"] for r in out))


def scen_K(S):
    """Quarantine committed while other requests of the same subject are in flight (model M4g)."""
    bad = dict(temporal=40, spatial=30, behavioural=60, system=55, business=20, stepup_ok=False)
    res = []
    for k in range(3):
        sub = ["cam01", "eng01", "sup03"][k]
        src, dst = ("D", "M") if sub != "sup03" else ("S", "D")
        if sub == "sup03":
            S.C["seg"].call("/create", {"id": "s-sup", "flows": [["S", "D"]], "principals": ["sup03"], "purpose": "x", "ttl_s": 600})
        if sub == "eng01":
            pass
        tag = f"q{k}"; qt = {"t": None}; stop = {"x": False}
        def attacker():
            cl = Z.Client(Z.PORTS["pep"])
            for _ in range(40):
                r = req(cl, S.tk, sub, src, dst, ctx=bad)
                if r.get("reason") == "quarantined":
                    qt["t"] = r["t_done"]; break
                time.sleep(0.02)
            stop["x"] = True
        def benign(cl):
            out = []
            while not stop["x"]:
                out.append(req(cl, S.tk, sub, src, dst, _test_delay_s=0.05, tag=tag))
            return out
        th = threading.Thread(target=attacker); th.start()
        rs, _ = run_threads(6, [[benign] for _ in range(6)]); th.join()
        rs = [x for r in rs for x in r]
        log = S.C["twin"].call("/log", {"n": 100000})["log"]
        late = [t - qt["t"] for t, frm, tg in log if tg == tag and qt["t"] and t > qt["t"]] if qt["t"] else []
        res.append(dict(subject=sub, quarantined=qt["t"] is not None, benign_requests=len(rs), forwarded_after_quarantine_observed=len(late),
                        max_lateness_s=max(late) if late else 0.0, outcomes=outcomes(rs)))
    return dict(rounds=res, total_forwarded_after_quarantine=sum(r["forwarded_after_quarantine_observed"] for r in res))


def scen_L(S):
    """v5: decision-audit consistency under concurrent mixed load (8 threads x 40 requests, unique tags).
    Checks: every forwarded request (twin log) had an 'allow' response; every response has exactly one audit
    record with the same decision (if the PEP keeps per-request decision records)."""
    hi = dict(temporal=40, spatial=30, behavioural=75, system=70, business=20)       # block tier -> deny
    kinds = [("cam01", "D", "M", None), ("plc07", "O", "O", None), ("eng01", "O", "O", None), ("sup03", "S", "D", None), ("cam01", "D", "M", hi)]
    work = []
    for i in range(8):
        jobs = []
        for j in range(40):
            p, a, b, ctx = kinds[(i + j) % len(kinds)]; tag = f"L{i}-{j}"
            jobs.append((lambda cl, p=p, a=a, b=b, ctx=ctx, tag=tag: dict(req(cl, S.tk, p, a, b, ctx=ctx, tag=tag), tag=tag)))
        work.append(jobs)
    rs, dur = run_threads(8, work)
    time.sleep(0.3)
    tw = {tg for _, _, tg in S.C["twin"].call("/log", {"n": 100000})["log"] if tg and tg.startswith("L")}
    ev = S.C["pep"].call("/events", {"n": 100000})["events"]
    dec = [e for e in ev if e.get("kind") == "decision" and str(e.get("tag", "")).startswith("L")]
    by_tag = {}
    for e in dec: by_tag.setdefault(e["tag"], []).append(e["decision"])
    allowed = {r["tag"] for r in rs if r["decision"] == "allow"}
    resp = {r["tag"]: r["decision"] for r in rs}
    return dict(requests=len(rs), outcomes=outcomes(rs), allowed=len(allowed), forwarded=len(tw),
                forwarded_without_allow=len(tw - allowed), allowed_not_forwarded=len(allowed - tw),
                deny_events_total=sum(1 for e in ev if e.get("kind") == "deny"),
                decision_records=len(dec), requests_without_record=sum(1 for t in resp if t not in by_tag),
                duplicate_records=sum(1 for v in by_tag.values() if len(v) > 1),
                record_decision_mismatch=sum(1 for t, d in resp.items() if t in by_tag and by_tag[t][0] != d))


def scen_M(S):
    """v5: stale context. Same request with a fresh timestamp, a 60-s-old timestamp and no timestamp."""
    pc = Z.Client(Z.PORTS["pep"]); out = {}
    for name, extra in [("fresh_ts", {"ts": time.time()}), ("stale_60s", {"ts": time.time() - 60}), ("no_ts", {})]:
        ctx = dict(CTX, **extra); ctx["stepup_ok"] = False        # step-up would fail: a step-up demand becomes a deny
        r = req(pc, S.tk, "eng01", "D", "M", ctx=ctx); out[name] = dict(decision=r["decision"], reason=r.get("reason"), risk=r.get("risk"))
    return out


def scen_N(S):
    """v5: downstream failure propagation. Twin stopped during a sequential load, then restarted."""
    pc = Z.Client(Z.PORTS["pep"]); phases = {}
    for ph in ("before", "twin_down", "after_restart"):
        if ph == "twin_down": S.stop("twin")
        if ph == "after_restart": S.start("twin"); time.sleep(1.0)
        rs = [req(pc, S.tk, "cam01", "D", "M", tag=f"N{ph}{i}") for i in range(20)]
        dn = [req(pc, S.tk, "eng01", "O", "O") for _ in range(5)]        # deny path (no segment) must stay responsive
        phases[ph] = dict(outcomes=outcomes(rs), max_latency_ms=max(r["client_us"] for r in rs) / 1e3,
                          deny_path=outcomes(dn), deny_path_max_ms=max(r["client_us"] for r in dn) / 1e3)
    return phases


SCEN = dict(L=scen_L, M=scen_M, N=scen_N, J=scen_J, K=scen_K, I=scen_I, A=scen_A, B=lambda S: scen_failure(S, "prov"), C=lambda S: dict(sequential=scen_failure(S, "pdp")),
            Cload=scen_C_under_load, D=lambda S: scen_failure(S, "seg"), E=scen_E, F=scen_F, G=scen_G, H=scen_H)

if __name__ == "__main__":
    sc, out = sys.argv[1], sys.argv[2]
    flags = {k: v for k, v in os.environ.items() if k.startswith("ZTAS_")}
    S = Stack()
    try:
        t0 = time.time(); res = SCEN[sc](S)
    finally:
        S.close()
    json.dump(dict(scenario=sc, flags=flags, started=time.strftime("%Y-%m-%d %H:%M:%S"), duration_s=time.time() - t0,
                   host=dict(cpus=os.cpu_count()), result=res), open(out, "w"), indent=1, default=str)
    print(sc, json.dumps(res, default=str)[:1500])
