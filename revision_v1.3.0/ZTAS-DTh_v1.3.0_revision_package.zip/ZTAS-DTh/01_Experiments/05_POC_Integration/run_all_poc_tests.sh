#!/bin/sh
# Runs every scenario in v3 configuration and the corresponding v2-behaviour controls. Localhost only.
# set -e removed: a hung control run must not stop later scenarios
cd "$(dirname "$0")"; mkdir -p raw
run() { name=$1; shift; sc=$1; shift; echo "== $name"; env "$@" timeout 900 python3 poc_failure_tests.py $sc raw/$name.json | cut -c1-600; }
run A_v3_window64 A ZTAS_REPLAY_W=64
run A_v3_window1024 A ZTAS_REPLAY_W=1024
run A_v2control A ZTAS_THREADLOCAL=0 ZTAS_REPLAY=strict   # note: FAILCLOSED left at 1, so shared-client errors surface as denials
run A_strict_replay_only A ZTAS_REPLAY=strict
run B_v3 B
run B_v2control B ZTAS_FAILCLOSED=0
run C_v3 C
run Cload_v3 Cload
run D_v3 D
run D_v2control D ZTAS_FAILCLOSED=0
run E_v3 E
run F_v3 F ZTAS_REPLAY_W=64
run F_v3_window1024 F ZTAS_REPLAY_W=1024
run F_v2control F ZTAS_REPLAY=strict ZTAS_THREADLOCAL=0   # hung for >8 min in our run; terminated manually
run G_v3 G
run G_noRevalidate G ZTAS_REVALIDATE=0
run H_v3 H
run H_v2control H ZTAS_PDP_PERSIST=0
run I_v3 I
run I_v2control I ZTAS_MISSING=zero
