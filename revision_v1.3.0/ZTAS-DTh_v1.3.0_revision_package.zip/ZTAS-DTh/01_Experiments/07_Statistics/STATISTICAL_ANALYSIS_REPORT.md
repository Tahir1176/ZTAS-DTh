# STATISTICAL_ANALYSIS_REPORT.md

> v4 report. Sections 'v4 additions' are new in this round; the v3 content below them is kept unchanged for traceability (original file `STATISTICAL_VALIDATION_REPORT.md` is also kept).

## v4 additions

**Ranking stability** (`ranking_stability.py`; `02_Data/Processed/statistics_ranking_stability.csv`; Supp. Table S12)
- ZTAS-DTh ranked first in 270/270 graphs.
- Kendall's W ranged from 0.95 to 1.00 per family.
- Modal ranking: ZTAS < ZT+prov < zones < ZT < perimeter.
- Sparse family: ZT and zones swap places (zones beat ZT in 50% of graphs). Zones beat ZT in 70–100% of graphs elsewhere; this follows from the assumed conduit parameters.
- The noisy and stealthy profiles give identical rankings because the baselines do not depend on the profile and ZTAS-DTh is always first.

**Paired evidence-policy contrasts**
- Graph-level paired bootstrap (4000 resamples), reported in the evidence report.

**Number check**
- `08_Final_Reports/number_check.py`: 182/182 (v3: 143/143).

---

## v3 content (unchanged)

# STATISTICAL_VALIDATION_REPORT.md — concern 8 (includes statistical_analysis_audit)

## 1. Audit of the v2 statistical analysis (statistical_analysis_audit)

| Item | v2 implementation | Assessment |
|---|---|---|
| Design | 9 topology families × 30 graphs × 50 runs; 2 attacker profiles; 5 architectures plus ablations | Adequate |
| Seeds | graph_seed = 10000·family + g; run_seed = 1 000 003·graph_seed + r; recorded per row | ✔ reproducible (Stage 9 re-run) |
| Pairing | Common random numbers: all architectures use the same draws per (graph, run) | ✔ exact pairing |
| Uncertainty | Two-stage hierarchical bootstrap (graphs, then runs within graphs), B = 2000 | ✔ Runs are not treated as independent graphs |
| Effect sizes | d_z at graph level; share of graphs favouring ZTAS-DTh | d_z is very large (−1.6 to −22) because between-graph SD is small. On its own it overstates practical importance, so v3 adds absolute and relative reductions and a practical-significance share |
| Aggregation | Mean over runs per graph, then over graphs | ✔ |
| Missing | Variance partition; graph-level ranges; explicit practical-significance criterion; topology-specific interpretation | Added in v3 |

## 2. Paired graph-level results (`statistics_paired_by_topology.csv`; target = ZTAS-DTh with the recommended evidence rule; stealthy attacker; compromised fraction)

| Topology | ZT+prov | ZTAS-DTh | Δ [95% CI] | Relative | Graph-level range of Δ | Graphs favouring | Graphs with Δ ≤ −0.05 | Between-graph share of variance |
|---|---|---|---|---|---|---|---|---|
| Reference | 0.492 | 0.138 | −0.353 [−0.388, −0.321] | −72% | −0.49 … −0.22 | 30/30 | 100% | 4.6% |
| Dense | 0.738 | 0.341 | −0.397 [−0.431, −0.363] | −54% | −0.52 … −0.20 | 30/30 | 100% | 3.4% |
| High interconnect | 0.591 | 0.203 | −0.388 [−0.420, −0.355] | −66% | −0.54 … −0.24 | 30/30 | 100% | 2.4% |
| Multi-supplier | 0.472 | 0.132 | −0.340 [−0.377, −0.303] | −72% | −0.50 … −0.12 | 30/30 | 100% | 5.2% |
| Feedback loop | 0.464 | 0.141 | −0.323 [−0.355, −0.290] | −70% | −0.46 … −0.15 | 30/30 | 100% | 4.1% |
| Shared repository | 0.327 | 0.116 | −0.211 [−0.243, −0.184] | −65% | −0.37 … −0.12 | 30/30 | 100% | 6.0% |
| Hub-and-spoke | 0.229 | 0.080 | −0.149 [−0.177, −0.124] | −65% | −0.34 … −0.07 | 30/30 | 100% | 8.2% |
| Multi-organisation | 0.130 | 0.057 | −0.072 [−0.088, −0.058] | −56% | −0.14 … −0.01 | 30/30 | **67%** | 4.6% |
| Sparse | 0.074 | 0.036 | −0.038 [−0.048, −0.029] | −52% | −0.11 … −0.01 | 30/30 | **20%** | 9.3% |

Against static ZT (stealthy), Δ ranges from −0.11 (sparse) to −0.78 (multi-organisation). Every CI excludes zero, and every graph favours ZTAS-DTh. Noisy-attacker results are in the CSV.

## 3. Interpretation

- **Statistical significance vs effect size vs practical significance.** Every CI excludes zero and every graph favours ZTAS-DTh, so under the default parameters the direction is unambiguous in every family. The absolute size is not:
  - In dense, interconnected, multi-supplier and reference threads, ZTAS-DTh removes 0.32–0.40 of the thread from compromise, that is 18–22 of 56 entities.
  - In multi-organisation and sparse threads it removes 0.04–0.07, about 2–4 entities.
  - Only 20% of sparse graphs and 67% of multi-organisation graphs reach the pre-declared practical threshold of 0.05.

  The relative reduction (51–72%) is similar across families. What differs is how much there is to protect: the baseline ZT+prov compromise is 0.07–0.74.
- **Graph-level variability is small compared with run-level variability.** Between-graph variance is 2–9% of the total variance of the per-run difference. Most variability comes from the entry point and the stochastic attack path within a graph. This is why graph-level d_z is so large, and why d_z is not used as the headline effect size.
- **Topology and mechanisms.**
  - *Provenance:* ZT+prov already performs well where organisational boundaries create many gate boundaries (multi-organisation 0.13) or where little propagates (sparse). Adding segments and the risk engine helps least there.
  - *Segmentation:* it has most leverage where many permanently open flows exist (dense, high-interconnect, reference).
  - *Propagation:* the more flows a thread has, the larger ZT+prov's residual compromise and the larger the absolute gain.

  These patterns agree with the joint-sensitivity analysis: the margin is smallest in the sparse family, and p_act is the most influential parameter.
- **Robustness.** Section 3 of `JOINT_SENSITIVITY_REPORT.md` shows that the direction holds in 96.7% of the joint parameter space. It is not universal: 1.2% of cells are worse by ≥ 0.01.
- **Model-dependent vs operational evidence.** All of the above is evidence about the simulator under assumed parameters. Statements such as "significantly improves industrial security" are not supported. The defensible statement is: *"under the simulated model and the stated parameter ranges, ZTAS-DTh had a lower compromised fraction than static ZT with provenance in every topology family; the absolute reduction ranged from 0.04 (sparse) to 0.40 (dense)."*

## 4. Figures
- `fig_graph_level_differences.pdf|png` shows every one of the 270 graph-level paired differences (grey) with the family mean and hierarchical-bootstrap CI (red), against static ZT and against ZT+provenance, with the 0.05 practical line. No graph-level outcome is hidden.
- `../joint_sensitivity/joint_sensitivity_figures/fig_joint_by_topology.pdf` shows the paired difference per topology in each regime.

## 5. Files
`statistical_analysis.py`, `statistical_analysis.ipynb`, `02_Data/processed/statistics_paired_by_topology.csv`, `statistics_graph_level_differences.csv`.
