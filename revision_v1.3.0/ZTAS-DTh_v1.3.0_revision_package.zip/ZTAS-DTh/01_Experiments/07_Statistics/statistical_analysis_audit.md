# statistical_analysis_audit.md (concern 8, Task 8.1)

Excerpt of `STATISTICAL_VALIDATION_REPORT.md`.

## 1. Audit of the v2 statistical analysis (statistical_analysis_audit)

| Item | v2 implementation | Assessment |
|---|---|---|
| Design | 9 topology families × 30 graphs × 50 runs; 2 attacker profiles; 5 architectures plus ablations | Adequate |
| Seeds | graph_seed = 10000·family + g; run_seed = 1 000 003·graph_seed + r; recorded per row | ✔ reproducible (Stage 9 re-run) |
| Pairing | Common random numbers: all architectures use the same draws per (graph, run) | ✔ exact pairing |
| Uncertainty | Two-stage hierarchical bootstrap (graphs, then runs within graphs), B = 2000 | ✔ Runs are not treated as independent graphs |
| Effect sizes | d_z at graph level; share of graphs favouring ZTAS-DTh | d_z is very large (−1.6 to −22) because between-graph SD is small. On its own it overstates practical importance, so v3 adds absolute and relative reductions and a practical-significance share |
| Aggregation | Mean over runs per graph, then over graphs | ✔ |
| Missing | Variance partition; graph-level ranges; explicit practical-significance criterion; topology-specific interpretation | Added in v3 |

