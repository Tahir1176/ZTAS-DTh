"""Ranking stability of the five architectures across graph instances (v4, concern 8 gap).
For every (topology, profile, graph) the five configurations are ranked by mean compromised fraction over 50 runs
(rank 1 = lowest). Reports the share of graphs in which each configuration holds each rank, Kendall's W
(concordance of rankings across graphs) per topology, and pairwise win shares. Input: v2 E1 raw data (unchanged)."""
import os
import numpy as np
import pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)); RAW = os.path.join(HERE, "..", "..", "02_Data", "Raw", "v2")
OUT = os.path.join(HERE, "..", "..", "02_Data", "Processed")
CF = ["perimeter", "zones", "zt", "zt_prov", "ztas_rec"]
df = pd.concat([pd.read_csv(os.path.join(RAW, "e1_main.csv")), pd.read_csv(os.path.join(RAW, "e1_main_rec.csv"))])
g = df[df.config.isin(CF)].groupby(["topology", "profile", "graph", "config"]).frac.mean().unstack("config")[CF]
rk = g.rank(axis=1, method="average")
rows = []
for (t, p), r in rk.groupby(level=[0, 1]):
    m, n = r.shape[0], r.shape[1]
    R = r.sum(axis=0); S = ((R - R.mean()) ** 2).sum(); W = 12 * S / (m ** 2 * (n ** 3 - n))
    gg = g.loc[(t, p)]
    row = dict(topology=t, profile=p, graphs=m, kendall_W=W, modal_ranking=" < ".join(r.mean().sort_values().index))
    for c in CF:
        row[f"rank1_{c}"] = float((r[c] == 1).mean())
    row["share_graphs_ztas_beats_ztprov"] = float((gg.ztas_rec < gg.zt_prov).mean())
    row["share_graphs_ztprov_beats_zt"] = float((gg.zt_prov < gg.zt).mean())
    row["share_graphs_zones_beats_zt"] = float((gg.zones < gg.zt).mean())
    rows.append(row)
R = pd.DataFrame(rows); R.to_csv(os.path.join(OUT, "statistics_ranking_stability.csv"), index=False)
pd.set_option("display.width", 250)
print(R[["topology", "profile", "kendall_W", "rank1_ztas_rec", "share_graphs_ztas_beats_ztprov", "share_graphs_zones_beats_zt", "modal_ranking"]].round(3).to_string())
