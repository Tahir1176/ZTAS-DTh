"""
Concern 8 (v5): effect sizes and multiplicity for the E1 graph-level paired differences (ZTAS-DTh minus baseline).
Experimental unit = graph instance (30 per topology family); runs within a graph are averaged first
(statistics_graph_level_differences.csv, unchanged). For each topology x profile x baseline:
  mean difference, graph-level SD, standardized paired effect d_z = mean/SD, share of graphs with |diff| >= 0.05,
  95% bootstrap CI and Bonferroni-adjusted simultaneous CI over the 9 families (alpha = 0.05/9 per family).
No p-values are computed (estimation framing). Usage: python3 effect_sizes_v5.py
"""
import os
import numpy as np
import pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, "..", "..")
d = pd.read_csv(os.path.join(ROOT, "02_Data", "Processed", "statistics_graph_level_differences.csv"))
rng = np.random.default_rng(8)
K = d.topology.nunique(); a_sim = 0.05 / K
rows = []
for (t, p, b), g in d.groupby(["topology", "profile", "baseline"]):
    x = g["diff"].to_numpy(); bs = np.array([rng.choice(x, len(x)).mean() for _ in range(10000)])
    rows.append(dict(topology=t, profile=p, baseline=b, n_graphs=len(x), mean_diff=x.mean(), sd_graph=x.std(ddof=1),
                     d_z=x.mean() / x.std(ddof=1) if x.std(ddof=1) > 0 else np.nan,
                     share_graphs_reduction_ge_005=(x <= -0.05).mean(), share_graphs_worse=(x > 0).mean(),
                     ci95_lo=np.percentile(bs, 2.5), ci95_hi=np.percentile(bs, 97.5),
                     ci_sim_lo=np.percentile(bs, 100 * a_sim / 2), ci_sim_hi=np.percentile(bs, 100 * (1 - a_sim / 2))))
r = pd.DataFrame(rows)
out = os.path.join(ROOT, "02_Data", "Processed", "statistics_effect_sizes_v5.csv"); r.to_csv(out, index=False)
s = r[r.baseline == "zt_prov"]
pd.set_option("display.width", 220)
print(s.round(3).to_string(index=False))
print("zt_prov: simultaneous CI excludes 0 in", int((s.ci_sim_hi < 0).sum()), "of", len(s), "family x profile cells")
print("zt_prov: simultaneous CI entirely below -0.05 in", int((s.ci_sim_hi < -0.05).sum()), "of", len(s))
print("d_z range (zt_prov):", s.d_z.min().round(2), s.d_z.max().round(2))
