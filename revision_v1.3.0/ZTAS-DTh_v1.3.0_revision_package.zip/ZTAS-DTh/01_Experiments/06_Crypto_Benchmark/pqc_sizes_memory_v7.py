"""
v7 (reviewer concern 10): key, ciphertext and signature sizes measured from the library objects actually used
(pqcrypto 1.0.0, cryptography for Ed25519), peak resident memory of a process performing each operation
(ru_maxrss, Linux, KiB; includes the Python interpreter and library, so it is an upper bound for the operation
and not a gateway figure), and the per-record communication overhead of per-record vs Merkle-batched ML-DSA-65
signatures, derived analytically from the measured sizes (32-byte SHA-256 hashes).
Server VM only; no gateway or HSM measurement. Usage: python3 pqc_sizes_memory_v7.py OUT_DIR
"""
import os, sys, json, math, subprocess, platform
import pandas as pd
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "02_Data", "Processed", "crypto_v7")
os.makedirs(OUT, exist_ok=True)
CHILD = r'''
import sys, resource, os
op = sys.argv[1]
from pqcrypto.sign import ml_dsa_44, ml_dsa_65, ml_dsa_87
from pqcrypto.kem import ml_kem_512, ml_kem_768, ml_kem_1024
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
base = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
msg = b"x" * 256
mods = dict(ml_dsa_44=ml_dsa_44, ml_dsa_65=ml_dsa_65, ml_dsa_87=ml_dsa_87, ml_kem_512=ml_kem_512, ml_kem_768=ml_kem_768, ml_kem_1024=ml_kem_1024)
if op == "baseline": pass
elif op.startswith("ml_dsa"):
    m = mods[op]; pk, sk = m.generate_keypair() if hasattr(m, "generate_keypair") else m.keygen()
    for _ in range(200): s = m.sign(sk, msg); m.verify(pk, msg, s)
elif op.startswith("ml_kem"):
    m = mods[op]; pk, sk = m.generate_keypair() if hasattr(m, "generate_keypair") else m.keygen()
    for _ in range(200): ct, ss = m.encaps(pk); m.decaps(sk, ct)
elif op == "ed25519":
    k = Ed25519PrivateKey.generate(); p = k.public_key()
    for _ in range(200): s = k.sign(msg); p.verify(s, msg)
print(base, resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
'''
def sizes():
    from pqcrypto.sign import ml_dsa_44, ml_dsa_65, ml_dsa_87
    from pqcrypto.kem import ml_kem_512, ml_kem_768, ml_kem_1024
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives import serialization as se
    rows = []; msg = b"x" * 256
    for n, m in [("ML-DSA-44", ml_dsa_44), ("ML-DSA-65", ml_dsa_65), ("ML-DSA-87", ml_dsa_87)]:
        pk, sk = m.generate_keypair() if hasattr(m, "generate_keypair") else m.keygen(); s = m.sign(sk, msg)
        rows.append(dict(algorithm=n, kind="signature", public_key=len(pk), secret_key=len(sk), signature_or_ciphertext=len(s)))
    for n, m in [("ML-KEM-512", ml_kem_512), ("ML-KEM-768", ml_kem_768), ("ML-KEM-1024", ml_kem_1024)]:
        pk, sk = m.generate_keypair() if hasattr(m, "generate_keypair") else m.keygen(); ct, ss = m.encaps(pk)
        rows.append(dict(algorithm=n, kind="KEM", public_key=len(pk), secret_key=len(sk), signature_or_ciphertext=len(ct)))
    k = Ed25519PrivateKey.generate()
    rows.append(dict(algorithm="Ed25519", kind="signature", public_key=len(k.public_key().public_bytes(se.Encoding.Raw, se.PublicFormat.Raw)),
                     secret_key=len(k.private_bytes(se.Encoding.Raw, se.PrivateFormat.Raw, se.NoEncryption())), signature_or_ciphertext=len(k.sign(msg))))
    return pd.DataFrame(rows)
S = sizes(); mem = []
for op in ["baseline", "ed25519", "ml_dsa_44", "ml_dsa_65", "ml_dsa_87", "ml_kem_512", "ml_kem_768", "ml_kem_1024"]:
    vals = []
    for rep in range(5):
        o = subprocess.run([sys.executable, "-c", CHILD, op], capture_output=True, text=True, check=True).stdout.split()
        vals.append(int(o[1]))
    mem.append(dict(operation=op, peak_rss_kib_median=sorted(vals)[2], peak_rss_kib_min=min(vals), peak_rss_kib_max=max(vals)))
M = pd.DataFrame(mem); b = M.set_index("operation").peak_rss_kib_median["baseline"]; M["delta_vs_baseline_kib"] = M.peak_rss_kib_median - b
sig = int(S.set_index("algorithm").signature_or_ciphertext["ML-DSA-65"]); H = 32
C = []
for B in [1, 8, 64, 256, 1024, 4096]:
    proof = H * math.ceil(math.log2(B)) if B > 1 else 0
    C.append(dict(batch_size=B, per_record_signature_share_bytes=sig / B, inclusion_proof_bytes=proof, per_record_total_bytes=sig / B + proof,
                  per_record_signing_bytes_unbatched=sig))
S.to_csv(os.path.join(OUT, "pqc_sizes.csv"), index=False); M.to_csv(os.path.join(OUT, "pqc_memory.csv"), index=False); pd.DataFrame(C).to_csv(os.path.join(OUT, "provenance_overhead.csv"), index=False)
import pqcrypto, cryptography
env = dict(python=platform.python_version(), machine=platform.machine(), processor=platform.processor(), kernel=platform.release(),
           pqcrypto="1.0.0 (pip show)", cryptography=cryptography.__version__)
json.dump(env, open(os.path.join(OUT, "environment.json"), "w"), indent=1)
print(S.to_string()); print(M.to_string()); print(pd.DataFrame(C).to_string()); print(env)
