"""
Cryptographic benchmark re-analysis and queueing re-analysis (revision v3, concern 6).
(1) Re-computes summary statistics from the RAW v2 samples (e3_crypto_samples.npz): median with bootstrap 95% CI,
    mean, p95, p99, IQR, coefficient of variation, Tukey far-outliers (> Q3 + 3 IQR), throughput (ops/s on one core).
(2) Discrete-event queueing model of the batch signer with alternatives to v2's assumptions:
    arrivals Poisson | bursty MMPP (10x rate for 10% of time, same mean) | clustered (bursts of 50 records);
    service deterministic (v2 fit t(B)=a+bB) | EMPIRICAL (resampled raw ML-DSA-65 batch-sign samples + tree cost).
    Single FIFO signer, size- and timeout-based batch closure. Network, ledger, HSM latency NOT included.
This is a model driven by server-CPU measurements, not a measurement of industrial latency.
Usage: python3 crypto_reanalysis.py V2_RAW_DIR OUT_DIR
"""
import sys, os, json
import numpy as np
import pandas as pd

rng = np.random.default_rng(20261119)


def boot_median(x, B=2000):
    idx = rng.integers(len(x), size=(B, len(x)))
    return np.percentile(np.median(x[idx], axis=1), [2.5, 97.5])


def summarise(S):
    rows = []
    for k in S.files:
        x = S[k].astype(float); q1, q3 = np.percentile(x, [25, 75]); lo, hi = boot_median(x)
        far = (x > q3 + 3 * (q3 - q1)).sum()
        rows.append(dict(op=k, n=len(x), median_us=np.median(x), median_ci_lo=lo, median_ci_hi=hi, mean_us=x.mean(),
                         p95_us=np.percentile(x, 95), p99_us=np.percentile(x, 99), max_us=x.max(), iqr_us=q3 - q1,
                         cv=x.std(ddof=1) / x.mean(), far_outliers=int(far), ops_per_s_one_core=1e6 / np.median(x)))
    return pd.DataFrame(rows)


def arrivals(kind, lam, horizon):
    if kind == "poisson":
        return np.cumsum(rng.exponential(1 / lam, int(lam * horizon * 1.05) + 10))
    if kind == "mmpp":       # 2-state: high = 10x base for 10% of time; mean rate lam -> base = lam / 1.9
        base = lam / 1.9; t, out, high = 0.0, [], False
        while t < horizon:
            dur = rng.exponential(1.0 if high else 9.0)          # mean high 1 s, mean low 9 s
            r = base * (10 if high else 1); n = rng.poisson(r * dur)
            out.append(t + np.sort(rng.random(n)) * dur); t += dur; high = not high
        return np.concatenate(out)
    # clustered: bursts of 50 records within 5 ms, burst starts Poisson with rate lam/50
    starts = np.cumsum(rng.exponential(50 / lam, int(lam * horizon / 50 * 1.05) + 2))
    return np.sort((starts[:, None] + rng.random((len(starts), 50)) * 0.005).ravel())


def service(size, mode, a, b, emp_sign, tree_per_rec):
    if mode == "deterministic":
        return (a + b * size) / 1e6
    return (rng.choice(emp_sign) + tree_per_rec * size) / 1e6


def run(kind, lam, Bt, tau, mode, a, b, emp, tpr, ver_us, horizon):
    arr = arrivals(kind, lam, horizon); arr = arr[arr < horizon]; n = len(arr)
    lat = np.empty(n); free = 0.0; busy = 0.0; i = 0; nb = 0; nto = 0; qmax = 0.0
    while i < n:
        deadline = arr[i] + tau
        end = min(i + Bt, np.searchsorted(arr, deadline, side="right"), n)
        end = max(end, i + 1)
        if end - i < Bt and end < n: close = deadline; nto += 1
        else: close = arr[end - 1]
        svc = service(end - i, mode, a, b, emp, tpr)
        st = max(close, free); qmax = max(qmax, st - close); fin = st + svc; free = fin; busy += svc
        lat[i:end] = fin - arr[i:end] + ver_us / 1e6; nb += 1; i = end
    span = max(arr[-1], free) - arr[0]
    # stability heuristic: backlog at the end of the horizon relative to the horizon
    return dict(arrivals=kind, rate=lam, batch=Bt, timeout_ms=tau * 1e3, service=mode, n_records=n,
                utilisation=busy / span, mean_batch=n / nb, frac_timeout=nto / nb,
                p50_ms=np.median(lat) * 1e3, p95_ms=np.percentile(lat, 95) * 1e3, p99_ms=np.percentile(lat, 99) * 1e3,
                max_ms=lat.max() * 1e3, max_queue_wait_ms=qmax * 1e3, final_backlog_s=max(0.0, free - horizon),
                stable=bool(busy / span < 0.95 and free - horizon < 1.0))


def main(raw, out):
    os.makedirs(out, exist_ok=True)
    S = np.load(os.path.join(raw, "e3_crypto_samples.npz"))
    summ = summarise(S); summ.to_csv(os.path.join(out, "crypto_summary_recomputed.csv"), index=False)
    R = json.load(open(os.path.join(raw, "e3_crypto_v2.json")))
    B = np.array([m["batch"] for m in R["merkle"]], float)
    t = np.array([m["build_and_sign"]["median_us"] for m in R["merkle"]], float)
    b, a = np.polyfit(B, t, 1)
    ver = float(np.median([m["verify_per_record_us_independent"] for m in R["merkle"]]))
    emp = S["ML-DSA-65_sign"].astype(float)                     # header signing dominates; empirical spread
    tpr = float(np.median(S["merkle_tree_4096"]) / 4096)      # tree build cost per record
    rows = []
    for kind in ["poisson", "mmpp", "clustered"]:
        for lam in [1, 10, 100, 1000, 5000, 10000]:
            for Bt in [1, 16, 64, 256, 1024]:
                for tau in [0.01, 0.1, 1.0]:
                    for mode in ["deterministic", "empirical"]:
                        h = 600.0 if lam <= 10 else (60.0 if lam <= 1000 else 20.0)
                        rows.append(run(kind, lam, Bt, tau, mode, a, b, emp, tpr, ver, h))
    q = pd.DataFrame(rows); q["fit_a_us"] = a; q["fit_b_us"] = b
    q.to_csv(os.path.join(out, "queueing_reanalysis.csv"), index=False)
    json.dump(dict(fit_a_us=a, fit_b_us_per_record=b, verify_us=ver, tree_us_per_record=tpr), open(os.path.join(out, "queue_fit.json"), "w"), indent=1)
    pd.set_option("display.width", 220)
    print(summ[summ.op.isin(["ed_sign", "ed_ver", "ML-DSA-65_sign", "ML-DSA-65_ver", "ML-DSA-87_sign", "kem_enc", "kem_dec",
                             "merkle_sign_1", "merkle_sign_1024", "batch_sig_ver_64"])].round(2).to_string())
    sel = q[(q.timeout_ms == 100) & (q.batch.isin([1, 64, 256])) & (q.rate.isin([10, 1000, 10000]))]
    print(sel[["arrivals", "rate", "batch", "service", "utilisation", "p50_ms", "p99_ms", "max_ms", "stable"]].round(2).to_string())


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
