# CRYPTO_BENCHMARK_AND_DEPLOYMENT_REPORT.md

> v4 report. Sections 'v4 additions' are new in this round; the v3 content below them is kept unchanged for traceability (original file `CRYPTOGRAPHIC_BENCHMARK_REPORT.md` is also kept).

## v4 additions

- **No new measurements in v4.** No gateway, ARM or HSM hardware is available.
- **Deployment context.** The comparison uses the published ML-DSA-65 timings of QZT-ICS (liboqs 0.10.0: Xeon Silver 4314 0.077 ms, Cortex-A55 0.51 ms, Cortex-M33 142.7 ms). The context was condensed into the Discussion subsection "Gateways, HSMs and cost".
- **Figure moved.** The batching and queueing figure moved to the supplement (Fig. S6) to shorten the main text. Table IX is still in the main text.

---

## v3 content (unchanged)

# CRYPTOGRAPHIC_BENCHMARK_REPORT.md — concern 6 (benchmark audit, statistics, queueing, deployment)

This file holds both the audit (`cryptographic_benchmark_audit.md` content) and the report.
**Scope.** The results are server-CPU micro-benchmarks and a model built on them. They are not gateway, HSM or industrial measurements.

## 1. Audit of the benchmark implementation (`src/bench_crypto_v2.py`)

| Item | Finding |
|---|---|
| Source | `bench_crypto_v2.py` (v2). Each timed call uses `time.perf_counter_ns`, preceded by 50 warm-up calls. All samples are saved to `e3_crypto_samples.npz`, and no outliers are removed. |
| Repetitions | 5000 for classical operations; 2000 for ML-DSA-44/65 sign and verify; 1000 for ML-DSA-87; 100 for SLH-DSA; 200 (40 for B ≥ 1024) for Merkle build-and-sign; 2000 for proofs. |
| Randomness | A fresh message for each signature. ML-DSA signing is randomized: it uses rejection sampling, so the running time varies. |
| Hardware | Intel Xeon @ 2.10 GHz, 2 vCPU (KVM), single-threaded timing. The CPU advertises `avx2`, `avx512f`, `aes` and `sha_ni`. |
| OS / runtime | Linux; Python 3.13.18; `cryptography` 50.0.1 linked against OpenSSL 4.0.2 (for Ed25519, ECDSA P-256 and X25519). |
| PQ library | `pqcrypto` 1.0.0 (Backbone Technologies; Apache-2.0). It is a manylinux_2_34 wheel built with maturin 1.14.1 and rustc 1.97.1, linked with LLD 22.1.6; the C parts were built with GCC 14.2.1. |
| ML-DSA implementation | Rust crate `backbone-ml-dsa` 0.2.0, using its software backend (`src/backends/soft.rs`; the path string is embedded in the binary). **Correction to v2:** v2 described the library only by the absence of AVX2 symbols. The binary is stripped, so the absence of symbols proves nothing. |
| AVX2 check (v3) | Disassembly (`objdump -d`) finds **182 instructions on 256-bit `%ymm` registers**, mostly vmovdqa/u, vpaddq, vpshufb, vextracti128, vpalignr and vpsrlq/vpsllq, and **11 `cpuid` instructions**. That pattern means the binary contains a small amount of AVX2 code selected at run time, which is consistent with a SIMD SHA-2 message schedule. Because the binary is stripped, we could not tell which primitive uses it. The large ML-DSA polynomial arithmetic is the portable software backend: with only 182 ymm instructions there is no AVX2 NTT. **Corrected statement:** "ML-DSA arithmetic runs in a portable software backend. The library contains a small amount of runtime-dispatched AVX2 code (probably hashing). We did not measure performance with AVX2 disabled." |
| Not done | No measurement with CPU features masked (no emulator available). No ARM or gateway measurement. No HSM. |
| Batch implementation | The Merkle tree uses odd-node promotion. The header binds the leaf count, gateway and first sequence number, and it is signed with ML-DSA-65. Build-and-sign is timed as one unit. |
| Queueing model (v2) | One FIFO signer; t(B) = a + b·B fitted to **medians** (a = 9588 µs, b = 0.75 µs per record); Poisson arrivals; batches close on size or timeout. Verification adds 186 µs per record. |

## 2. Re-analysis of the raw samples (`02_Data/processed/crypto/crypto_summary_recomputed.csv`)

The medians were recomputed from the raw samples, with 2000 bootstrap resamples of the median for the 95% CI.

| Operation | n | Median µs [95% CI] | Mean | p95 | p99 | Far outliers (> Q3 + 3 IQR) | ops/s, one core |
|---|---|---|---|---|---|---|---|
| Ed25519 sign | 5000 | 32.3 [32.2, 32.3] | 36.2 | 49.9 | 67.4 | 91 | 31 000 |
| Ed25519 verify | 5000 | 116.2 [115.3, 117.1] | 120.8 | 155.3 | 180.1 | 23 | 8 600 |
| ML-DSA-65 sign | 2000 | 9348 [9217, 9488] | 10 449 | 14 904 | 16 300 | 0 | 107 |
| ML-DSA-65 verify | 2000 | 180.4 [179.6, 181.3] | 195.8 | 274.0 | 314.1 | 111 | 5 540 |
| ML-DSA-87 sign | 1000 | 13 775 [13 446, 14 106] | 15 028 | 21 265 | 23 467 | 0 | 73 |
| ML-KEM-768 encaps | 5000 | 68.6 [68.0, 69.4] | 76.0 | 102.5 | 116.2 | 2 | 14 600 |
| Merkle build+sign, B = 1 | 200 | 10 136 [9 432, 10 690] | 11 078 | 15 891 | 19 736 | 1 | 99 |
| Merkle build+sign, B = 1024 | 40 | 10 583 [10 385, 11 441] | 11 849 | 17 172 | 17 924 | 2 | 95 (≈ 97 000 records/s) |

**Check against the manuscript.** All medians quoted in v2 match the raw data: ML-DSA-65 verify 180 µs, sign 9.3 ms, Ed25519 verify 116 µs, per-record signing 10.1 ms at B = 1 and about 10 µs at B = 1024.

**New observation.** ML-DSA signing has a heavy right tail from rejection sampling: the mean is 12% above the median and p99 is 1.7× the median. v2 fitted its queueing model to medians, which understates the **mean** service time, and the mean is what decides queue stability. With the empirical service times, per-record signing (B = 1) is already unstable at 100 records/s. The deterministic median model calls it stable at that rate, where utilisation is about 0.96. The v2 sentence "saturates one core above about 100 records/s" should read "at or below about 100 records/s".

## 3. Queueing re-analysis (`queueing_reanalysis.csv`; 540 configurations)

What was varied:
- **Arrivals:** Poisson; bursty MMPP (10× the base rate for 10% of the time, same mean); clustered (bursts of 50 records within 5 ms).
- **Rate:** 1–10 000 records/s.
- **Batch size:** B ∈ {1, 16, 64, 256, 1024}.
- **Timeout:** τ ∈ {10, 100, 1000} ms.
- **Service time:** deterministic (the v2 fit) or empirical (raw ML-DSA-65 signing samples plus measured tree cost).

**Highest stable rate tested, τ = 100 ms** (stable = utilisation < 0.95 and backlog < 1 s at the horizon):

| Arrivals | B = 1 | B = 16 | B = 64 | B = 256 |
|---|---|---|---|---|
| Poisson (deterministic / empirical) | 100 / **10** | 1000 / 1000 | 5000 / 5000 | 10 000 / 10 000 |
| MMPP | 100 / **10** | 100 / 100 | 5000 / 10 000\* | 10 000 / 10 000 |
| Clustered | 10 / 10 | 1000 / 1000 | 5000 / 5000 | 10 000 / 10 000 |

\*At 10 000/s, B = 64 sits at the edge of saturation (utilisation 0.86–0.95). There the verdict flips with the service-time assumption, so treat it as unstable.

**p99 latency, B = 256, τ = 100 ms, empirical service:**
- At 1–1000 records/s the timeout dominates: about 111–116 ms under all three arrival processes.
- At 10 000/s: Poisson 39 ms, clustered 56 ms, **MMPP 1627 ms**.

Bursts that briefly exceed signer capacity raise the p99 by a factor of 40. Under Poisson arrivals the same configuration looks comfortable, so a Poisson assumption alone is optimistic for bursty industrial traffic (shift changes, batch uploads, reconnection after an outage).

**Low rate.** At 10 records/s with τ = 10 ms the p99 is about 25–27 ms for B ≥ 16. B = 1 with clustered arrivals has a p99 of about 1.0 s, because a burst of 50 records queues behind 50 sequential signatures.

**What the model leaves out:** network, ledger anchoring, HSM latency, multi-core signers, gateway CPUs, and correlation between arrivals and service times. These are modelled latencies, not measured industrial ones.

## 4. Deployment discussion (input to manuscript §VIII)

- **Edge gateways.** Server-core results cannot be carried over to gateways. A Cortex-A class gateway is expected to sign several times slower, but we have not measured this. Batching, which spreads one signature over B records, is what makes PQ signing feasible at all. The critical parameter is the mean (not median) signing time on the target CPU, and it must be measured before choosing B and τ.
- **HSMs.** None was used. HSM signing adds a device round trip and limits throughput; ML-DSA support in HSM firmware varies between products. Batching reduces the number of HSM calls by a factor of B.
- **Hardware acceleration.** The ML-DSA arithmetic we measured runs in a portable software backend. Vectorised (AVX2/NEON) implementations would change the absolute numbers but not the batching argument.
- **Key rotation and revocation.** Gateway keys are bound to epochs, and the PoC enforces revocation within the CRL refresh bound (1 s, Scenario E). After a key compromise, every header signed under that epoch after the compromise time must be distrusted. Only headers anchored with a trusted timestamp before the compromise stay valid (Proposition 3).
- **Ledger availability and network interruption.** Gateways keep signing and buffer anchors during an outage. Verifiers accept unanchored records only for low-risk flows. The queueing model shows that reconnection bursts are the worst case: they behave like the MMPP arrivals.
- **Archival verification and migration.** Records must remain verifiable for the asset's lifetime. This requires periodic re-signing or anchoring under new algorithms and hybrid (classical + PQ) signatures during migration. None of this was evaluated here.
- **Needs industrial testing:** signing on gateway CPUs and HSMs (mean and tail), ledger anchoring latency, burst profiles in real plant traffic, and the operational cost of key rotation.

## 5. Re-run of the benchmark (Stage 9)
The archived benchmark script from a clean checkout of v1.0.0 was run twice: once while other work ran on the second vCPU, and once on an otherwise idle VM. Across all 57 timed operations the medians were **0.74–2.41 ×** the archived values (median ratio 1.04–1.11). See `01_Experiments/reproducibility/crypto_benchmark_rerun_comparison.csv`.

| Operation | Archived median | Re-run (other load) | Re-run (idle) |
|---|---|---|---|
| ML-DSA-65 sign | 9.35 ms | 9.09 ms | 13.74 ms |
| ML-DSA-65 verify | 180 µs | 435 µs | 315 µs |

**Consequence.** Absolute costs on this shared VM are indicative only, within about a factor of two. Only the qualitative conclusions are robust: verify ≪ sign, batching amortisation, and a per-record signing cap of about 70–110 records/s per core. The manuscript states this. Statistics on gateway-class hardware would need repeated runs on dedicated machines.
