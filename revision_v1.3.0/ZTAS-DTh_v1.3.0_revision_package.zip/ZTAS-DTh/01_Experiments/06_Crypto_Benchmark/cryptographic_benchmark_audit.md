# cryptographic_benchmark_audit.md (concern 6, Task 6.1)

Excerpt of `CRYPTOGRAPHIC_BENCHMARK_REPORT.md`.

## 1. Audit of the benchmark implementation (`src/bench_crypto_v2.py`)

| Item | Finding |
|---|---|
| Source | `bench_crypto_v2.py` (v2). Each timed call uses `time.perf_counter_ns`, preceded by 50 warm-up calls. All samples are saved to `e3_crypto_samples.npz`, and no outliers are removed. |
| Repetitions | 5000 for classical operations; 2000 for ML-DSA-44/65 sign and verify; 1000 for ML-DSA-87; 100 for SLH-DSA; 200 (40 for B ≥ 1024) for Merkle build-and-sign; 2000 for proofs. |
| Randomness | A fresh message for each signature. ML-DSA signing is randomized: it uses rejection sampling, so the running time varies. |
| Hardware | Intel Xeon @ 2.10 GHz, 2 vCPU (KVM), single-threaded timing. The CPU advertises `avx2`, `avx512f`, `aes` and `sha_ni`. |
| OS / runtime | Linux; Python 3.13.18; `cryptography` 50.0.1 linked against OpenSSL 4.0.2 (for Ed25519, ECDSA P-256 and X25519). |
| PQ library | `pqcrypto` 1.0.0 (Backbone Technologies; Apache-2.0). It is a manylinux_2_34 wheel built with maturin 1.14.1 and rustc 1.97.1, linked with LLD 22.1.6; the C parts were built with GCC 14.2.1. |
| ML-DSA implementation | Rust crate `backbone-ml-dsa` 0.2.0, using its software backend (`src/backends/soft.rs`; the path string is embedded in the binary). **Correction to v2:** v2 described the library only by the absence of AVX2 symbols. The binary is stripped, so the absence of symbols proves nothing. |
| AVX2 check (v3) | Disassembly (`objdump -d`) finds **182 instructions on 256-bit `%ymm` registers**, mostly vmovdqa/u, vpaddq, vpshufb, vextracti128, vpalignr and vpsrlq/vpsllq, and **11 `cpuid` instructions**. That pattern means the binary contains a small amount of AVX2 code selected at run time, which is consistent with a SIMD SHA-2 message schedule. Because the binary is stripped, we could not tell which primitive uses it. The large ML-DSA polynomial arithmetic is the portable software backend: with only 182 ymm instructions there is no AVX2 NTT. **Corrected statement:** "ML-DSA arithmetic runs in a portable software backend. The library contains a small amount of runtime-dispatched AVX2 code (probably hashing). We did not measure performance with AVX2 disabled." |
| Not done | No measurement with CPU features masked (no emulator available). No ARM or gateway measurement. No HSM. |
| Batch implementation | The Merkle tree uses odd-node promotion. The header binds the leaf count, gateway and first sequence number, and it is signed with ML-DSA-65. Build-and-sign is timed as one unit. |
| Queueing model (v2) | One FIFO signer; t(B) = a + b·B fitted to **medians** (a = 9588 µs, b = 0.75 µs per record); Poisson arrivals; batches close on size or timeout. Verification adds 186 µs per record. |

