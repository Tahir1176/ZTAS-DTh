# PROJECT_AUDIT_REPORT.md — audit before the v4 revision round (20 Nov 2026)

## 1. Environment
- **Machine:** 2 vCPU, 7 GB RAM, 30 GB free disk, no GPU (none needed: all workloads are CPU-bound Python).
- **Software:** Python 3.13.18 with numpy, scipy, pandas, scikit-learn, SALib, networkx, matplotlib, nbconvert, cryptography 50.0.1 and pqcrypto 1.0.0. All are already installed, so nothing was reinstalled.

## 2. What exists (inventory)

| Item | Location | State |
|---|---|---|
| Original thesis and v1 paper | `../thesis`, `../paper`, `src/` lineage, `06_Manuscript/v2_baseline` | Preserved, unchanged |
| v2 package (first major revision) | `../ZTAS_DTh_MAJOR_REVISION` | Preserved, unchanged |
| v3 package (second major revision) | `../ZTAS_DTh_Major_Revision_Research` | **Frozen.** It is byte-identical to the archived release v1.1.0 (Zenodo doi:10.5281/zenodo.24379544) |
| v4 workspace (this round) | `ZTAS_DTh_Major_Revision_Research_v4/` | A copy of v3, restructured to the folder layout requested in this round. All paths in the scripts were updated, and 143/143 manuscript numbers re-check against the outputs after the move |
| Public repository | github.com/Tahir1176/ZTAS-DTh (v1.0.0, v1.1.0) | Verified |
| Simulator | `src/dth_sim.py`, `topologies.py` | 9 topology families; 5 architectures plus ablations |
| Risk engine | E2 `src/risk_engine_eval.py`; v3 extension `01_Experiments/02_Risk_Engine` | Synthetic distributions only |
| Evidence study | `01_Experiments/03_Evidence_Accumulation` | Continuous time, 7 profiles × 4 rates × 5 policies |
| Formal | `src/formal/model_check.py` (M1–M3), `model_check_v3.py` (M4a–e), `ProvenanceGate.tla` | Python bounded checker; TLA+ **never executed**; **no Alloy model exists** |
| PoC | `src/poc/ztas_poc.py` (v2), `ztas_poc_v3.py` | Six localhost services; tests T-A to T-I |
| Crypto | `src/bench_crypto_v2.py`, raw samples, `01_Experiments/06_Crypto_Benchmark` | Server VM only |
| Manuscript | `06_Manuscript/v3/main.tex` (18 pp.), `supplement.tex` (14 pp.) | Current title differs from the title in this round's prompt (see §5) |

## 3. The ten concerns against existing evidence: gap analysis

The ten concerns in this round are the same ten addressed in the v3 round. The items below are the **requirements of this round that v3 did not fully meet**; only these will be executed. Everything else is re-verified, not re-run.

| ID | Already evidenced in v3 | Genuine gap in v3 (to execute now) |
|---|---|---|
| C1 | Parameter audit; LHS + regimes + Sobol over 11 parameters; 5 architectures; topology dependence; ranking | (a) **Legitimate requests affected** are not measured in the joint study. (b) The parameter audit lacks the "justification" and "recommended range" columns. (c) "Compromised segments" is proxied only by the number of phases (needs stating) |
| C2 | Audit; operational specification; protocol; 6 distributions; prevalence 0.1–20%; calibration transfer; cost thresholds | (a) **Noisy telemetry**, (b) **missing telemetry** (imputation strategies), (c) **attack-intensity sweep** were not evaluated. (d) The specification does not separate theoretical signals from signals implemented in the prototype |
| C3 | Time-based study; 7 profiles; 5 policies, including criticality-aware | (a) **Threshold sensitivity** (κ sweep) in time; (b) **approval-delay sensitivity**; (c) **emergency / safety-aware** policy with a safe-state option; (d) **risk/propagation-aware** threshold |
| C4 | M1–M4 (28 checks, negative controls); boundary diagram; property map | (a) **Segment expiry** and **quarantine** races are not modelled. (b) The property map lacks "bound" and "limitation" columns. (c) Alloy is absent and must be stated, not claimed |
| C5 | Audit; mapping; tests T-A to T-I with controls; sequence diagram | (a) **Run-to-run variability** (each configuration was run once); (b) explicit **failure-propagation** check (whether one failed service affects unrelated flows) |
| C6 | Build/disassembly audit; CIs; queue DES; re-run variability; deployment | No experimental gap. Report renamed. The external gateway measurements (Qadri 2026) are already cited |
| C7 | Contribution audit; comparison; 2 verified 2026 works; worked scenario | (a) An explicit **supported / partial / weak / unsupported / integration** classification of every novelty claim |
| C8 | Paired graph-level analysis; practical threshold; variance partition; figure | (a) **Ranking stability across graphs** (all five architectures) for the v2 E1 data |
| C9 | Audit; 5 profiles; 7-scenario mapping | No experimental gap. Report renamed |
| C10 | Clean-checkout reproduction of v1.0.0; 143-number check; manifest | (a) **Re-execution of v3 experiments** (joint sensitivity, evidence, profiles) to verify determinism; (b) the manifest lacks a "result association" column, and the checklist lacks a "manuscript claim" column |
| Manuscript | – | (a) **Length**: 18 pp. against the TII target; shorten. (b) Integrate the new evidence |

## 4. Execution plan (staged; pilot before each full run)
1. **Stage 1, experiments:**
   - C2 noise/missing/intensity (cheap)
   - C3 threshold, approval and emergency policies (about 15 min)
   - C1 legitimate impact over the joint points (cheap; reuses the joint design)
   - C5 repeated T-A ×3 and failure propagation (about 5 min; run with nothing else active)
   - C8 ranking stability (cheap)
   - C10 deterministic re-execution of subsets (about 10 min)
2. **Stage 2:** formal M4f/M4g (segment expiry, quarantine); property map with bounds; novelty classification.
3. **Stage 3:**
   - manuscript v4 (shortened, new evidence integrated);
   - response;
   - reports under the names requested in this round;
   - evidence manifest;
   - readiness report;
   - delivery.

## 5. Decisions taken without asking (stated so they can be overridden)
- **Title.** This round's prompt names the manuscript "ZTAS-DTh: A Lifecycle-Spanning, Context-Adaptive Zero-Trust Security Architecture for the Digital Thread in Industrial Digital Twin Ecosystems". The current title is "…—Design, Bounded Formal Analysis, and Simulation-Based Evaluation". The current title describes the evidence type more accurately, so it is kept. The prompt's title remains available if the authors prefer it.
- **Workspace.** The v3 workspace stays frozen because it is the archived v1.1.0 release. All v4 work happens in `ZTAS_DTh_Major_Revision_Research_v4/`.
