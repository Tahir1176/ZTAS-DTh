# REVISION_EXECUTION_LOG.md — second major revision (v2 → v3)

Machine: 2 vCPU, 7 GB RAM, Linux, Python 3.13.18, numpy 2.5.3, scipy 1.18.1, pandas 3.0.5, SALib (pip), networkx 3.7.
All timestamps are taken from the system clock (PKT, UTC+5) when the entry was written.

| Date/time | Stage | Experiment / action | Script | Config / seed | Status | Outputs | Errors / notes |
|---|---|---|---|---|---|---|---|
| 2026-11-19 20:21 | 1 | Workspace created; v2 package copied to src/ and 06_Manuscript/v2_baseline (read-only reference); parameter audit | – | – | done | 01_Experiments/joint_sensitivity/parameter_audit.csv | v2 package at ../ZTAS_DTh_MAJOR_REVISION left untouched |
| 2026-11-19 20:22 | 2 | Joint sensitivity pilot (70 points x 36 units) and LazyScore equivalence check (max abs diff 7e-15; identical simulate() outputs) | joint_sensitivity_experiment.py --pilot | seed 20261119 | done | /tmp (discarded) | – |
| 2026-11-19 20:28 | 2 | Joint sensitivity LHS: 850 points x 144 units x 5 configs (612 000 sims) | joint_sensitivity_experiment.py lhs | joint_sensitivity_config.yaml; seed 20261119; graph seeds 10000*ti+g+500 | completed | 02_Data/raw/joint_sensitivity_raw.csv.gz (+points, meta) | none; checkpoint parts kept |
| 2026-11-19 20:28 | 2 | Sobol/Saltelli N=256 (3328 points x 16 units x 2 configs), reference topology | joint_sensitivity_experiment.py sobol | same | completed | 02_Data/raw/joint_sensitivity_sobol_raw.csv.gz | none |
| 2026-11-19 20:23 | 3 | Risk engine extended (prevalence 0.1-20%, calibration transfer, cost/budget thresholds) | risk_engine_extended_experiment.py | seed 20261119; N=1e5 per class | completed | 02_Data/processed/risk_engine/* | none |
| 2026-11-19 20:27 | 5 | M4 model checking, attempt 1 | model_check_v3.py | DELTA=2, TMAX=6 | completed; 1 negative control did NOT produce a counterexample (mis-specified) | logs/model_check_v3_attempt1.* | control replaced, see attempt 2 |
| 2026-11-19 20:27 | 5 | M4 model checking, attempt 2 (16 runs) + M1-M3 re-run (12 runs) | model_check_v3.py; model_check.py | same | completed; all 28 match expectation; M1-M3 identical to v2 log | logs/model_check_v3.*, model_check_rerun.* | – |
| 2026-11-19 20:30 | 6 | PoC tests A-E (v3 + v2-behaviour controls) | run_all_poc_tests.sh | env flags in each JSON | completed | 01_Experiments/poc_failure_testing/raw/*.json | v2 shared-client controls produced cross-thread HTTP exceptions (expected finding) |
| 2026-11-19 20:40 | 6 | PoC test F v2 control | poc_failure_tests.py F | ZTAS_REPLAY=strict ZTAS_THREADLOCAL=0 | HUNG > 8 min; terminated manually 20:45; result JSON written by hand stating HUNG | raw/F_v2control.json | runner script had set -e, so G/H were run separately (run_rest.sh) |
| 2026-11-19 20:40 | 6 | PoC tests G, H (v3 + controls) | run_rest.sh | flags in JSON | completed | raw/G_*.json, raw/H_*.json | – |
| 2026-11-19 20:44 | 4 | Evidence accumulation, continuous time (52 500 runs) + legitimate side | evidence_accumulation_experiment.py | seeds 7000003*g+1009*r+17; legit seeds 31337+i | completed; 0 censored | 02_Data/raw/evidence_accumulation_raw.csv.gz; 02_Data/processed/evidence_accumulation_legitimate.csv | pilot 1 revealed decay applied to auth/segment-denied requests (inconsistent with v2 semantics); fixed before full run, pilot discarded |
| 2026-11-19 20:45 | 6 | PoC test A with anti-replay window W=1024; F with W=1024 | poc_failure_tests.py | ZTAS_REPLAY_W=1024 | completed; 0 failures; 1 accept per round | raw/A_v3_window1024.json, raw/F_v3_window1024.json | W=64 had 22.8% denials at 16 clients |
| 2026-11-19 20:43 | 7 | Crypto statistics recomputed from raw v2 samples; queue DES 540 configs | crypto_reanalysis.py | seed 20261119 | completed | 02_Data/processed/crypto/* | – |
| 2026-11-19 20:52 | 6 | PoC test I (missing risk inputs) v3 and v2 control | poc_failure_tests.py I | ZTAS_MISSING | completed | raw/I_*.json | – |
| 2026-11-19 20:48 | 8 | Statistical re-analysis of v2 E1 data | statistical_analysis.py | seed 20261119 | completed | 02_Data/processed/statistics_*.csv | – |
| 2026-11-19 20:50 | 8 | Attacker profiles (5 profiles, 90 graphs x 20 runs) | adversary_profiles_experiment.py | graph seeds 10000*ti+g+700 | completed | 02_Data/raw/adversary_profiles_raw.csv.gz | simulator multi-entry change regression-tested (72 v2 rows identical) |
| 2026-11-19 20:50 | 9 | Clean-checkout reproduction of release v1.0.0 started | repro.sh (run_all.sh e1,e2,formal,e3,e4) | archived seeds | running | /home/claude/repro_v1 | – |
| 2026-11-19 21:22 | 9 | Clean-checkout reproduction finished; crypto benchmark re-run on idle VM; number check 143/143 | repro.sh; bench_crypto_v2.py; number_check.py | – | completed | 01_Experiments/reproducibility/*, 08_Final_Reports/NUMBER_CHECK.md | crypto timing not reproducible within 2.4x (reported) |
| 2026-11-19 21:22 | 10 | Manuscript v3 compiled (18 pp.), supplement (14 pp.), DOCX via pandoc, response filled with final page numbers | pdflatex/bibtex; make_supplement.py; make_docx.py | – | completed | 08_Final_Reports/* | – |
| 2026-11-20 01:42 | 10 | Release v1.1.0: package uploaded by author (blob verified identical), .zenodo.json/CITATION.cff/README updated, GitHub release published, Zenodo DOI 10.5281/zenodo.24379544 minted; manuscript Data Availability updated | browser | – | completed | GitHub/Zenodo | – |
| 2026-11-20 06:27 | v4-1 | Risk-engine robustness (noise, missing, withholding, intensity) | 02_Risk_Engine/risk_engine_robustness_experiment.py | seed 20261120 | completed (10 s) | 02_Data/Processed/risk_engine_robustness/ | – |
| 2026-11-20 06:27 | v4-1 | Evidence policy extension pilot (2 graphs x 5 runs) then full run started | 03_Evidence_Accumulation/evidence_policy_extension_experiment.py | seeds as v3 | pilot ok; full running | 02_Data/Raw/evidence_policy_extension_raw.csv.gz | – |

## v4 — Stage 1 completion (2026-11-20)

| Step | Script | Output | Status |
|---|---|---|---|
| Evidence-policy extension, full run (80 attack tasks x 11 policies x 30 runs; legitimate side 3 classes x 2 families x 3 rates) | `01_Experiments/03_Evidence_Accumulation/evidence_policy_extension_experiment.py` | `02_Data/Raw/evidence_policy_extension_raw.csv.gz`, `02_Data/Processed/evidence_policy_extension_legitimate.csv` | done |
| Analysis (graph-cluster bootstrap CIs; prop-aware legitimate cost = 0.25·κ2 + 0.75·κ3 because the legitimate simulator only applies κ/decay keys) | `analyse_evidence_policy_extension.py` | `evidence_policy_extension_summary.csv`, `..._legitimate_wide.csv`, `fig_evidence_policy_extension.pdf/png` | done |
| Legitimate impact over the 850 joint LHS points | `01_Experiments/01_Joint_Sensitivity/joint_legitimate_impact.py` | `02_Data/Processed/joint_legitimate_impact.csv`, `fig_joint_legitimate_impact.pdf/png` | done |
| parameter_audit.csv: `justification`, `recommended_range` columns added (both copies) | inline | `01_Experiments/01_Joint_Sensitivity/parameter_audit.csv`, `05_Tables/parameter_audit.csv` | done |
| PoC v4 race tests T-J, T-K with re-check on/off | `poc_failure_tests.py` + `src/poc/ztas_poc_v4.py` | `05_POC_Integration/raw_v4/*.json`, `poc_race_tests_v4.csv` | done |
| T-A concurrency x3 with re-check on/off | `poc_failure_tests.py A` | `poc_concurrency_repeats_v4.csv` | done |
| Deterministic re-execution (3 joint units, 2 evidence tasks, 2 adversary tasks) | `09_Reproducibility/rerun_subset_joint.py`, `rerun_subset_other.py` | `rerun_subset_joint_v4.csv`, `rerun_subset_other_v4.csv` | done; all within 1e-9 (joint units bit-identical) |

Notes / failures:
- The T-J/T-K harness injects a 50 ms delay between authorisation and forwarding (`_test_delay_s`) to make the race observable; the re-check narrows the window to the time between the re-check and the forward call, it does not remove it. Stated as such.
- A separate failure-propagation PoC test was planned but not run; existing T-B..T-I scenarios (component outage, fail-closed) cover it partially.
- Safe-state policy: the simulator does not count safe-state transitions as a separate production-impact metric; only its effect on compromise is reported.

## v4 — Archiving (2026-11-20)
- **Package README:** rewritten for v1.2.0.
- **Repository metadata:** `.zenodo.json`, `CITATION.cff` and the repository README were updated via the GitHub web editor.
- **Upload:** the user uploaded `revision_v1.2.0/ZTAS-DTh_v1.2.0_revision_package.zip`. Its git blob 7c5ddf2cde3adf88ac2dfd7bb11dbf48e4114eb4 is identical to the local file.
- **Release:** GitHub release `v1.2.0` was published.
- **Zenodo:** record 24386844, doi:10.5281/zenodo.24386844, version 1.2.0, 4 creators, file Tahir1176/ZTAS-DTh-v1.2.0.zip (41 MB).
- **Manuscript:** Data Availability now cites v1.2.0 (bib key `ztas2026zenodo12`). The manuscript was rebuilt (17 pp.); number check 182/182.
