# Response to Reviewers: ZTAS-DTh (revision v7)

We thank the reviewer for a detailed and demanding report. Before revising, we audited the v6 manuscript independently against its code, data and logs rather than against its own text (`02_Audit/Technical_Audit_Report.md`).

The audit found no reported result without a generating script and output. It did find four problems that we have corrected or qualified:

1. The E1 simulator did not implement one term of Eq. (2).
2. The advantage of the production risk weights is partly built into the synthetic data.
3. The risk engine silently assumed authentic and fresh telemetry.
4. Mechanism attribution depended on an attribution convention.

Section numbers refer to the revised manuscript; supplementary tables are numbered S1–S50.

## Concern 1: Novelty and originality

- **Contributions (§I).** The contributions are now typed and bounded:
  - (1) analytical: the lifecycle-flow threat model;
  - (2) architectural, integrative: the coupling of decisions to boundary lineage, with flow-scoped segments;
  - (3) methodological and experimental: counterfactual evaluation, factorial ablation, joint sensitivity;
  - (4) formal: bounded checking including multi-PEP rules.

  We state that neither the components nor their mere combination is claimed as novel. The prototype is described as supporting evidence, not as a contribution.
- **Abstract.** Rewritten to state the gap (zero trust without lineage; provenance without access conditioning), the main findings and the limits of the evidence.
- **Comparison table.** Table I is retained. It covers 13 verified works and separates capability coverage from evidence type.

## Concern 2: Simulation assumptions

- **Parameter table.** `06_Tables/Parameter_Table_Concern2.xlsx` covers all 34 parameters with definition, value or range, source, rationale and sensitivity testing. Each is classified as an engineering assumption, experimental design choice, synthetic, sensitivity-tested or unvalidated. The only empirical parameter is the server-VM cryptographic cost, and it is not industrial.
- **Robustness vs generalisability.** §VIII-F now separates robustness within the simulated parameter space from generalisability to real plants, and states that no experiment addresses the latter.
- **Simulator fidelity.** The audit found that the E1 simulator did not subtract evidence after a passed step-up, as Eq. (2) and the prototype do. We re-ran ZTAS-DTh with the decrement on the same 13,500 graph-runs per attacker profile. The compromised fraction changed by at most 0.013 (noisy attacker) and 0.0005 (stealthy attacker), and every graph still favoured ZTAS-DTh. Reported in §VI-A and Supplementary Table S43.

## Concern 3: Topology realism

§VI-A now distinguishes four things:
- **Diversity**, shown by the structural statistics in Supplementary Table S37;
- **Structural plausibility**, argued from IEC 62264 and DTh reference architectures, not from data;
- **Industrial realism**, not assessed;
- **Empirical validation**, none.

Generation is fully specified by family parameters and seeds.

## Concern 4: Risk engine

The engine is described as an implemented, uncalibrated simulation mechanism. It is not presented as a validated detection model. New analyses (§VII-F, Supplementary Tables S45–S47):
- **Alternative weights.** Over 1000 weight vectors near the production weights, the median ROC-AUC changed by at most 0.01. Arbitrary weights performed much worse (median 0.65–0.93 against 0.75–0.99). We state that this advantage is partly built in, because the synthetic attacker raises the components that the production weights emphasise.
- **Manipulated telemetry.** An attacker supplying legitimate-looking behavioural and system values in 90% of requests cut the noisy attacker's step-up rate from 0.67–0.76 to 0.07–0.08.
- **Stale telemetry.** Accepting stale values has the same effect. Treating them as missing (the PoC's freshness bound) restored detection to 0.91–0.98, at a false step-up cost of roughly the legitimate stale share (0.05–0.07 at 5%).
- **Explicit assumption.** We have added assumption A6, authentic and fresh telemetry, to §III-B and §IV-A, and the limitation to §VIII-F.

## Concern 5: Baseline fairness

This was addressed in v6 with three pieces of evidence, which are unchanged:
- the zones-with-monitoring fairness run (ordering unchanged);
- the baseline audit table (Supplementary Table S40);
- the factorial ablation.

The v7 E1 fidelity check (Concern 2) confirms that the comparison with static ZT plus provenance is not inflated by the omitted decrement.

## Concern 6: Statistical rigour

The design was audited:
- **Unit of analysis.** The graph is the unit (30 per family); runs are nested within graphs, and the hierarchical or graph-cluster bootstrap avoids pseudo-replication.
- **Multiplicity.** Bonferroni-adjusted simultaneous intervals are used across families.
- **Tests.** No p-values are reported. $d_z$ is reported but explicitly not used as a measure of benefit.
- **Joint design.** Cell shares with a two-way cluster bootstrap.

The v7 analyses use the same graph-level bootstrap. Every number in the manuscript is checked automatically against the output files (307/307).

## Concern 7: Factorial ablation and attribution

Supplementary Table S44 adds classical main effects, all two- and three-way interactions, and the range of each mechanism's marginal contribution over the six orders of introduction. §VII-C now states:
- which conclusions are independent of the attribution convention. The risk engine never added more than 0.10 against the stealthy attacker, in any order or family.
- which are not. The provenance/segments split depends on order where the two overlap; for example, in the multi-organisation family segments add 0.06–0.53 and provenance 0.23–0.72.

We claim that provenance and segments together carry the margin, and that given provenance, segments carry nearly all of the rest. We do not claim a unique ranking of the two.

## Concern 8: Formal verification

`07_Formal_Verification/Formal_Verification_Audit.md` lists, for every property: the specification, the tool, the bounds, the actual log files and the limitations. It also copies the specifications, configurations and logs.

- **What was done.** Only bounded invariant checking of abstract models: 40 Python checks, and 19 TLC configurations on 5 models with identical verdicts and state counts.
- **What was not done.** No liveness, no unbounded proof, no verification of the implementation.
- **Proof sketches.** Propositions 1–3 are informal.
- **Legacy specification.** An older TLA+ file is marked as never executed.
- **Tool version.** The TLC build (version 2026.11.19, git bc1b506) and the jar's hash are recorded.

## Concern 9: Evidence accumulation, containment and safety

These parts are retained from earlier rounds: the evidence-rule trade-off, the threshold sweep, graded responses with their legitimate cost, operator approval for operations assets, and the roadmap in which automatic enforcement begins outside the operations phase.

v7 adds the finding that forged or stale telemetry neutralises evidence accumulation, which is relevant to containment. The manuscript continues to state that reduced simulated compromise is not evidence of physical safety, and makes no safety claim.

## Concern 10: Post-quantum benchmarking

§VII-H and Supplementary Table S48 now document:
- **Sizes.** Measured from the library objects: ML-DSA-65 public key, secret key and signature 1952 / 4032 / 3309 B; ML-KEM-768 ciphertext 1088 B. These match FIPS 203/204.
- **Per-record provenance bytes.** As a function of batch size: 3309 B unbatched, 244 B at B = 64, then dominated by the inclusion proof.
- **Memory.** Process-level memory, whose increase from the operations was below measurement resolution; we report no memory figure.
- **Scope.** All measurements are server-VM software micro-benchmarks. No gateway, HSM or industrial measurement was made, and the text says so.

## Concern 11: Distributed architecture vs single-host PoC

§VIII-D (added in v6) separates the distributed design from the single-host implementation. It discusses partitions, revocation propagation, policy synchronisation, clock skew and resource constraints, supported by models M5a and M5b. v7 additionally lists, in Limitations, the specified mechanisms that the prototype does not implement:
- fast path and ML-KEM key establishment;
- remote attestation;
- HSM;
- two-person rule;
- distributed ledger.

A two-process partition experiment on one host was considered (Priority B) and not run. It is listed as future work together with a multi-host testbed.

## Concern 12: Deployment roadmap

The seven-phase roadmap (Table XI, Supplementary Table S42) is labelled as a proposal. v7 adds its principal costs to §VIII-D: identity issuance, lineage-policy authoring and segment maintenance, which must be revisited at each process or supplier change. Legacy devices remain behind gateway proxies.

## Editorial and technical (Phase 3)

- **Title.** Retained: it already states the bounded and simulation-based character of the evidence.
- **Introduction.** Gains an organisation paragraph.
- **Notation.** Ambiguous symbol reuse is removed: risk components are $c_k$, the inclusion proof is $\gamma$, prevalence is $\pi_{\mathrm{mal}}$, noise SD is $\sigma_n$, the staleness bound is $\Delta_{\mathrm{st}}$, and the request rate is $\nu$.
- **Algorithm 1.** Checked line by line against the prototype; it matches.
- **Limitations and Conclusion.** Rewritten to state what was demonstrated and what was not.
- **References.** All 70 cited references are logged with their verification method (`02_Audit/Reference_Verification_Log.csv`).

## Reproducibility and archival

`08_Reproducibility/Release_Audit.md` maps every result to archived or unarchived files. Results available in v1.2.0 reproduce exactly with the current code. The v5–v7 analyses are packaged as a draft release v1.3.0 with a SHA-256 manifest. It will be published on Zenodo with the authors' approval, and its DOI will then replace the statement that these analyses are not yet archived.
