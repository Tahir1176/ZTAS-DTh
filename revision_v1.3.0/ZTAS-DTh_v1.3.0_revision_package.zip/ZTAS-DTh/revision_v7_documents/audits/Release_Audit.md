# Release and Reproducibility Audit (Phase 5)

Prepared 26 Nov 2026.

**Question.** Which results in manuscript v7 correspond to archived code and data, and which to unarchived, modified or new material?

**Method.** Every file of the working codebase was compared by SHA-256 with the read-only copy of release v1.2.0 (`File_Inventory.xlsx`; 921 files at audit time). Each manuscript result was then mapped to its scripts and outputs (`evidence_release_map.csv`, `file_release_status.csv`).

## 1. Releases

| Release | DOI | Content |
|---|---|---|
| v1.0.0 | (ztas2026zenodo) | Core E1–E4 experiments; a clean checkout reproduced the principal results |
| v1.1.0 | 10.5281/zenodo.24379544 | Joint sensitivity, risk engine, evidence accumulation, M4a–e, PoC, crypto, attacker profiles |
| v1.2.0 | 10.5281/zenodo.24386844 | Risk robustness, evidence-policy extension, legitimate cost, ranking stability, M4f–g, re-check, T-J/T-K, re-execution checks |
| **v1.3.0** | **not published** | Draft prepared in `10_Final_Submission/release_v1.3.0_DRAFT/` (651 files, SHA-256 manifest, release notes, CITATION.cff) |

## 2. Result-by-result status

| result                                       | release_status                     |
|:---------------------------------------------|:-----------------------------------|
| E1 propagation (Fig. 2, Table VI)            | unarchived (new or modified)       |
| Graph-level effects, simultaneous CIs        | unarchived (new or modified)       |
| Joint sensitivity                            | fully archived (v1.2.0 or earlier) |
| Joint robustness, alternate ranges           | unarchived (new or modified)       |
| Joint legitimate cost                        | fully archived (v1.2.0 or earlier) |
| Risk engine E2                               | fully archived (v1.2.0 or earlier) |
| Risk robustness                              | fully archived (v1.2.0 or earlier) |
| Missingness as signal                        | unarchived (new or modified)       |
| Monitoring step-up rate                      | unarchived (new or modified)       |
| Evidence accumulation (Table VIII)           | fully archived (v1.2.0 or earlier) |
| Evidence policy extension                    | fully archived (v1.2.0 or earlier) |
| Graded responses                             | unarchived (new or modified)       |
| Model checking M1-M4g                        | fully archived (v1.2.0 or earlier) |
| TLC M1, M4f, M4g                             | unarchived (new or modified)       |
| Model checking + TLC M5 (v6)                 | unarchived (new or modified)       |
| Crypto costs                                 | fully archived (v1.2.0 or earlier) |
| Crypto re-run                                | unarchived (new or modified)       |
| PoC T-A..T-K                                 | unarchived (new or modified)       |
| PoC T-L..T-N, extended T-J                   | unarchived (new or modified)       |
| Factorial ablation (v6)                      | unarchived (new or modified)       |
| Zones + monitoring (v6)                      | unarchived (new or modified)       |
| Topology statistics (v6)                     | unarchived (new or modified)       |
| Number check                                 | unarchived (new or modified)       |
| Risk engine weights, mimicry, staleness (v7) | unarchived (new or modified)       |
| Factorial effects and order dependence (v7)  | unarchived (new or modified)       |
| E1 step-up decrement fidelity (v7)           | unarchived (new or modified)       |
| PQC sizes, memory, provenance overhead (v7)  | unarchived (new or modified)       |

**How to read "unarchived (new or modified)".** At least one script or output of the result is new or changed since v1.2.0. For results that existed in v1.2.0 (E1, PoC T-A to T-K), this status comes only from **additive** changes to shared scripts:
- `dth_sim.py` gained new configurations and an option that is off by default;
- `poc_failure_tests.py` gained new scenarios.

Re-running E1 with the current code reproduces the v1.2.0 values exactly: 27,000 paired rows for each of zt, zt_prov and ztas_rec, maximum difference 0.

## 3. File-level summary

| release_status              |   files |
|:----------------------------|--------:|
| unarchived-new              |     517 |
| archived-unchanged (v1.2.0) |     396 |
| archived-modified           |       8 |

## 4. Reproduction status of the analyses new in v7

| Analysis | Deterministic seed | Executed | Re-executable from package |
|---|---|---|---|
| Risk engine: weights, mimicry, staleness | 20261126 | Yes (single execution) | Yes, `01_Experiments/02_Risk_Engine/risk_engine_v7_experiment.py` |
| Factorial effects and order dependence | bootstrap 20261127 | Yes | Yes, from the v6 factorial raw data |
| E1 step-up decrement | E1 seeds | Yes | Yes, ~15 min on 2 cores |
| PQC sizes, memory, overhead | n/a (sizes deterministic; memory measured 5×) | Yes | Yes; memory values are environment-specific |

## 5. Actions

1. **Publish v1.3.0.** This requires the authors' approval and their GitHub/Zenodo accounts, and has not been done. After publication, cite its DOI in the Data and Code Availability section in place of "not yet part of an archived release".
2. **Keep `number_check.py` in the release.** It checks every number in the manuscript against the archived outputs (307/307).
3. **Timing-dependent results** (crypto, PoC latency and race counts) are reproducible in kind, not in value. The manuscript reports a run-to-run factor of about 2 and the stochastic nature of the race counts.
