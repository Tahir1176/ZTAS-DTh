# Technical Audit Report (Phase 1): ZTAS-DTh manuscript v6

Prepared 26 Nov 2026.

This audit was done against the code, data and logs, not against the manuscript's description of them. Previous revision history was not taken as evidence.

## 1. Evidence-to-claim matrix

**Evidence categories:**
- **Impl.** Implemented.
- **Exp.** Experimentally evaluated on the implementation.
- **Sim.** Simulated.
- **FC.** Formally checked (bounded).
- **An.** Analytically derived.
- **Spec.** Specified but not implemented.
- **Prop.** Proposed.
- **NV.** Not verified.
- **Uns.** Unsupported.

| # | Claim (v6) | Location | Supporting evidence | Category | Verification status | Issue | Action (v7) |
|---|---|---|---|---|---|---|---|
| 1 | ZTAS-DTh reduces simulated compromise vs ZT+prov in every family and every graph (stealthy 0.14 vs 0.49 reference) | Abstract, §VII-A/B | `e1_main*.csv`; re-run reproduces exactly | Sim. | Verified (number check) | Conditional on assumed parameters (stated) | Keep |
| 2 | 96.7% / 75.5% of joint cells lower / lower by ≥0.05 | Abstract, §VII-D | `joint_sensitivity_results.csv` | Sim. | Verified | Shares of an assumed range (stated) | Keep |
| 3 | Margin vanishes for sparse threads, open segments, stealthy attackers | §VII-D | Tree, Sobol, by-topology tables | Sim. | Verified | Tree CV balanced accuracy 0.71 < majority 0.755 (stated) | Keep |
| 4 | Against stealthy attackers the margin comes from segments and provenance; the risk engine contributes 2–9% | §VII-C, Conclusion | `contributions.csv` (Shapley) | Sim. | Verified | Shapley is one attribution convention; the provenance/segment split depends on order (v7 analysis) | **Qualify:** add main effects, interactions and order ranges; say the P/S split is not uniquely identifiable |
| 5 | The E1 risk engine implements Eq. (2) | §IV-D, §VI-A | `dth_sim.py` | Sim. | **Partly unsupported**: E1 omits the −1 decrement after a passed step-up and has no outage model | Could favour ZTAS-DTh | **Ran E1 with the decrement:** +0.001 to +0.013 (noisy), ≤0.0005 (stealthy); disclose |
| 6 | Production weights dominate uniform weights | §VII-F | E2 | Sim. | Verified on synthetic data | The advantage is partly built in: the synthetic attacker shifts exactly the components the production weights emphasise | **Add caveat** plus the Dirichlet weight study |
| 7 | Risk engine robust to noise and missing data in the stated ways | §VII-F | Robustness and missingness studies | Sim. | Verified | No study of manipulated or stale telemetry | **v7 study:** mimicry and staleness; telemetry integrity becomes an explicit assumption |
| 8 | 26–94 false escalations per true at 0.1% prevalence | Abstract, §VII-F | E2 | Sim. (synthetic) | Verified | Synthetic distributions (stated) | Keep |
| 9 | Revised evidence rule: no false isolation; containment 0.43 → 0.11 | §VII-F/G | Evidence studies | Sim. | Verified | Assumed legitimate failure rates (stated) | Keep |
| 10 | Graded monitoring reduces compromise by 23.6 entities | §VII-G | Graded study | Sim. | Verified | Assumed effect sizes of measures (stated) | Keep |
| 11 | Properties P1–P8 hold within bounds; 40 checks; 19 re-checked with TLC | §V, Table IV | Python logs, TLC logs, results JSON | FC. | Verified: logs exist, verdicts and state counts match | Bounded, abstract, no liveness (stated) | Keep |
| 12 | Proposition 1 (integrity) | §V | Proof sketch | An. | Informal reduction | Not machine-checked (stated in the property map) | Keep, labelled sketch |
| 13 | Merkle v1 encoding collision found; corrected | §IV-F, M3 | `model_check.py` M3 | FC. | Verified | — | Keep |
| 14 | PoC enforces Algorithm 1 incl. lineage, replay window, fail-closed, re-check, version re-validation | §VII-I, Alg. 1 | `ztas_poc_v4/v5.py`, test logs | Impl. + Exp. | Verified by reading code: lines 1–11 of Alg. 1 present (re-validation `ZTAS_REVALIDATE`, re-check `ZTAS_RECHECK_ENFORCE`) | Algorithm consistent with code | Keep |
| 15 | Two-path design (fast path, hybrid ML-KEM) | §IV-F | — | Spec. | Not implemented | Not stated explicitly in E4 | **Disclose in E4 / Limitations** |
| 16 | Remote attestation feeds the system component | §IV-D | — | Spec. | Not implemented (context injected) | Stated as "injected context" | Make explicit |
| 17 | ML-DSA-65 sign 9.3 ms, verify 180 µs on a server core | §VII-H | `e3_crypto_samples.npz`; re-run 0.78–1.22× | Exp. (server) | Verified | Server only (stated) | Keep |
| 18 | Key and signature sizes, memory, bandwidth | §VII-H | Only the 3.3 kB signature mentioned | — | Incomplete | Concern 10 | **v7:** sizes measured from the library objects; process memory; per-record bytes by batch size (analytical) |
| 19 | Batching keeps p99 latency at 36–82 ms | §VII-H | Queueing model on measured costs | Sim. + An. | Verified | Model omits network, ledger, HSM (stated) | Keep |
| 20 | Distributed revocation needs a staleness bound ≤ Δ at every PEP | §V M5 | M5a logs | FC. | Verified (both checkers) | Abstract network | Keep |
| 21 | Zones-with-monitoring check leaves the ordering unchanged | §VII-C | `zones_monitoring_summary.csv` | Sim. | Verified | — | Keep |
| 22 | Topologies span a plausible structural range | §VI-A | Topology statistics | Sim. (synthetic) | Verified as diversity | Plausibility is a judgement; no industrial validation | **Separate** diversity / plausibility / realism / validation explicitly |
| 23 | Deployment roadmap | §VIII-D | — | Prop. | Not executed (labelled) | — | Keep, add governance/cost/maintenance notes |
| 24 | Reduced simulated compromise is not evidence of physical safety | §VIII-C/E | — | — | Correct statement | — | Keep |
| 25 | Code and data available; releases v1.0.0–v1.2.0 | Data availability | Zenodo DOIs | — | Verified earlier | v5–v7 additions unarchived | **State precisely;** prepare v1.3.0 |

No claim was found that is unsupported and also presented as evidence. Claims 5 and 6 needed correction or qualification, and claims 15, 16 and 18 needed clearer disclosure.

## 2. Audit by topic

1. **Architecture.** The five layers are consistent with Algorithm 1 and the PoC. Fig. 1 marks implemented vs specified components (v6). The fast path and attestation are specified only (rows 15–16).
2. **Threat model.**
   - Explicit about capabilities and exclusions (physical destruction, radio DoS).
   - Gap: the risk engine assumes that the telemetry it scores is authentic and fresh, but the adversary model lets the attacker "keep its behaviour close to that of the entity it controls". It does not say whether the attacker can forge telemetry. The v7 mimicry study shows that the engine fails if it can. Added as explicit assumption A6.
3. **Security assumptions.** A1–A5 hold. Added A6: telemetry sources are authenticated and time-stamped by components outside the attacker's control.
4. **Lifecycle-flow model.** Definition 1 is consistent with the simulator (gate boundary = phase or owner change; artifact-mediated share $f_{art}$ drawn per edge).
5. **Graph construction.** Deterministic from seeds; 9 families; statistics in Supplementary Table S37. Plausibility is argued from reference architectures (IEC 62264, Helu et al.), not validated.
6. **Simulation design.** Common random numbers, 60-step horizon, Bernoulli mechanism filters. The E1 omission of the Eq. (2) decrement is quantified in v7 (row 5).
7. **Risk scoring.** Weighted sum on [0,100]; weights on the simplex; thresholds 30/70/90. Deterministic. Mid-scale imputation is consistent in the PoC and the robustness study.
8. **Thresholds.** Expert-chosen; cost- and budget-constrained alternatives are derived on synthetic data only.
9. **Telemetry.** Noise, missingness, withholding and correlated outages were covered. Mimicry and staleness are added in v7.
10. **Baselines.** Mechanisms, configuration and bias are documented (Supplementary Table S40). Zones-with-monitoring fairness check done.
11. **Statistics.**
    - The unit is the graph (30 per family). Runs are nested within graphs, and the hierarchical and graph-cluster bootstrap avoids pseudo-replication.
    - No p-values.
    - Bonferroni-adjusted simultaneous CIs over the 9 families.
    - $d_z$ is reported but not used as a benefit measure.
    - Joint design: cell shares with a two-way cluster bootstrap.
    - Appropriate. No change needed beyond the v7 analyses using the same scheme.
12. **Ablation.** Full 2^3 factorial, now with main effects, two- and three-way interactions, and order-dependence ranges (v7).
13. **Sensitivity.** One-at-a-time, joint LHS, Sobol, PRCC, alternate ranges. Robustness is within the simulated space only; the manuscript keeps that separate from real-world generalisation.
14. **Formal verification.** See `07_Formal_Verification/Formal_Verification_Audit.md`.
15. **Crypto benchmarking.** Server VM. v7 adds measured sizes and process-level memory, and states that the operations' memory cost is below process-level resolution.
16. **Software.** Python services on one host. Fixes switchable, with controls re-run.
17. **Reproducibility.** See `08_Reproducibility/Release_Audit.md`.
18. **Industrial applicability.** Roadmap proposed; governance, cost and maintenance are discussed briefly. Nothing validated in a plant.
19. **Conclusions.** Consistent with the evidence after the v7 qualifications.

## 3. Notation audit (Phase 3.8)

Ambiguous reuse of symbols found in v6, and the v7 fix for each:

| Symbol | Uses in v6 | v7 change |
|---|---|---|
| $\rho$ | risk components $\rho_k$ **and** provenance records $\rho_i$ / Alg. 1 record | risk components renamed $c_k$ |
| $\pi$ | inclusion proof (Alg. 1), segment purpose $\pi_\sigma$, prevalence $\pi$ (E2 cost) | proof renamed $\gamma$; prevalence renamed $\pi_{\mathrm{mal}}$ |
| $\sigma$ | segment **and** noise standard deviation (E2) | noise renamed $\sigma_{n}$ |
| $S$ | staleness bound (M5a), service phase $\mathsf{S}$, scenarios S1–S8 | staleness bound renamed $\Delta_{\mathrm{st}}$ |
| $r$ | risk score $r(q)$ **and** request rate (E2 continuous time) | rate renamed $\nu$ |
| $d$ | generic-monitoring probability **and** PDP decision in Alg. 1 | kept: the contexts are disjoint and the decision is defined locally in Algorithm 1 (renaming would collide with $\delta$ in Eq. (2)) |
| $\Delta$ | revocation bound, simplex $\Delta^4$, interval $\Delta t$ | Standard usage; kept |

## 4. Title

The title is accurate: lifecycle-spanning, zero-trust, digital thread, design, *bounded* formal analysis, *simulation-based* evaluation. It already signals the evidence type. **Kept unchanged.**
