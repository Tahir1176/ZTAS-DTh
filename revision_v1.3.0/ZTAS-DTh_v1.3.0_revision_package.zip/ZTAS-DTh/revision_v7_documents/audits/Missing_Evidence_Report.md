# Missing Evidence Report (Phase 0)

Prepared 26 Nov 2026 for manuscript v6 → v7.

**Method.** `08_Reproducibility/evidence_and_release_check.py` looks up the scripts and output files of every result reported in v6 in the working codebase. It then compares each file with archived release v1.2.0 by SHA-256.

The per-file list (921 files, with sha256 and release status) is in `02_Audit/File_Inventory.xlsx`.

## 1. Results whose scripts or outputs are missing

**None.** Every result group reported in v6 has its generating script(s) and output file(s) in the working tree. That covers 23 groups: E1, statistics, joint sensitivity, alternate ranges, legitimate cost, risk engine, robustness, missingness, monitoring rate, evidence accumulation, policy extension, graded responses, model checking M1–M4g, TLC M1/M4f/M4g, M5 with TLC, crypto, crypto re-run, PoC T-A to T-K, PoC T-L to T-N, factorial, zones + monitoring, topology statistics and the number check.

## 2. Executed but not archived

Of the 921 files:
- 396 are unchanged from v1.2.0;
- 8 differ from v1.2.0 (listed below);
- 517 are new.

**The 8 modified files.**

| File | Change | Effect on archived results |
|---|---|---|
| `src/dth_sim.py` | v6/v7 added configurations (`zt_seg`, `zt_risk`, `zones_mon`) and an option `success_decrement`, off by default | None. Re-runs reproduce the archived E1 values exactly (27,000 paired rows per configuration, difference 0) |
| `01_Experiments/05_POC_Integration/poc_failure_tests.py` | v5 added scenarios L, M, N; the scenario dict was extended | None for T-A to T-K (same functions) |
| `08_Final_Reports/number_check.py`, `NUMBER_CHECK.md` | Extended with v5–v7 checks | Not a result |
| `01_Experiments/09_Reproducibility/make_manifest.py`, `02_Data/manifests/reproducibility_manifest.csv` | Manifest regenerated | Not a result |
| `src/poc/keys/idp.pub`, `prov.pub` | Keys are regenerated on every PoC start | Expected; the keys are ephemeral test keys |

**Result groups that depend on unarchived files:**
- alternate ranges and surrogate validation;
- missingness as a signal;
- monitoring step-up rate;
- graded responses;
- TLC re-checks;
- model M5;
- crypto re-run;
- PoC T-L to T-N and the extended T-J;
- effect sizes;
- factorial ablation;
- zones + monitoring;
- topology statistics;
- all v7 analyses.

Release v1.3.0 is prepared in `10_Final_Submission/release_v1.3.0/` but **not published**; publishing needs the authors' approval.

## 3. Described in the manuscript but not implemented or not executed

These were confirmed by reading the code, not the text.

| Item | Where described | Status in code | Manuscript treatment (v7) |
|---|---|---|---|
| Fast path for time-critical commands with hybrid ML-KEM key establishment | §IV-F | Not implemented in the PoC; ML-KEM only micro-benchmarked (E3) | Now stated in E4 and Limitations; dashed in Fig. 1 |
| Remote attestation, firmware hashes (system risk component) | §IV-D | Not implemented; the component is injected as context | Stated ("injected context") |
| Permissioned-ledger anchoring of batch headers | §IV-F | SQLite table on one host | Stated ("no distributed ledger") |
| HSM-held gateway keys | §IV-A/F | Keys held in process memory and files | Stated |
| Two-person rule for policy changes | P8, §VIII-C | Not implemented; model-checked only (M4e) | Stated |
| Calibration protocol | Supplement | Proposal only, not executed | Labelled "not executed" |
| Deployment roadmap | §VIII-D | Proposal only | Labelled "not executed" |
| Threat intelligence, behavioural baselines, DT-based security simulation, weight calibration, compliance mapping, playbooks | Fig. 1 | Not implemented | Dashed in Fig. 1 |
| Eq. (2) decrement of evidence after a successful step-up | §IV-D | In the PoC, but **not in the E1 simulator** (found in this audit) | v7 runs E1 with the decrement: the result changes by at most 0.013 (noisy) and ≤0.0005 (stealthy); disclosed in §VI-A |

## 4. Evidence that does not exist and cannot be produced here

- Plant telemetry, or any industrial calibration of risk weights and thresholds.
- Gateway, PLC or HSM measurements (cryptographic costs, memory, latency).
- A multi-host or distributed deployment, real network partitions, clock skew.
- A real DTh topology.
- Operator studies (workload, decision time).
- Physical-process or safety-system interaction.

The manuscript states each of these as a limitation. None is presented as evidence.

## 5. Tool availability

- **TLC.** `tla2tools.jar` (sha256 `fdffef24…6713`, TLC2 2026.11.19, git bc1b506) with OpenJDK 21 is available. It was executed for M1, M4f, M4g, M5a and M5b; the logs are in `src/formal/tla/logs/`.
- **Python checker.** Available and executed.
- **Not available:** Apalache, TLAPS, or other provers. No unbounded proof was attempted.
