# Formal Verification Audit (Concern 8)

Prepared 26 Nov 2026. This file states what was actually checked, with which tool, within which bounds, and where the execution evidence is. Every log referenced below is a real tool output, copied unchanged from `codebase/src/formal/` into `07_Formal_Verification/logs/`.

## What kind of assurance this is

**Is:**
- Explicit-state, **bounded** model checking of small **abstract** models.
- Invariants only (safety properties).
- Done with a purpose-written Python breadth-first checker. 5 of the models (M1, M4f, M4g, M5a, M5b) were also transcribed into TLA+ and re-checked with TLC.
- Propositions 1–3 are **analytical proof sketches** (informal reductions to EUF-CMA and collision resistance). They are not machine-checked.

**Is not:**
- No temporal or liveness properties were checked.
- No unbounded proof (no TLAPS or Apalache).
- No verification of the implementation (the PoC is tested, not verified).
- No timing analysis.

**The Python checks are not TLA+ verification.** They are reported separately, and only the configurations marked † in Table IV were run in TLC.

## Execution environment

- **Python checker:** Python 3.13, `codebase/src/formal/model_check*.py` (deterministic BFS).
- **TLC:** `tla2tools.jar`, SHA-256 `fdffef247f563ef6edbfd44958d2a82db79e7564e07cb673262d896353fa6713`. Manifest: TLC2 version 2026.11.19.180144, git bc1b506, X-Git-Tag 2026.11.15 rolling v1.8.0. Run on OpenJDK 21.
- **TLC command:** `java -cp tla2tools.jar tlc2.TLC -deadlock -workers 1 -config <cfg> <spec>.tla`, issued by `run_tlc_m1.py`, `run_tlc_m4fg.py` and `run_tlc_m5.py`.
- **Counts:** 40 Python checks (M1–M3: 12, M4a–e: 16, M4f–g: 4, M5a–b: 8), all matching expectation. 19 TLC configurations, all with the same verdict; where the property holds, the distinct-state counts are identical (280, 11,760, 11,760, 250, 41, 7,336, 32).
- **Counterexamples:** TLC trace files (`*_TTrace_*.tla/.bin`) are kept in `codebase/src/formal/tla/`. Python counterexample traces are in the `.log` files.
- **Not executed:** the legacy file `specs/LEGACY_ProvenanceGate_not_executed.tla`. It is kept for reference only.

## Property table

| Property | Specification | Tool | Model bounds | Actual execution evidence | Result | Limitations |
|---|---|---|---|---|---|---|
| P1 Flow authorisation: Delivery on flow e => unexpired segment contains (e,s) AND PDP allow valid at delivery time | M2 (model_check.py); M4b, M4c (model_check_v3.py); M4f (model_check_v4.py, CheckToEnforceM4f.tla) | Python BFS (M2, M4b, M4c); Python BFS + TLC (M4f) | M2 <=3 deliveries, 1 policy change; M4b 2 deliveries, arbitrary fail/recover; M4c 2 requests, 1 update; M4f clock<=4, 2 requests | logs/model_check_results.json, model_check_v3_results.json, model_check_v4_results.json; logs/tlc_M4f_1.log, tlc_M4f_2.log | Holds within bounds; every negative control produced a counterexample | Residual window between PEP re-check and forward call is not modelled at code level; T-J uses an injected 50 ms delay |
| P2 Provenance integrity: Accepted record and artifact equal what an uncompromised gateway signed | Proposition 1 (proof sketch); M1 (model_check.py, ProvenanceGateM1.tla); M4b | Python BFS + TLC (M1); Python BFS (M4b) | M1 N<=3 records; M4b 2 deliveries | logs/model_check_results.json; logs/tlc_M1_1..7.log, tlc_M1_results.json | Holds within bounds; every negative control produced a counterexample | No machine-checked proof; key compromise breaks the property (M1 control shows it) |
| P3 Freshness / replay: Each record accepted at most once (strict mode: increasing order) | Proposition 2; M1 (ProvenanceGateM1.tla); M4d (model_check_v3.py); M5b (model_check_v6.py, CrossGateReplayM5b.tla) | Python BFS + TLC (M1, M5b); Python BFS (M4d) | M1 N<=3; M4d 2 PEP workers, 1 duplicated record; M5b 2 gates, 1 record replayed to both, store reachability toggles | logs/model_check_results.json, model_check_v3_results.json, model_check_v6_results.json; logs/tlc_M1_*.log, tlc_M5b_5..8.log | Holds within bounds; every negative control produced a counterexample | Window mode gives only bounded reordering; verifier state across replicas not modelled; across gates only with shared atomic replay state, which must fail closed when unreachable (M5b) |
| P4 Lineage consistency: Accepted artifacts satisfy the artifact type's lineage policy | none (lineage policy tested in PoC scenarios S3-S5) | none (tests only) | - | PoC logs only (05_POC_Integration/raw*) | Not model-checked; PoC scenarios behaved as specified | Not model-checked |
| P5 Batch binding: Distinct leaf lists -> distinct signed Merkle headers | M3 (model_check.py) | Python BFS (M3) | Exhaustive, 3-letter alphabet, <=5 leaves | logs/model_check_results.json | Holds within bounds; every negative control produced a counterexample | Larger batches covered only by the length-binding argument |
| P6 Revocation: No acceptance under a revoked key epoch/principal later than Delta after revocation | Proposition 3; M1 (ProvenanceGateM1.tla); M4a (model_check_v3.py); M5a (model_check_v6.py, DistributedRevocationM5a.tla) | Python BFS + TLC (M1, M5a); Python BFS (M4a) | Delta=2, clock<=6, 1 revocable principal; M5a 2 PEPs, partition from IdP, clock<=6, Delta=2 | logs/model_check_results.json, model_check_v3_results.json, model_check_v6_results.json; logs/tlc_M1_*.log, tlc_M5a_1..4.log | Holds within bounds; every negative control produced a counterexample | Network delay distributions and clock skew not modelled; with several PEPs the bound holds only if every PEP enforces a staleness bound <= Delta; a partitioned PEP then denies legitimate requests (M5a cost witness) |
| P7 Containment after quarantine: After quarantine is acknowledged, no request of the subject is forwarded | M2 (model_check.py); M4g (model_check_v4.py, CheckToEnforceM4g.tla) | Python BFS (M2); Python BFS + TLC (M4g) | M2 <=3 deliveries; M4g 2 in-flight requests | logs/model_check_results.json, model_check_v4_results.json; logs/tlc_M4g_3.log, tlc_M4g_4.log | Holds within bounds; every negative control produced a counterexample | Quarantine consistency across replicated PDPs not modelled |
| P8 Plane separation: Only control-plane administrators change policy; malicious change needs a quorum | M2 (model_check.py); M4e (model_check_v3.py) | Python BFS (M2, M4e) | 2 administrators | logs/model_check_results.json, model_check_v3_results.json | Holds within bounds; every negative control produced a counterexample | Two-person rule specified but NOT implemented in the PoC |
| F1 Fail-closed under component failure: No delivery without a PDP decision, verified provenance and a confirmed open segment, under arbitrary failure/recovery | M4b (model_check_v3.py) | Python BFS (M4b) | 2 deliveries | logs/model_check_v3_results.json | Holds within bounds; every negative control produced a counterexample | Byzantine component behaviour not modelled; liveness (eventual service) not checked |

## Missing properties and why they were not added

- **Liveness.** For example, "a quarantine request is eventually enforced" or "revocation eventually reaches every PEP". This would need fairness assumptions on the network and operators, which the paper does not model. It is left as future work and stated in the paper.
- **P4, lineage consistency.** It depends on the lineage-policy content rather than on protocol structure. Model-checking it would check the policy, not the architecture. It is tested in the PoC.
- **Larger bounds** (more principals, records or enforcement points). No state explosion was reached at the current bounds (largest 11,760 states), but the checks are deliberately small. Correctness for larger configurations is not claimed.
