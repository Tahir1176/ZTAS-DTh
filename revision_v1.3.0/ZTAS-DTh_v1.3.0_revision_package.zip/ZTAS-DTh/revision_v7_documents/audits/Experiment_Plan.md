# Experiment Plan (Phase 4)

Before planning, existing scripts, data and results were inspected (`02_Audit/Missing_Evidence_Report.md`). Experiments already complete in v3–v6 were not repeated:
- joint sensitivity and alternate ranges;
- risk noise, missingness and withholding;
- graded responses;
- the factorial ablation;
- zones with monitoring;
- topology statistics;
- M5.

| ID | Experiment | Concern | Resources | Difficulty | Expected scientific value | Priority | Status |
|---|---|---|---|---|---|---|---|
| A1 | E1 with the Eq. (2) decrement after a passed step-up (fidelity check of the simulator against the paper) | 2, 5, 7 | 2 cores, ~15 min | Low | Removes a hidden bias found in the audit | A | **Done:** +0.001–0.013 (noisy), ≤0.0005 (stealthy); every graph still favours ZTAS-DTh |
| A2 | Risk engine with alternative weights (1000 Dirichlet draws, two concentrations) | 4 | <5 min | Low | Shows how much the weight choice matters, and that its advantage is partly built in | A | **Done** |
| A3 | Manipulated telemetry (mimicry) | 4, 9 | <1 min | Low | Tests the unstated telemetry-integrity assumption | A | **Done:** TPR 0.67–0.76 → 0.07–0.08 at 90% mimicry (noisy) |
| A4 | Stale telemetry with and without a freshness bound | 4, 11 | <1 min | Low | Quantifies the trade-off behind PoC test T-M | A | **Done** |
| A5 | Factorial main effects, interactions and order dependence of attribution | 7 | Analysis only | Low | Shows which attribution claims are convention-independent | A | **Done** |
| A6 | PQC sizes measured from library objects; process memory; per-record provenance bytes vs batch size | 10 | <1 min | Low | Fills the documentation gaps on sizes, memory and communication | A | **Done**; memory below process-level resolution (reported as such) |
| B1 | Two PEP processes on one host with an emulated partition (fault-injection proxy) as an implementation counterpart of M5a | 11 | ~1 day of engineering | Medium | Would move M5a from model to implementation test; still single-host | B | **Not run.** Needs changes to the PoC's service wiring and a proxy; resources prioritised for A1–A6 |
| B2 | Adaptive attacker that times actions to outages or segment windows | 2, 9 | E1 simulator extension | Medium | Closes a stated threat-model gap | B | Not run; stated as a limitation |
| B3 | Joint sensitivity repeated with the decrement on | 2 | ~4 h | Medium | Low expected value, because A1 changes are ≤0.013 | B | Not run (A1 makes it unnecessary) |
| C1 | Multi-host deployment with network emulation, clock skew, replicated PDPs | 11 | Testbed | High | High | C | Future work |
| C2 | ML-DSA/ML-KEM on gateway CPUs and HSMs | 10 | Hardware | High | High | C | Future work |
| C3 | Risk-engine calibration on plant telemetry (shadow mode) | 4, 12 | Plant access | High | Very high | C | Future work (roadmap phases 3–4) |
| C4 | HIL testbed with a physical process (safety interaction) | 9 | Testbed | High | High | C | Future work |
| C5 | Liveness properties with fairness assumptions (TLC temporal checking) | 8 | Modelling effort | Medium | Medium | C | Future work |
