Analysis notebooks are copies; the executable originals live next to their scripts in 01_Experiments/.
