# NUMBER_CHECK.md — manuscript numbers vs output files

307/307 checks pass.

| Quantity | Manuscript | File (rounded) | Result | Note |
|---|---|---|---|---|
| cells ZTAS<ZT+prov (continuous) | 96.7 | 96.7 | PASS |  |
| cells advantage>=0.05 | 75.5 | 75.5 | PASS |  |
| cells worse by >=0.01 | 1.2 | 1.2 | PASS |  |
| continuous mean diff | -0.23 | -0.23 | PASS |  |
| continuous CI lo | -0.25 | -0.25 | PASS |  |
| continuous CI hi | -0.21 | -0.21 | PASS |  |
| adverse mean diff | -0.12 | -0.12 | PASS |  |
| adverse CI lo | -0.15 | -0.15 | PASS |  |
| adverse CI hi | -0.10 | -0.10 | PASS |  |
| adverse ZTAS rank1 | 44 | 44 | PASS |  |
| adverse ZTAS frac | 0.62 | 0.62 | PASS |  |
| containment diff (continuous) | 0.20 | 0.20 | PASS |  |
| reach_O diff (continuous) | 0.23 | 0.23 | PASS |  |
| Table joint optimistic | 0.40 | 0.40 | PASS |  |
| Table joint optimistic | 0.18 | 0.18 | PASS |  |
| Table joint optimistic | 0.03 | 0.03 | PASS |  |
| Table joint optimistic | 99.5 | 99.5 | PASS |  |
| Table joint optimistic | 62.9 | 62.9 | PASS |  |
| Table joint moderate | 0.74 | 0.74 | PASS |  |
| Table joint moderate | 0.44 | 0.44 | PASS |  |
| Table joint moderate | 0.21 | 0.21 | PASS |  |
| Table joint moderate | 98.5 | 98.5 | PASS |  |
| Table joint moderate | 80.7 | 80.7 | PASS |  |
| Table joint adverse | 0.90 | 0.90 | PASS |  |
| Table joint adverse | 0.74 | 0.74 | PASS |  |
| Table joint adverse | 0.62 | 0.62 | PASS |  |
| Table joint adverse | 80.8 | 80.8 | PASS |  |
| Table joint adverse | 55.9 | 55.9 | PASS |  |
| Table joint continuous | 0.68 | 0.68 | PASS |  |
| Table joint continuous | 0.48 | 0.48 | PASS |  |
| Table joint continuous | 0.25 | 0.25 | PASS |  |
| Table joint continuous | 96.7 | 96.7 | PASS |  |
| Table joint continuous | 75.5 | 75.5 | PASS |  |
| Sobol ST p_act | 0.35 | 0.35 | PASS |  |
| Sobol ST p_exploit | 0.30 | 0.30 | PASS |  |
| Sobol ST mu_mal | 0.29 | 0.29 | PASS |  |
| Sobol ST p_auth | 0.22 | 0.22 | PASS |  |
| Sobol ST d_generic | 0.22 | 0.22 | PASS |  |
| Sobol ST f_art | 0.19 | 0.19 | PASS |  |
| Sobol ST p_v | 0.13 | 0.13 | PASS |  |
| Sobol ST stepup_fail | 0.13 | 0.13 | PASS |  |
| Sobol ST kappa | 0.06 | 0.06 | PASS |  |
| sum S1 | 0.4 | 0.4 | PASS |  |
| sum ST | 1.9 | 1.9 | PASS |  |
| tree accuracy | 0.82 | 0.82 | PASS |  |
| by topology dense | -0.32 | -0.32 | PASS |  |
| by topology sparse | -0.04 | -0.04 | PASS |  |
| profile noisy ZTAS | 0.04 | 0.04 | PASS |  |
| profile noisy ZT+prov | 0.40 | 0.40 | PASS |  |
| profile stealthy ZTAS | 0.14 | 0.14 | PASS |  |
| profile stealthy ZT+prov | 0.40 | 0.40 | PASS |  |
| profile insider_cred ZTAS | 0.28 | 0.28 | PASS |  |
| profile insider_cred ZT+prov | 0.49 | 0.49 | PASS |  |
| profile rapid ZTAS | 0.31 | 0.31 | PASS |  |
| profile rapid ZT+prov | 0.57 | 0.57 | PASS |  |
| profile coordinated ZTAS | 0.31 | 0.31 | PASS |  |
| profile coordinated ZT+prov | 0.65 | 0.65 | PASS |  |
| profile practical min | 84 | 84 | PASS |  |
| profile practical max | 94 | 94 | PASS |  |
| sparse share practical | 20 | 20 | PASS |  |
| multi_org share practical | 67 | 67 | PASS |  |
| multi_org diff | 0.07 | 0.07 | PASS |  |
| sparse diff | 0.04 | 0.04 | PASS |  |
| dense diff | 0.40 | 0.40 | PASS |  |
| feedback diff (lower end 0.32) | 0.32 | 0.32 | PASS |  |
| ICC min | 2 | 2 | PASS |  |
| ICC max | 9 | 9 | PASS |  |
| rel min | 51 | 51 | PASS |  |
| rel max | 72 | 72 | PASS |  |
| dz min | -1.6 | -1.6 | PASS |  |
| dz max | -5.9 | -5.9 | PASS |  |
| heavy 55 false/true | 26 | 26 | PASS |  |
| heavy 28 false/true | 94 | 94 | PASS |  |
| 16-94 lower | 16 | 16 | PASS |  |
| precision max (1-6%) | 6 | 6 | PASS |  |
| precision min | 1 | 1 | PASS |  |
| false step-ups lower | 1200 | 1200 | PASS |  |
| false step-ups upper | 1700 | 1700 | PASS |  |
| ECE in-condition | 0.003 | 0.003 | PASS |  |
| ECE other min | 0.014 | 0.014 | PASS |  |
| ECE other max | 0.029 | 0.029 | PASS |  |
| ECE 20% min | 0.04 | 0.04 | PASS |  |
| ECE 20% max | 0.18 | 0.18 | PASS |  |
| threshold heavy fp 0.1% | 64.5 | 64.5 | PASS |  |
| threshold heavy fp 20% | 14.0 | 14.0 | PASS |  |
| budget10 gaussian | 30.0 | 30.0 | PASS |  |
| budget10 heavy | 52.0 | 52.0 | PASS |  |
| evidence original_k2 contained_before_O | 0.43 | 0.43 | PASS |  |
| evidence original_k2 compromised | 25.2 | 25.2 | PASS |  |
| evidence original_k2 requests | 30.0 | 30.0 | PASS |  |
| evidence revised_k3_decay contained_before_O | 0.11 | 0.11 | PASS |  |
| evidence revised_k3_decay compromised | 49.0 | 49.0 | PASS |  |
| evidence revised_k3_decay requests | 62.5 | 62.5 | PASS |  |
| evidence alt_k3_nodecay contained_before_O | 0.23 | 0.23 | PASS |  |
| evidence alt_k3_nodecay compromised | 40.2 | 40.2 | PASS |  |
| evidence alt_k3_nodecay requests | 45.5 | 45.5 | PASS |  |
| evidence time_decay_k3 contained_before_O | 0.11 | 0.11 | PASS |  |
| evidence time_decay_k3 compromised | 49.0 | 49.0 | PASS |  |
| evidence time_decay_k3 requests | 62.5 | 62.5 | PASS |  |
| evidence criticality_aware contained_before_O | 0.11 | 0.11 | PASS |  |
| evidence criticality_aware compromised | 48.1 | 48.1 | PASS |  |
| evidence criticality_aware requests | 62.5 | 62.5 | PASS |  |
| first response r=1 | 78 | 78 | PASS |  |
| first response r=1000 | 0.08 | 0.08 | PASS |  |
| low-intensity time decay contained | 0.00 | 0.00 | PASS |  |
| full moderate original | 58 | 58 | PASS |  |
| full moderate revised | 35 | 35 | PASS |  |
| full stealthy original | 25 | 25 | PASS |  |
| full stealthy revised | 21 | 21 | PASS |  |
| paired original vs revised | -23.8 | -23.8 | PASS |  |
| paired crit vs revised | -0.84 | -0.84 | PASS |  |
| legit original | 0.9995 | 0.9995 | PASS |  |
| legit alt | 0.89 | 0.89 | PASS |  |
| legit original min | 15 | 15 | PASS |  |
| legit original max | 100 | 100 | PASS |  |
| PoC artifact c1 p50 | 2.3 | 2.3 | PASS |  |
| PoC artifact c1 p99 | 11.6 | 11.6 | PASS |  |
| PoC artifact c16 p50 | 27.6 | 27.6 | PASS |  |
| PoC artifact c16 p99 | 58 | 58 | PASS |  |
| PoC artifact sat | 560 | 560 | PASS |  |
| PoC plain sat | 930 | 930 | PASS |  |
| strict c2 | 18 | 18 | PASS |  |
| strict c16 | 77 | 77 | PASS |  |
| v2 shared min | 51 | 51 | PASS |  |
| v2 shared max | 94 | 94 | PASS |  |
| G forwards | 37 | 37 | PASS |  |
| G max late | 0.47 | 0.47 | PASS |  |
| E last allow | 0.51 | 0.51 | PASS |  |
| E idp | 4.6 | 4.6 | PASS |  |
| Cload after | 629 | 629 | PASS |  |
| Cload allowed | 0 | 0 | PASS |  |
| H recovery ms | 17 | 17 | PASS |  |
| ML-DSA-65 sign median ms | 9.3 | 9.3 | PASS |  |
| CI lo | 9.2 | 9.2 | PASS |  |
| CI hi | 9.5 | 9.5 | PASS |  |
| mean ms | 10.4 | 10.4 | PASS |  |
| p99 ms | 16.3 | 16.3 | PASS |  |
| queue poisson | 39 | 39 | PASS |  |
| queue clustered | 56 | 56 | PASS |  |
| queue mmpp s | 1.6 | 1.6 | PASS |  |
| B=1 at 100/s empirical unstable | 1 | 1 | PASS |  |
| formal checks M1-M4g (of 40 total) | 32 | 32 | PASS |  |
| formal all match | 1 | 1 | PASS |  |
| M4f holds states | 250 | 250 | PASS |  |
| M4f NEG states | 63 | 63 | PASS |  |
| M4g holds states | 41 | 41 | PASS |  |
| M4g NEG states | 30 | 30 | PASS |  |
| noise FPR sigma20 gauss | 0.10 | 0.10 | PASS |  |
| noise AUC sigma0 | 0.80 | 0.80 | PASS |  |
| noise AUC sigma20 | 0.66 | 0.66 | PASS |  |
| noise f/t 0 | 0.46 | 0.46 | PASS |  |
| noise f/t 20 | 356 | 356 | PASS |  |
| mid50 FPR 5% | 0.022 | 0.022 | PASS |  |
| mid50 FPR 20% | 0.17 | 0.17 | PASS |  |
| withhold zero | 0.06 | 0.06 | PASS |  |
| withhold legit_mean | 0.07 | 0.07 | PASS |  |
| withhold reweight | 0.07 | 0.07 | PASS |  |
| withhold mid50 | 0.97 | 0.97 | PASS |  |
| intensity 70 | 20 | 20 | PASS |  |
| intensity 16 | 249 | 249 | PASS |  |
| k1 compromised | 5.3 | 5.3 | PASS |  |
| k1 CI lo | 4.4 | 4.4 | PASS |  |
| k1 CI hi | 6.2 | 6.2 | PASS |  |
| k1 contained | 79 | 79 | PASS |  |
| k2 compromised | 40.2 | 40.2 | PASS |  |
| k3 compromised | 49 | 49 | PASS |  |
| k5 compromised | 54 | 54 | PASS |  |
| stealthy/rapid min | 54.5 | 54.5 | PASS |  |
| stealthy/rapid max | 55.2 | 55.2 | PASS |  |
| stealthy/rapid contained max | 1.3 | 1.3 | PASS |  |
| propaware contained | 14 | 14 | PASS |  |
| k1 legit min 1/s | 40 | 40 | PASS |  |
| k1 legit max 1/s | 100 | 100 | PASS |  |
| k2 legit max 1/s | 0.6 | 0.6 | PASS |  |
| k2 legit max 10/s | 4.2 | 4.2 | PASS |  |
| joint both | 79.5 | 79.5 | PASS |  |
| ztas rank1 all | 1 | 1 | PASS |  |
| W min | 0.95 | 0.95 | PASS |  |
| T-J off | 24 | 24 | PASS |  |
| T-J on | 0 | 0 | PASS |  |
| T-K off | 18 | 18 | PASS |  |
| T-K on | 0 | 0 | PASS |  |
| v5 cells | 3600 | 3600 | PASS |  |
| v5 median cell diff | -0.16 | -0.16 | PASS |  |
| v5 top25 share | 61 | 61 | PASS |  |
| v5 stealthy tertile | 66.5 | 66.5 | PASS |  |
| v5 middle tertile | 75.9 | 75.9 | PASS |  |
| v5 noisy tertile | 84.3 | 84.3 | PASS |  |
| v5 topo min | 31 | 31 | PASS |  |
| v5 topo max | 92 | 92 | PASS |  |
| v5 narrow lower | 98.9 | 98.9 | PASS |  |
| v5 attacker lower | 86.7 | 86.7 | PASS |  |
| v5 baseline lower | 96.8 | 96.8 | PASS |  |
| v5 attacker adv | 63.4 | 63.4 | PASS |  |
| v5 baseline adv | 51.2 | 51.2 | PASS |  |
| v5 attacker worse | 5.8 | 5.8 | PASS |  |
| v5 tree cv acc | 0.80 | 0.80 | PASS |  |
| v5 tree cv bal | 0.71 | 0.71 | PASS |  |
| v5 majority | 0.755 | 0.755 | PASS |  |
| v5 root count | 200 | 200 | PASS |  |
| v5 S1 d_generic | -0.06 | -0.06 | PASS |  |
| v5 inter max | 0.27 | 0.27 | PASS |  |
| v5 inter 4th | 0.21 | 0.21 | PASS |  |
| v5 flag both FPR | 0.003 | 0.003 | PASS |  |
| v5 flag both TPR | 97 | 97 | PASS |  |
| v5 flag both onlyB | 22 | 22 | PASS |  |
| v5 flag any FPR | 0.098 | 0.098 | PASS |  |
| v5 flag both FPR o5 | 0.052 | 0.052 | PASS |  |
| v5 flag any FPR o5 | 0.144 | 0.144 | PASS |  |
| v5 monitor mod | 23.6 | 23.6 | PASS |  |
| v5 monitor mod lo | 21.1 | 21.1 | PASS |  |
| v5 monitor mod hi | 26.2 | 26.2 | PASS |  |
| v5 monitor burst | 26.4 | 26.4 | PASS |  |
| v5 contained | 42 | 42 | PASS |  |
| v5 graded mod | 23.6 | 23.6 | PASS |  |
| v5 graded burst | 31.1 | 31.1 | PASS |  |
| v5 alert | 6.25 | 6.25 | PASS |  |
| v5 stealthy best | 3.3 | 3.3 | PASS |  |
| v5 TJ v4 | 5 | 5 | PASS |  |
| v5 TJ v5 | 2 | 2 | PASS |  |
| v5 TJ off | 120 | 120 | PASS |  |
| v5 TJ off ms | 51 | 51 | PASS |  |
| v5 TJ max | 2.5 | 2.5 | PASS |  |
| v5 sim CIs excl 0 | 18 | 18 | PASS |  |
| v5 sim CIs < -0.05 | 16 | 16 | PASS |  |
| v5 thr 0.02 | 86 | 86 | PASS |  |
| v5 thr 0.1 | 61 | 61 | PASS |  |
| v5 thr 0.2 | 43 | 43 | PASS |  |
| v5 crypto min | 0.78 | 0.78 | PASS |  |
| v5 crypto max | 1.22 | 1.22 | PASS |  |
| v6 TLC configs (M1, M4f, M4g, M5) | 19 | 19 | PASS |  |
| v5 TLC all match | 1 | 1 | PASS |  |
| v5 attacker adv lo | 57.9 | 57.9 | PASS |  |
| v5 attacker adv hi | 69.1 | 69.1 | PASS |  |
| v5 baseline adv lo | 45.1 | 45.1 | PASS |  |
| v5 baseline adv hi | 57.4 | 57.4 | PASS |  |
| v6 M5 checks | 8 | 8 | PASS |  |
| v6 total checks | 40 | 40 | PASS |  |
| v6 M5 all match | 1 | 1 | PASS |  |
| v6 M5a states | 7,336 | 7,336 | PASS |  |
| v6 M5b states | 32 | 32 | PASS |  |
| v6 TLC M5 states match | 1 | 1 | PASS |  |
| v6 flows min | 103 | 103 | PASS |  |
| v6 flows max | 448 | 448 | PASS |  |
| v6 density min | 0.03 | 0.03 | PASS |  |
| v6 density max | 0.13 | 0.13 | PASS |  |
| v6 gate share min | 18 | 18 | PASS |  |
| v6 gate share max | 52 | 52 | PASS |  |
| v6 cv dense | 0.31 | 0.31 | PASS |  |
| v6 cv hub | 1.18 | 1.18 | PASS |  |
| v6 O reach sparse | 55 | 55 | PASS |  |
| v6 O reach others >99 | 1 | 1 | PASS |  |
| v6 stealthy share prov min | 36 | 36 | PASS |  |
| v6 stealthy share prov max | 63 | 63 | PASS |  |
| v6 stealthy share seg min | 34 | 34 | PASS |  |
| v6 stealthy share seg max | 61 | 61 | PASS |  |
| v6 stealthy share risk min | 2 | 2 | PASS |  |
| v6 stealthy share risk max | 9 | 9 | PASS |  |
| v6 stealthy removal risk min | 0.001 | 0.001 | PASS |  |
| v6 stealthy removal risk max | 0.052 | 0.052 | PASS |  |
| v6 noisy risk share min | 39 | 39 | PASS |  |
| v6 noisy risk share max | 68 | 68 | PASS |  |
| v6 noisy removal risk min | 0.01 | 0.01 | PASS |  |
| v6 noisy removal risk max | 0.34 | 0.34 | PASS |  |
| v6 noisy interaction neg CI | 9 | 9 | PASS |  |
| v6 stealthy interaction neg CI | 7 | 7 | PASS |  |
| v6 interaction dense | +0.23 | +0.23 | PASS |  |
| v6 interaction hi | +0.11 | +0.11 | PASS |  |
| v6 ref zt_prov | 0.49 | 0.49 | PASS |  |
| v6 ref P+S | 0.16 | 0.16 | PASS |  |
| v6 ref all | 0.14 | 0.14 | PASS |  |
| v6 mon gain min | 0.05 | 0.05 | PASS |  |
| v6 mon gain max | 0.15 | 0.15 | PASS |  |
| v6 mon CI excl 0 | 1 | 1 | PASS |  |
| v6 zonesmon<zt all | 1 | 1 | PASS |  |
| v6 ztprov-zonesmon min | 0.02 | 0.02 | PASS |  |
| v6 ztprov-zonesmon max | 0.18 | 0.18 | PASS |  |
| v6 ztas better every graph | 1 | 1 | PASS |  |
| v7 decrement max diff noisy | 0.013 | 0.013 | PASS |  |
| v7 decrement max diff stealthy <=0.0005 | 1 | 1 | PASS |  |
| v7 decrement all graphs favour | 1 | 1 | PASS |  |
| v7 stealthy max marginal risk <0.10 | 1 | 1 | PASS |  |
| v7 multi_org seg min | 0.06 | 0.06 | PASS |  |
| v7 multi_org seg max | 0.53 | 0.53 | PASS |  |
| v7 multi_org prov min | 0.23 | 0.23 | PASS |  |
| v7 multi_org prov max | 0.72 | 0.72 | PASS |  |
| v7 c20 median AUC diff <=0.01 | 1 | 1 | PASS |  |
| v7 uniform med AUC min | 0.65 | 0.65 | PASS |  |
| v7 uniform med AUC max | 0.93 | 0.93 | PASS |  |
| v7 prod AUC min | 0.75 | 0.75 | PASS |  |
| v7 prod AUC max | 0.99 | 0.99 | PASS |  |
| v7 noisy base TPR min | 0.67 | 0.67 | PASS |  |
| v7 noisy base TPR max | 0.76 | 0.76 | PASS |  |
| v7 mimic TPR min | 0.07 | 0.07 | PASS |  |
| v7 mimic TPR max | 0.08 | 0.08 | PASS |  |
| v7 fresh TPR min | 0.91 | 0.91 | PASS |  |
| v7 fresh TPR max | 0.98 | 0.98 | PASS |  |
| v7 fresh FPR min | 0.05 | 0.05 | PASS |  |
| v7 fresh FPR max | 0.07 | 0.07 | PASS |  |
| v7 ML-DSA-65 pk | 1952 | 1952 | PASS |  |
| v7 ML-DSA-65 sk | 4032 | 4032 | PASS |  |
| v7 ML-DSA-65 sig | 3309 | 3309 | PASS |  |
| v7 ML-KEM-768 ct | 1088 | 1088 | PASS |  |
| v7 per-record B=64 | 244 | 244 | PASS |  |
| v7 per-record B=4096 | 385 | 385 | PASS |  |
| v7 memory indistinguishable | 1 | 1 | PASS |  |
| v7 peak RSS MiB | 75 | 75 | PASS |  |
