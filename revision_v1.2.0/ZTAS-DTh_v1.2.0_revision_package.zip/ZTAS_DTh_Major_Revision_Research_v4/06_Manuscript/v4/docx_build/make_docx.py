"""Builds a Word version of the manuscript with pandoc (figures as PNG; tables inlined)."""
import re, subprocess, os
os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
s = open("main.tex").read()
ext = dict(re.findall(r"\\newlabel\{(s(?:tab|fig):[^}]*)\}\{\{([^}]*)\}", open("supplement.aux").read()))
s = re.sub(r"\\ref\{(s(?:tab|fig):[^}]*)\}", lambda m: ext[m.group(1)], s)
def unwrap(s, cmd):
    out, i = "", 0
    while True:
        j = s.find(cmd, i)
        if j < 0: return out + s[i:]
        k = j + len(cmd); depth = 1; m = k
        while depth:
            c = s[m]; depth += (c == "{") - (c == "}"); m += 1
        out += s[i:j] + s[k:m - 1]; i = m
i = s.index(r"\resizebox{\textwidth}{!}{\begin{tikzpicture}"); j = s.index(r"\end{tikzpicture}}", i) + len(r"\end{tikzpicture}}")
s = s[:i] + r"\includegraphics[width=\textwidth]{docx_build/arch.png}" + s[j:]
s = re.sub(r"\\includegraphics\[[^\]]*\]\{figs/([^}]*)\.pdf\}", lambda m: r"\includegraphics[width=6in]{docx_build/%s.png}" % m.group(1), s)
s = re.sub(r"\\input\{(tables/[^}]*)\}", lambda m: open(m.group(1) + ("" if m.group(1).endswith(".tex") else ".tex")).read(), s)
s = unwrap(s, r"\resizebox{\columnwidth}{!}{"); s = unwrap(s, r"\resizebox{\textwidth}{!}{")
def args(l, n):
    res, i = [], l.index("\\multicolumn") + len("\\multicolumn")
    for _ in range(n):
        i = l.index("{", i); d = 1; j = i + 1
        while d:
            d += (l[j] == "{") - (l[j] == "}"); j += 1
        res.append(l[i + 1:j - 1]); i = j
    return res
lines, pend, out = s.split("\n"), [], []
for l in lines:
    if re.match(r"\s*\\multicolumn\{(3|5|7|13)\}\{@\{\}", l):
        pend.append(args(l, 3)[2]); continue
    out.append(l)
    if pend and l.strip().startswith("\\end{table"):
        out.append("\n\\noindent " + " ".join(pend) + "\n"); pend = []
s = "\n".join(out)
s = s.replace(r"\multicolumn{6}{c|}{Capability (criteria in note)}", r"\multicolumn{6}{c}{Capability}").replace("{@{}l|cccccc|cccccc@{}}", "{@{}lcccccccccccc@{}}")
s = s.replace(r"\checkmark", "✓").replace(r">{\raggedright\arraybackslash}", "")
open("docx_build/main_docx.tex", "w").write(s)
r = subprocess.run(["pandoc", "docx_build/main_docx.tex", "--from=latex", "--to=docx", "--citeproc", "--bibliography=refs.bib",
                    "--csl=docx_build/ieee-min.csl", "--resource-path=.:docx_build", "-o", "docx_build/ZTAS_DTh_Revised_Manuscript.docx"], capture_output=True, text=True)
print("\n".join(l for l in r.stderr.splitlines() if "math" not in l.lower() and "fetch" not in l.lower())[:800])
import docx
d = docx.Document("docx_build/ZTAS_DTh_Revised_Manuscript.docx")
print("paras", len(d.paragraphs), "tables", len(d.tables), "images", len(d.inline_shapes))
