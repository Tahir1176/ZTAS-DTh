"""Builds supplement.tex (v4) from the moved floats and the result files (no numbers typed by hand)."""
import json, csv, os
import pandas as pd, yaml
R = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")
E = lambda *p: os.path.join(R, "01_Experiments", *p)
D = lambda *p: os.path.join(R, "02_Data", *p)
blocks = json.load(open(os.path.join(R, "06_Manuscript", "moved_blocks_v4.json")))
UMAP = {"⇒": "$\\Rightarrow$", "∋": "$\\ni$", "∧": "$\\wedge$", "Δ": "$\\Delta$", "≤": "$\\le$", "≥": "$\\ge$", "→": "$\\rightarrow$",
        "κ": "$\\kappa$", "μ": "$\\mu$", "−": "-", "×": "$\\times$", "≈": "$\\approx$", "…": "...", "–": "--", "—": "---", "′": "'", "ᵃ": ""}
def tex(x):
    x = _tex(x)
    for k, v in UMAP.items(): x = x.replace(k, v)
    return x
def _tex(x): return str(x).replace("&", "\\&").replace("%", "\\%").replace("_", "\\_").replace("#", "\\#").replace("->", "$\\rightarrow$").replace("<=", "$\\le$").replace(">=", "$\\ge$").replace("~", "$\\sim$")
out = [r"""\documentclass[journal,onecolumn]{IEEEtran}
\usepackage[T1]{fontenc}\usepackage{amsmath,amssymb}\usepackage{graphicx}\usepackage{booktabs,array,longtable}\usepackage[hidelinks]{hyperref}
\renewcommand{\thetable}{S\arabic{table}}\renewcommand{\thefigure}{S\arabic{figure}}\renewcommand{\thesection}{S\arabic{section}}
\newcommand{\ztas}{ZTAS-DTh}
\begin{document}
\title{Supplementary Material for ``ZTAS-DTh: A Lifecycle-Spanning Zero-Trust Security Architecture for the Digital Thread''}
\author{Muhammad Tahir, Waqas Ahmed, Ammar Hassan, and Imran Rashid}
\maketitle
\noindent All numbers in this supplement are generated from the archived revision package (scripts in \texttt{src/} and \texttt{01\_Experiments/}, data in \texttt{02\_Data/}). Evidence type throughout: simulation, synthetic distributions, server-CPU benchmarks and a single-host software proof of concept; none is an industrial measurement.
"""]
def sec(t): out.append("\\section{%s}\n" % t)
def strip_label(b, lab, new):
    return b.replace("\\label{%s}" % lab, "\\label{%s}" % new).replace("table*", "table").replace("figure*", "figure").replace("[!t]", "[!h]")
# ---------------- S1 moved v2 material
sec("Material moved from the main text")
for lab in ["tab:lifecycle", "tab:e1metrics", "fig:sens", "tab:risk", "tab:evidence", "fig:risk", "tab:poc", "tab:stride", "tab:e1main", "fig:abl", "fig:graphs", "fig:evtime", "fig:crypto"]:
    num, kind, b = blocks[lab]
    out.append(strip_label(b, lab, "s" + lab) + "\n")
out.append("\\clearpage\n")
# ---------------- joint sensitivity configuration
sec("Joint sensitivity: parameter ranges, rationale and regimes")
cfg = yaml.safe_load(open(E("01_Joint_Sensitivity", "joint_sensitivity_config.yaml")))
rows = ["\\begin{longtable}{@{}p{2.4cm}p{2.2cm}p{11.2cm}@{}}\\caption{Jointly varied parameters (all ranges are exploratory assumptions)}\\\\\\toprule Parameter & Range & Rationale\\\\\\midrule"]
for k, v in cfg["parameters"].items():
    rows.append(f"\\texttt{{{tex(k)}}} & [{v['range'][0]}, {v['range'][1]}] & {tex(v['rationale'])}\\\\")
rows.append("\\midrule\\multicolumn{3}{@{}p{16cm}@{}}{Regimes restrict only defensive parameters: " + "; ".join(
    f"\\emph{{{r}}}: " + ", ".join(f"\\texttt{{{tex(k)}}} {v}" for k, v in spec.items()) for r, spec in cfg["regimes"].items()) + ".}\\\\\\bottomrule\\end{longtable}")
out.append("\n".join(rows) + "\n")
gi = pd.read_csv(E("01_Joint_Sensitivity", "joint_sensitivity_global_indices.csv"))
out.append("\\begin{table}[!h]\\centering\\caption{Global sensitivity of the paired difference frac(\\ztas{}) $-$ frac(ZT+prov): Sobol indices (reference topology, Saltelli $N=256$) and PRCC (continuous LHS, nine families)}\\small\\begin{tabular}{@{}lrrrrr@{}}\\toprule Parameter & $S_1$ & 95\\% CI & $S_T$ & 95\\% CI & PRCC\\\\\\midrule")
for _, r in gi.sort_values("ST_d", ascending=False).iterrows():
    out.append(f"\\texttt{{{tex(r.parameter)}}} & {r.S1_d:.3f} & $\\pm${r.S1conf_d:.3f} & {r.ST_d:.3f} & $\\pm${r.STconf_d:.3f} & {r.PRCC_d_prov:+.3f}\\\\")
out.append("\\bottomrule\\end{tabular}\\end{table}\n")
bt = pd.read_csv(E("01_Joint_Sensitivity", "joint_sensitivity_by_topology.csv"))
out.append("\\begin{table}[!h]\\centering\\caption{Paired difference by topology and design [95\\% two-way bootstrap CI]; share of points with an advantage of at least 0.05}\\small\\begin{tabular}{@{}llrrrr@{}}\\toprule Design & Topology & ZT+prov & \\ztas{} & Difference [CI] & $\\le-0.05$\\\\\\midrule")
for _, r in bt.iterrows():
    out.append(f"{r.design} & {tex(r.topology)} & {r.ztprov:.3f} & {r.ztas:.3f} & {r.d_prov:+.3f} [{r.lo:+.3f}, {r.hi:+.3f}] & {100*r.share_points_advantage_ge_0_05:.0f}\\%\\\\")
out.append("\\bottomrule\\end{tabular}\\end{table}\n")
out.append("\\begin{figure}[!h]\\centering\\includegraphics[width=0.8\\textwidth]{figs/fig_joint_by_topology.pdf}\\caption{Paired difference per topology and regime (95\\% CIs).}\\end{figure}\n")
tree = open(E("01_Joint_Sensitivity", "joint_sensitivity_vanishing_advantage_tree.txt")).read()
out.append("\\noindent\\textbf{Vanishing-advantage tree.}\\begin{verbatim}\n" + tree + "\\end{verbatim}\n")
li = pd.read_csv(D("Processed", "joint_legitimate_impact.csv"))
g = li.groupby("design").agg(d=("d_prov", "mean"), ff=("false_iso_field_device_heavy", "mean"), fs=("false_iso_field_device_heavy", lambda x: (x > 0.01).mean()), fh=("false_iso_human_operator_gauss", "mean"))
out.append("\\begin{table}[!h]\\centering\\caption{Legitimate cost over the joint design: false isolation per 8-h shift at 1 request/s implied by each point's evidence threshold and decay (field devices: heavy-tailed scores; operators: Gaussian), next to the attack-side advantage}\\label{stab:jointlegit}\\small\\begin{tabular}{@{}lrrrr@{}}\\toprule Design & Mean difference & Field devices & Points with $>1\\%$ & Operators\\\\\\midrule")
for k, r in g.iterrows():
    out.append(f"{k} & {r.d:+.3f} & {r.ff:.4f} & {100*r.fs:.1f}\\% & {r.fh:.4f}\\\\")
c = li[li.design == "continuous"]; both = ((c.d_prov <= -0.05) & (c.false_iso_field_device_heavy <= 0.01)).mean()
out.append("\\bottomrule\\end{tabular}\\end{table}\n")
out.append(f"In the continuous design, {100*both:.1f}\\% of point--topology cells combine an advantage of at least 0.05 with at most 1\\% false isolation of field devices per shift. Static ZT and ZT+prov have no evidence rule, so their false isolation from this mechanism is zero by construction; their legitimate cost from generic monitoring is not modelled.\n")
out.append("\\begin{figure}[!h]\\centering\\includegraphics[width=0.85\\textwidth]{figs/fig_joint_legitimate_impact.pdf}\\caption{Joint design: (a) false isolation of legitimate field devices by evidence threshold and decay; (b) attack-side advantage against legitimate false isolation per point.}\\label{sfig:jointlegit}\\end{figure}\n")
rs = pd.read_csv(D("Processed", "statistics_ranking_stability.csv")); rs = rs[rs.profile == "stealthy"]
out.append("\\begin{table}[!h]\\centering\\caption{Ranking stability across the 30 graphs of each family (stealthy attacker; baselines are profile-independent, so the noisy profile gives the same rankings). $W$: Kendall's coefficient of concordance}\\label{stab:rank}\\small\\begin{tabular}{@{}lrlrr@{}}\\toprule Topology & $W$ & Modal ranking (best first) & \\ztas{} first & Zones beat ZT\\\\\\midrule")
for _, r in rs.iterrows():
    out.append(f"{tex(r.topology)} & {r.kendall_W:.3f} & {tex(r.modal_ranking.replace('ztas_rec', 'ZTAS'))} & {100*r.rank1_ztas_rec:.0f}\\% & {100*r.share_graphs_zones_beats_zt:.0f}\\%\\\\")
out.append("\\bottomrule\\end{tabular}\\end{table}\n\\clearpage\n")
# ---------------- attacker profiles and scenario mapping
sec("Adversary model: attacker profiles and scenario mapping")
ap = pd.read_csv(E("08_Attack_Model", "adversary_profiles_summary.csv"))
out.append("\\begin{table}[!h]\\centering\\caption{Mean fraction compromised by attacker profile (9 families $\\times$ 10 fresh graphs $\\times$ 20 runs)}\\small\\begin{tabular}{@{}lrrrrrrrr@{}}\\toprule Profile & Perim. & Zones & ZT & ZT+prov & \\ztas{} & Difference & Graphs $<0$ & Graphs $\\le-0.05$\\\\\\midrule")
for _, r in ap.iterrows():
    out.append(f"{tex(r.profile)} & {r.perimeter:.2f} & {r.zones:.2f} & {r.zt:.2f} & {r.zt_prov:.2f} & {r.ztas:.2f} & {r.d_prov:+.3f} & {100*r.share_graphs_ztas_better:.0f}\\% & {100*r.share_practical:.0f}\\%\\\\")
out.append("\\bottomrule\\end{tabular}\\end{table}\n")
m = pd.read_csv(E("08_Attack_Model", "attack_scenario_mapping.csv"))
out.append("{\\scriptsize\\begin{longtable}{@{}p{2.2cm}p{2.0cm}p{1.6cm}p{2.0cm}p{2.6cm}p{2.7cm}p{2.7cm}@{}}\\caption{Representative industrial attack behaviours mapped to the model (ATT\\&CK for ICS technique names; no procedures)}\\\\\\toprule Scenario & Techniques & Movement & Artifact/interface & ZTAS-DTh controls & Model representation & Model limitation\\\\\\midrule")
for _, r in m.iterrows():
    out.append(" & ".join(tex(x) for x in [r.scenario, r.attck_ics_techniques, r.lifecycle_movement, r.artifact_or_interface, r.relevant_ztas_controls, r.model_representation, r.model_limitation]) + "\\\\")
out.append("\\bottomrule\\end{longtable}}\n\\clearpage\n")
# ---------------- risk engine
sec("Risk engine: operational measurement specification, calibration and prevalence")
sp = pd.read_csv(E("02_Risk_Engine", "risk_dimension_operational_specification.csv"))
out.append("{\\scriptsize\\begin{longtable}{@{}p{1.2cm}p{2.6cm}p{2.0cm}p{2.4cm}p{2.0cm}p{2.0cm}p{2.0cm}p{1.9cm}@{}}\\caption{Proposed operational specification of the risk dimensions (a deployment specification, not a measurement)}\\\\\\toprule Dimension & Signals & Source & Normalisation & Noise & Missing data & Manipulation & Calibration\\\\\\midrule")
for _, r in sp.iterrows():
    out.append(" & ".join(tex(x) for x in [r.dimension, r.observable_signals, r.data_source, r.normalisation_method, r.noise_sources, r.missing_data_problem, r.attacker_manipulation, r.calibration_requirement]) + "\\\\")
out.append("\\bottomrule\\end{longtable}}\n")
proto = open(E("02_Risk_Engine", "risk_calibration_protocol.md")).read()
out.append("\\subsection*{Proposed calibration protocol (not executed)}\n\\begin{itemize}\n" + "\n".join(
    "\\item " + tex(l.strip().lstrip("#").strip()) for l in proto.splitlines() if l.startswith("## ")) + "\n\\end{itemize}\nThe full protocol is in \\texttt{01\\_Experiments/risk\\_engine/risk\\_calibration\\_protocol.md}.\n")
pm = pd.read_csv(D("Processed", "risk_engine", "risk_engine_processed.csv"))
x = pm[(pm.tier == "step_up")]
out.append("{\\scriptsize\\begin{longtable}{@{}lrrrrrrrr@{}}\\caption{Step-up tier ($\\theta_1=30$) by family, attacker mean and prevalence ($10^5$ draws per class)}\\\\\\toprule Family & $\\mu_{mal}$ & Prev. & TPR & FPR & Precision & PR-AUC & False esc./$10^5$ & False per true\\\\\\midrule")
for _, r in x.iterrows():
    out.append(f"{tex(r.family)} & {r.mu_mal:.0f} & {100*r.prevalence:g}\\% & {r.TPR:.3f} & {r.FPR:.4f} & {r.precision:.3f} & {r.PR_AUC:.3f} & {r.false_alerts_per_1e5:.0f} & {r.false_alerts_per_true_alert:.2f}\\\\")
out.append("\\bottomrule\\end{longtable}}\n\\clearpage\n")
rb = pd.read_csv(D("Processed", "risk_engine_robustness", "risk_engine_robustness.csv"))
out.append("{\\scriptsize\\begin{longtable}{@{}llrrlrrrr@{}}\\caption{Risk-engine robustness (step-up tier $\\theta_1=30$): measurement noise ($\\sigma$), missing components ($q$, by imputation rule), adversarial withholding of the behavioural and system components ($q_a$), and attack intensity ($\\mu_{mal}$)}\\label{stab:riskrob}\\\\\\toprule Study & Family & $\\mu_{mal}$ & Level & Rule & TPR & FPR & ROC-AUC & False/true at 0.1\\%\\\\\\midrule")
for _, r in rb.iterrows():
    out.append(f"{r.study} & {tex(r.family)} & {r.mu_mal:.0f} & {r.level:g} & {tex(r.rule)} & {r.TPR:.3f} & {r.FPR:.4f} & {r.ROC_AUC:.3f} & {r.false_per_true_0_001 if False else r['false_per_true_0.001']:.1f}\\\\")
out.append("\\bottomrule\\end{longtable}}\n\\begin{figure}[!h]\\centering\\includegraphics[width=0.9\\textwidth]{figs/fig_risk_robustness.pdf}\\caption{Risk-engine robustness to noise, missing data, adversarial withholding and attack intensity.}\\label{sfig:riskrob}\\end{figure}\n\\clearpage\n")
# ---------------- evidence policy extension
sec("Evidence policies: threshold sensitivity and alternative responses")
ev = pd.read_csv(D("Processed", "evidence_policy_extension_summary.csv"))
lab = {"kappa1_decay": "$\\kappa=1$", "kappa2_decay": "$\\kappa=2$", "kappa3_decay": "$\\kappa=3$ (revised)", "kappa4_decay": "$\\kappa=4$", "kappa5_decay": "$\\kappa=5$",
       "revised_approval0s": "revised, approval 0 s", "revised_approval30s": "revised, approval 30 s", "revised_approval600s": "revised, approval 600 s",
       "emergency_isolation": "emergency isolation", "safe_state": "safe state", "propagation_aware": "propagation-aware"}
out.append("{\\scriptsize\\begin{longtable}{@{}llrrrr@{}}\\caption{Evidence-policy extension at 1000 requests/s (risk-only configuration; 10 graphs $\\times$ 30 runs; common random numbers). All policies use per-evaluation decay and outage awareness}\\label{stab:evx}\\\\\\toprule Profile & Policy & Compromised (of 56) [95\\% CI] & Contained before $\\mathsf{O}$ & Median $t$ to containment (s) & Median requests\\\\\\midrule")
order = list(lab)
for pr in ["moderate", "burst", "stealthy", "rapid_multistep"]:
    for pol in order:
        r = ev[(ev.profile == pr) & (ev.rate == 1000) & (ev.policy == pol)].iloc[0]
        ci = [r.ci_compromised_lo, r.ci_compromised_hi]
        t = "--" if pd.isna(r.median_t_containment_s) else f"{r.median_t_containment_s:.3f}"; q = "--" if pd.isna(r.median_requests_before_containment) else f"{r.median_requests_before_containment:.0f}"
        out.append(f"{tex(pr)} & {lab[pol]} & {r.mean_compromised:.1f} [{ci[0]:.1f}, {ci[1]:.1f}] & {r.p_contained_before_O:.3f} & {t} & {q}\\\\")
out.append("\\bottomrule\\end{longtable}}\n")
lw = pd.read_csv(D("Processed", "evidence_policy_extension_legitimate_wide.csv"))
out.append("\\begin{table}[!h]\\centering\\caption{Legitimate false isolation per 8-h shift by evidence threshold (2000 entities per cell; propagation-aware assumes the top out-degree quartile uses $\\kappa=2$)}\\label{stab:evxlegit}\\small\\begin{tabular}{@{}llrrrrrr@{}}\\toprule Class & Scores & Rate & $\\kappa=1$ & $\\kappa=2$ & $\\kappa=3$ & $\\kappa\\ge4$ & Prop.-aware\\\\\\midrule")
for _, r in lw.iterrows():
    out.append(f"{tex(r.cls)} & {tex(r.scenario)} & {r.rate:g} & {r.kappa1_decay:.4f} & {r.kappa2_decay:.4f} & {r.kappa3_decay:.4f} & {max(r.kappa4_decay, r.kappa5_decay):.4f} & {r.propagation_aware:.4f}\\\\")
out.append("\\bottomrule\\end{tabular}\\end{table}\n\\begin{figure}[!h]\\centering\\includegraphics[width=0.9\\textwidth]{figs/fig_evidence_policy_extension.pdf}\\caption{Evidence-policy extension: (a) mean compromised entities by policy and attacker profile; (b) legitimate false isolation by threshold.}\\label{sfig:evx}\\end{figure}\n\\clearpage\n")
# ---------------- formal
sec("Formal analysis: assurance boundary and property map")
out.append("\\begin{figure}[!h]\\centering\\includegraphics[width=\\textwidth]{figs/formal_assurance_boundary.pdf}\\caption{Assurance boundary: trusted, modelled, implemented, tested and unverified components.}\\end{figure}\n")
pmap = pd.read_csv(E("04_Formal_Assurance", "property_map_v4.csv"))
out.append("{\\scriptsize\\begin{longtable}{@{}p{1.3cm}p{2.6cm}p{1.6cm}p{1.6cm}p{2.4cm}p{2.3cm}p{1.6cm}p{2.4cm}@{}}\\caption{Property, enforcement, bound and evidence map (v4)}\\label{stab:pmap}\\\\\\toprule Property & Statement & Component & Models & Bounds & PoC tests & Status & Limitations\\\\\\midrule")
for _, r in pmap.iterrows():
    out.append(" & ".join(tex(x) for x in [r.property + " " + r["name"], r.formal_statement, r.enforcing_component, r.models, r.bounds, r.implementation_tests, r.status, r.limitations]) + "\\\\")
out.append("\\bottomrule\\end{longtable}}\n\\clearpage\n")
# ---------------- PoC
sec("Proof of concept: request sequence, component mapping and concurrency measurements")
out.append("\\begin{figure}[!h]\\centering\\includegraphics[width=0.95\\textwidth]{figs/poc_sequence_diagram.pdf}\\caption{Request sequence in the v3 proof of concept (editable Mermaid source in the package).}\\end{figure}\n")
pc = pd.read_csv(E("05_POC_Integration", "poc_concurrency_processed.csv"))
out.append("{\\scriptsize\\begin{longtable}{@{}llrrrrrrr@{}}\\caption{Concurrency test T-A (120 requests per client; single run per configuration)}\\\\\\toprule Run & Kind & Clients & Throughput (req/s) & p50 (ms) & p95 & p99 & Failure rate & PEP CPU (s)\\\\\\midrule")
for _, r in pc.iterrows():
    out.append(f"{tex(r.run)} & {r.kind} & {r.concurrency} & {r.throughput_rps:.0f} & {r.p50_ms:.2f} & {r.p95_ms:.2f} & {r.p99_ms:.2f} & {r.failure_rate:.3f} & {r.pep_cpu_s:.2f}\\\\")
out.append("\\bottomrule\\end{longtable}}\nThe v2-control \\emph{plain} rows are invalid: the run outlasted the 300-s token lifetime (timeouts caused by the shared-client defect), so the remaining requests were denied as expired.\n")
rt = pd.read_csv(E("05_POC_Integration", "poc_race_tests_v4.csv"))
out.append("\\begin{table}[!h]\\centering\\caption{Check-to-enforce race tests (v4 PEP with and without enforcement-time re-check; the harness injects a 50-ms delay between authorisation and forwarding)}\\label{stab:race}\\small\\begin{tabular}{@{}llrrrr@{}}\\toprule Test & Variant & Rounds & Requests & Unsafe forwards & Max. lateness (ms)\\\\\\midrule")
for _, r in rt.iterrows():
    out.append(f"{tex(r.test)} & {tex(r.variant)} & {r.rounds} & {r.requests} & {r.unsafe_forwards} & {r.max_lateness_ms:.1f}\\\\")
out.append("\\bottomrule\\end{tabular}\\end{table}\n")
cr = pd.read_csv(E("05_POC_Integration", "poc_concurrency_repeats_v4.csv"))
g = cr.groupby(["variant", "kind", "clients"]).agg(t=("thr", "mean"), ts=("thr", "std"), p=("p50", "mean"), ps=("p50", "std"), q=("p99", "mean"), f=("fail", "max")).reset_index()
out.append("{\\scriptsize\\begin{longtable}{@{}llrrrrr@{}}\\caption{T-A repeated three times with the v4 PEP: mean (SD) over repetitions}\\label{stab:tarep}\\\\\\toprule Re-check & Kind & Clients & Throughput (req/s) & p50 (ms) & p99 (ms) & Max. failure rate\\\\\\midrule")
for _, r in g.iterrows():
    out.append(f"{tex(r.variant)} & {r.kind} & {r.clients} & {r.t:.0f} ({r.ts:.0f}) & {r.p:.2f} ({r.ps:.2f}) & {r.q:.1f} & {r.f:.3f}\\\\")
out.append("\\bottomrule\\end{longtable}}\n\\clearpage\n")
# ---------------- crypto
sec("Cryptographic benchmark re-analysis and queueing")
cs = pd.read_csv(D("Processed", "crypto", "crypto_summary_recomputed.csv"))
cs = cs[~cs.op.str.contains("proof_|merkle_tree_|batch_sig_ver_(?:1|4|16|256|1024|4096)$|keygen", regex=True)]
out.append("{\\scriptsize\\begin{longtable}{@{}lrrrrrrr@{}}\\caption{Re-computed statistics from the raw v2 samples ($\\mu$s; median CI by 2000 bootstrap resamples)}\\\\\\toprule Operation & $n$ & Median & 95\\% CI & Mean & p95 & p99 & Far outliers\\\\\\midrule")
for _, r in cs.iterrows():
    out.append(f"{tex(r.op)} & {r.n} & {r.median_us:.1f} & [{r.median_ci_lo:.1f}, {r.median_ci_hi:.1f}] & {r.mean_us:.1f} & {r.p95_us:.1f} & {r.p99_us:.1f} & {r.far_outliers}\\\\")
out.append("\\bottomrule\\end{longtable}}\n")
q = pd.read_csv(D("Processed", "crypto", "queueing_reanalysis.csv"))
s2 = q[(q.timeout_ms == 100) & (q.service == "empirical") & (q.batch.isin([1, 16, 64, 256]))].pivot_table(index=["arrivals", "rate"], columns="batch", values="p99_ms")
out.append("\\begin{table}[!h]\\centering\\caption{Modelled 99th-percentile signing latency (ms), $\\tau_b=100$ ms, empirical service times; ``unst.'' = signer unstable}\\small\\begin{tabular}{@{}llrrrr@{}}\\toprule Arrivals & Rate (rec/s) & $B=1$ & $B=16$ & $B=64$ & $B=256$\\\\\\midrule")
st = q[(q.timeout_ms == 100) & (q.service == "empirical")].set_index(["arrivals", "rate", "batch"]).stable
for (a, rt), row in s2.iterrows():
    cells = [("unst." if not st[(a, rt, b)] else f"{row[b]:.0f}") for b in [1, 16, 64, 256]]
    out.append(f"{a} & {rt} & " + " & ".join(cells) + "\\\\")
out.append("\\bottomrule\\end{tabular}\\end{table}\n\\clearpage\n")
# ---------------- reproducibility
sec("Reproducibility")
rp = E("09_Reproducibility", "reproduction_checklist.csv")
if os.path.exists(rp):
    c = pd.read_csv(rp)
    out.append("{\\scriptsize\\begin{longtable}{@{}p{3.2cm}p{3.4cm}p{2.6cm}p{6.2cm}@{}}\\caption{Reproduction of principal results from a clean checkout of release v1.0.0 and from the revision package}\\\\\\toprule Experiment & Source script & Status & Result of reproduction\\\\\\midrule")
    for _, r in c.iterrows():
        out.append(f"{tex(r.experiment)} & {tex(r.source_script)} & {tex(r.status)} & {tex(r.reproduced)}\\\\")
    out.append("\\bottomrule\\end{longtable}}\n")
rr = pd.concat([pd.read_csv(E("09_Reproducibility", "rerun_subset_joint_v4.csv")).rename(columns={"unit": "task"}).assign(task=lambda d: "joint " + d.task), pd.read_csv(E("09_Reproducibility", "rerun_subset_other_v4.csv"))])
out.append("\\begin{table}[!h]\\centering\\caption{Deterministic re-execution of archived tasks from scratch (v4)}\\label{stab:rerun}\\small\\begin{tabular}{@{}lrrr@{}}\\toprule Task & Rows & Max. abs. difference & Within $10^{-9}$\\\\\\midrule")
for _, r in rr.iterrows():
    out.append(f"{tex(r.task)} & {r.rows_matched} & {r.max_abs_diff:.1e} & {'yes' if r['within_1e-9'] else 'no'}\\\\")
out.append("\\bottomrule\\end{tabular}\\end{table}\nNon-zero differences arise only from writing floating-point values to CSV text and reading them back.\n")
out.append("\\end{document}\n")
open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "supplement.tex"), "w").write("\n".join(out))
print("ok")
