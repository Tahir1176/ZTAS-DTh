"""Checks every principal number quoted in the manuscript against the output files (concern 10, Task 10.4).
Writes NUMBER_CHECK.md. A check passes when the file value, rounded as printed, equals the manuscript value
and the manuscript string occurs in main.tex."""
import os, json, re
import pandas as pd, numpy as np
R = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
J = lambda *p: os.path.join(R, *p)
tex = open(J("06_Manuscript", "v4", "main.tex")).read()
rows = []
def chk(name, value, printed, fmt, text_snippet=None):
    ok_num = (fmt.format(value) == printed)
    ok_txt = True if text_snippet is None else (text_snippet in tex)
    rows.append((name, printed, fmt.format(value), "PASS" if ok_num and ok_txt else "FAIL", "" if ok_txt else "snippet not found"))
# ---- joint sensitivity
js = pd.read_csv(J("01_Experiments/01_Joint_Sensitivity/joint_sensitivity_results.csv")).set_index("design")
c = js.loc["continuous"]; a = js.loc["adverse"]
chk("cells ZTAS<ZT+prov (continuous)", 100 * c.share_cells_ztas_lower_than_ztprov, "96.7", "{:.1f}", "96.7\\%")
chk("cells advantage>=0.05", 100 * c["share_cells_advantage_ge_0.05"], "75.5", "{:.1f}", "75.5\\%")
chk("cells worse by >=0.01", 100 * c["share_cells_ztas_worse_by_ge_0.01"], "1.2", "{:.1f}", "1.2\\%")
chk("continuous mean diff", c.d_prov_mean, "-0.23", "{:.2f}", "$-0.23$ $[-0.25,-0.21]$")
chk("continuous CI lo", c.d_prov_lo, "-0.25", "{:.2f}")
chk("continuous CI hi", c.d_prov_hi, "-0.21", "{:.2f}")
chk("adverse mean diff", a.d_prov_mean, "-0.12", "{:.2f}", "$-0.12$ $[-0.15,-0.10]$")
chk("adverse CI lo", a.d_prov_lo, "-0.15", "{:.2f}"); chk("adverse CI hi", a.d_prov_hi, "-0.10", "{:.2f}")
chk("adverse ZTAS rank1", 100 * a.share_cells_ztas_rank1, "44", "{:.0f}", "only 44\\% of cells")
chk("adverse ZTAS frac", a.frac_ztas, "0.62", "{:.2f}", "lost 62\\%")
chk("containment diff (continuous)", c.d_prov_contained_mean, "0.20", "{:.2f}", "Containment rose by 0.20")
chk("reach_O diff (continuous)", -c.d_prov_reach_O_mean, "0.23", "{:.2f}", "fell by 0.23")
for d, cols in [("optimistic", ["0.40", "0.18", "0.03", "99.5", "62.9"]), ("moderate", ["0.74", "0.44", "0.21", "98.5", "80.7"]),
                ("adverse", ["0.90", "0.74", "0.62", "80.8", "55.9"]), ("continuous", ["0.68", "0.48", "0.25", "96.7", "75.5"])]:
    r = js.loc[d]
    for v, p, f in zip([r.frac_zt, r.frac_zt_prov, r.frac_ztas, 100 * r.share_cells_ztas_lower_than_ztprov, 100 * r["share_cells_advantage_ge_0.05"]], cols, ["{:.2f}"] * 3 + ["{:.1f}"] * 2):
        chk(f"Table joint {d}", v, p, f)
gi = pd.read_csv(J("01_Experiments/01_Joint_Sensitivity/joint_sensitivity_global_indices.csv")).set_index("parameter")
for par, p in [("p_act", "0.35"), ("p_exploit", "0.30"), ("mu_mal", "0.29"), ("p_auth", "0.22"), ("d_generic", "0.22"), ("f_art", "0.19"), ("p_v", "0.13"), ("stepup_fail", "0.13"), ("kappa", "0.06")]:
    chk(f"Sobol ST {par}", gi.loc[par, "ST_d"], p, "{:.2f}")
chk("sum S1", gi.S1_d.sum(), "0.4", "{:.1f}"); chk("sum ST", gi.ST_d.sum(), "1.9", "{:.1f}")
tree = open(J("01_Experiments/01_Joint_Sensitivity/joint_sensitivity_vanishing_advantage_tree.txt")).read()
chk("tree accuracy", float(re.search(r"training accuracy ([0-9.]+)", tree).group(1)), "0.82", "{:.2f}", "accuracy 0.82")
bt = pd.read_csv(J("01_Experiments/01_Joint_Sensitivity/joint_sensitivity_by_topology.csv")).set_index(["design", "topology"])
chk("by topology dense", bt.loc[("continuous", "dense"), "d_prov"], "-0.32", "{:.2f}"); chk("by topology sparse", bt.loc[("continuous", "sparse"), "d_prov"], "-0.04", "{:.2f}")
# ---- adversary profiles
ap = pd.read_csv(J("01_Experiments/08_Attack_Model/adversary_profiles_summary.csv")).set_index("profile")
for prof, z, zp in [("noisy", "0.04", "0.40"), ("stealthy", "0.14", "0.40"), ("insider_cred", "0.28", "0.49"), ("rapid", "0.31", "0.57"), ("coordinated", "0.31", "0.65")]:
    chk(f"profile {prof} ZTAS", ap.loc[prof, "ztas"], z, "{:.2f}"); chk(f"profile {prof} ZT+prov", ap.loc[prof, "zt_prov"], zp, "{:.2f}")
chk("profile practical min", 100 * ap.share_practical.min(), "84", "{:.0f}"); chk("profile practical max", 100 * ap.share_practical.max(), "94", "{:.0f}")
# ---- statistics
st = pd.read_csv(J("02_Data/Processed/statistics_paired_by_topology.csv"))
s = st[(st.metric == "frac") & (st.profile == "stealthy") & (st.baseline == "zt_prov")].set_index("topology")
chk("sparse share practical", 100 * s.loc["sparse", "share_graphs_practical"], "20", "{:.0f}"); chk("multi_org share practical", 100 * s.loc["multi_org", "share_graphs_practical"], "67", "{:.0f}")
chk("multi_org diff", -s.loc["multi_org", "mean_diff"], "0.07", "{:.2f}"); chk("sparse diff", -s.loc["sparse", "mean_diff"], "0.04", "{:.2f}")
chk("dense diff", -s.loc["dense", "mean_diff"], "0.40", "{:.2f}"); chk("feedback diff (lower end 0.32)", -s.loc["feedback_loop", "mean_diff"], "0.32", "{:.2f}")
chk("ICC min", 100 * s.icc_between.min(), "2", "{:.0f}"); chk("ICC max", 100 * s.icc_between.max(), "9", "{:.0f}")
chk("rel min", -100 * s.relative_change.max(), "51", "{:.0f}"); chk("rel max", -100 * s.relative_change.min(), "72", "{:.0f}")
chk("dz min", s.d_z.max(), "-1.6", "{:.1f}"); chk("dz max", s.d_z.min(), "-5.9", "{:.1f}")
# ---- risk engine
pm = pd.read_csv(J("02_Data/Processed/risk_engine/risk_engine_processed.csv"))
q = pm[(pm.tier == "step_up") & (pm.prevalence == 0.001)].set_index(["family", "mu_mal"])
chk("heavy 55 false/true", q.loc[("heavy_tailed", 55), "false_alerts_per_true_alert"], "26", "{:.0f}", "26--94 escalations")
chk("heavy 28 false/true", q.loc[("heavy_tailed", 28), "false_alerts_per_true_alert"], "94", "{:.0f}")
sub = q.loc[[("skewed", 55), ("skewed", 28), ("heavy_tailed", 55), ("heavy_tailed", 28), ("correlated", 55), ("correlated", 28)]]
chk("16-94 lower", sub.false_alerts_per_true_alert.min(), "16", "{:.0f}", "16--94 escalations were false")
chk("precision max (1-6%)", 100 * sub.precision.max(), "6", "{:.0f}"); chk("precision min", 100 * sub.precision.min(), "1", "{:.0f}")
chk("false step-ups lower", (sub.false_alerts_per_1e5.min() // 100) * 100, "1200", "{:.0f}"); chk("false step-ups upper", round(sub.false_alerts_per_1e5.max(), -2), "1700", "{:.0f}")
cal = pd.read_csv(J("02_Data/Processed/risk_engine/risk_engine_calibration.csv"))
chk("ECE in-condition", cal[cal.in_calibration_condition].ECE.iloc[0], "0.003", "{:.3f}")
o = cal[(cal.prevalence == 0.01) & ~cal.in_calibration_condition & ~cal.family.isin(["gaussian", "overlapping"])]
chk("ECE other min", o.ECE.min(), "0.014", "{:.3f}"); chk("ECE other max", o.ECE.max(), "0.029", "{:.3f}")
o2 = cal[(cal.prevalence == 0.2)]; chk("ECE 20% min", o2.ECE.min(), "0.04", "{:.2f}"); chk("ECE 20% max", o2.ECE.max(), "0.18", "{:.2f}")
th = pd.read_csv(J("02_Data/Processed/risk_engine/risk_engine_thresholds.csv"))
h = th[(th.family == "heavy_tailed") & (th.mu_mal == 28) & (th.scenario == "fp_costly")].set_index("prevalence").opt_threshold
chk("threshold heavy fp 0.1%", h.loc[0.001], "64.5", "{:.1f}"); chk("threshold heavy fp 20%", h.loc[0.2], "14.0", "{:.1f}")
b = th[(th.scenario == "budget_10_per_1e5") & (th.prevalence == 0.01)].set_index(["family", "mu_mal"]).opt_threshold
chk("budget10 gaussian", b.loc[("gaussian", 28)], "30.0", "{:.1f}"); chk("budget10 heavy", b.loc[("heavy_tailed", 28)], "52.0", "{:.1f}")
# ---- evidence
ev = pd.read_csv(J("02_Data/Processed/evidence_accumulation_processed.csv"))
e = ev[(ev.cfg == "risk_only") & (ev.profile == "moderate") & (ev.rate == 10)].set_index("policy")
for pol, cb, nc, rq in [("original_k2", "0.43", "25.2", "30.0"), ("revised_k3_decay", "0.11", "49.0", "62.5"), ("alt_k3_nodecay", "0.23", "40.2", "45.5"),
                        ("time_decay_k3", "0.11", "49.0", "62.5"), ("criticality_aware", "0.11", "48.1", "62.5")]:
    chk(f"evidence {pol} contained_before_O", e.loc[pol, "contained_before_O"], cb, "{:.2f}")
    chk(f"evidence {pol} compromised", e.loc[pol, "n_compromised"], nc, "{:.1f}")
    chk(f"evidence {pol} requests", e.loc[pol, "requests_before_containment_median"], rq, "{:.1f}")
m1 = ev[(ev.cfg == "risk_only") & (ev.profile == "moderate") & (ev.policy == "revised_k3_decay")].set_index("rate").t_first_response_median_s
chk("first response r=1", m1.loc[1], "78", "{:.0f}"); chk("first response r=1000", m1.loc[1000], "0.08", "{:.2f}")
lo = ev[(ev.cfg == "risk_only") & (ev.profile == "low_intensity") & (ev.rate == 1) & (ev.policy == "time_decay_k3")].iloc[0]
chk("low-intensity time decay contained", lo.contained, "0.00", "{:.2f}")
f = ev[(ev.cfg == "full") & (ev.rate == 10)].set_index(["profile", "policy"]).contained
chk("full moderate original", 100 * f.loc[("moderate", "original_k2")], "58", "{:.0f}"); chk("full moderate revised", 100 * f.loc[("moderate", "revised_k3_decay")], "35", "{:.0f}")
chk("full stealthy original", 100 * f.loc[("stealthy", "original_k2")], "25", "{:.0f}"); chk("full stealthy revised", 100 * f.loc[("stealthy", "revised_k3_decay")], "21", "{:.0f}")
pc = pd.read_csv(J("01_Experiments/03_Evidence_Accumulation/evidence_policy_paired_comparison.csv")).set_index(["profile", "rate", "policy"])
chk("paired original vs revised", pc.loc[("moderate", 10, "original_k2"), "mean_diff_n_compromised"], "-23.8", "{:.1f}")
chk("paired crit vs revised", pc.loc[("moderate", 10, "criticality_aware"), "mean_diff_n_compromised"], "-0.84", "{:.2f}")
leg = pd.read_csv(J("02_Data/Processed/evidence_accumulation_legitimate.csv"))
x = leg[(leg.scenario == "heavy_tailed") & (leg.cls == "field_device") & (leg.rate == 1.0)].set_index("policy").false_isolation_per_shift
chk("legit original", x.loc["original_k2"], "0.9995", "{:.4f}"); chk("legit alt", x.loc["alt_k3_nodecay"], "0.89", "{:.2f}")
o = leg[leg.policy == "original_k2"].false_isolation_per_shift
chk("legit original min", 100 * o.min(), "15", "{:.0f}"); chk("legit original max", 100 * o.max(), "100", "{:.0f}")
# ---- PoC
P = lambda n: json.load(open(J("01_Experiments/05_POC_Integration/raw", n)))["result"]
A = P("A_v3_window1024.json")
chk("PoC artifact c1 p50", A["artifact_c1"]["latency_all"]["median_ms"], "2.3", "{:.1f}"); chk("PoC artifact c1 p99", A["artifact_c1"]["latency_all"]["p99_ms"], "11.6", "{:.1f}")
chk("PoC artifact c16 p50", A["artifact_c16"]["latency_all"]["median_ms"], "27.6", "{:.1f}"); chk("PoC artifact c16 p99", A["artifact_c16"]["latency_all"]["p99_ms"], "58", "{:.0f}")
chk("PoC artifact sat", round(max(v["throughput_rps"] for k, v in A.items() if k.startswith("artifact")), -1), "560", "{:.0f}")
chk("PoC plain sat", round(max(v["throughput_rps"] for k, v in A.items() if k.startswith("plain")), -1), "930", "{:.0f}")
S = P("A_strict_replay_only.json")
chk("strict c2", 100 * S["artifact_c2"]["failure_rate"], "18", "{:.0f}"); chk("strict c16", 100 * S["artifact_c16"]["failure_rate"], "77", "{:.0f}")
V = P("A_v2control.json")
chk("v2 shared min", 100 * min(V[f"artifact_c{c}"]["failure_rate"] for c in [2, 4, 8, 16]), "51", "{:.0f}"); chk("v2 shared max", 100 * max(V[f"artifact_c{c}"]["failure_rate"] for c in [2, 4, 8, 16]), "94", "{:.0f}")
G = P("G_noRevalidate.json"); chk("G forwards", G["total_forwarded_after_ack"], "37", "{:d}"); chk("G max late", max(r["max_lateness_s"] for r in G["rounds"]), "0.47", "{:.2f}")
E_ = P("E_v3.json"); chk("E last allow", E_["revocation"]["last_allow_after_revocation_s"], "0.51", "{:.2f}"); chk("E idp", E_["idp_outage"]["first_non_allow_after_s"], "4.6", "{:.1f}")
C_ = P("Cload_v3.json"); chk("Cload after", C_["completed_after_stop"], "629", "{:d}"); chk("Cload allowed", C_["allowed_after_stop"], "0", "{:d}")
H_ = P("H_v3.json"); chk("H recovery ms", 1000 * H_["recovery_time_s"], "17", "{:.0f}")
# ---- crypto
cs = pd.read_csv(J("02_Data/Processed/crypto/crypto_summary_recomputed.csv")).set_index("op")
r = cs.loc["ML-DSA-65_sign"]
chk("ML-DSA-65 sign median ms", r.median_us / 1000, "9.3", "{:.1f}"); chk("CI lo", r.median_ci_lo / 1000, "9.2", "{:.1f}"); chk("CI hi", r.median_ci_hi / 1000, "9.5", "{:.1f}")
chk("mean ms", r.mean_us / 1000, "10.4", "{:.1f}"); chk("p99 ms", r.p99_us / 1000, "16.3", "{:.1f}")
qq = pd.read_csv(J("02_Data/Processed/crypto/queueing_reanalysis.csv"))
w = qq[(qq.rate == 10000) & (qq.batch == 256) & (qq.timeout_ms == 100) & (qq.service == "empirical")].set_index("arrivals").p99_ms
chk("queue poisson", w.loc["poisson"], "39", "{:.0f}"); chk("queue clustered", w.loc["clustered"], "56", "{:.0f}"); chk("queue mmpp s", w.loc["mmpp"] / 1000, "1.6", "{:.1f}")
u = qq[(qq.rate == 100) & (qq.batch == 1) & (qq.timeout_ms == 100) & (qq.arrivals == "poisson")].set_index("service").stable
chk("B=1 at 100/s empirical unstable", float(not u.loc["empirical"]), "1", "{:.0f}")
# ---- formal
fm = json.load(open(J("src/formal/logs/model_check_v3_results.json"))); f0 = json.load(open(J("src/formal/logs/model_check_results_rerun.json")))
f4 = json.load(open(J("src/formal/logs/model_check_v4_results.json")))
chk("formal total checks", len(fm) + len(f0) + len(f4), "32", "{:d}", "all 32 checks"); chk("formal all match", float(all(x["matches_expectation"] for x in fm + f0 + f4)), "1", "{:.0f}")
st = {(x["model"], x["config"][:3] == "NEG"): x["states"] for x in f4}
chk("M4f holds states", st[("M4f", False)], "250", "{:d}", "M4f & Segment expiry in flight; re-check at enforcement (P1) & 250"); chk("M4f NEG states", st[("M4f", True)], "63", "{:d}")
chk("M4g holds states", st[("M4g", False)], "41", "{:d}"); chk("M4g NEG states", st[("M4g", True)], "30", "{:d}")
# ---- v4: risk robustness
rb = pd.read_csv(J("02_Data/Processed/risk_engine_robustness/risk_engine_robustness.csv"))
g = lambda **k: rb[np.logical_and.reduce([rb[a] == b for a, b in k.items()])].iloc[0]
chk("noise FPR sigma20 gauss", g(study="noise", family="gaussian", mu_mal=28, level=20).FPR, "0.10", "{:.2f}", "rose from $5\\times10^{-5}$ to 0.10")
chk("noise AUC sigma0", g(study="noise", family="gaussian", mu_mal=28, level=0).ROC_AUC, "0.80", "{:.2f}", "fell from 0.80 to 0.66")
chk("noise AUC sigma20", g(study="noise", family="gaussian", mu_mal=28, level=20).ROC_AUC, "0.66", "{:.2f}")
chk("noise f/t 0", g(study="noise", family="gaussian", mu_mal=28, level=0)["false_per_true_0.001"], "0.46", "{:.2f}", "rose from 0.46 to 356")
chk("noise f/t 20", g(study="noise", family="gaussian", mu_mal=28, level=20)["false_per_true_0.001"], "356", "{:.0f}")
chk("mid50 FPR 5%", g(study="missing", family="gaussian", mu_mal=28, level=0.05, rule="mid50").FPR, "0.022", "{:.3f}", "raised the FPR to 0.022")
chk("mid50 FPR 20%", g(study="missing", family="gaussian", mu_mal=28, level=0.2, rule="mid50").FPR, "0.17", "{:.2f}", "to 0.17 when 20")
for r_, v in [("zero", "0.06"), ("legit_mean", "0.07"), ("reweight", "0.07")]:
    chk(f"withhold {r_}", g(study="withholding", family="gaussian", mu_mal=55, level=0.9, rule=r_).TPR, v, "{:.2f}", "TPR fell to 0.06--0.07")
chk("withhold mid50", g(study="withholding", family="gaussian", mu_mal=55, level=0.9, rule="mid50").TPR, "0.97", "{:.2f}", "against 0.97 under mid-scale")
chk("intensity 70", g(study="intensity", family="heavy_tailed", mu_mal=70)["false_per_true_0.001"], "20", "{:.0f}", "from 20 ($\\mu_{mal}=70$) to 249")
chk("intensity 16", g(study="intensity", family="heavy_tailed", mu_mal=16)["false_per_true_0.001"], "249", "{:.0f}")
# ---- v4: evidence extension
ev = pd.read_csv(J("02_Data/Processed/evidence_policy_extension_summary.csv")); ev = ev[ev.rate == 1000].set_index(["profile", "policy"])
m = lambda pr, po: ev.loc[(pr, po)]
chk("k1 compromised", m("moderate", "kappa1_decay").mean_compromised, "5.3", "{:.1f}", "compromised 5.3 entities [4.4, 6.2]")
chk("k1 CI lo", m("moderate", "kappa1_decay").ci_compromised_lo, "4.4", "{:.1f}"); chk("k1 CI hi", m("moderate", "kappa1_decay").ci_compromised_hi, "6.2", "{:.1f}")
chk("k1 contained", 100 * m("moderate", "kappa1_decay").p_contained_before_O, "79", "{:.0f}", "operations in 79\\% of runs")
chk("k2 compromised", m("moderate", "kappa2_decay").mean_compromised, "40.2", "{:.1f}", "compromised 40.2 entities")
chk("k3 compromised", m("moderate", "kappa3_decay").mean_compromised, "49", "{:.0f}", "49--54 entities")
chk("k5 compromised", m("moderate", "kappa5_decay").mean_compromised, "54", "{:.0f}")
sr = [m(p, k).mean_compromised for p in ["stealthy", "rapid_multistep"] for k in ["kappa2_decay", "kappa3_decay", "kappa4_decay", "kappa5_decay"]]
chk("stealthy/rapid min", min(sr), "54.5", "{:.1f}", "54.5--55.2 entities"); chk("stealthy/rapid max", max(sr), "55.2", "{:.1f}")
chk("stealthy/rapid contained max", 100 * max(m(p, k).p_contained_before_O for p in ["stealthy", "rapid_multistep"] for k in ["kappa2_decay", "kappa3_decay", "kappa4_decay", "kappa5_decay"]), "1.3", "{:.1f}", "at most 1.3\\% contained")
chk("propaware contained", 100 * m("moderate", "propagation_aware").p_contained_before_O, "14", "{:.0f}", "from 11\\% to 14\\%")
lw = pd.read_csv(J("02_Data/Processed/evidence_policy_extension_legitimate_wide.csv"))
chk("k1 legit min 1/s", 100 * lw[lw.rate == 1].kappa1_decay.min(), "40", "{:.0f}", "40--100\\% of legitimate"); chk("k1 legit max 1/s", 100 * lw[lw.rate == 1].kappa1_decay.max(), "100", "{:.0f}")
chk("k2 legit max 1/s", 100 * lw[lw.rate == 1].kappa2_decay.max(), "0.6", "{:.1f}", "at most 0.6\\% per shift"); chk("k2 legit max 10/s", 100 * lw[lw.rate == 10].kappa2_decay.max(), "4.2", "{:.1f}", "4.2\\% for heavy-tailed operators")
# ---- v4: joint legit, ranking, PoC
li = pd.read_csv(J("02_Data/Processed/joint_legitimate_impact.csv")); c4 = li[li.design == "continuous"]
chk("joint both", 100 * ((c4.d_prov <= -0.05) & (c4.false_iso_field_device_heavy <= 0.01)).mean(), "79.5", "{:.1f}", "79.5\\% of cells")
rk = pd.read_csv(J("02_Data/Processed/statistics_ranking_stability.csv"))
chk("ztas rank1 all", rk.rank1_ztas_rec.min(), "1", "{:.0f}", "ranked first in all 270 graphs"); chk("W min", rk.kendall_W.min(), "0.95", "{:.2f}", "0.95--1.0 per family")
rt = pd.read_csv(J("01_Experiments/05_POC_Integration/poc_race_tests_v4.csv")).set_index(["test", "variant"])
chk("T-J off", rt.loc[("T-J segment-expiry race", "recheck_off")].unsafe_forwards, "24", "{:.0f}", "24 of 720 requests"); chk("T-J on", rt.loc[("T-J segment-expiry race", "recheck_on")].unsafe_forwards, "0", "{:.0f}", "0/720 forwards")
chk("T-K off", rt.loc[("T-K quarantine race", "recheck_off")].unsafe_forwards, "18", "{:.0f}", "18 of 36 requests"); chk("T-K on", rt.loc[("T-K quarantine race", "recheck_on")].unsafe_forwards, "0", "{:.0f}", "0/36 forwards")
# ---- write
P_ = sum(r[3] == "PASS" for r in rows)
with open(J("08_Final_Reports", "NUMBER_CHECK.md"), "w") as fh:
    fh.write(f"# NUMBER_CHECK.md — manuscript numbers vs output files\n\n{P_}/{len(rows)} checks pass.\n\n| Quantity | Manuscript | File (rounded) | Result | Note |\n|---|---|---|---|---|\n")
    for r in rows: fh.write("| " + " | ".join(str(x) for x in r) + " |\n")
print(P_, "/", len(rows)); [print(r) for r in rows if r[3] != "PASS"]
