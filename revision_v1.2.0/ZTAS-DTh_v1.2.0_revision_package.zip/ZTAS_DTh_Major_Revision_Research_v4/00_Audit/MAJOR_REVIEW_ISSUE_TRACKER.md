# MAJOR_REVIEW_ISSUE_TRACKER.md (v4)

This tracker supersedes `MAJOR_REVIEWER_ISSUE_TRACKER.md` (v3), which is kept unchanged.

**What "Verified" means**
- The work was executed.
- Its outputs were inspected against the raw data.
- The manuscript numbers were checked against the output files by `08_Final_Reports/number_check.py` (182/182 pass).
- It does **not** mean the reviewer's concern is fully resolved; the remaining limitations are listed in the last column.

**Where things are:** manuscript sections refer to v4 (`06_Manuscript/v4/main.pdf`); "Supp." refers to `supplement.pdf`.

| ID | Concern | Severity | v3 state | v4 work (this round) | Manuscript (v4) | Status | Remaining limitation |
|---|---|---|---|---|---|---|---|
| C1 | Joint parameter robustness | Critical | LHS + Sobol + PRCC + tree | Legitimate false isolation evaluated at all 850 joint points; parameter_audit justification and recommended_range columns; 3 units re-run bit-identical | VII-D (new paragraph), Supp. S11, Fig. S8 | **Verified** | Ranges assumed; zones not degraded; "compromised segments" proxied by phases reached |
| C2 | Risk-engine calibration and operational validity | Critical | Synthetic families, prevalence, calibration transfer, protocol | Robustness to noise, missing data under four imputation rules, adversarial withholding and intensity; signal specification with prototype status | VI (E2), VII-F (new paragraph), Supp. S17, Fig. S9 | **Verified** (synthetic) | **No real-data calibration (blocked: no data)**; all dimensions THEORETICAL in the PoC |
| C3 | Evidence accumulation and delayed containment | Major | Continuous-time study with 5 policies | κ = 1–5, approval 0/30/600 s, emergency isolation, safe state, propagation-aware; 4 profiles; paired CIs; legitimate cost per κ | VI, VII-G (new paragraph), Supp. S18–S19, Fig. S10 | **Verified** | Response tuning cannot contain stealthy attackers; safe-state cost not modelled; non-adaptive attacker |
| C4 | Formal assurance | Major | M1–M4e, 28 checks | M4f/M4g (check-to-enforce) with negative controls → 32 checks; property map with bounds and limitations; FORMAL_ASSURANCE_REPORT | V, Table IV, Alg. 1, Supp. S20 | **Verified** | TLC not executed; no Alloy; no code-level verification, liveness, replicas or Byzantine faults |
| C5 | Integrated PoC | Major | T-A–T-I, one run each | PEP re-check at enforcement (v4); T-J/T-K with controls; T-A ×3 for variability and re-check cost | VI (E4), VII-I, Table X, Supp. S22–S23 | **Verified** | Single host; injected context; residual check-to-forward window; failure-propagation test not run; two-person rule not implemented |
| C6 | Crypto and deployment | Major | Re-analysis, DES, disassembly | Discussion condensed with published gateway-class timings; figure moved to supplement | VII-H, VIII-C, Supp. Fig. S6 | **Verified** | No gateway/HSM/ARM measurement |
| C7 | Novelty | Major | Contributions rewritten; 2026 works compared | Claims N1–N9 classified (NOVELTY_AND_RELATED_WORK_AUDIT) | I, II | **Verified** | Integrative and methodological novelty |
| C8 | Statistical interpretation | Moderate | Graph-level analysis, practical threshold | Ranking stability (Kendall's W) over 270 graphs; paired bootstrap for policy contrasts | VII-A, Supp. S12 | **Verified** | Model-dependent evidence |
| C9 | Attack model | Moderate | 5 profiles, ATT&CK mapping | Burst and rapid profiles in the evidence extension; stealthy/rapid evasion of every κ ≥ 2 reported | VII-G, VIII-E | **Verified** | Non-adaptive attacker |
| C10 | Reproducibility | Major | v1.1.0 archived; clean-checkout reproduction | 7 tasks re-run from scratch (≤ 4.5e-13); EXPERIMENT_EVIDENCE_MANIFEST; checklist with claims; number check 182/182 | Data availability, Supp. S27 | **Verified** (package) | v4 additions not yet archived (v1.2.0 needs author approval) |
| — | Manuscript length | — | 18 pp. | STRIDE table, E1 per-family table, ablation figure, graph-level, evidence-time and crypto figures moved to supplement; discussion condensed | — | 17 pp. | Still long for TII; further cuts possible on request |
