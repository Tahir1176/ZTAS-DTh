# REPRODUCIBILITY_AND_EVIDENCE_AUDIT.md

> v4 report. Sections 'v4 additions' are new in this round; the v3 content below them is kept unchanged for traceability (original file `REPRODUCIBILITY_VALIDATION_REPORT.md` is also kept).

## v4 additions

**Deterministic re-execution from scratch** (`rerun_subset_joint.py`, `rerun_subset_other.py`; Supp. Table S27)
- Joint-sensitivity units reference_0_0, sparse_1_2 and hub_spoke_3_1: 4250 rows each, bit-identical.
- Evidence-extension tasks (g0 moderate 1000; g7 burst 10) and adversary tasks (reference g0; multi_org g9): max. abs. difference ≤ 4.5e-13, from the CSV text round-trip.

**Evidence manifest**
- `EXPERIMENT_EVIDENCE_MANIFEST.csv` links every manuscript result to its script, data, figure or table, and status.
- `reproduction_checklist_v4.csv` adds a `manuscript_claim` column.

**Number check:** 182/182 manuscript numbers match the output files.

**Not archived yet.** The v4 additions are in the revision package but not yet in a Zenodo release. Publishing a v1.2.0 release requires the authors' approval.

---

## v3 content (unchanged)

# REPRODUCIBILITY_VALIDATION_REPORT.md — concern 10

## 1. What was tested
- **Archived release.** Release v1.0.0: GitHub tag `v1.0.0` of `Tahir1176/ZTAS-DTh`, archived on Zenodo as doi:10.5281/zenodo.24372430.
- **How it was obtained.** The Zenodo API is not reachable from this build environment (the outbound allowlist refused the request). We therefore used a clean `git archive` of tag v1.0.0 from the local clone; its blobs had previously been verified one by one against GitHub. The Zenodo file is GitHub's archive of the same tag.
- **What was run.** The release's own `run_all.sh`, unchanged, for steps e1, e2, formal, e3 and e4 (`repro_logs/repro.sh`, `repro_driver.log`). The step durations are:

| Step | Duration |
|---|---|
| e1 (main, rec, pv, oat, statistics, notebook) | 1133 s |
| e2 | 156 s |
| formal | < 1 s |
| e3 | 79 s |
| e4 | 9 s |

All steps exited with status 0. The shipped data were saved before the run and compared afterwards.

## 2. Results (`reproduction_checklist.csv`)

**Bit-identical reproduction**:

| Experiment | Rows reproduced | What else matched |
|---|---|---|
| E1 main | 147 000 | – |
| E1 recommended rule | 27 000 | – |
| p_v sweep | 432 000 | – |
| OAT | all rows | – |
| Processed statistics | – | `e1_summary`, `e1_effects` (max abs difference 2·10⁻¹⁶), `provenance_sensitivity` |
| E2 | – | metrics, confusion matrices, evidence accumulation |
| Formal M1–M3 | – | 12/12 results and state counts |
| PoC | – | 13/13 scenario outcomes |

The manuscript headline (reference topology, stealthy attacker) is reproduced: ZTAS-DTh 0.138 [0.125, 0.152] versus ZT+provenance 0.492 [0.454, 0.533] and static ZT 0.832 [0.808, 0.854].

**Not bit-reproducible: timing.** We re-ran the crypto benchmark twice, once while other work ran on the second vCPU and once on an otherwise idle VM. Medians were 0.74–2.41 × the archived values (median ratio 1.04–1.11; `crypto_benchmark_rerun_comparison.csv`). Examples:
- ML-DSA-65 sign: 9.35 ms archived; 9.09 and 13.74 ms re-run.
- ML-DSA-65 verify: 180 µs archived; 435 and 315 µs re-run.

The archived numbers are therefore one sample from a variable shared VM. The qualitative conclusions reproduce:
- verification is much cheaper than signing;
- batching amortises signing by about three orders of magnitude;
- per-record signing caps at roughly 70–110 records/s per core.

The **discrepancy and correction** in the manuscript: the crypto results now state that absolute costs varied by up to a factor of about 2.4 between runs on the same VM type and are indicative only. The ML-DSA verification sentence quotes the range. The PoC latency (2.45 ms vs 3.03 ms archived median) also varies, so the latency figures are labelled as single-run values.

## 3. v3 package
- Every v3 analysis was re-executed from its raw data through an executed notebook: joint sensitivity, risk engine, evidence, statistics, crypto.
- `08_Final_Reports/number_check.py` compares **143 numbers quoted in the manuscript** with the output files after rounding. All 143 pass. Four mismatches found during drafting were corrected in the manuscript and reports: a Sobol index 0.21 → 0.22, a relative-reduction bound 52 → 51%, an ECE range, and a PoC median 2.4 → 2.3 ms.
- The long v3 simulations (joint sensitivity, evidence study, attacker profiles) were executed once each and are deterministic given their seeds. They were not re-run a second time in this session. Their seeds and configurations are recorded, so they can be.

## 4. Manifest
`02_Data/manifests/reproducibility_manifest.csv` lists every file of the v3 package with its purpose, experiment, version, configuration, seed, dependencies and SHA-256.

## 5. Remaining gaps
- The v3 package is archived as GitHub release v1.1.0, Zenodo doi:10.5281/zenodo.24379544 (concept DOI 10.5281/zenodo.24372429); the archived file contains the uploaded package byte-identically (git blob 717bf51e…).
- `requirements.txt` lists versions without hashes, and there is no container image. The environment used is recorded in the execution log.
- Timing results are not reproducible beyond about a factor of 2 on shared VMs.
- The download of the Zenodo file itself could not be verified from this environment.
