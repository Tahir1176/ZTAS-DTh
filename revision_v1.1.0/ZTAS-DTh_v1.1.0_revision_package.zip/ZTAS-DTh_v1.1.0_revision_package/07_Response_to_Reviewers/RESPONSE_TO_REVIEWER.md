# Response to the Reviewer — second major revision (v3)

**Manuscript:** ZTAS-DTh: A Lifecycle-Spanning Zero-Trust Security Architecture for the Digital Thread—Design, Bounded Formal Analysis, and Simulation-Based Evaluation

We thank the reviewer for a detailed and demanding report. We treated each concern as a hypothesis to test, not a wording problem. The revision adds new experiments, a new formal model, new implementation tests, and a re-analysis of existing data. Several of the results are unfavourable to the architecture. They are reported in full, and the claims have been narrowed to match.

Page numbers refer to the revised manuscript (`ZTAS_DTh_Revised_Manuscript.pdf`); "Supp." refers to the Supplementary Material (`ZTAS_DTh_Supplementary_Material.pdf`). File paths refer to the revision package `ZTAS_DTh_Major_Revision_Research/`.

---

## Concern 1 — Joint parameter robustness and conditional effectiveness

**Reviewer comment.** The central performance claim depends on the assumed effectiveness of several defensive mechanisms (exploit success, authorisation, monitoring, artifact-mediated share, provenance rejection, segment opening, step-up failure, evidence threshold, decay, approval delay). One-at-a-time variation is insufficient; a joint analysis is needed to establish when the advantage holds and when it diminishes.

**Response.** We agree. One-at-a-time sweeps cannot reveal interactions. We replaced them as the primary robustness evidence with a joint design.

**Actions taken.**
- **Parameter audit.** Every simulator parameter was classified as assumption, configuration or derived; none is measured.
- **Latin-hypercube sampling.** Eleven parameters were varied jointly: 400 points over the full ranges, plus 150 points in each of three explicitly defined defensive-control regimes (optimistic, moderate, adverse).
- **Evaluation units.** All five architectures were evaluated on 144 common evaluation units (9 families × 4 fresh graphs × 4 runs) with common random numbers, giving 612 000 simulations.
- **Sobol indices.** Computed on the reference topology (Saltelli N = 256, 3328 points), together with PRCC across all families.
- **Uncertainty.** A two-way cluster bootstrap over parameter points and graphs.
- **Vanishing advantage.** A decision tree locating where the advantage over ZT+provenance falls below 0.05.

**Evidence.**
- `01_Experiments/joint_sensitivity/` contains the experiment, configuration, analysis, executed notebook, results CSVs, figures and `JOINT_SENSITIVITY_REPORT.md`.
- Raw data: `02_Data/raw/joint_sensitivity_*`.

**Findings.**
- ZTAS-DTh had a lower compromised fraction than ZT+provenance in 96.7% of point–topology cells and was lower by ≥ 0.05 in 75.5%. It was **worse by ≥ 0.01 in 1.2%**.
- In the adverse regime the margin shrank to −0.12 [−0.15, −0.10], and ZTAS-DTh ranked first in only 44% of cells. Static zones, which were not degraded, often did as well.
- The margin is driven by interactions (ΣS₁ ≈ 0.4 vs ΣS_T ≈ 1.9). The most influential parameters are the segment duty cycle (S_T = 0.35), exploit rate (0.30) and attacker stealth (0.29).
- The advantage nearly vanishes in sparse threads, and when segments are mostly open and the attacker is stealthy.

**Manuscript changes.**
- §VI (p. 6): joint design, ranges and regimes.
- New §VII-D "Joint Parameter Robustness" (p. 11), with Table IX and Fig. 5.
- Abstract, Introduction and Conclusion now state the conditional nature of the advantage.
- Supp. S2 gives the ranges, rationales, regimes, global indices, per-topology results and the decision tree.

**Remaining limitation.**
- The joint ranges are assumptions.
- Zones and perimeter parameters were not degraded, which biases the adverse-regime comparison in favour of zones; this is stated in Threats to Validity.
- Each cell rests on 16 units.

---

## Concern 2 — Calibration and operational validity of the 5-D risk engine

**Reviewer comment.** The risk engine is evaluated mainly on synthetic distributions. Its behaviour may differ under distribution shift, low prevalence, correlated or heavy-tailed data, overlap and asymmetric costs. A clearer operational interpretation is needed.

**Response.** We agree, and we now state explicitly that **the engine has been evaluated only on synthetic distributions and has not been calibrated on industrial data**. We did not run a calibration, because no labelled data were available.

**Actions taken.**
1. **Implementation audit** across the manuscript, the simulator, the E2 study and the PoC. It found:
   - three different decay units (simulation step, request, second);
   - no step-up credit in E1;
   - no block-tier evidence in E2;
   - **missing dimensions treated as zero risk in the PoC (fail-open)**, now fixed and verified by test T-I;
   - "degraded mode" in Algorithm 1 versus fail-closed in the code (text corrected).
2. **Operational measurement specification** for each dimension: signals, source, frequency, normalisation, noise, missing data, privacy, manipulation and calibration need.
3. **Calibration protocol** (proposed, not executed): shadow mode, labelled data, constrained logistic fitting, cost- and budget-constrained thresholds, drift monitoring and recalibration triggers.
4. **Extended experiment.**
   - Prevalence 0.1–20%, 10⁵ draws per class, Wilson CIs, operator workload per 10⁵ requests.
   - Calibration transfer (Platt; ECE, Brier).
   - Cost-sensitive thresholds under four cost scenarios, including safety-critical isolation, plus budget-constrained thresholds.

**Evidence.** `01_Experiments/risk_engine/` (`risk_engine_audit.md`, `risk_dimension_operational_specification.csv`, `risk_calibration_protocol.md`, the experiment script, `risk_engine_analysis.ipynb`, `RISK_ENGINE_VALIDATION_REPORT.md`); `02_Data/processed/risk_engine/` (processed metrics, confusion matrices, calibration, thresholds).

**Findings.**
- With heavy-tailed, skewed or correlated legitimate scores, ROC-AUC is 0.75–0.97. Yet at 0.1% prevalence 16–94 escalations are false per true one (precision 1–6%), and operator workload is 1200–1700 false step-ups per 10⁵ requests.
- Gaussian assumptions are the optimistic case.
- A calibration fitted in one condition over-predicts three- to fourfold in others.
- The cost-optimal threshold moves from 64.5 to 14 with prevalence, so no universal threshold exists.

**Manuscript changes.**
- §IV-D (p. 4): calibration status, measurement definition, missing-data rule, decay units.
- §VI: E2 extension.
- §VII-F (p. 12): prevalence, workload, calibration and thresholds.
- Discussion and Limitations.
- Supp. S4: specification, protocol and full prevalence table.

**Remaining limitation.** No industrial telemetry and no calibration. The results describe model behaviour, not detection performance.

---

## Concern 3 — Evidence accumulation and delayed containment

**Reviewer comment.** The revised rule raises the median escalated requests to quarantine a stealthy attacker from 22 to 86. A request count does not establish operational acceptability.

**Response.** We agree, and the new analysis shows the cost is larger than the request count suggested.

**Actions taken.**
- Audit of the evidence mechanism.
- A **continuous-time event simulation** that couples request-driven attack progression with wall-clock elements (operator approval, time-based decay):
  - 4 base rates (1–1000 req/s), 7 attacker profiles and 5 policies, the last of these a criticality-aware policy that restricts rather than isolates operations assets;
  - common random numbers, 52 500 runs, none censored;
  - legitimate false isolation per 8 h shift at 0.1–10 req/s.

**Evidence.** `01_Experiments/evidence_accumulation/` (script, analysis, notebook, figures, paired comparisons, `EVIDENCE_ACCUMULATION_REPORT.md`); `02_Data/raw/evidence_accumulation_raw.csv.gz`; `02_Data/processed/evidence_accumulation_*.csv`.

**Findings.**
- With request-based decay, outcomes are rate-invariant except for time.
- The revised rule reduces containment before the operations phase from 0.43 to 0.11 and roughly doubles the number of compromised entities (−23.8 [−26.1, −21.8] in favour of the original rule).
- It avoids false isolation that the original rule causes in 15–100% of legitimate entities per shift.
- Wall-clock decay lets a slow attacker evade completely.
- No evidence policy contains stealthy or rapid attackers by itself.
- The criticality-aware policy gives a small gain (−0.84 entities) at a 0.1% restriction cost.

**Manuscript changes.**
- §IV-D: decay units.
- §VI: the design.
- New §VII-G (p. 13), with Table X and Fig. 6.
- §VII-F: "a point on a trade-off curve, not an operationally validated setting".
- Discussion: safety of responses.

**Remaining limitation.**
- The rates, approval delay and profiles are assumptions.
- The criticality-aware policy is a simulation policy, not a demonstrated safety function.
- Emergency override is not modelled.

---

## Concern 4 — Formal assurance and its boundaries

**Reviewer comment.** Bounded abstract model checking does not verify the integrated implementation. Strengthen where feasible and define the limits precisely.

**Response.** We added model M4 for asynchronous, distributed enforcement and mapped every property to its enforcing component, assumption and type of evidence. We do not claim implementation-level assurance.

**Actions taken.**
- Audit of P1–P8, Propositions 1–3 and M1–M3; M1–M3 were re-run with identical results.
- **M4a–e:**
  - M4a: revocation with cached decisions and an asynchronous CRL;
  - M4b: PDP, provenance and segmentation-controller failure;
  - M4c: a policy-update race;
  - M4d: concurrent replay;
  - M4e: compromised administrators and a two-person rule.
- Each sub-model has negative controls: 16 runs, all matching expectation.
- **One mis-specified negative control is reported.** In the first M4a run, a control produced no counterexample; it was replaced, and both logs are kept.
- **Assurance-boundary diagram** and a **property → enforcement → verification-status map**.
- P3, P6, P7 and P8 statements were updated to the design rules found: window mode, revocation bound, durable quarantine, quorum.

**Evidence.** `src/formal/model_check_v3.py`; `src/formal/logs/model_check_v3*.log|json`, `model_check_rerun.log`; `01_Experiments/formal_analysis/FORMAL_ANALYSIS_REPORT.md`; `formal_assurance_boundary.png|pdf`.

**Manuscript changes.**
- §V (p. 6): new M4 paragraph; Table IV updated; Table V now has 28 checks.
- Algorithm 1 updated: atomic anti-replay window, re-validation, fail-closed.
- Discussion, "What is guaranteed…", separates cryptographic, model-checked, implementation-tested and assumed properties.
- Supp. S5: boundary diagram and property map.

**Remaining limitation.**
- TLC was not run.
- The models are small and bounded.
- There is no code-level verification, liveness, timing or replicated-PDP consistency.

---

## Concern 5 — Integrated proof of concept

**Reviewer comment.** The PoC demonstrates selected workflows on one host but does not evaluate concurrency, failure behaviour or integrated interactions.

**Response.** We added a concurrency and failure test suite. **It found six defects in the v2 PoC, two of them security-relevant.**
1. A shared HTTP client caused responses to be delivered to the wrong request; a misattributed "allow" was therefore possible.
2. A quarantined device regained access after a PDP restart.

All six defects were fixed. Every fix is switchable, so the v2 behaviour was re-run as a control under identical conditions.

**Actions taken.**
- PoC audit and a component mapping: implemented, mocked, abstracted or not implemented.
- Tests T-A to T-I on a fresh stack each, localhost only:
  - T-A: concurrency (1–16 clients);
  - T-B, T-C, T-D: provenance, PDP (also under load) and segmentation-controller failure;
  - T-E: revocation under load and IdP outage;
  - T-F: 16 concurrent replays;
  - T-G: segment revocation race;
  - T-H: PDP restart and recovery;
  - T-I: missing risk inputs.
- Measurements: p50, p95 and p99 latency, throughput, CPU, RSS and failure rate.
- Sequence diagram, with editable Mermaid source.

**Evidence.**
- `src/poc/ztas_poc_v3.py`.
- `01_Experiments/poc_failure_testing/`: tests, `run_all_poc_tests.sh`, `raw/*.json`, `poc_concurrency_processed.csv`, `poc_implementation_audit.md`, `POC_INTEGRATION_REPORT.md`, `poc_sequence_diagram.*`.

**Manuscript changes.**
- §VI: E4 test suite.
- §VII-I (p. 14): new Table XII and results.
- The text states that this is a controlled software demonstration on a 2-vCPU host, not an industrial deployment.
- Supp. S6: sequence diagram and full concurrency table.

**Remaining limitation.**
- Single host.
- Mocked step-up and context; stub twin.
- No distributed ledger and no implemented two-person rule.
- One run per configuration.

---

## Concern 6 — Cryptographic benchmarking, queueing and deployment

**Reviewer comment.** The implementation details, queueing assumptions, portability claim and deployment implications need clarification.

**Response.**
- **The portability claim was incorrectly reasoned and is corrected.** The binary is stripped, so the absence of AVX2 symbols proves nothing. Disassembly shows 182 instructions on 256-bit registers and 11 `cpuid` instructions, i.e. a small amount of run-time-dispatched AVX2 code, probably hashing. The ML-DSA arithmetic is the crate's portable software backend.
- **The queueing model was re-analysed** with bursty arrivals and empirical service times.

**Actions taken.**
- Audit of the library, build (rustc 1.97.1, maturin, LLD 22.1.6; GCC 14.2.1 for the C parts), CPU flags, repetitions, warm-up and randomisation.
- Statistics recomputed from the raw samples: median with bootstrap CI, mean, p95, p99, outliers, throughput.
- **A new observation:** ML-DSA signing is right-skewed (mean 12% above the median). v2 fitted medians, which understates the mean service time that decides stability; per-record signing is already unstable at 100 records/s with empirical service times.
- A discrete-event queue covering Poisson, Markov-modulated bursty and clustered arrivals, deterministic versus empirical service, and 540 configurations. At 10⁴ records/s with B = 256, the p99 is 39 ms under Poisson arrivals but 1.6 s under bursts.
- A deployment discussion covering gateways, HSMs, acceleration, key rotation and revocation, ledger and network interruption, archival verification and migration.

**Evidence.** `01_Experiments/crypto/` (`crypto_reanalysis.py`, notebook, `CRYPTOGRAPHIC_BENCHMARK_REPORT.md`); `02_Data/processed/crypto/`.

**Manuscript changes.**
- §VI (E3): library description corrected.
- §VII-H (p. 13): mean/median, CIs and burst results.
- Discussion: gateways, HSMs and interoperability.
- Supp. S7.

**Remaining limitation.** No gateway, HSM or ARM measurement, and no run with AVX2 disabled. The latencies are modelled, not measured industrial latencies.

---

## Concern 7 — Novelty and incremental contribution

**Reviewer comment.** The architecture combines established mechanisms; the novelty is integrative and must be justified.

**Response.** We agree that the components are not novel and now say so in the Introduction. We audited each contribution claim and searched for recent closest work. That search found two 2026 works, QZT-ICS (Qadri) and Humphrey's cyber-twin-informed ZT. Both are now cited and were read in full. QZT-ICS has stronger implementation evidence than ours (a hardware-in-the-loop testbed) but addresses transport- and process-level trust rather than lifecycle lineage, and does not compare against a provenance-verifying baseline; Humphrey is an early-stage report whose qualitative segmentation findings we cite in the Discussion. QZT-ICS's measured PQC costs on Cortex-M33/A55 hardware are cited to bound our server-only benchmarks.

The defensible contributions are:
1. the artifact- versus interface-mediated threat model;
2. the coupling of lineage verification with per-request ZT and flow-scoped segments;
3. a **counterfactual evaluation against a ZT+provenance baseline**, which identifies where the coupling stops helping;
4. supporting assurance.

A worked comparison of a compromised CAM service across all five architectures is aligned with the simulation boundary.

**Evidence.** `01_Experiments/novelty/` (`NOVELTY_AUDIT.md`, `RELATED_WORK_CRITICAL_COMPARISON.md`, `NOVELTY_AND_POSITIONING_REPORT.md`).

**Manuscript changes.**
- §I (p. 1): contributions rewritten.
- §II (p. 2): new works and positioning.
- Table I: two new rows.
- Discussion: worked example extended to zones and linked to the simulation boundary.

**Remaining limitation.** The novelty remains integrative and methodological. Evidence of benefit is model-based.

---

## Concern 8 — Statistical interpretation and practical significance

**Reviewer comment.** Strengthen the interpretation of graph-level variability, effect sizes and topology-dependent benefits.

**Actions taken.** The paired graph-level analysis was re-done against ZT and ZT+provenance. It reports:
- absolute and relative reductions;
- graph-level ranges;
- a **pre-declared practical-significance threshold** (0.05, about 3 of 56 entities) and the share of graphs reaching it;
- a variance partition (between-graph share 2–9%);
- an explanation of why d_z is not used as the benefit measure;
- a figure showing all 270 graph-level differences;
- topology-mechanism interpretation;
- explicit separation of statistical significance, effect size, robustness, practical significance and model-dependent evidence.

**Evidence.** `01_Experiments/statistics/` (`statistical_analysis.py`, notebook, `fig_graph_level_differences.*`, `STATISTICAL_VALIDATION_REPORT.md` with the audit); `02_Data/processed/statistics_*.csv`.

**Findings.** Every graph favours ZTAS-DTh. However, only 20% of sparse and 67% of multi-organisation graphs reach the practical threshold, against 100% in the other seven families. The relative reduction (52–72%) is similar across families; the absolute benefit depends on how much the baseline leaves exposed.

**Manuscript changes.**
- §VI: practical-significance criterion.
- Benefit section (p. 11): new Fig. 3.
- Threats to Validity.

**Remaining limitation.** All evidence is about the simulator under assumed parameters.

---

## Concern 9 — Attack model and operational interpretation

**Actions taken.**
- **Adversary-model audit** covering capabilities, entry, credentials, exploit, movement, artifact and interface propagation, replay, stealth, detection and containment.
- Five attacker profiles: noisy, stealthy, rapid multi-step, **coordinated** (three footholds; new simulator capability, backward compatible with 72 v2 rows reproduced exactly) and credentialed. They were run on 90 fresh graphs.
- A mapping of seven representative industrial behaviours to the model, with ATT&CK-for-ICS technique names, no procedures, and the limitation of each abstraction.
- An explicit statement of what the model omits: adaptation, coordination between footholds, intra-entity stages, physical consequences.

**Evidence.** `01_Experiments/adversary/` (experiment, summary, `attack_scenario_mapping.csv`, `ADVERSARY_MODEL_VALIDATION_REPORT.md`); `02_Data/raw/adversary_profiles_raw.csv.gz`.

**Findings.** Rapid, coordinated and credentialed attackers roughly double ZTAS-DTh's compromised fraction (0.28–0.31 vs 0.14) and its reach of the operations phase. Every graph still favours ZTAS-DTh over ZT+provenance.

**Manuscript changes.**
- §III (p. 2): attacker profiles and the mapping.
- §VII-D: attacker-profile results.
- Threats to Validity.
- Supp. S3.

**Remaining limitation.** Fixed probabilities and a non-adaptive attacker.

---

## Concern 10 — Reproducibility package

**Actions taken.**
- **Clean-checkout reproduction of release v1.0.0** (git tag; blobs previously verified against GitHub; Zenodo itself is not reachable from our build environment).
- Principal results re-run and compared with the archived data and the manuscript.
- Archive audit, reproduction checklist, and a manifest with SHA-256 checksums for every file of the v3 package.

**Evidence.** `01_Experiments/reproducibility/` (`reproducibility_archive_audit.csv`, `reproduction_checklist.csv`, `reproducibility_manifest.csv`, `REPRODUCIBILITY_VALIDATION_REPORT.md`, `repro_logs/`).

**Results.** A clean checkout of v1.0.0 reproduced E1 (main, recommended rule, p_v sweep, OAT), the processed statistics, E2, formal M1–M3 and all PoC scenario outcomes bit-identically, including the headline 0.138 [0.125, 0.152] vs 0.492 [0.454, 0.533]. Crypto timings were **not** reproducible beyond about a factor of two on the shared VM (medians 0.74–2.41× the archived values), so the manuscript now labels absolute costs as indicative. All 143 v3 numbers quoted in the manuscript were checked against the output files (`08_Final_Reports/NUMBER_CHECK.md`); four drafting mismatches were corrected.

**Manuscript changes.** Data and Code Availability (p. 17): states what release v1.0.0 contains, that it was reproduced, and that the v3 experiments are in the revision package and are to be released under the concept DOI.

**Remaining limitation.** The v3 package is not yet archived on Zenodo; publishing a new release needs the authors' approval. The long v3 simulations were executed once (they are seeded and can be re-run). There is no container image or hashed lock file.
