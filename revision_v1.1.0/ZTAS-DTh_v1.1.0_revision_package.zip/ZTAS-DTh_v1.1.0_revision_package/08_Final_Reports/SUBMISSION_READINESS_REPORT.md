# SUBMISSION_READINESS_REPORT.md — independent assessment of the v3 manuscript

This assessment was written after the revision. It deliberately takes the reviewer's position, not the authors'.

## 1. Criteria

| Criterion | Assessment | Grade |
|---|---|---|
| **Scientific novelty** | Integrative, and now honestly stated as such. The defensible contributions are three: coupling lineage verification to per-request ZT and flow-scoped segments; a counterfactual evaluation against a provenance-verifying baseline, including where the coupling stops helping; and the artifact- vs interface-mediated threat model. A reviewer looking for a new algorithm or primitive will not find one. | Moderate |
| **Technical correctness** | Six PoC defects were found and fixed, two of them security-relevant. Inconsistencies between the text and the code (decay units, PDP failure, missing data) were corrected. The portability claim and the queue-stability reasoning were corrected. M1–M3 and all v1.0.0 results reproduce. No known open correctness issue. | Good |
| **Experimental quality** | Joint sensitivity with regimes and Sobol indices; paired CRN designs everywhere; wall-clock evidence study; failure and concurrency tests with switchable controls. The weakness is that every control-effectiveness parameter is assumed and the topologies are synthetic. | Good (for a model-based study) |
| **Statistical validity** | Hierarchical and two-way cluster bootstraps; graph-level reporting; pre-declared practical threshold; variance partition; no significance tests over-interpreted. Cells in the joint study rest on 16 units each. | Good |
| **Formal assurance** | Bounded abstract models with 28 checks, negative controls and a reported failed control. The scope is stated precisely. TLC was not run, and there is no code-level verification. | Adequate, clearly bounded |
| **Reproducibility** | A clean checkout of v1.0.0 reproduces bit-identically, except for timing. 143 manuscript numbers are checked automatically. There is a SHA-256 manifest. The v3 package is not yet archived, and there is no container image. | Good (after archiving: very good) |
| **Literature positioning** | Table I has evidence-type columns. Two 2026 works were added and read in full; QZT-ICS has stronger implementation evidence (HIL testbed) and is positioned as complementary. | Good |
| **Industrial relevance** | High in topic. The evidence is not industrial: no plant, telemetry, gateway or HSM. Safety, governance and privacy are discussed, not demonstrated. | Limited |
| **Writing quality** | Claims are calibrated, and limitations are explicit and specific. The manuscript is long (18 pp. plus a 14-pp. supplement). | Good; length is a problem |

## 2. Remaining weaknesses (ranked)
1. **No industrial validation or calibration.** This is the main barrier at an applied industrial venue such as IEEE TII. The paper cannot remove it without a plant or testbed partner.
2. **Length.** At 18 pages the manuscript probably exceeds the target journal's page limit (check the current author guidelines). Candidates to move to the supplement:
   - the STRIDE table;
   - the provenance-scenario table, keeping a summary paragraph;
   - the ablation figure;
   - part of the E2 distribution description;
   - Table VII, the per-family E1 table, which is partly redundant with Fig. 2 and Fig. 3.
3. **The revised evidence rule weakens containment substantially** (0.43 → 0.11 before operations). The paper reports this honestly. A reviewer may still ask for a better rule. The criticality-aware policy helps only marginally.
4. **The advantage is conditional on segments being closed most of the time.** No evidence exists on achievable segment duty cycles in real threads.
5. **Single execution of the long v3 simulations.** They are seeded and re-runnable.
6. **Crypto absolute timings vary by up to 2.4× between runs** on the shared VM.
7. **Two-person rule, time-critical command path and distributed ledger** are not implemented.

## 3. Independent recommendation
**Minor Revision**, conditional on two things:
- (a) shortening the manuscript to the venue's page limit;
- (b) archiving the v3 package (new Zenodo release) and updating the Data Availability statement.

All ten major concerns have been addressed with new experiments, new analysis or corrected claims, to the extent possible without industrial data. Where a concern could not be fully resolved — calibration (C2), implementation-level assurance (C4), industrial PoC (C5), gateway and HSM performance (C6) — the manuscript now states the limitation explicitly and narrows the claim.

If the editor treats the absence of industrial validation as decisive for this venue, the realistic outcome is **reject and resubmit elsewhere**. The manuscript as revised would then suit a security venue that accepts model-based evaluation, for example IEEE TDSC, Computers & Security, or ACM TOPS.

## 4. Author actions before submission
- Waqas Ahmed's affiliation: confirmed by the authors as MCS-NUST (same as M. Tahir).
- Add ORCID iDs, funding and conflict-of-interest statements.
- Publication of the v3 package as release v1.1.0 approved by the authors (19 Nov 2026).
- Check the page limit and shorten (see §2.2).
- The two 2026 works (Qadri; Humphrey) have now been read in full and Table I / Related Work / Discussion updated accordingly.
