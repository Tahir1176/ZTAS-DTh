# NUMBER_CHECK.md — manuscript numbers vs output files

143/143 checks pass.

| Quantity | Manuscript | File (rounded) | Result | Note |
|---|---|---|---|---|
| cells ZTAS<ZT+prov (continuous) | 96.7 | 96.7 | PASS |  |
| cells advantage>=0.05 | 75.5 | 75.5 | PASS |  |
| cells worse by >=0.01 | 1.2 | 1.2 | PASS |  |
| continuous mean diff | -0.23 | -0.23 | PASS |  |
| continuous CI lo | -0.25 | -0.25 | PASS |  |
| continuous CI hi | -0.21 | -0.21 | PASS |  |
| adverse mean diff | -0.12 | -0.12 | PASS |  |
| adverse CI lo | -0.15 | -0.15 | PASS |  |
| adverse CI hi | -0.10 | -0.10 | PASS |  |
| adverse ZTAS rank1 | 44 | 44 | PASS |  |
| adverse ZTAS frac | 0.62 | 0.62 | PASS |  |
| containment diff (continuous) | 0.20 | 0.20 | PASS |  |
| reach_O diff (continuous) | 0.23 | 0.23 | PASS |  |
| Table joint optimistic | 0.40 | 0.40 | PASS |  |
| Table joint optimistic | 0.18 | 0.18 | PASS |  |
| Table joint optimistic | 0.03 | 0.03 | PASS |  |
| Table joint optimistic | 99.5 | 99.5 | PASS |  |
| Table joint optimistic | 62.9 | 62.9 | PASS |  |
| Table joint moderate | 0.74 | 0.74 | PASS |  |
| Table joint moderate | 0.44 | 0.44 | PASS |  |
| Table joint moderate | 0.21 | 0.21 | PASS |  |
| Table joint moderate | 98.5 | 98.5 | PASS |  |
| Table joint moderate | 80.7 | 80.7 | PASS |  |
| Table joint adverse | 0.90 | 0.90 | PASS |  |
| Table joint adverse | 0.74 | 0.74 | PASS |  |
| Table joint adverse | 0.62 | 0.62 | PASS |  |
| Table joint adverse | 80.8 | 80.8 | PASS |  |
| Table joint adverse | 55.9 | 55.9 | PASS |  |
| Table joint continuous | 0.68 | 0.68 | PASS |  |
| Table joint continuous | 0.48 | 0.48 | PASS |  |
| Table joint continuous | 0.25 | 0.25 | PASS |  |
| Table joint continuous | 96.7 | 96.7 | PASS |  |
| Table joint continuous | 75.5 | 75.5 | PASS |  |
| Sobol ST p_act | 0.35 | 0.35 | PASS |  |
| Sobol ST p_exploit | 0.30 | 0.30 | PASS |  |
| Sobol ST mu_mal | 0.29 | 0.29 | PASS |  |
| Sobol ST p_auth | 0.22 | 0.22 | PASS |  |
| Sobol ST d_generic | 0.22 | 0.22 | PASS |  |
| Sobol ST f_art | 0.19 | 0.19 | PASS |  |
| Sobol ST p_v | 0.13 | 0.13 | PASS |  |
| Sobol ST stepup_fail | 0.13 | 0.13 | PASS |  |
| Sobol ST kappa | 0.06 | 0.06 | PASS |  |
| sum S1 | 0.4 | 0.4 | PASS |  |
| sum ST | 1.9 | 1.9 | PASS |  |
| tree accuracy | 0.82 | 0.82 | PASS |  |
| by topology dense | -0.32 | -0.32 | PASS |  |
| by topology sparse | -0.04 | -0.04 | PASS |  |
| profile noisy ZTAS | 0.04 | 0.04 | PASS |  |
| profile noisy ZT+prov | 0.40 | 0.40 | PASS |  |
| profile stealthy ZTAS | 0.14 | 0.14 | PASS |  |
| profile stealthy ZT+prov | 0.40 | 0.40 | PASS |  |
| profile insider_cred ZTAS | 0.28 | 0.28 | PASS |  |
| profile insider_cred ZT+prov | 0.49 | 0.49 | PASS |  |
| profile rapid ZTAS | 0.31 | 0.31 | PASS |  |
| profile rapid ZT+prov | 0.57 | 0.57 | PASS |  |
| profile coordinated ZTAS | 0.31 | 0.31 | PASS |  |
| profile coordinated ZT+prov | 0.65 | 0.65 | PASS |  |
| profile practical min | 84 | 84 | PASS |  |
| profile practical max | 94 | 94 | PASS |  |
| sparse share practical | 20 | 20 | PASS |  |
| multi_org share practical | 67 | 67 | PASS |  |
| multi_org diff | 0.07 | 0.07 | PASS |  |
| sparse diff | 0.04 | 0.04 | PASS |  |
| dense diff | 0.40 | 0.40 | PASS |  |
| feedback diff (lower end 0.32) | 0.32 | 0.32 | PASS |  |
| ICC min | 2 | 2 | PASS |  |
| ICC max | 9 | 9 | PASS |  |
| rel min | 51 | 51 | PASS |  |
| rel max | 72 | 72 | PASS |  |
| dz min | -1.6 | -1.6 | PASS |  |
| dz max | -5.9 | -5.9 | PASS |  |
| heavy 55 false/true | 26 | 26 | PASS |  |
| heavy 28 false/true | 94 | 94 | PASS |  |
| 16-94 lower | 16 | 16 | PASS |  |
| precision max (1-6%) | 6 | 6 | PASS |  |
| precision min | 1 | 1 | PASS |  |
| false step-ups lower | 1200 | 1200 | PASS |  |
| false step-ups upper | 1700 | 1700 | PASS |  |
| ECE in-condition | 0.003 | 0.003 | PASS |  |
| ECE other min | 0.014 | 0.014 | PASS |  |
| ECE other max | 0.029 | 0.029 | PASS |  |
| ECE 20% min | 0.04 | 0.04 | PASS |  |
| ECE 20% max | 0.18 | 0.18 | PASS |  |
| threshold heavy fp 0.1% | 64.5 | 64.5 | PASS |  |
| threshold heavy fp 20% | 14.0 | 14.0 | PASS |  |
| budget10 gaussian | 30.0 | 30.0 | PASS |  |
| budget10 heavy | 52.0 | 52.0 | PASS |  |
| evidence original_k2 contained_before_O | 0.43 | 0.43 | PASS |  |
| evidence original_k2 compromised | 25.2 | 25.2 | PASS |  |
| evidence original_k2 requests | 30.0 | 30.0 | PASS |  |
| evidence revised_k3_decay contained_before_O | 0.11 | 0.11 | PASS |  |
| evidence revised_k3_decay compromised | 49.0 | 49.0 | PASS |  |
| evidence revised_k3_decay requests | 62.5 | 62.5 | PASS |  |
| evidence alt_k3_nodecay contained_before_O | 0.23 | 0.23 | PASS |  |
| evidence alt_k3_nodecay compromised | 40.2 | 40.2 | PASS |  |
| evidence alt_k3_nodecay requests | 45.5 | 45.5 | PASS |  |
| evidence time_decay_k3 contained_before_O | 0.11 | 0.11 | PASS |  |
| evidence time_decay_k3 compromised | 49.0 | 49.0 | PASS |  |
| evidence time_decay_k3 requests | 62.5 | 62.5 | PASS |  |
| evidence criticality_aware contained_before_O | 0.11 | 0.11 | PASS |  |
| evidence criticality_aware compromised | 48.1 | 48.1 | PASS |  |
| evidence criticality_aware requests | 62.5 | 62.5 | PASS |  |
| first response r=1 | 78 | 78 | PASS |  |
| first response r=1000 | 0.08 | 0.08 | PASS |  |
| low-intensity time decay contained | 0.00 | 0.00 | PASS |  |
| full moderate original | 58 | 58 | PASS |  |
| full moderate revised | 35 | 35 | PASS |  |
| full stealthy original | 25 | 25 | PASS |  |
| full stealthy revised | 21 | 21 | PASS |  |
| paired original vs revised | -23.8 | -23.8 | PASS |  |
| paired crit vs revised | -0.84 | -0.84 | PASS |  |
| legit original | 0.9995 | 0.9995 | PASS |  |
| legit alt | 0.89 | 0.89 | PASS |  |
| legit original min | 15 | 15 | PASS |  |
| legit original max | 100 | 100 | PASS |  |
| PoC artifact c1 p50 | 2.3 | 2.3 | PASS |  |
| PoC artifact c1 p99 | 11.6 | 11.6 | PASS |  |
| PoC artifact c16 p50 | 27.6 | 27.6 | PASS |  |
| PoC artifact c16 p99 | 58 | 58 | PASS |  |
| PoC artifact sat | 560 | 560 | PASS |  |
| PoC plain sat | 930 | 930 | PASS |  |
| strict c2 | 18 | 18 | PASS |  |
| strict c16 | 77 | 77 | PASS |  |
| v2 shared min | 51 | 51 | PASS |  |
| v2 shared max | 94 | 94 | PASS |  |
| G forwards | 37 | 37 | PASS |  |
| G max late | 0.47 | 0.47 | PASS |  |
| E last allow | 0.51 | 0.51 | PASS |  |
| E idp | 4.6 | 4.6 | PASS |  |
| Cload after | 629 | 629 | PASS |  |
| Cload allowed | 0 | 0 | PASS |  |
| H recovery ms | 17 | 17 | PASS |  |
| ML-DSA-65 sign median ms | 9.3 | 9.3 | PASS |  |
| CI lo | 9.2 | 9.2 | PASS |  |
| CI hi | 9.5 | 9.5 | PASS |  |
| mean ms | 10.4 | 10.4 | PASS |  |
| p99 ms | 16.3 | 16.3 | PASS |  |
| queue poisson | 39 | 39 | PASS |  |
| queue clustered | 56 | 56 | PASS |  |
| queue mmpp s | 1.6 | 1.6 | PASS |  |
| B=1 at 100/s empirical unstable | 1 | 1 | PASS |  |
| formal total checks | 28 | 28 | PASS |  |
| formal all match | 1 | 1 | PASS |  |
