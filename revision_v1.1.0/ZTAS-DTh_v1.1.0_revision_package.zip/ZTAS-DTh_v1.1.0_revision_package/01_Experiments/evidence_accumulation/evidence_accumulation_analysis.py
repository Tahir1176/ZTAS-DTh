"""Analysis of the wall-clock evidence-accumulation experiment (concern 3).
Uncertainty: cluster bootstrap over graph instances (runs nested in graphs)."""
import os
import numpy as np
import pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, "..", "..")
RAW = os.path.join(ROOT, "02_Data", "raw"); PROC = os.path.join(ROOT, "02_Data", "processed")
FIG = os.path.join(HERE, "evidence_accumulation_figures"); os.makedirs(FIG, exist_ok=True)
rng = np.random.default_rng(3)
POL = ["original_k2", "revised_k3_decay", "alt_k3_nodecay", "time_decay_k3", "criticality_aware"]


def cboot(d, col, B=1000, stat=np.nanmean):
    gs = d.graph.unique(); by = {g: d[d.graph == g][col].to_numpy(float) for g in gs}
    est = stat(d[col].to_numpy(float)); bs = []
    for _ in range(B):
        x = np.concatenate([by[g] for g in rng.choice(gs, len(gs))]); bs.append(stat(x))
    return est, *np.nanpercentile(bs, [2.5, 97.5])


def main():
    d = pd.read_csv(os.path.join(RAW, "evidence_accumulation_raw.csv.gz"))
    L = pd.read_csv(os.path.join(PROC, "evidence_accumulation_legitimate.csv"))
    rows = []
    for (cfg, prof, rate, pol), x in d.groupby(["cfg", "profile", "rate", "policy"]):
        r = dict(cfg=cfg, profile=prof, rate=rate, policy=pol, n_runs=len(x), censored=int(x.censored.sum()))
        for col, st in [("contained", np.nanmean), ("contained_before_O", np.nanmean), ("reached_O", np.nanmean),
                        ("n_compromised", np.nanmean)]:
            e, lo, hi = cboot(x, col, stat=st); r[col], r[col + "_lo"], r[col + "_hi"] = e, lo, hi
        r["t_first_response_median_s"] = x.t_first_response.median()
        r["t_containment_median_s"] = x.t_containment.median()
        r["t_containment_p90_s"] = x.t_containment.quantile(0.9)
        r["requests_before_containment_median"] = x.requests_before_containment.median()
        r["t_reach_O_median_s"] = x.t_reach_O.median()
        rows.append(r)
    S = pd.DataFrame(rows); S.to_csv(os.path.join(PROC, "evidence_accumulation_processed.csv"), index=False)
    # paired policy comparison vs revised (same seeds within run -> paired)
    pw = d[d.cfg == "risk_only"].pivot_table(index=["profile", "rate", "graph", "run"], columns="policy", values="n_compromised").reset_index()
    comp = []
    for (prof, rate), x in pw.groupby(["profile", "rate"]):
        for p in POL:
            if p == "revised_k3_decay": continue
            x2 = x.assign(diff=x[p] - x["revised_k3_decay"])
            e, lo, hi = cboot(x2, "diff"); comp.append(dict(profile=prof, rate=rate, policy=p, vs="revised_k3_decay",
                                                           mean_diff_n_compromised=e, lo=lo, hi=hi))
    pd.DataFrame(comp).to_csv(os.path.join(HERE, "evidence_policy_paired_comparison.csv"), index=False)
    # figures
    fig, ax = plt.subplots(1, 3, figsize=(7.2, 2.5))
    sub = S[(S.cfg == "risk_only") & (S.profile == "moderate")]
    for p, c in zip(POL, ["#c8553d", "#2a6f97", "#8d99ae", "#e0a458", "#4c956c"]):
        s = sub[sub.policy == p].sort_values("rate")
        ax[0].plot(s.rate, s.t_first_response_median_s, "o-", ms=3, color=c, label=p)
        ax[1].plot(s.rate, s.n_compromised, "o-", ms=3, color=c)
    ax[0].set_xscale("log"); ax[0].set_yscale("log"); ax[0].set_xlabel("base request rate (req/s)"); ax[0].set_ylabel("median time to first response (s)")
    ax[0].legend(frameon=False, fontsize=5); ax[0].set_title("(a) moderate attacker")
    ax[1].set_xscale("log"); ax[1].set_xlabel("base request rate (req/s)"); ax[1].set_ylabel("mean compromised (of 56)")
    ax[1].set_title("(b) moderate attacker")
    s10 = S[(S.cfg == "risk_only") & (S.rate == 10)]
    profs = list(dict.fromkeys(s10.profile)); x = np.arange(len(profs))
    for k, (p, c) in enumerate(zip(POL, ["#c8553d", "#2a6f97", "#8d99ae", "#e0a458", "#4c956c"])):
        s = s10[s10.policy == p].set_index("profile").loc[profs]
        ax[2].bar(x + (k - 2) * 0.16, s.contained_before_O, 0.16, color=c)
    ax[2].set_xticks(x); ax[2].set_xticklabels(profs, rotation=35, ha="right", fontsize=6)
    ax[2].set_ylabel("P(contained before ops. phase)"); ax[2].set_title("(c) r = 10 req/s")
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig_evidence_time.pdf")); fig.savefig(os.path.join(FIG, "fig_evidence_time.png"))
    pd.set_option("display.width", 250)
    print(S[S.cfg == "risk_only"][["profile", "rate", "policy", "contained", "contained_before_O", "reached_O", "n_compromised",
                                   "t_first_response_median_s", "t_containment_median_s", "requests_before_containment_median"]].round(3).to_string())
    print(S[S.cfg == "full"][["profile", "policy", "contained", "contained_before_O", "n_compromised", "t_first_response_median_s"]].round(3).to_string())
    print(L.pivot_table(index=["scenario", "cls", "rate"], columns="policy", values="false_isolation_per_shift").round(4).to_string())
    print(L[L.policy == "criticality_aware"][["scenario", "cls", "rate", "false_restriction_per_shift", "false_isolation_per_shift"]].round(4).to_string())


if __name__ == "__main__":
    main()
