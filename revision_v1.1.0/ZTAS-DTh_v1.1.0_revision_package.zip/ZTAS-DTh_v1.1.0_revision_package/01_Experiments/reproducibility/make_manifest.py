"""Reproducibility manifest for the v3 revision package: file, purpose, experiment, version, configuration,
seed, dependency, SHA-256. Run from the package root: python3 01_Experiments/reproducibility/make_manifest.py"""
import os, hashlib, csv, sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
RULES = [  # (path prefix, purpose, experiment, configuration, seed)
    ("01_Experiments/joint_sensitivity", "joint sensitivity (C1)", "E1-joint", "joint_sensitivity_config.yaml", "20261119; graph 10000*ti+g+500"),
    ("02_Data/raw/joint_sensitivity", "raw data, joint sensitivity", "E1-joint", "joint_sensitivity_config.yaml", "20261119"),
    ("01_Experiments/risk_engine", "risk-engine extended evaluation (C2)", "E2-ext", "script constants", "20261119"),
    ("02_Data/processed/risk_engine", "processed risk-engine results", "E2-ext", "script constants", "20261119"),
    ("01_Experiments/evidence_accumulation", "wall-clock evidence study (C3)", "E2-time", "script constants", "7000003*g+1009*r+17; legit 31337+i"),
    ("02_Data/raw/evidence_accumulation", "raw evidence study", "E2-time", "script constants", "as above"),
    ("02_Data/processed/evidence_accumulation", "processed evidence study", "E2-time", "script constants", "as above"),
    ("01_Experiments/formal_analysis", "formal analysis report and boundary diagram (C4)", "formal", "-", "-"),
    ("src/formal", "model checkers and logs", "formal", "DELTA=2, TMAX=6", "deterministic"),
    ("01_Experiments/poc_failure_testing", "PoC tests (C5)", "E4-tests", "ZTAS_* env flags in raw JSON", "-"),
    ("src/poc", "proof-of-concept services", "E4", "ZTAS_* env flags", "-"),
    ("01_Experiments/crypto", "crypto re-analysis (C6)", "E3", "-", "20261119"),
    ("02_Data/processed/crypto", "processed crypto/queue results", "E3", "-", "20261119"),
    ("02_Data/raw/e3_", "raw v2 crypto samples", "E3", "bench_crypto_v2.py", "-"),
    ("01_Experiments/statistics", "statistical re-analysis (C8)", "E1-stats", "-", "20261119"),
    ("02_Data/processed/statistics", "processed statistics", "E1-stats", "-", "20261119"),
    ("02_Data/raw/v2", "v2 E1 raw data (copied unchanged)", "E1", "run_e1.py", "graph 10000*ti+g; run 1000003*gs+r"),
    ("01_Experiments/adversary", "adversary model (C9)", "E1-profiles", "PROFILES in script", "graph 10000*ti+g+700"),
    ("02_Data/raw/adversary", "raw attacker-profile data", "E1-profiles", "-", "as above"),
    ("01_Experiments/novelty", "novelty and positioning (C7)", "-", "-", "-"),
    ("01_Experiments/reproducibility", "reproducibility verification (C10)", "repro", "-", "-"),
    ("src/", "v2 simulator and analysis code (v3: multi-entry extension in dth_sim.py)", "E1/E2/E3", "-", "-"),
    ("06_Manuscript/v3", "revised manuscript source", "-", "-", "-"),
    ("06_Manuscript/v2_baseline", "previous manuscript (unchanged)", "-", "-", "-"),
    ("07_Response", "response to reviewer", "-", "-", "-"),
    ("00_Audit", "tracker, execution log, changelog", "-", "-", "-"),
    ("08_Final_Reports", "final reports", "-", "-", "-"),
]
DEP = "python 3.13.18; numpy 2.5.3; scipy 1.18.1; pandas 3.0.5; scikit-learn 1.9.1; SALib; networkx 3.7; pyyaml; matplotlib; cryptography 50.0.1; pqcrypto 1.0.0"
rows = []
for dp, dn, fn in os.walk(ROOT):
    dn[:] = [d for d in dn if not d.endswith(".parts") and d != "__pycache__"]
    for f in sorted(fn):
        p = os.path.join(dp, f); rel = os.path.relpath(p, ROOT)
        if rel.endswith((".aux", ".log", ".out", ".blg")) and "logs" not in rel: continue
        h = hashlib.sha256(open(p, "rb").read()).hexdigest()
        purpose, exp, cfg, seed = "other", "-", "-", "-"
        for pre, pu, ex, cf, sd in RULES:
            if rel.startswith(pre): purpose, exp, cfg, seed = pu, ex, cf, sd; break
        rows.append(dict(file=rel, purpose=purpose, experiment=exp, version="v3 (2026-11-19)", configuration=cfg, seed=seed,
                         dependency=DEP if rel.endswith((".py", ".ipynb", ".sh")) else "-", bytes=os.path.getsize(p), sha256=h))
out = os.path.join(ROOT, "02_Data", "manifests", "reproducibility_manifest.csv")
with open(out, "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
print(len(rows), "files ->", out)
