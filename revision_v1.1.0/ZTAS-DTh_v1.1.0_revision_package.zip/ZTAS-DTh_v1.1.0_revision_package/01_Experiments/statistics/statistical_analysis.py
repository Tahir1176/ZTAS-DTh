"""
Statistical re-analysis of E1 (revision v3, concern 8). Inputs: v2 raw E1 data (e1_main.csv, e1_main_rec.csv),
copied unchanged to 02_Data/raw/v2/. Target = 'ztas_rec' (ZTAS-DTh with the recommended evidence rule; the
configuration behind the manuscript's headline numbers). Comparators: static ZT and static ZT + provenance.

Unit of inference = graph instance (30 per topology family); 50 Monte-Carlo runs per graph are averaged first,
so runs are never treated as independent graphs. Reported per topology x profile:
  graph-level paired mean difference with 95% hierarchical bootstrap CI (graphs, then runs within graphs);
  graph-level SD of the difference, min/max over graphs, share of graphs favouring ZTAS-DTh;
  standardised effect size d_z (graph level) AND absolute / relative reduction (practical scale);
  variance partition of the per-run difference: between-graph vs within-graph (ICC);
  share of graphs whose reduction is >= 0.05 (pre-declared practical-significance convention: ~3 of 56 entities).
"""
import os
import numpy as np
import pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, "..", "..")
RAW = os.path.join(ROOT, "02_Data", "raw", "v2"); OUT = os.path.join(ROOT, "02_Data", "processed")
rng = np.random.default_rng(20261119)
MET = ["frac", "reach_O", "contained"]


def hboot(X, B=2000):
    G, R = X.shape; gi = rng.integers(G, size=(B, G)); ri = rng.integers(R, size=(B, G, R))
    return np.percentile(np.nanmean(X[gi[:, :, None], ri].reshape(B, -1), axis=1), [2.5, 97.5])


def main():
    df = pd.concat([pd.read_csv(os.path.join(RAW, "e1_main.csv")), pd.read_csv(os.path.join(RAW, "e1_main_rec.csv"))])
    rows, graphs = [], []
    for (topo, prof), d in df.groupby(["topology", "profile"]):
        t = d[d.config == "ztas_rec"].set_index(["graph", "run"])
        for base in ["zt", "zt_prov"]:
            b = d[d.config == base].set_index(["graph", "run"])
            for m in MET:
                diff = (t[m] - b[m]).rename("d").reset_index()
                X = diff.pivot_table(index="graph", columns="run", values="d").to_numpy(float)
                gm = X.mean(axis=1); lo, hi = hboot(X)
                within = np.mean(X.var(axis=1, ddof=1)); between = gm.var(ddof=1)
                good = (gm < 0) if m != "contained" else (gm > 0)
                prac = (gm <= -0.05) if m != "contained" else (gm >= 0.05)
                rows.append(dict(topology=topo, profile=prof, baseline=base, metric=m, baseline_mean=b[m].mean(), ztas_mean=t[m].mean(),
                                 mean_diff=X.mean(), ci_lo=lo, ci_hi=hi, relative_change=X.mean() / b[m].mean() if b[m].mean() else np.nan,
                                 graph_sd=gm.std(ddof=1), graph_min=gm.min(), graph_max=gm.max(),
                                 d_z=gm.mean() / gm.std(ddof=1) if gm.std(ddof=1) > 0 else np.nan,
                                 share_graphs_favouring=good.mean(), share_graphs_practical=prac.mean(),
                                 icc_between=between / (between + within) if (between + within) > 0 else np.nan,
                                 ci_excludes_zero=bool(lo > 0 or hi < 0)))
                if m == "frac":
                    for g, v in enumerate(gm):
                        graphs.append(dict(topology=topo, profile=prof, baseline=base, graph=g, diff=v))
    R = pd.DataFrame(rows); R.to_csv(os.path.join(OUT, "statistics_paired_by_topology.csv"), index=False)
    Gd = pd.DataFrame(graphs); Gd.to_csv(os.path.join(OUT, "statistics_graph_level_differences.csv"), index=False)
    # figure: graph-level paired differences (stealthy), both comparators
    fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.7), sharey=True)
    topos = R[(R.metric == "frac") & (R.profile == "stealthy") & (R.baseline == "zt_prov")].sort_values("mean_diff").topology.tolist()
    for k, base in enumerate(["zt", "zt_prov"]):
        for i, tpl in enumerate(topos):
            v = Gd[(Gd.topology == tpl) & (Gd.profile == "stealthy") & (Gd.baseline == base)]["diff"]
            ax[k].scatter(v, np.full(len(v), i) + rng.uniform(-0.18, 0.18, len(v)), s=4, color="#8d99ae", alpha=0.8, lw=0)
            r = R[(R.topology == tpl) & (R.profile == "stealthy") & (R.baseline == base) & (R.metric == "frac")].iloc[0]
            ax[k].errorbar(r.mean_diff, i, xerr=[[r.mean_diff - r.ci_lo], [r.ci_hi - r.mean_diff]], fmt="o", ms=3.5, color="#c8553d", capsize=2)
        ax[k].axvline(0, color="k", lw=0.6); ax[k].axvline(-0.05, color="k", lw=0.5, ls=":")
        ax[k].set_xlabel(f"frac(ZTAS-DTh) - frac({'static ZT' if base == 'zt' else 'static ZT + prov.'})")
    ax[0].set_yticks(range(len(topos))); ax[0].set_yticklabels(topos, fontsize=7)
    ax[0].set_title("(a) vs static ZT, stealthy attacker", fontsize=8); ax[1].set_title("(b) vs static ZT + provenance", fontsize=8)
    fig.tight_layout(); fig.savefig(os.path.join(HERE, "fig_graph_level_differences.pdf")); fig.savefig(os.path.join(HERE, "fig_graph_level_differences.png"), dpi=200)
    pd.set_option("display.width", 250)
    print(R[R.metric == "frac"][["topology", "profile", "baseline", "baseline_mean", "ztas_mean", "mean_diff", "ci_lo", "ci_hi", "relative_change",
                                 "graph_sd", "graph_min", "graph_max", "d_z", "share_graphs_favouring", "share_graphs_practical", "icc_between"]].round(3).to_string())


if __name__ == "__main__":
    main()
