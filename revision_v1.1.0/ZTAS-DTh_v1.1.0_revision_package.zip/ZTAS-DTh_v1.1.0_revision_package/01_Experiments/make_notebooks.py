"""Creates executed analysis notebooks that re-run each v3 analysis script from the archived raw data."""
import nbformat as nbf, os
NB = {
 "joint_sensitivity/joint_sensitivity_analysis.ipynb": ("Joint sensitivity analysis (concern 1)", "joint_sensitivity_analysis.py", "",
   ["joint_sensitivity_results.csv", "joint_sensitivity_by_topology.csv", "joint_sensitivity_global_indices.csv"],
   ["joint_sensitivity_figures/fig_joint_sensitivity.png", "joint_sensitivity_figures/fig_joint_sensitivity_indices.png", "joint_sensitivity_figures/fig_joint_by_topology.png"]),
 "risk_engine/risk_engine_analysis.ipynb": ("Risk-engine extended evaluation (concern 2; synthetic distributions only)", "risk_engine_extended_experiment.py", "../../02_Data/raw ../../02_Data/processed/risk_engine",
   ["../../02_Data/processed/risk_engine/risk_engine_processed.csv", "../../02_Data/processed/risk_engine/risk_engine_calibration.csv", "../../02_Data/processed/risk_engine/risk_engine_thresholds.csv"], []),
 "evidence_accumulation/evidence_accumulation_analysis.ipynb": ("Evidence accumulation in wall-clock time (concern 3)", "evidence_accumulation_analysis.py", "",
   ["../../02_Data/processed/evidence_accumulation_processed.csv", "evidence_policy_paired_comparison.csv"], ["evidence_accumulation_figures/fig_evidence_time.png"]),
 "crypto/cryptographic_benchmark_analysis.ipynb": ("Cryptographic benchmark and queueing re-analysis (concern 6)", "crypto_reanalysis.py", "../../02_Data/raw ../../02_Data/processed/crypto",
   ["../../02_Data/processed/crypto/crypto_summary_recomputed.csv", "../../02_Data/processed/crypto/queueing_reanalysis.csv"], []),
 "statistics/statistical_analysis.ipynb": ("Statistical re-analysis of E1 (concern 8)", "statistical_analysis.py", "",
   ["../../02_Data/processed/statistics_paired_by_topology.csv"], ["fig_graph_level_differences.png"]),
}
for path, (title, script, args, csvs, figs) in NB.items():
    nb = nbf.v4.new_notebook(); c = nb.cells
    c.append(nbf.v4.new_markdown_cell(f"# {title}\nRe-runs `{script}` on the archived data and displays its outputs. Evidence type: simulation/benchmark under stated assumptions; not industrial measurement."))
    c.append(nbf.v4.new_code_cell(f"%run {script} {args}".strip()))
    c.append(nbf.v4.new_code_cell("import pandas as pd\npd.set_option('display.width', 200)\n" + "\n".join(f"display(pd.read_csv('{x}').head(25))" for x in csvs)))
    if figs:
        c.append(nbf.v4.new_code_cell("from IPython.display import Image\n" + "\n".join(f"display(Image('{f}'))" for f in figs)))
    nbf.write(nb, path)
print("written", len(NB))
