"""
Analysis of the joint sensitivity experiment (revision v3, concern 1).
Inputs : 02_Data/raw/joint_sensitivity_raw.csv.gz (+_points.csv), joint_sensitivity_sobol_raw.csv.gz (+_points.csv)
Outputs: 02_Data/processed/joint_sensitivity_processed.csv, 01_Experiments/joint_sensitivity/joint_sensitivity_results.csv,
         joint_sensitivity_*.csv tables and joint_sensitivity_figures/*.pdf|png
Uncertainty: two-way cluster bootstrap that resamples parameter points AND graph instances (within topology)
independently; Monte-Carlo runs inside a graph are never treated as independent graphs.
"""
import os, sys, json
import numpy as np
import pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.stats import rankdata
from sklearn.tree import DecisionTreeClassifier, export_text
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, "..", "..")
RAW = os.path.join(ROOT, "02_Data", "raw"); PROC = os.path.join(ROOT, "02_Data", "processed")
FIG = os.path.join(HERE, "joint_sensitivity_figures"); os.makedirs(FIG, exist_ok=True)
NAMES = ["p_exploit", "p_auth", "d_generic", "p_act", "f_art", "p_v", "mu_mal", "stepup_fail", "kappa", "decay", "approval_delay"]
ARCH = ["perimeter", "zones", "zt", "zt_prov", "ztas"]
MET = ["frac", "reach_O", "n_phases", "path_len", "detected", "t_detect", "contained", "residual"]
DESIGNS = ["optimistic", "moderate", "adverse", "continuous"]
rng = np.random.default_rng(7)
plt.rcParams.update({"font.size": 8, "figure.dpi": 150})


def two_way_boot(cell, value, B=1000):
    """cell: DataFrame with columns point, topology, graph and `value` (unit means already averaged over runs)."""
    pts = cell.point.unique(); X = cell.pivot_table(index="point", columns=["topology", "graph"], values=value)
    X = X.loc[pts].to_numpy(float); P, Gc = X.shape
    topo_of = np.array([c[0] for c in cell.pivot_table(index="point", columns=["topology", "graph"], values=value).columns])
    groups = [np.where(topo_of == t)[0] for t in np.unique(topo_of)]
    est = np.nanmean(X); bs = np.empty(B)
    for b in range(B):
        pi = rng.integers(P, size=P)
        gi = np.concatenate([g[rng.integers(len(g), size=len(g))] for g in groups])
        bs[b] = np.nanmean(X[np.ix_(pi, gi)])
    return est, *np.percentile(bs, [2.5, 97.5])


def prcc(X, y):
    R = np.column_stack([rankdata(c) for c in X.T]); ry = rankdata(y); out = []
    for j in range(R.shape[1]):
        Z = np.column_stack([np.ones(len(ry)), np.delete(R, j, axis=1)])
        ex = R[:, j] - Z @ np.linalg.lstsq(Z, R[:, j], rcond=None)[0]
        ey = ry - Z @ np.linalg.lstsq(Z, ry, rcond=None)[0]
        out.append(np.corrcoef(ex, ey)[0, 1])
    return np.array(out)


def main():
    raw = pd.read_csv(os.path.join(RAW, "joint_sensitivity_raw.csv.gz"))
    pts = pd.read_csv(os.path.join(RAW, "joint_sensitivity_raw_points.csv"))
    # unit = (topology, graph, run); per (point, topology, graph, config) mean over runs
    g = raw.groupby(["point", "design", "topology", "graph", "config"])[MET].mean().reset_index()
    cellmean = g.groupby(["point", "design", "topology", "config"])[MET].mean().reset_index()
    cellmean.to_csv(os.path.join(PROC, "joint_sensitivity_processed.csv"), index=False)
    wide = g.pivot_table(index=["point", "design", "topology", "graph"], columns="config", values="frac").reset_index()
    wide["d_prov"] = wide["ztas"] - wide["zt_prov"]; wide["d_zt"] = wide["ztas"] - wide["zt"]
    for m in ["reach_O", "contained", "detected", "residual", "path_len", "n_phases"]:
        w2 = g.pivot_table(index=["point", "design", "topology", "graph"], columns="config", values=m).reset_index()
        wide[f"d_prov_{m}"] = (w2["ztas"] - w2["zt_prov"]).to_numpy()
    res = []
    # ---- summary by design
    for d in DESIGNS:
        w = wide[wide.design == d]
        row = dict(design=d, n_points=w.point.nunique(), n_cells=len(w.groupby(["point", "topology"])))
        for c in ARCH:
            row[f"frac_{c}"] = w[c].mean()
        for v in ["d_prov", "d_zt", "d_prov_reach_O", "d_prov_contained", "d_prov_detected", "d_prov_residual", "d_prov_path_len", "d_prov_n_phases"]:
            e, lo, hi = two_way_boot(w, v); row[f"{v}_mean"], row[f"{v}_lo"], row[f"{v}_hi"] = e, lo, hi
        cm = w.groupby(["point", "topology"])[["d_prov"] + ARCH].mean()
        row["share_cells_ztas_lower_than_ztprov"] = float((cm.d_prov < 0).mean())
        row["share_cells_advantage_ge_0.05"] = float((cm.d_prov <= -0.05).mean())
        row["share_cells_ztas_worse_by_ge_0.01"] = float((cm.d_prov >= 0.01).mean())
        rk = cm[ARCH].rank(axis=1, method="min")
        row["share_cells_ztas_rank1"] = float((rk["ztas"] == 1).mean())
        row["share_cells_ranking_zt_prov_le_zt"] = float((cm["zt_prov"] <= cm["zt"]).mean())
        res.append(row)
    summ = pd.DataFrame(res); summ.to_csv(os.path.join(HERE, "joint_sensitivity_results.csv"), index=False)
    # ---- by topology x design
    tt = []
    for (d, t), w in wide.groupby(["design", "topology"]):
        e, lo, hi = two_way_boot(w, "d_prov", B=500)
        cm = w.groupby("point")[["d_prov"]].mean()
        tt.append(dict(design=d, topology=t, ztprov=w.zt_prov.mean(), ztas=w.ztas.mean(), d_prov=e, lo=lo, hi=hi,
                       share_points_advantage_ge_0_05=float((cm.d_prov <= -0.05).mean()),
                       share_points_ztas_worse=float((cm.d_prov > 0).mean())))
    tt = pd.DataFrame(tt); tt.to_csv(os.path.join(HERE, "joint_sensitivity_by_topology.csv"), index=False)
    # ---- graph-level variability (continuous design): per graph mean difference
    gl = wide[wide.design == "continuous"].groupby(["topology", "graph"]).d_prov.mean().reset_index()
    gl.to_csv(os.path.join(HERE, "joint_sensitivity_graph_level.csv"), index=False)
    # ---- PRCC on continuous LHS (point-level mean over all units of all topologies)
    cont = wide[wide.design == "continuous"].groupby("point")[["d_prov", "ztas", "zt_prov"]].mean().join(pts.set_index("point")[NAMES])
    pr = pd.DataFrame({"parameter": NAMES, "PRCC_d_prov": prcc(cont[NAMES].to_numpy(), cont.d_prov.to_numpy()),
                       "PRCC_frac_ztas": prcc(cont[NAMES].to_numpy(), cont.ztas.to_numpy()),
                       "PRCC_frac_ztprov": prcc(cont[NAMES].to_numpy(), cont.zt_prov.to_numpy())})
    # ---- Sobol on reference topology
    from SALib.analyze import sobol as sa
    sr = pd.read_csv(os.path.join(RAW, "joint_sensitivity_sobol_raw.csv.gz"))
    sp = pd.read_csv(os.path.join(RAW, "joint_sensitivity_sobol_raw_points.csv"))
    sw = sr.pivot_table(index=["point", "graph", "run"], columns="config", values="frac").reset_index()
    sw["d"] = sw.ztas - sw.zt_prov; Y = sw.groupby("point")[["d", "ztas", "zt_prov"]].mean().loc[sp.point]
    prob = {"num_vars": len(NAMES), "names": NAMES, "bounds": [[0, 1]] * len(NAMES)}
    sob = {}
    for col in ["d", "ztas", "zt_prov"]:
        S = sa.analyze(prob, Y[col].to_numpy(), calc_second_order=False, seed=11)
        sob[col] = S
        pr[f"S1_{col}"] = S["S1"]; pr[f"S1conf_{col}"] = S["S1_conf"]; pr[f"ST_{col}"] = S["ST"]; pr[f"STconf_{col}"] = S["ST_conf"]
    pr.to_csv(os.path.join(HERE, "joint_sensitivity_global_indices.csv"), index=False)
    # ---- where does the advantage vanish? interpretable tree on continuous LHS cells
    cells = wide[wide.design == "continuous"].groupby(["point", "topology"]).d_prov.mean().reset_index().merge(pts[["point"] + NAMES], on="point")
    y = (cells.d_prov > -0.05).astype(int)
    Xt = pd.get_dummies(cells[NAMES + ["topology"]], columns=["topology"])
    tree = DecisionTreeClassifier(max_depth=3, min_samples_leaf=40, random_state=0).fit(Xt, y)
    rules = export_text(tree, feature_names=list(Xt.columns), show_weights=True)
    open(os.path.join(HERE, "joint_sensitivity_vanishing_advantage_tree.txt"), "w").write(
        "Decision tree (depth 3): class 1 = advantage of ZTAS-DTh over ZT+prov smaller than 0.05 (point x topology cells, continuous LHS)\n"
        f"training accuracy {tree.score(Xt, y):.3f}; base rate of class 1 = {y.mean():.3f}\n\n" + rules)
    # ---- figures
    fig, ax = plt.subplots(1, 3, figsize=(7.2, 2.4))
    cols = {"optimistic": "#2a6f97", "moderate": "#8d99ae", "adverse": "#c8553d", "continuous": "#333333"}
    for d in DESIGNS:
        cm = wide[wide.design == d].groupby(["point", "topology"]).d_prov.mean()
        ax[0].hist(cm, bins=np.linspace(-0.9, 0.2, 45), histtype="step", color=cols[d], label=d, density=True)
    ax[0].axvline(0, color="k", lw=0.6); ax[0].set_xlabel("frac(ZTAS) - frac(ZT+prov)"); ax[0].set_ylabel("density"); ax[0].legend(frameon=False, fontsize=6)
    ax[0].set_title("(a) per point x topology", fontsize=7)
    c2 = wide[wide.design == "continuous"].groupby("point")[["d_prov"]].mean().join(pts.set_index("point")[NAMES])
    def heat(a, xv, yv, title):
        xb = pd.cut(c2[xv], 6); yb = pd.cut(c2[yv], 6)
        H = c2.groupby([yb, xb], observed=False).d_prov.mean().unstack()
        im = a.imshow(H.to_numpy(), origin="lower", aspect="auto", cmap="RdBu_r", vmin=-0.6, vmax=0.6,
                      extent=[c2[xv].min(), c2[xv].max(), c2[yv].min(), c2[yv].max()])
        a.set_xlabel(xv); a.set_ylabel(yv); a.set_title(title); return im
    heat(ax[1], "p_act", "mu_mal", "(b) continuous LHS")
    im = heat(ax[2], "p_v", "f_art", "(c) continuous LHS")
    fig.colorbar(im, ax=ax[2], fraction=0.05); fig.tight_layout()
    fig.savefig(os.path.join(FIG, "fig_joint_sensitivity.pdf")); fig.savefig(os.path.join(FIG, "fig_joint_sensitivity.png"))
    fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.4))
    o = pr.sort_values("ST_d")
    ax[0].barh(o.parameter, o.ST_d, xerr=o.STconf_d, color="#8d99ae", label="total ST"); ax[0].barh(o.parameter, o.S1_d, color="#2a6f97", height=0.4, label="first-order S1")
    ax[0].set_title("(a) Sobol indices of the paired difference\n(reference topology)"); ax[0].legend(frameon=False, fontsize=6)
    o = pr.reindex(pr.PRCC_d_prov.abs().sort_values().index)
    ax[1].barh(o.parameter, o.PRCC_d_prov, color=["#c8553d" if x > 0 else "#2a6f97" for x in o.PRCC_d_prov])
    ax[1].axvline(0, color="k", lw=0.6); ax[1].set_title("(b) PRCC with the paired difference\n(continuous LHS, 9 topologies)")
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig_joint_sensitivity_indices.pdf")); fig.savefig(os.path.join(FIG, "fig_joint_sensitivity_indices.png"))
    fig, ax = plt.subplots(figsize=(7.2, 2.5))
    topos = sorted(tt.topology.unique()); x = np.arange(len(topos))
    for k, d in enumerate(["optimistic", "moderate", "adverse"]):
        s = tt[tt.design == d].set_index("topology").loc[topos]
        ax.errorbar(x + (k - 1) * 0.22, s.d_prov, yerr=[s.d_prov - s.lo, s.hi - s.d_prov], fmt="o", ms=3, color=cols[d], label=d)
    ax.axhline(0, color="k", lw=0.6); ax.set_xticks(x); ax.set_xticklabels(topos, rotation=20, ha="right")
    ax.set_ylabel("frac(ZTAS) - frac(ZT+prov)"); ax.legend(frameon=False, fontsize=6, ncol=3); fig.tight_layout()
    fig.savefig(os.path.join(FIG, "fig_joint_by_topology.pdf")); fig.savefig(os.path.join(FIG, "fig_joint_by_topology.png"))
    pd.set_option("display.width", 250)
    print(summ.T.round(3).to_string()); print(pr.round(3).to_string()); print(tt.round(3).to_string()); print(rules)


if __name__ == "__main__":
    main()
