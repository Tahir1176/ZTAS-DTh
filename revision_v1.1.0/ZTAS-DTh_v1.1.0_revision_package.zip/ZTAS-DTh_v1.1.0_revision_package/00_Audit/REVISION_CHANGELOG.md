# REVISION_CHANGELOG.md — v2 → v3 (second major revision)

## Errors and weaknesses found in v2, and their correction
1. **PoC unsafe under concurrency.** The PEP shared one HTTP connection per backend across server threads. Responses were delivered to the wrong request, so a misattributed *allow* was possible. **Fix:** one client per thread. Found by test T-A/T-F.
2. **Strict replay ordering denies legitimate concurrent traffic** (18–77% at 2–16 clients). **Fix:** atomic anti-replay window W = 1024. P3 is restated: at most once; order is guaranteed only in strict mode.
3. **IdP, segmentation-controller and provenance outages were unhandled.** The handler raised an exception, so there was no response and nothing was logged. **Fix:** fail closed with a logged reason, plus a staleness bound on the cached CRL.
4. **TOCTOU between segment check and forwarding.** 37 requests were forwarded after a revocation was acknowledged. **Fix:** policy-version re-validation (model M4c).
5. **Quarantine lost on PDP restart.** **Fix:** persisted state.
6. **Missing risk dimension treated as zero risk (fail-open).** **Fix:** conservative imputation (50).
7. **Algorithm 1 said "degraded mode" while the code fails closed.** Text corrected.
8. **Portability claim based on the absence of AVX2 symbols in a stripped binary.** Corrected by disassembly analysis.
9. **Queue stability judged on median signing time.** It is decided by the mean. Corrected: per-record signing is unstable at ~100 records/s.
10. **Decay units inconsistent** across E1 (step), E2 (request) and the PoC (second). Now stated per artefact; the consequence (time-based decay is evadable) was evaluated.
11. **The "86 vs 22 requests" containment cost understated the security cost.** In wall-clock simulation, early containment falls from 0.43 to 0.11 and compromised entities roughly double.
12. **Original-rule false isolation underestimated in v2** (8% per shift at 480 requests per shift). At 0.1–10 req/s it is 15–100% per shift.

## New work
- **Joint sensitivity:** LHS over 11 parameters and 3 regimes; 612 000 paired simulations; Sobol indices (Saltelli, 3328 points); PRCC; vanishing-advantage tree.
- **Risk engine:** prevalence 0.1–20%, operator workload, calibration transfer (ECE, Brier), cost- and budget-constrained thresholds, operational measurement specification, calibration protocol (proposed).
- **Evidence accumulation in continuous time:** 7 attacker profiles × 4 rates × 5 policies, including a criticality-aware policy; legitimate false isolation at 0.1–10 req/s.
- **Formal model M4** (5 sub-models, 16 runs including negative controls), assurance-boundary diagram, property → evidence map.
- **PoC v3** with switchable fixes; tests T-A to T-I; sequence diagram.
- **Crypto:** build and disassembly audit, bootstrap CIs, mean and tails, discrete-event queue with bursty and clustered arrivals and empirical service times.
- **Statistics:** graph-level paired differences, practical-significance threshold, variance partition, figure of all 270 graph differences.
- **Adversary:** audit; 5 profiles including coordinated (multi-foothold simulator extension) and credentialed; 7-scenario mapping to ATT&CK for ICS.
- **Novelty:** contribution audit, critical comparison, two new 2026 references (verified), worked comparison across five architectures.
- **Reproducibility:** clean-checkout reproduction of v1.0.0, checklist, manifest with SHA-256.

## Manuscript changes by section

| Section | Change |
|---|---|
| Abstract | Rewritten: integrative contribution stated; joint robustness, vanishing regions, prevalence result, evidence trade-off, design rules and defects; ≤ 250 words |
| I Introduction | Closest 2026 works; "including the conditions under which it contributes little"; contributions rewritten (components explicitly not claimed) |
| II Related work | QZT-ICS and Humphrey 2026 added (also to Table I); positioning paragraph rewritten (coverage ≠ benefit) |
| III Threat model | Attacker profiles and scenario mapping; what the model omits |
| IV Architecture | Risk-engine calibration status, measurement definition, missing-data rule, decay units; Algorithm 1 (atomic window, re-validation, fail-closed); replay-window paragraph; lifecycle table moved to Supp. |
| V Formal | P3/P6/P7/P8 restated; M4 paragraph; Table V extended to 28 checks; failed negative control reported |
| VI Methodology | Practical-significance criterion; joint design; E2 extension; wall-clock evidence design; E3 library correction and queue alternatives; E4 test suite |
| VII Results | Graph-level figure and interpretation; new "Joint Parameter Robustness" (table + figure + attacker profiles); prevalence/workload/calibration/thresholds; new "Evidence Accumulation in Wall-Clock Time" (table + figure); crypto mean/tails and bursts; PoC concurrency and failure table. Several v2 tables and figures moved to Supp. S1 |
| VIII Discussion | Worked example covers zones and links to the simulation boundary; guaranteed / model-checked / tested / assumed / demonstrated / unvalidated; safety of responses; governance with two-person rule and revocation bound; gateways and HSMs; segment-operation effort; threats to validity; expanded limitations |
| IX Conclusion | Rewritten around the conditional result and the lessons learned |
| Data availability | States what v1.0.0 contains, that it was reproduced, and that v3 experiments are to be released under the concept DOI |
| References | +2 (verified 2026 works) |
| Supplementary Material | New (S1 moved material; S2 joint sensitivity; S3 adversary; S4 risk engine; S5 formal; S6 PoC; S7 crypto; S8 reproducibility) |
