# REVISION_EXECUTION_LOG.md — second major revision (v2 → v3)

Machine: 2 vCPU, 7 GB RAM, Linux, Python 3.13.18, numpy 2.5.3, scipy 1.18.1, pandas 3.0.5, SALib (pip), networkx 3.7.
All timestamps are taken from the system clock (PKT, UTC+5) when the entry was written.

| Date/time | Stage | Experiment / action | Script | Config / seed | Status | Outputs | Errors / notes |
|---|---|---|---|---|---|---|---|
| 2026-11-19 20:21 | 1 | Workspace created; v2 package copied to src/ and 06_Manuscript/v2_baseline (read-only reference); parameter audit | – | – | done | 01_Experiments/joint_sensitivity/parameter_audit.csv | v2 package at ../ZTAS_DTh_MAJOR_REVISION left untouched |
| 2026-11-19 20:22 | 2 | Joint sensitivity pilot (70 points x 36 units) and LazyScore equivalence check (max abs diff 7e-15; identical simulate() outputs) | joint_sensitivity_experiment.py --pilot | seed 20261119 | done | /tmp (discarded) | – |
| 2026-11-19 20:28 | 2 | Joint sensitivity LHS: 850 points x 144 units x 5 configs (612 000 sims) | joint_sensitivity_experiment.py lhs | joint_sensitivity_config.yaml; seed 20261119; graph seeds 10000*ti+g+500 | completed | 02_Data/raw/joint_sensitivity_raw.csv.gz (+points, meta) | none; checkpoint parts kept |
| 2026-11-19 20:28 | 2 | Sobol/Saltelli N=256 (3328 points x 16 units x 2 configs), reference topology | joint_sensitivity_experiment.py sobol | same | completed | 02_Data/raw/joint_sensitivity_sobol_raw.csv.gz | none |
| 2026-11-19 20:23 | 3 | Risk engine extended (prevalence 0.1-20%, calibration transfer, cost/budget thresholds) | risk_engine_extended_experiment.py | seed 20261119; N=1e5 per class | completed | 02_Data/processed/risk_engine/* | none |
| 2026-11-19 20:27 | 5 | M4 model checking, attempt 1 | model_check_v3.py | DELTA=2, TMAX=6 | completed; 1 negative control did NOT produce a counterexample (mis-specified) | logs/model_check_v3_attempt1.* | control replaced, see attempt 2 |
| 2026-11-19 20:27 | 5 | M4 model checking, attempt 2 (16 runs) + M1-M3 re-run (12 runs) | model_check_v3.py; model_check.py | same | completed; all 28 match expectation; M1-M3 identical to v2 log | logs/model_check_v3.*, model_check_rerun.* | – |
| 2026-11-19 20:30 | 6 | PoC tests A-E (v3 + v2-behaviour controls) | run_all_poc_tests.sh | env flags in each JSON | completed | 01_Experiments/poc_failure_testing/raw/*.json | v2 shared-client controls produced cross-thread HTTP exceptions (expected finding) |
| 2026-11-19 20:40 | 6 | PoC test F v2 control | poc_failure_tests.py F | ZTAS_REPLAY=strict ZTAS_THREADLOCAL=0 | HUNG > 8 min; terminated manually 20:45; result JSON written by hand stating HUNG | raw/F_v2control.json | runner script had set -e, so G/H were run separately (run_rest.sh) |
| 2026-11-19 20:40 | 6 | PoC tests G, H (v3 + controls) | run_rest.sh | flags in JSON | completed | raw/G_*.json, raw/H_*.json | – |
| 2026-11-19 20:44 | 4 | Evidence accumulation, continuous time (52 500 runs) + legitimate side | evidence_accumulation_experiment.py | seeds 7000003*g+1009*r+17; legit seeds 31337+i | completed; 0 censored | 02_Data/raw/evidence_accumulation_raw.csv.gz; 02_Data/processed/evidence_accumulation_legitimate.csv | pilot 1 revealed decay applied to auth/segment-denied requests (inconsistent with v2 semantics); fixed before full run, pilot discarded |
| 2026-11-19 20:45 | 6 | PoC test A with anti-replay window W=1024; F with W=1024 | poc_failure_tests.py | ZTAS_REPLAY_W=1024 | completed; 0 failures; 1 accept per round | raw/A_v3_window1024.json, raw/F_v3_window1024.json | W=64 had 22.8% denials at 16 clients |
| 2026-11-19 20:43 | 7 | Crypto statistics recomputed from raw v2 samples; queue DES 540 configs | crypto_reanalysis.py | seed 20261119 | completed | 02_Data/processed/crypto/* | – |
| 2026-11-19 20:52 | 6 | PoC test I (missing risk inputs) v3 and v2 control | poc_failure_tests.py I | ZTAS_MISSING | completed | raw/I_*.json | – |
| 2026-11-19 20:48 | 8 | Statistical re-analysis of v2 E1 data | statistical_analysis.py | seed 20261119 | completed | 02_Data/processed/statistics_*.csv | – |
| 2026-11-19 20:50 | 8 | Attacker profiles (5 profiles, 90 graphs x 20 runs) | adversary_profiles_experiment.py | graph seeds 10000*ti+g+700 | completed | 02_Data/raw/adversary_profiles_raw.csv.gz | simulator multi-entry change regression-tested (72 v2 rows identical) |
| 2026-11-19 20:50 | 9 | Clean-checkout reproduction of release v1.0.0 started | repro.sh (run_all.sh e1,e2,formal,e3,e4) | archived seeds | running | /home/claude/repro_v1 | – |
| 2026-11-19 21:22 | 9 | Clean-checkout reproduction finished; crypto benchmark re-run on idle VM; number check 143/143 | repro.sh; bench_crypto_v2.py; number_check.py | – | completed | 01_Experiments/reproducibility/*, 08_Final_Reports/NUMBER_CHECK.md | crypto timing not reproducible within 2.4x (reported) |
| 2026-11-19 21:22 | 10 | Manuscript v3 compiled (18 pp.), supplement (14 pp.), DOCX via pandoc, response filled with final page numbers | pdflatex/bibtex; make_supplement.py; make_docx.py | – | completed | 08_Final_Reports/* | – |
