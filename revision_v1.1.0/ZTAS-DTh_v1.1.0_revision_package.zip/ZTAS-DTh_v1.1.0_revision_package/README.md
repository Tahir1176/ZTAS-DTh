# ZTAS_DTh_Major_Revision_Research — second major revision package (v3, 19 Nov 2026)

Start here:
- `08_Final_Reports/ZTAS_DTh_Revised_Manuscript.pdf` (+ `.docx`, LaTeX source in `06_Manuscript/v3/`)
- `08_Final_Reports/ZTAS_DTh_Supplementary_Material.pdf`
- `07_Response_to_Reviewers/RESPONSE_TO_REVIEWER.md|docx|pdf`
- `08_Final_Reports/SUBMISSION_READINESS_REPORT.md` and `08_Final_Reports/NUMBER_CHECK.md` (143/143 manuscript numbers checked against the outputs)
- `00_Audit/`: `MAJOR_REVIEWER_ISSUE_TRACKER.md`, `REVISION_EXECUTION_LOG.md`, `REVISION_CHANGELOG.md`

## Map from reviewer concern to evidence

| Concern | Folder | Report | Raw / processed data |
|---|---|---|---|
| 1 Joint robustness | `01_Experiments/joint_sensitivity/` | `JOINT_SENSITIVITY_REPORT.md` | `02_Data/raw/joint_sensitivity_raw.csv.gz`, `..._sobol_raw.csv.gz`; `02_Data/processed/joint_sensitivity_processed.csv` |
| 2 Risk engine | `01_Experiments/risk_engine/` | `RISK_ENGINE_VALIDATION_REPORT.md` | `02_Data/raw/risk_engine_raw.csv.gz`; `02_Data/processed/risk_engine/` (incl. `risk_engine_confusion_matrices/`) |
| 3 Evidence accumulation | `01_Experiments/evidence_accumulation/` | `EVIDENCE_ACCUMULATION_REPORT.md` | `02_Data/raw/evidence_accumulation_raw.csv.gz`; `02_Data/processed/evidence_accumulation_*.csv` |
| 4 Formal | `01_Experiments/formal_analysis/`, `src/formal/` | `FORMAL_ANALYSIS_REPORT.md` | `src/formal/logs/` |
| 5 PoC | `01_Experiments/poc_failure_testing/`, `src/poc/ztas_poc_v3.py` | `POC_INTEGRATION_REPORT.md` | `01_Experiments/poc_failure_testing/raw/` |
| 6 Crypto | `01_Experiments/crypto/` | `CRYPTOGRAPHIC_BENCHMARK_REPORT.md` | `02_Data/raw/e3_*`; `02_Data/processed/crypto/` |
| 7 Novelty | `01_Experiments/novelty/` | `NOVELTY_AND_POSITIONING_REPORT.md` | – |
| 8 Statistics | `01_Experiments/statistics/` | `STATISTICAL_VALIDATION_REPORT.md` | `02_Data/raw/v2/`; `02_Data/processed/statistics_*.csv` |
| 9 Adversary | `01_Experiments/adversary/` | `ADVERSARY_MODEL_VALIDATION_REPORT.md` | `02_Data/raw/adversary_profiles_raw.csv.gz` |
| 10 Reproducibility | `01_Experiments/reproducibility/` | `REPRODUCIBILITY_VALIDATION_REPORT.md` | `02_Data/manifests/reproducibility_manifest.csv` |

## Reproducing

Requirements: Python 3.13 with numpy, scipy, pandas, scikit-learn, SALib, networkx, pyyaml, matplotlib, nbconvert, cryptography and pqcrypto. Exact versions are listed in `00_Audit/REVISION_EXECUTION_LOG.md`. Run every command from the package root, in this order.

```bash
# 1. Joint sensitivity (C1); about 10 min on 2 cores
cd 01_Experiments/joint_sensitivity && python3 joint_sensitivity_experiment.py lhs ../../02_Data/raw/joint_sensitivity_raw.csv.gz \
  && python3 joint_sensitivity_experiment.py sobol ../../02_Data/raw/joint_sensitivity_sobol_raw.csv.gz && python3 joint_sensitivity_analysis.py; cd -

# 2. Risk engine (C2)
cd 01_Experiments/risk_engine && python3 risk_engine_extended_experiment.py ../../02_Data/raw ../../02_Data/processed/risk_engine; cd -

# 3. Evidence accumulation (C3); about 30 min
cd 01_Experiments/evidence_accumulation && python3 evidence_accumulation_experiment.py ../../02_Data/raw/evidence_accumulation_raw.csv.gz \
  ../../02_Data/processed/evidence_accumulation_legitimate.csv && python3 evidence_accumulation_analysis.py; cd -

# 4. Formal models (C4)
cd src/formal && python3 model_check.py logs/model_check_results_rerun.json && python3 model_check_v3.py logs/model_check_v3_results.json; cd -

# 5. Proof-of-concept tests (C5); localhost only
sh 01_Experiments/poc_failure_testing/run_all_poc_tests.sh

# 6. Crypto re-analysis (C6), statistics (C8), attacker profiles (C9)
cd 01_Experiments/crypto && python3 crypto_reanalysis.py ../../02_Data/raw ../../02_Data/processed/crypto; cd -
cd 01_Experiments/statistics && python3 statistical_analysis.py; cd -
cd 01_Experiments/adversary && python3 adversary_profiles_experiment.py ../../02_Data/raw/adversary_profiles_raw.csv.gz; cd -

# 7. Number check and manifest
python3 08_Final_Reports/number_check.py
python3 01_Experiments/reproducibility/make_manifest.py
```

## Integrity notes
- The previous package (`../ZTAS_DTh_MAJOR_REVISION`) and the v2 manuscript (`06_Manuscript/v2_baseline/`) are unchanged.
- The `src/` folder is a copy of the v2 code. It has one backward-compatible change (multi-foothold entry in `dth_sim.py`, regression-tested) and the new files `formal/model_check_v3.py` and `poc/ztas_poc_v3.py`.
- Failures are kept and documented:
  - the hung v2-control test;
  - the mis-specified negative control;
  - the discarded evidence pilot;
  - crypto timing irreproducibility.
